/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.util.*;
import java.io.File;
import java.util.*;


/**
 * Abstract class that uses a static method to construct a HandleStorage instance.
 */
public abstract class HandleStorageFactory {
  public static final String STORAGE_TYPE = "storage_type";
  public static final String STORAGE_CLASS = "storage_class";
  public static final String CUSTOM_STORAGE_CONFIG = "storage_config";
  public static final String SQL_CONFIG = "sql_settings";

  /**
   * Create a HandleStorage instance using the server configuration from
   * the given StreamTable configuration that is based in the given
   * directory.
   */
  public static HandleStorage getStorage(File serverDir, StreamTable config, boolean isPrimary)
    throws Exception
  {
    HandleStorage storage = null;
    
    // open the handle database
    String storageType = config.getStr(STORAGE_TYPE,"").toUpperCase().trim();
    if(storageType.equals("SQL")) {
      StreamTable sqlConfig = (StreamTable)config.get(SQL_CONFIG);
      if(sqlConfig==null) {
        throw new HandleException(HandleException.INVALID_VALUE,
                                  "Missing "+SQL_CONFIG+" section in config file");
      }
      storage = new SQLHandleStorage();
      storage.init(sqlConfig);
      return storage;
    } else if(storageType.equalsIgnoreCase("BDBJE")) {
      StreamTable configCopy = (StreamTable)config.deepClone();
      configCopy.put("serverDir", serverDir.getAbsolutePath());
      storage = (HandleStorage)Class.
        forName("net.handle.server.bdbje.BDBJEHandleStorage").newInstance();
      //storage = new net.handle.server.bdbje.BDBJEHandleStorage(serverDir);
      storage.init(configCopy);
      return storage;
    } else if(storageType.equals("CUSTOM")) {
      // load a user-defined class to be used as storage
      String storageClassName = String.valueOf(config.get(STORAGE_CLASS)).trim();
      Class storageClass = Class.forName(storageClassName);
    
      StreamTable cfgTable = (StreamTable)config.get(CUSTOM_STORAGE_CONFIG);
      if(cfgTable==null) cfgTable = new StreamTable();
      
      Object obj = storageClass.newInstance();
      if(obj instanceof HandleStorage) {
        storage = (HandleStorage)obj;
        cfgTable.put("serverDir", serverDir.getAbsolutePath());
        storage.init(cfgTable);
        return storage;
      } else {
        throw new HandleException(HandleException.INVALID_VALUE,
                                  "Custom storage class "+storageClassName+
                                  " does not implement the HandleStorage interface");
      }
    } else {
      storage = new JDBHandleStorage(serverDir, isPrimary);
      storage.init(config);
      return storage;
    }
  }

}

