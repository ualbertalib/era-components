/**********************************************************************\
  © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Random;
import java.util.Vector;

import javax.crypto.interfaces.DHPrivateKey;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.spec.DHParameterSpec;

import net.handle.hdllib.AbstractMessage;
import net.handle.hdllib.AbstractRequest;
import net.handle.hdllib.AbstractResponse;
import net.handle.hdllib.AddValueRequest;
import net.handle.hdllib.AdminRecord;
import net.handle.hdllib.AuthenticationInfo;
import net.handle.hdllib.ChallengeAnswerRequest;
import net.handle.hdllib.ChallengeResponse;
import net.handle.hdllib.Common;
import net.handle.hdllib.CreateHandleRequest;
import net.handle.hdllib.DeleteHandleRequest;
import net.handle.hdllib.DumpHandlesCallback;
import net.handle.hdllib.DumpHandlesRequest;
import net.handle.hdllib.DumpHandlesResponse;
import net.handle.hdllib.Encoder;
import net.handle.hdllib.ErrorResponse;
import net.handle.hdllib.GenericRequest;
import net.handle.hdllib.GenericResponse;
import net.handle.hdllib.GetSiteInfoResponse;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.HandleResolver;
import net.handle.hdllib.HandleStorage;
import net.handle.hdllib.HandleValue;
import net.handle.hdllib.ListHandlesRequest;
import net.handle.hdllib.ListHandlesResponse;
import net.handle.hdllib.ModifyValueRequest;
import net.handle.hdllib.NextTxnIdResponse;
import net.handle.hdllib.PublicKeyAuthenticationInfo;
import net.handle.hdllib.RemoveValueRequest;
import net.handle.hdllib.ResolutionRequest;
import net.handle.hdllib.ResolutionResponse;
import net.handle.hdllib.ResponseMessageCallback;
import net.handle.hdllib.RetrieveTxnRequest;
import net.handle.hdllib.RetrieveTxnResponse;
import net.handle.hdllib.ScanCallback;
import net.handle.hdllib.SecretKeyAuthenticationInfo;
import net.handle.hdllib.ServerInfo;
import net.handle.hdllib.SessionExchangeKeyRequest;
import net.handle.hdllib.SessionInfo;
import net.handle.hdllib.SessionSetupRequest;
import net.handle.hdllib.SessionSetupResponse;
import net.handle.hdllib.SiteInfo;
import net.handle.hdllib.Transaction;
import net.handle.hdllib.TransactionCallback;
import net.handle.hdllib.TransactionQueueInterface;
import net.handle.hdllib.Util;
import net.handle.hdllib.ValueReference;
import net.handle.hdllib.VerifyAuthRequest;
import net.handle.hdllib.VerifyAuthResponse;
import net.handle.security.HdlSecurityProvider;
import net.handle.util.IntTable;
import net.handle.util.StreamTable;
import net.handle.util.StreamVector;
import net.handle.util.StringUtils;

public final class HandleServer extends AbstractServer {
	private static final byte MSG_INTERNAL_ERROR[] = Util.encodeString("Internal Error");
	private static final byte MSG_NOT_A_PRIMARY[] = Util.encodeString("Not a primary server");
	private static final byte MSG_SERVER_TEMPORARILY_DISABLED[] = Util.encodeString("Server temporarily disabled");
	private static final byte MSG_WRONG_SERVER_HASH[] = Util.encodeString("Request was hashed incorrectly");
	private static final byte MSG_NA_NOT_HOMED_HERE[] = Util.encodeString("That naming authority doesn't live here");
	private static final byte MSG_INDEXES_MUST_BE_POSITIVE[] = Util.encodeString("Value indexes must be non-negative");
	private static final byte MSG_EMPTY_VALUE_LIST[] = Util.encodeString("Value list was empty");
	private static final byte MSG_READ_ONLY_VALUE[] = Util.encodeString("Value is read-only");
	private static final byte MSG_NOT_A_NA_HANDLE[] = Util.encodeString("Handle is not a naming authority handle");
	private static final byte MSG_INVALID_ENCODING[] = Util.encodeString("Invalid UTF8 encoding");
	private static final byte MSG_INVALID_NA_HANDLE[] = Util.encodeString("Invalid naming authority handle");
	private static final byte MSG_SERVER_BACKUP[] = Util
		.encodeString("Server is doing backup now, only can resolve handles. Come back later");

	private static final byte MSG_NEED_RSA_EXCHANGEKEY[] = Util
		.encodeString("Invalid exchange key type. Need RSA public key.");
	private static final byte MSG_INVALID_SESSION_OR_TIMEOUT[] = Util
		.encodeString("Invalid session id or session time out. Please try again.");
	private static final byte MSG_NEED_LIST_HDLS_PERM[] = Util
		.encodeString("This server does not support the list handles operation.");
	private static final byte SERVER_STATUS_HANDLE[] = Util.encodeString("0.SITE/status");
	private static final byte SERVER_STATUS_HDL_TYPE[] = Util.encodeString("CNRI.SERVER_STATUS");
	private static final byte MSG_SESSION_REQUIRED[] = Util
		.encodeString("Sessions are required for administration on this server");

	public static final String CASE_SENSITIVE = "case_sensitive";
	public static final String ENABLE_STATUS_HDL = "enable_status_handle";
	public static final String SERVER_ADMIN_FULL_ACCESS = "server_admin_full_access";
	public static final String MAX_AUTH_TIME = "max_auth_time";
	public static final String THIS_SERVER_ID = "this_server_id";
	public static final String IS_PRIMARY = "is_primary";
	public static final String SERVER_ADMINS = "server_admins";
	public static final String BACKUP_ADMINS = "backup_admins";
	public static final String REPLICATION_ADMINS = "replication_admins";
	public static final String REPLICATION_INTERVAL = "replication_interval";
	public static final String DO_RECURSION = "allow_recursion";
	public static final String ALLOW_NA_ADMINS = "allow_na_admins";
	public static final String READ_ONLY_TXN_QUEUE = "read_only_txn_queue";
	public static final String ALLOW_LIST_HANDLES = "allow_list_hdls";
	public static final String PREFERRED_GLOBAL = "preferred_global";
	public static final String MAX_SESSION_TIME = "max_session_time";
	public static final String REQUIRE_SESSIONS = "require_sessions";
	public static final String ENCRYPTION_ALGORITHM = "encryption_alg";

	public static final String DB_TXN_QUEUE_DIR = "dbtxns";
	public static final String TXN_QUEUE_DIR = "txns";
	public static final String TXN_ID_FILE = "txn_id";
	public static final String STORAGE_FILE = "handles.jdb";
	public static final String NA_STORAGE_FILE = "nas.jdb";
	public static final String CACHE_STORAGE_FILE = "cache.jdb";
	public static final String STORAGE_FILE_BACKUP = "handles.jdb.backup";
	public static final String NA_STORAGE_FILE_BACKUP = "nas.jdb.backup";
	public static final String SITE_INFO_FILE = "siteinfo.bin";
	public static final String REPLICATION_FILE = "incoming.dct";
	public static final String LAST_TXN_ID = "last_txn_id";
	public static final String LAST_TIMESTAMP = "last_timestamp";
	public static final String REPLICATION_SOURCES = "sources";
	public static final String REPLICATION_AUTH = "replication_authentication";
	public static final String REPLICATION_SERVER_INFO_FILE = "txnsrcsv.bin";
	public static final String REPLICATION_STATUS_FILE = "txnstat.dct";
	public static final String REPLICATION_PRIV_KEY_FILE = "replpriv.bin";
	public static final String REPLICATION_SECRET_KEY_FILE = "replsec.bin";
	public static final String PRIVATE_KEY_FILE = "privkey.bin";
	public static final String REPLICATION_TIMEOUT = "replication_timeout";
	public static final String DO_REPLICATION = "do_replication";

	public static final int RECURSION_LIMIT = 10;
	public static final int LIST_HANDLES_PER_MSG = 50;

	public static final String DEFAULT_ENC_ALG = "DES"; // options: DES, AES, DESEDE

	private final String TRANSACTION_LOCK = "TRANSACTION_LOCK";
	private final String NEXT_TXN_ID_LOCK = "NEXT_TXN_ID_LOCK";

	private static final int NUM_DSA_AUTH_SIGNATURES = 20;
	private static final int NUM_SERVER_SIGNATURES = 50;

	private static final int DEL_HANDLE_PERM[] = { AdminRecord.DELETE_HANDLE };
	private static final int ADD_HANDLE_PERM[] = { AdminRecord.ADD_HANDLE };
	private static final int READ_VAL_PERM[] = { AdminRecord.READ_VALUE };
	private static final int ADD_ADM_PERM[] = { AdminRecord.ADD_ADMIN };
	private static final int ADD_VAL_PERM[] = { AdminRecord.ADD_VALUE };
	private static final int ADD_ADM_AND_VAL_PERM[] = { AdminRecord.ADD_ADMIN, AdminRecord.ADD_VALUE };
	private static final int REM_VAL_PERM[] = { AdminRecord.REMOVE_VALUE };
	private static final int REM_ADM_PERM[] = { AdminRecord.REMOVE_VALUE };
	private static final int REM_ADM_AND_VAL_PERM[] = { AdminRecord.REMOVE_ADMIN, AdminRecord.REMOVE_VALUE };
	private static final int MOD_ADM_PERM[] = { AdminRecord.MODIFY_ADMIN };
	private static final int MOD_VAL_PERM[] = { AdminRecord.MODIFY_VALUE };
	private static final int ADM_TO_VAL_PERM[] = { AdminRecord.REMOVE_ADMIN, AdminRecord.MODIFY_VALUE };
	private static final int VAL_TO_ADM_PERM[] = { AdminRecord.MODIFY_VALUE, AdminRecord.ADD_ADMIN };

	private static final int ADD_SUB_NA_PERM[] = { AdminRecord.ADD_NAMING_AUTH };
	private static final int LIST_HDLS_PERM[] = { AdminRecord.LIST_HANDLES };

	private static final byte SIGN_TEST[] = Util.encodeString("Testing...1..2..3");

	private final GenericRequest nextTxnIdRequest;

	private boolean keepRunning = true;
	private boolean serverEnabled = true;
	private static int nextAuthId = 0;
	private long maxAuthTime;
	private final HandleStorage storage;
	private final IntTable pendingAuthorizations;
	private boolean caseSensitive = false;
	private boolean serverAdminFullAccess = false;
	private ValueReference serverAdmins[] = {};
	private ValueReference backupAdmins[] = {};
	private ValueReference replicationAdmins[] = {};
	private boolean useRSA = false;
	private boolean requireSessions = false;

	private TransactionQueueInterface txnQueue;
	private int currentSigIndex = 0;
	private SiteInfo thisSite = null;
	private int thisServerNum = -1;

	private PrivateKey privateKey = null;
	private Signature serverSignatures[] = null;
	private boolean allowRecursiveQueries = true;
	private boolean allowNAAdmins = true;
	private boolean allowListHdls = true;
	private String preferredGlobal = null;
	private boolean isPrimary = false;
	private boolean doReplication = false;
	private long nextTxnId = -1;
	private File txnIdFile = null;
	private boolean nextTxnIdInitialized = false;
	private File replicationStatusFile = null;
	private File replicationSvrInfoFile = null;

	private AuthenticationInfo replicationAuth;
	private ReplicationDaemon replicationDaemon;
	private SiteInfo replicationSite = null;
	private long replicationLastTxnIds[];
	private long replicationLastTimeStamps[];
	private int replicationTimeout = 300000; // default timeout of 5 minutes
	private long startTime = 0;
	private long numRequests = 0;
	private boolean enableStatusHandle = true;
	private int encryptionAlgorithm;
	private Object lockHash[] = { new Object() };

	// time between replication refreshes default: 3 minutes
	private long replicationInterval = 3 * 60 * 1000;

	// a server side session manager to manage session
	private final SessionManager sessions = new SessionManager();
	private String writeLock = null;

	public HandleServer(Main main, StreamTable config) throws Exception {
		super(main, config);
		this.pendingAuthorizations = new IntTable();
		this.startTime = System.currentTimeMillis();
		this.enableStatusHandle = config.getBoolean(ENABLE_STATUS_HDL, true);

		writeLock = String.valueOf((new Random()).nextInt());
		requireSessions = config.getBoolean(REQUIRE_SESSIONS, false);
		String encAlg = config.getStr(ENCRYPTION_ALGORITHM, DEFAULT_ENC_ALG).toLowerCase().trim();
		if (encAlg.equals("des")) {
			encryptionAlgorithm = HdlSecurityProvider.ENCRYPT_ALG_DES;
		} else if (encAlg.equals("desede")) {
			encryptionAlgorithm = HdlSecurityProvider.ENCRYPT_ALG_DESEDE;
		} else if (encAlg.equals("aes")) {
			encryptionAlgorithm = HdlSecurityProvider.ENCRYPT_ALG_AES;
		} else {
			throw new Exception("Invalid encryption algorithm: '" + encAlg + "'; Please use either des, desede, or aes");
		}

		if (config.containsKey(DO_RECURSION))
			allowRecursiveQueries = config.getBoolean(DO_RECURSION);

		if (config.containsKey(SERVER_ADMIN_FULL_ACCESS))
			serverAdminFullAccess = config.getBoolean(SERVER_ADMIN_FULL_ACCESS);
		if (config.containsKey(ALLOW_LIST_HANDLES))
			allowListHdls = config.getBoolean(ALLOW_LIST_HANDLES);

		if (config.containsKey(ALLOW_NA_ADMINS))
			allowNAAdmins = config.getBoolean(ALLOW_NA_ADMINS);

		if (config.containsKey(PREFERRED_GLOBAL)) {
			preferredGlobal = config.getStr(PREFERRED_GLOBAL);
			Properties p = new Properties(System.getProperties());
			p.put("hdllib.preferredGlobal", preferredGlobal);
			System.setProperties(p);
		}

		if (config.containsKey(REPLICATION_TIMEOUT))
			replicationTimeout = Integer.parseInt(String.valueOf(config.get(REPLICATION_TIMEOUT)));
		else
			replicationTimeout = 5 * 60 * 1000; // default replication timeout is 5 mins

		// get the site info that describes this site that this server is
		// a part of
		try {
			// get the index of this server in the site info
			int thisId = Integer.parseInt((String) config.get(THIS_SERVER_ID));

			// get the site information from the site-info file
			SiteInfo site = new SiteInfo();
			File siteInfoFile = new File(main.getConfigDir(), SITE_INFO_FILE);
			if (!siteInfoFile.exists() || !siteInfoFile.canRead()) {
				System.err.println("Missing or inaccessible site info file: " + siteInfoFile.getAbsolutePath());
				throw new Exception("Missing or inaccessible site info file: " + siteInfoFile.getAbsolutePath());
			}
			byte siteInfoBuf[] = new byte[(int) siteInfoFile.length()];
			new FileInputStream(siteInfoFile).read(siteInfoBuf);

			Encoder.decodeSiteInfoRecord(siteInfoBuf, 0, site);

			thisServerNum = -1;
			for (int i = 0; i < site.servers.length; i++) {
				if (site.servers[i].serverId == thisId) {
					thisServerNum = i;
				}
			}

			if (thisServerNum < 0) {
				throw new Exception("Server ID " + thisId + " does not exist in site!");
			}
			thisSite = site;
		} catch (Exception e) {
			System.err.println("Invalid site/server specification: " + e);
			throw e;
		}

		// this secret key bytes will be used to encrypt/decrypt both server key
		// and session exchange key
		byte secKey[] = null;
		try {
			// read the private key from the private key file...
			File privateKeyFile = new File(main.getConfigDir(), PRIVATE_KEY_FILE);
			if (!privateKeyFile.exists() || !privateKeyFile.canRead()) {
				System.err.println("Missing or inaccessible private key file: " + privateKeyFile.getAbsolutePath());
				throw new Exception("Missing or inaccessible private key file: " + privateKeyFile.getAbsolutePath());
			}
			FileInputStream in = new FileInputStream(privateKeyFile);
			byte encKeyBytes[] = new byte[(int) privateKeyFile.length()];
			int n = 0;
			int r;
			while (n < encKeyBytes.length && (r = in.read(encKeyBytes, n, encKeyBytes.length - n)) >= 0) {
				n += r;
			}

			byte keyBytes[] = null;
			if (Util.requiresSecretKey(encKeyBytes)) {
				// ask for a secret key to decrypt the private key get the passphrase
				// and decrypt the server's private key, it will also be used for
				// encrpting/decrypt the RSA/DH session exchange keys
				//        secKey = Util.getPassphrase("Enter the passphrase for this server's authentication private key: ");
				// pc: skip passphrase prompt by getting from System properity
				secKey = System.getProperty("passphrase").getBytes();
			}

			keyBytes = Util.decrypt(encKeyBytes, secKey);

			try {
				privateKey = Util.getPrivateKeyFromBytes(keyBytes, 0);
			} catch (Exception e) {
				System.err.println("\n**********************************************" + "****************************"
					+ "\nError parsing private key, please make sure " + "the passphrase is correct.\n"
					+ "***************************" + "***********************************************\n");
				throw e;
			}

			//clear the private key bytes in memory
			for (int i = 0; i < keyBytes.length; i++)
				keyBytes[i] = (byte) 0;

			// create a bunch of the signature objects so that signing responses
			// doesn't become a bottleneck
			serverSignatures = new Signature[NUM_SERVER_SIGNATURES];
			for (int i = 0; i < serverSignatures.length; i++) {
				serverSignatures[i] = Signature.getInstance(Common.SIGNATURE_ALGORITHM);
				serverSignatures[i].initSign(privateKey);
			}

			// the signature has been initialized... now let's verify that it matches
			// the signature in the site information for this server.
			PublicKey pubKey = thisSite.servers[thisServerNum].getPublicKey();

			// generate a test signature, 
			serverSignatures[0].update(SIGN_TEST);
			byte testSig[] = serverSignatures[0].sign();

			// verify the test signature
			Signature verifier = Signature.getInstance(serverSignatures[0].getAlgorithm());
			verifier.initVerify(pubKey);

			verifier.update(SIGN_TEST);
			if (!verifier.verify(testSig)) {
				throw new Exception("Private key doesn't match public key from site info!");
			}

		} catch (Exception e) {
			System.err.println("Unable to initialize server signature object: " + e);
			e.printStackTrace(System.err);
			throw e;
		}

		SessionManager.initializeSessionKeyRandom();

		sessions.checkTimeoutSession();

		int maxSessionTimeout = Common.DEFAULT_SESSION_TIMEOUT;
		if (config.containsKey(MAX_SESSION_TIME)) {
			try {
				maxSessionTimeout = Integer.parseInt(String.valueOf(config.get(MAX_SESSION_TIME)).trim());
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
					"Invalid session timeout allowance.  Using default (24 hours)");
			}
		}
		if (maxSessionTimeout < 60) { //less than one minute, set it to 1 minute
			maxSessionTimeout = 60;
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Adjusted session timeout allowance. Using 1 minute.");
		}
		SessionInfo.setDefaultTimeout(maxSessionTimeout);

		// see if RSA is supported
		try {
			HdlSecurityProvider.getInstance().sign_RSA_MD5_PKCS1(null, 0, 0, null);
		} catch (NoSuchAlgorithmException e) {
			useRSA = false;
		} catch (Exception e) {
			useRSA = true;
		}

		// try to load the rsa key
		if (useRSA && !sessions.loadRSAKeys(secKey, main.getConfigDir())) {
			sessions.generateRSAKeys(secKey, main.getConfigDir());
		}

		// clear the secret key
		for (int i = 0; secKey != null && i < secKey.length; i++)
			secKey[i] = (byte) 0;

		isPrimary = thisSite.isPrimary;

		// Get the next transaction ID, and prepare the file for updating
		txnIdFile = new File(main.getConfigDir(), TXN_ID_FILE);
		FileReader fin = null;
		try {
			if (txnIdFile.exists()) {
				char ch[] = new char[512];
				fin = new FileReader(txnIdFile);
				int r, n = 0;
				while ((r = fin.read(ch, n, ch.length - n)) >= 0)
					n += r;
				nextTxnId = Long.parseLong(new String(ch, 0, n).trim());
				nextTxnIdInitialized = true;
			} else {
				nextTxnId = 1;
				nextTxnIdInitialized = false;
			}
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Invalid transaction ID! " + e);
			throw e;
		} finally {
			if (fin != null) {
				try {
					fin.close();
				} catch (Exception e) {
				}
			}
		}

		if (config.containsKey(SERVER_ADMINS)) {
			try {
				Vector adminVect = (Vector) config.get(SERVER_ADMINS);
				serverAdmins = new ValueReference[adminVect.size()];
				for (int i = 0; i < adminVect.size(); i++) {
					String adminStr = String.valueOf(adminVect.elementAt(i));
					int colIdx = adminStr.indexOf(':');
					if (colIdx <= 0)
						throw new Exception("Invalid server administrator ID: \"" + adminStr + "\"");
					serverAdmins[i] = new ValueReference(Util.encodeString(adminStr.substring(colIdx + 1)), Integer
						.parseInt(adminStr.substring(0, colIdx)));
				}
			} catch (Exception e) {
				throw new Exception("Error processing server administrator list: " + e);
			}
		}

		if (config.containsKey(BACKUP_ADMINS)) {
			try {
				Vector adminVect = (Vector) config.get(BACKUP_ADMINS);
				backupAdmins = new ValueReference[adminVect.size()];
				for (int i = 0; i < adminVect.size(); i++) {
					String adminStr = String.valueOf(adminVect.elementAt(i));
					int colIdx = adminStr.indexOf(':');
					if (colIdx <= 0)
						throw new Exception("Invalid server backup administrator ID: \"" + adminStr + "\"");
					backupAdmins[i] = new ValueReference(Util.encodeString(adminStr.substring(colIdx + 1)), Integer
						.parseInt(adminStr.substring(0, colIdx)));
				}
			} catch (Exception e) {
				throw new Exception("Error processing server backup administrator list: " + e);
			}
		}

		if (config.containsKey(REPLICATION_ADMINS)) {
			try {
				Vector adminVect = (Vector) config.get(REPLICATION_ADMINS);
				replicationAdmins = new ValueReference[adminVect.size()];
				for (int i = 0; i < adminVect.size(); i++) {
					String adminStr = String.valueOf(adminVect.elementAt(i));
					int colIdx = adminStr.indexOf(':');
					if (colIdx <= 0)
						throw new Exception("Invalid replication administrator ID: \"" + adminStr + "\"");
					replicationAdmins[i] = new ValueReference(Util.encodeString(adminStr.substring(colIdx + 1)),
						Integer.parseInt(adminStr.substring(0, colIdx)));
				}
			} catch (Exception e) {
				throw new Exception("Error processing replication administrator list: " + e);
			}
		} else {
			replicationAdmins = new ValueReference[0];
		}

		if (config.containsKey(REPLICATION_INTERVAL)) {
			String repIntStr = String.valueOf(config.get(REPLICATION_INTERVAL));
			try {
				replicationInterval = Long.parseLong(repIntStr);
			} catch (Exception e) {
				System.err.println("Error: invalid replication interval \"" + repIntStr + "\"; using default: "
					+ replicationInterval + " milliseconds");
			}
		}

		doReplication = !isPrimary && config.getBoolean(DO_REPLICATION, true);

		if (isPrimary) {
			// create the transaction queue.
			if (config.getBoolean(READ_ONLY_TXN_QUEUE, false)) {
				txnQueue = new ReadOnlyTransactionQueue(new File(main.getConfigDir(), TXN_QUEUE_DIR));
			} else {
				txnQueue = new TransactionQueue(new File(main.getConfigDir(), TXN_QUEUE_DIR));
			}
		} else if (doReplication) {
			if (config.containsKey(REPLICATION_AUTH)) {
				String replAuthSpec = config.getStr(REPLICATION_AUTH, "");
				String replFields[] = StringUtils.split(replAuthSpec, ':');
				if (replFields.length < 3)
					throw new HandleException(HandleException.INVALID_VALUE, "Invalid replication auth descriptor: "
						+ replAuthSpec);
				int replHdlIdx = Integer.parseInt(replFields[1]);
				if (replFields[0].equals("privatekey")) {
					// private key replication
					byte passphrase[] = null;

					File privKeyFile = new File(main.getConfigDir(), REPLICATION_PRIV_KEY_FILE);
					byte privKeyBytes[] = new byte[(int) privKeyFile.length()];
					FileInputStream in = new FileInputStream(privKeyFile);
					int r = 0;
					int n = 0;
					while (n < privKeyBytes.length && ((r = in.read(privKeyBytes, n, privKeyBytes.length - n)) >= 0))
						n += r;

					try {
						if (Util.requiresSecretKey(privKeyBytes)) {
							passphrase = Util
								.getPassphrase("Enter the passphrase for this servers replication private key: ");
						}
						privKeyBytes = Util.decrypt(privKeyBytes, passphrase);
					} catch (Exception e) {
						throw new HandleException(HandleException.INVALID_VALUE, "Error decrypting private key: " + e);
					} finally {
						if (passphrase != null)
							for (int i = 0; i < passphrase.length; i++)
								passphrase[i] = (byte) 0;
					}

					AuthenticationInfo info = null;
					replicationAuth = new PublicKeyAuthenticationInfo(Util.encodeString(replFields[2]), replHdlIdx,
						Util.getPrivateKeyFromBytes(privKeyBytes, 0));
				} else if (replAuthSpec.startsWith("secretkey:")) {
					File secKeyFile = new File(main.getConfigDir(), REPLICATION_SECRET_KEY_FILE);
					byte secKeyBytes[] = new byte[(int) secKeyFile.length()];
					FileInputStream in = new FileInputStream(secKeyFile);
					int r = 0;
					int n = 0;
					while (n < secKeyBytes.length && ((r = in.read(secKeyBytes, n, secKeyBytes.length - n)) >= 0))
						n += r;

					replicationAuth = new SecretKeyAuthenticationInfo(Util.encodeString(replFields[2]), replHdlIdx,
						secKeyBytes);
				} else {
					throw new HandleException(HandleException.INVALID_VALUE, "Unknown authentication type: "
						+ replFields[0]);
				}
			} else {
				throw new HandleException(HandleException.INVALID_VALUE,
					"Servers in non-primary sites need to specify " + "replication authentication information");
			}
			loadReplicationInfo();
		}

		caseSensitive = config.getBoolean(CASE_SENSITIVE);

		// load the database/storage system
		storage = HandleStorageFactory.getStorage(main.getConfigDir(), config, isPrimary);

		try {
			maxAuthTime = Long.parseLong(String.valueOf(config.get(MAX_AUTH_TIME)).trim());
		} catch (Exception e) {
			System.err.println("Invalid authentication time allowance.  " + "Using default (20 seconds)");
			maxAuthTime = 20000;
		}

		// add local site info to resolver configuration to avoid trips to global
		// when we are only talking to our peers
		final SiteInfo ss[] = { thisSite };
		storage.scanNAs(new ScanCallback() {
			public void scanHandle(byte handle[]) {
				resolver.getConfiguration().setLocalSites(Util.decodeString(handle), ss);
			}
		});

		// expand the lockHash so that more write operations can happen in parallel
		lockHash = new Object[256];
		for (int i = 0; i < lockHash.length; i++) {
			lockHash[i] = new Object();
		}

		ChallengeResponse.initializeRandom();

		nextTxnIdRequest = new GenericRequest(Common.SERVER_TXN_ID_HANDLE, AbstractMessage.OC_GET_NEXT_TXN_ID, null);
		nextTxnIdRequest.certify = true;

		// start thread to purge timed-out pendingAuthorizations.
		ChallengePurgeThread cpt = new ChallengePurgeThread();
		cpt.setDaemon(true);
		cpt.setPriority(Thread.MIN_PRIORITY);
		cpt.start();

		if (!isPrimary && doReplication) {
			replicationDaemon = new ReplicationDaemon();
			replicationDaemon.setDaemon(true);
			replicationDaemon.setPriority(Thread.MIN_PRIORITY);
			replicationDaemon.start();
		}
	}

	/** Return the siteinfo for this server. */
	public SiteInfo getSiteInfo() {
		return thisSite;
	}

	/** Return the server information for this server */
	public ServerInfo getServerInfo() {
		return thisSite.servers[thisServerNum];
	}

	/******************************************************************************
	 * Save the replication state to the file system.  This is called after every
	 * attempt at retrieving handle transactions from the source service.
	 ******************************************************************************/
	private void saveReplicationInfo() throws HandleException {
		try {
			// save in the status of the replication.
			StreamTable replicationConfig = new StreamTable();
			StreamVector sources = new StreamVector();
			replicationConfig.put(REPLICATION_SOURCES, sources);
			for (int i = 0; i < replicationLastTxnIds.length; i++) {
				StreamTable sourceTable = new StreamTable();
				sourceTable.put(LAST_TXN_ID, String.valueOf(replicationLastTxnIds[i]));
				sourceTable.put(LAST_TIMESTAMP, String.valueOf(replicationLastTimeStamps[i]));
				sources.addElement(sourceTable);
			}
			replicationConfig.writeToFile(replicationStatusFile);
		} catch (Exception e) {
			e.printStackTrace(System.err);
			if (e instanceof HandleException)
				throw (HandleException) e;
			throw new HandleException(HandleException.INTERNAL_ERROR, "Error saving replication state: " + e);
		}
	}

	/******************************************************************************
	 * Load the replication information (source servers, txn IDs, etc) from the
	 * file where it was saved.  This is called once when the server is started
	 * (before the handle storage is accessible).
	 ******************************************************************************/
	private void loadReplicationInfo() throws HandleException {
		// need to read the replication source information here....
		// this needs to be read from a file that it can be written back
		// to after it is updated dynamically.  The configuration should
		// include the servers public key information so that it can be
		// authenticated as the true source of the transaction handles.
		try {

			// read the primary (or replication source) site information from
			// the appropriate file.  I used a site info record because we
			// basically need all of the site info (public key, admin ports, etc)
			// and there's no sense in specifying a different config file layout
			// just for this
			replicationSvrInfoFile = new File(main.getConfigDir(), REPLICATION_SERVER_INFO_FILE);

			if (!replicationSvrInfoFile.exists()) {
				throw new HandleException(HandleException.CONFIGURATION_ERROR, "No replication site found ("
					+ replicationSvrInfoFile + ")");
			}

			byte siteBuf[] = new byte[(int) replicationSvrInfoFile.length()];
			FileInputStream fin = new FileInputStream(replicationSvrInfoFile);
			int r, n = 0;
			while (n < siteBuf.length && (r = fin.read(siteBuf, n, siteBuf.length - n)) >= 0) {
				n += r;
			}
			fin.close();
			replicationSite = new SiteInfo();
			Encoder.decodeSiteInfoRecord(siteBuf, 0, replicationSite);

			// Read in the status of the replication.  This should set
			// the default values for the replication status if the 
			// status file doesn't exist.
			replicationStatusFile = new File(main.getConfigDir(), REPLICATION_STATUS_FILE);
			if (!replicationStatusFile.exists()) {
				replicationLastTxnIds = new long[replicationSite.servers.length];
				replicationLastTimeStamps = new long[replicationLastTxnIds.length];
				for (int i = 0; i < replicationLastTxnIds.length; i++) {
					replicationLastTxnIds[i] = 0;
					replicationLastTimeStamps[i] = 0;
				}
			} else {
				StreamTable replicationConfig = new StreamTable();
				replicationConfig.readFromFile(replicationStatusFile);
				StreamVector sources = (StreamVector) replicationConfig.get(REPLICATION_SOURCES);
				replicationLastTxnIds = new long[sources.size()];
				replicationLastTimeStamps = new long[sources.size()];
				for (int i = 0; i < sources.size(); i++) {
					StreamTable sourceTable = (StreamTable) sources.elementAt(i);
					replicationLastTxnIds[i] = Long.parseLong(String.valueOf(sourceTable.get(LAST_TXN_ID)));
					replicationLastTimeStamps[i] = Long.parseLong(String.valueOf(sourceTable.get(LAST_TIMESTAMP)));
				}
			}

		} catch (Exception e) {
			System.err.println("Error reading replication configuration: " + e);
			e.printStackTrace(System.err);
			if (e instanceof HandleException)
				throw (HandleException) e;
			throw new HandleException(HandleException.INVALID_VALUE, "Cannot read replication configuration: " + e);
		}

	}

	/*****************************************************************************
	 * Thread that retrieves handle transactions from the primary servers or 
	 * some other source of transactions, according to the server configuration.
	 * This thread is not started on primary servers.
	 *****************************************************************************/
	private class ReplicationDaemon extends Thread {
		private final HandleResolver retrievalResolver = new HandleResolver();

		@Override
		public void run() {
			boolean redumpNeeded = false;
			retrievalResolver.setTcpTimeout(replicationTimeout);
			while (keepRunning) {
				if (!redumpNeeded) {
					try {
						// Talk to each one of the primary servers (or replication source
						// servers) and retrieve any transactions that we don't have.

						TxnCallback callback = new TxnCallback();
						for (int i = 0; i < replicationSite.servers.length; i++) {
							RetrieveTxnRequest req = new RetrieveTxnRequest(replicationLastTxnIds[i],
								replicationLastTimeStamps[i], thisSite.hashOption, thisSite.servers.length,
								thisServerNum, replicationAuth);
							req.encrypt = false;
							req.certify = true;

							try {
								AbstractResponse res = retrievalResolver.sendRequestToServer(req,
									replicationSite.servers[i]);

								if (res.responseCode == AbstractMessage.RC_SUCCESS) {
									callback.setServerNum(i);

									// decode the public key to authenticate the stream
									PublicKey pubKey = replicationSite.servers[i].getPublicKey();

									int status = ((RetrieveTxnResponse) res).processStreamedPart(callback, pubKey);

									if (status == RetrieveTxnResponse.NEED_TO_REDUMP) {
										redumpNeeded = true;
										break;
									} else if (status == RetrieveTxnResponse.SENDING_TRANSACTIONS) {
										saveReplicationInfo();
									} else {
										main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
											"Unknown status code from server during replication: " + status);
									}

								} else {
									main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
										"Unexpected response to replication request: " + res);
								}

								// this doesn't handle wrap-around serial numbers - maybe it should.
								// but the numbers can go so large it shouldn't matter.
								// The date/time/seconds could be used.
								if (res.siteInfoSerial > replicationSite.serialNumber) {
									main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
										"Updating replication info from version " + replicationSite.serialNumber
											+ " to version " + res.siteInfoSerial);
									updateReplicationConfiguration(replicationSite, i);
									break;
								}

							} catch (HandleException e) {
								main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error doing replication at server: "
									+ replicationSite.servers[i] + ": " + e);
								e.printStackTrace(System.err);
							}
						}
					} catch (Throwable t) {
						main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Error in replication daemon: " + t);
						t.printStackTrace(System.err);
					}
				}

				// do not rest until the dump is complete!
				while (redumpNeeded) {
					try {

						System.err.println("------------------------------\n" + "---- REDUMPING HANDLES!!! ----\n"
							+ "------------------------------");

						serverEnabled = false;

						// indicate that all servers need to be dumped - 
						// in case we get interrupted
						for (int i = 0; i < replicationLastTimeStamps.length; i++) {
							replicationLastTimeStamps[i] = 0;
							replicationLastTxnIds[i] = 0;
						}

						// delete *all* handles
						// it's ok to delete all handles, because *sites* are
						// replicated, not naming authorities.
						storage.deleteAllRecords();

						// send dump request to *all* primary servers,
						// this could/should be parallelized
						DumpHandlesRequest req = new DumpHandlesRequest(thisSite.hashOption, thisSite.servers.length,
							thisServerNum, replicationAuth);

						Exception error = null;
						// dump the entire handle database from each primary server
						for (int i = 0; i < replicationSite.servers.length; i++) {
							AbstractResponse response = retrievalResolver.sendRequestToServer(req,
								replicationSite.servers[i]);

							if (response.responseCode == AbstractMessage.RC_SUCCESS) {
								((DumpHandlesResponse) response).processStreamedPart(new DumpHdlCallback(i),
									replicationSite.servers[i].getPublicKey());
							}
						}

						// and then save new replication info.
						saveReplicationInfo();

						serverEnabled = true;
						redumpNeeded = false;
						System.err.println("------------------------------------\n"
							+ "---------- REDUMP FINISHED ---------\n" + "------------------------------------");
					} catch (Throwable e) {
						main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Error attempting to reload all handles: " + e);
					}
				}

				try {
					// sleep for one minute
					Thread.currentThread().sleep(replicationInterval);
				} catch (Throwable e) {
					main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error sleeping in replication thread: " + e);
				}
			}
		}
	}

	/****************************************************************************
	 * This method is used to bring our local replication site information into 
	 * sync with the actual site information.  The two can get out of sync when
	 * the replication source site changes configuration, or just increases the
	 * serial number associated with the site.  The information passed to this 
	 * method should be 1) the site information that supposedly has the old
	 * serial #, and 2) the index of the server that returned the out-of-date
	 * serial number message.
	 ****************************************************************************/
	private void updateReplicationConfiguration(SiteInfo oldSiteInfo, int serverNum) throws HandleException {
		if (!replicationSvrInfoFile.canWrite()) {
			main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
				"I don't have permission to save the updated replication site info!");
			throw new HandleException(HandleException.REPLICATION_ERROR,
				"Insufficient permissions to save the updated replication site info!");
		}
		if (!replicationStatusFile.canWrite()) {
			main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
				"I don't have permission to save the updated replication state!");
			throw new HandleException(HandleException.REPLICATION_ERROR,
				"Insufficient permissions to save the updated replication state!");
		}

		// the first thing we need to do is to get the new site information.
		// we should be able to do that by contacting the addresses of one of
		// the servers from the old configuration (starting with the server that
		// we just got a response from).  Failing that, we have to wait for 
		// manual intervention.

		if (oldSiteInfo == null) {
			main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Missing replication source site information");
			return;
		}

		GenericRequest req = new GenericRequest(Common.BLANK_HANDLE, AbstractMessage.OC_GET_SITE_INFO, replicationAuth);
		HandleException exception = null;
		SiteInfo newSiteInfo = null;
		try {
			AbstractResponse response = resolver.sendRequestToServer(req, oldSiteInfo.servers[serverNum]);
			if (response.responseCode == AbstractMessage.RC_SUCCESS) {
				newSiteInfo = ((GetSiteInfoResponse) response).siteInfo;
			}
		} catch (HandleException e) {
			main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to retrieve updated site info from server: "
				+ oldSiteInfo.servers[serverNum]);
		}

		for (int i = 0; newSiteInfo == null && i < oldSiteInfo.servers.length; i++) {
			try {
				AbstractResponse response = resolver.sendRequestToServer(req, oldSiteInfo.servers[i]);
				if (response.responseCode == AbstractMessage.RC_SUCCESS) {
					newSiteInfo = ((GetSiteInfoResponse) response).siteInfo;
				}
			} catch (HandleException e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to retrieve updated site info from server: "
					+ oldSiteInfo.servers[serverNum]);
			}
		}

		if (newSiteInfo == null) {
			throw new HandleException(HandleException.REPLICATION_ERROR, "Unable to update outdated site info!");
		}

		// save the updated site info to a file
		try {
			// make sure that we can never get stuck using the last siteinfo's
			// status with the new sites info.  This is done by clearing the
			// status file temporarily
			FileOutputStream out = new FileOutputStream(replicationStatusFile);
			out.close();

			// write the new information to the site info file
			out = new FileOutputStream(replicationSvrInfoFile);
			out.write(Encoder.encodeSiteInfoRecord(newSiteInfo));
			out.close();
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to save replication source site info: " + e);
			throw new HandleException(HandleException.REPLICATION_ERROR, "Unable to save updated site info: " + e);
		}

		// adjust our current replication state to account for the new 
		// source sites.
		long newLastTxnIds[] = new long[newSiteInfo.servers.length];
		long newLastTS[] = new long[newSiteInfo.servers.length];
		long minTxnId = -1;
		long minLastTS = 0;
		for (int i = 0; i < oldSiteInfo.servers.length; i++) {
			if (replicationLastTxnIds[i] < minTxnId || i == 0)
				minTxnId = replicationLastTxnIds[i];
			if (replicationLastTimeStamps[i] < minLastTS || i == 0)
				minLastTS = replicationLastTimeStamps[i];
		}
		for (int i = 0; i < newLastTxnIds.length; i++) {
			newLastTxnIds[i] = minTxnId;
			newLastTS[i] = minLastTS;
		}
		replicationSite = newSiteInfo;
		replicationLastTxnIds = newLastTxnIds;
		replicationLastTimeStamps = newLastTS;
		saveReplicationInfo();
	}

	/****************************************************************************
	 * Class used to process the results of DumpHandlesRequest messages.  
	 * Since that request type is streamable, this class is used as the
	 * target for the callback.
	 ****************************************************************************/
	private class DumpHdlCallback implements DumpHandlesCallback {
		private int currentServerNum = -1;

		private DumpHdlCallback(int serverNum) {
			this.currentServerNum = serverNum;
			System.err.println("Starting dump of source server #" + serverNum);
		}

		public synchronized void addHandle(byte handle[], HandleValue values[]) throws Exception {
			if (!caseSensitive)
				handle = Util.upperCase(handle);
			System.err.println("---> " + Util.decodeString(handle));
			try {
				storage.deleteHandle(handle);
			} catch (Exception e) {
				//System.err.println("Error deleting handle before re-add: "+e);
				//e.printStackTrace(System.err);
			}
			storage.createHandle(handle, values);
		}

		public synchronized void addNamingAuthority(byte authHandle[]) throws Exception {

			System.err.println("NA-> " + Util.decodeString(authHandle));
			storage.setHaveNA(authHandle, true);
		}

		public synchronized void finishProcessing(long date, long txnId) {
			System.err.println("----finalizing dump from server: " + currentServerNum + " date: "
				+ (new java.util.Date(date)) + "; last txnId: " + txnId);
			replicationLastTimeStamps[currentServerNum] = date;
			replicationLastTxnIds[currentServerNum] = txnId;
		}
	}

	/****************************************************************************
	 * Class used to process the results of RetrieveTxnRequest messages.  
	 * Since that request type is streamable, this class is used as the
	 * target for the callback.
	 ****************************************************************************/
	private class TxnCallback implements TransactionCallback {
		private int currentServerNum = -1;
		private final int txnCounter = 0;

		private void setServerNum(int newServerNum) {
			this.currentServerNum = newServerNum;
		}

		public void processTransaction(Transaction txn) throws HandleException {
			System.err.println("--Processing " + txn);
			switch (txn.action) {
			case Transaction.ACTION_CREATE_HANDLE:
			case Transaction.ACTION_UPDATE_HANDLE:
				try {
					storage.deleteHandle((caseSensitive ? txn.handle : Util.upperCase(txn.handle)));
				} catch (Exception e) {
					System.err.println("Error deleting handle before re-creating during replication: " + e);
					e.printStackTrace(System.err);
				}
				storage.createHandle((caseSensitive ? txn.handle : Util.upperCase(txn.handle)), txn.values);
				break;
			case Transaction.ACTION_DELETE_HANDLE:
				if (!storage.deleteHandle((caseSensitive ? txn.handle : Util.upperCase(txn.handle)))) {
					main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
						"Warning: got delete-handle transaction for non-existent handle: "
							+ Util.decodeString(txn.handle));
				}
				break;
			case Transaction.ACTION_HOME_NA:
				storage.setHaveNA(txn.handle, true);
				break;
			case Transaction.ACTION_UNHOME_NA:
				storage.setHaveNA(txn.handle, false);
				break;
			default:
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Encountered unknown transaction type (" + txn.action
					+ ") during replication for handle: " + Util.decodeString(txn.handle));
			}

			replicationLastTxnIds[currentServerNum] = txn.txnId;
		}

		public void finishProcessing(long date) {
			replicationLastTimeStamps[currentServerNum] = date;
		}
	}

	/****************************************************************************
	 * Thread that purges old challenges after a specified period of time
	 * ////Currently hard-coded to 30 seconds - this should be configurable!!!!
	 ****************************************************************************/
	private class ChallengePurgeThread extends Thread {
		@Override
		public void run() {
			while (keepRunning) {
				try {
					Thread.currentThread().sleep(30000);
					long now = System.currentTimeMillis();
					for (IntTable.IntTableEnumerator enumeration = pendingAuthorizations.keys(); enumeration
						.hasMoreElements();) {
						int key = enumeration.nextKey();
						ChallengeResponseInfo cri = (ChallengeResponseInfo) pendingAuthorizations.get(key);
						if (cri == null || cri.hasExpired()) {
							pendingAuthorizations.remove(key);
						}
					}

				} catch (Throwable e) {
					main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Error purging pending authentications: " + e);
				}
			}
		}
	}

	//check whether the session id indicate a pending challenge
	private boolean pendingChallenge(int sessionId) {
		if (sessionId < 0)
			return false;
		ChallengeResponseInfo crInfo = (ChallengeResponseInfo) pendingAuthorizations.get(sessionId);
		if (crInfo != null)
			return true;
		else
			return false;
	}

	private void sendResponse(ResponseMessageCallback callback, AbstractResponse response) throws HandleException {
		response.siteInfoSerial = thisSite.serialNumber;

		// If this is a certified request, sign the response.
		// We could be acting as a cache, so only sign the response
		//  if the cacheCertify flag is set, or if the response
		//  was handled locally (ie there is no other signature
		//  on it).
		if (response.certify && (response.cacheCertify || response.signature == null)) {

			boolean signed = false;

			//session mannered response signing: use session key, return MAC code
			//with the message
			if (response.sessionId > 0) {
				// try to use session key to certify first ...  in case of
				// OC_SESSION_EXCHANGEKEY and OC_SESSION_SETUP, the client need to wait
				// for the response to confirm the session key is established.  so
				// don't sign with the session key if the request is
				// OC_SESSION_EXCHANGEKEY or OC_SESSION_SETUP.
				ServerSideSessionInfo sssinfo = getSession(response.sessionId);

				if (sssinfo != null && sssinfo.lastRequestId > 0 && response.opCode != AbstractMessage.OC_SESSION_SETUP
					&& response.opCode != AbstractMessage.OC_SESSION_EXCHANGEKEY) {
					try {
						response.signMessage(sssinfo.getSessionKey());
						signed = true;
					} catch (Exception e) {
						main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Exception signing response: " + e);
						signed = false;
					}
				}
			}

			if (!signed) { //if session key signing fails
				// normal way of sending certified response through signature of server
				// private key
				try {
					// rotating through an array of signatures avoids a bottleneck
					// since we have to 'synchronize' on the signature while signing
					int sigIndex = currentSigIndex++;
					if (sigIndex >= serverSignatures.length)
						sigIndex = currentSigIndex = 0;

					Signature sig = serverSignatures[sigIndex];

					synchronized (sig) {
						response.signMessage(sig);
					}
				} catch (Exception e) {
					// If we get an error while signing the response, we return
					// the unsigned message anyway.  Maybe an error message would
					// be better?
					main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Exception signing response: " + e);
				}
			}
		}

		callback.handleResponse(response);
	}

	/**********************************************************************
	 * Given a request object, handle the request and return a response
	 **********************************************************************/
	@Override
	public void processRequest(AbstractRequest req, ResponseMessageCallback callback) throws HandleException {
		if (!serverEnabled) {
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_SERVER_TEMPORARILY_DISABLED));
			return;
		}

		// handle the request...
		processRequest(req, null, null, callback);
	}

	private void processRequest(AbstractRequest req, ChallengeResponse cRes, ChallengeAnswerRequest crReq,
		ResponseMessageCallback callback) throws HandleException {
		numRequests++;

		// if the session id doesn't indicate a challenge entry or a valid session entry
		// then it is a invlaid session
		if (req.sessionId > 0 && !pendingChallenge(req.sessionId) && !validSession(req)) {
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT,
				MSG_INVALID_SESSION_OR_TIMEOUT));
			return;
		}

		// please take note that all the req.authInfo is null in server side (this method)
		// even for administrative request.
		// this is because the decode message process can't re-produce the authInfo
		// on server side.
		// please see Encoder.java, all decodeMessage methods.

		// insert the request id into session information if the request has a valid session link
		validSession(req);

		// see if we need to be primary
		if (req.isAdminRequest && !isPrimary) {
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NOT_A_PRIMARY));
		}

		// now process the request
		switch (req.opCode) {
		case AbstractMessage.OC_GET_SITE_INFO:
			sendResponse(callback, new GetSiteInfoResponse(req, thisSite));
			break;
		case AbstractMessage.OC_RESOLUTION:
			// handle a resolution request
			sendResponse(callback, doResolution((ResolutionRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_LIST_HANDLES:
			doListHandles(callback, (ListHandlesRequest) req, cRes, crReq);
			break;
		case AbstractMessage.OC_SESSION_SETUP:
			sendResponse(callback, doSessionSetup((SessionSetupRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_SESSION_EXCHANGEKEY:
			sendResponse(callback, doKeyExchange((SessionExchangeKeyRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_SESSION_TERMINATE:
			sendResponse(callback, doSessionTerminate((GenericRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_RESPONSE_TO_CHALLENGE:
			// look up the challenge that matches this response in the
			// pendingAuthorizations table
			ChallengeResponseInfo crInfo = (ChallengeResponseInfo) pendingAuthorizations.get(req.sessionId);
			if (crInfo == null || crInfo.hasExpired()) {
				sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_AUTHEN_TIMEOUT, null));
			} else {
				processRequest(crInfo.originalRequest, crInfo.challenge, (ChallengeAnswerRequest) req, callback);
			}
			break;
		case AbstractMessage.OC_VERIFY_CHALLENGE:
			sendResponse(callback, verifyChallenge((VerifyAuthRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_DUMP_HANDLES:
			sendResponse(callback, doDumpHandles((DumpHandlesRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_ADD_VALUE:
			sendResponse(callback, doAddValue((AddValueRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_REMOVE_VALUE:
			sendResponse(callback, doRemoveValue((RemoveValueRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_MODIFY_VALUE:
			sendResponse(callback, doModifyValue((ModifyValueRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_CREATE_HANDLE:
			sendResponse(callback, doCreateHandle((CreateHandleRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_DELETE_HANDLE:
			sendResponse(callback, doDeleteHandle((DeleteHandleRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_GET_NEXT_TXN_ID:
			sendResponse(callback, getNextTxnId((GenericRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_RETRIEVE_TXN_LOG:
			sendResponse(callback, doRetrieveTxnLog((RetrieveTxnRequest) req, cRes, crReq));
			break;
		case AbstractMessage.OC_HOME_NA:
			sendResponse(callback, doHomeNA(req, cRes, crReq));
			break;
		case AbstractMessage.OC_UNHOME_NA:
			sendResponse(callback, doUnhomeNA(req, cRes, crReq));
			break;
		case AbstractMessage.OC_BACKUP_SERVER:
			sendResponse(callback, doBackup((GenericRequest) req, cRes, crReq));
			break;
		default:
			throw new HandleException(HandleException.INTERNAL_ERROR, "Unknown operation: " + req.opCode);
		}
	}

	class ChallengeResponseInfo {
		long timeStarted;
		int sessionId;
		ChallengeResponse challenge;
		AbstractRequest originalRequest;

		final boolean hasExpired() {
			return timeStarted < (System.currentTimeMillis() - maxAuthTime);
		}
	}

	/************************************************************************
	 * Return a message with the next consecutive transaction identifier. 
	 ************************************************************************/
	private final AbstractResponse getNextTxnId(GenericRequest req, ChallengeResponse cRes, ChallengeAnswerRequest crReq)
		throws HandleException {
		return new NextTxnIdResponse(req, getNextTxnId());
	}

	/** Get the next transaction ID  */
	private final long getNextTxnId() throws HandleException {
		long thisTxnId;
		synchronized (NEXT_TXN_ID_LOCK) {

			// if there is not yet any nextTxnId, get one from the authoritative server
			// in this service.  This is done because not all upgraded servers maintain
			// their own next-transaction-ID since IDs had to be unique across the entire
			// site and not just within 
			// transaction IDs be unique across the site - not just within a single
			// server.  
			if (!nextTxnIdInitialized && thisSite.servers.length > 1
				&& thisSite.determineServerNum(Common.SERVER_TXN_ID_HANDLE) != thisServerNum) {
				// if the txn ID lives on another server and we don't yet have one
				long tmpID = retrieveNextTxnId();
				nextTxnId = Math.max(nextTxnId + 1, tmpID);
			} else {
				nextTxnId++;
			}
			nextTxnIdInitialized = true;

			if (nextTxnId < 0)
				nextTxnId = 0;
			thisTxnId = nextTxnId;
			try {
				FileWriter fw = new FileWriter(txnIdFile);
				fw.write(String.valueOf(nextTxnId));
				fw.close();
			} catch (Exception e) {
				throw new HandleException(HandleException.INTERNAL_ERROR, "Unable to store new transaction ID");
			}
		}
		return thisTxnId;
	}

	/************************************************************************
	 * Tells the server that it will now be responsible for handles under
	 * the specified naming authority.
	 ************************************************************************/
	private final AbstractResponse doHomeNA(AbstractRequest req, ChallengeResponse cRes, ChallengeAnswerRequest crReq)
		throws HandleException {
		if (!Util.startsWithCI(req.handle, Common.NA_HANDLE_PREFIX)) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Was asked to home non-naming authority handle: '"
				+ Util.decodeString(req.handle) + "' ");
			return new ErrorResponse(req, AbstractRequest.RC_ERROR, MSG_NOT_A_NA_HANDLE);
		}

		//create challenge when there is no challenge answer info, or it is not a valid session
		if ((cRes == null || crReq == null) && !authenticatedSession(req))
			return createChallenge(req);

		boolean hasPermission = false;
		Vector valuesToTraverse = new Vector();
		ValueReference thisAdmin = null;

		if (crReq != null) {
			thisAdmin = new ValueReference(crReq.userIdHandle, crReq.userIdIndex);
		} else {
			//a valid session is assumed
			ServerSideSessionInfo sssinfo = getSession(req.sessionId);
			if (sssinfo != null) {
				thisAdmin = new ValueReference(sssinfo.identityKeyHandle, sssinfo.identityKeyIndex);
			} else
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
		}

		for (int i = 0; i < serverAdmins.length; i++) {
			ValueReference admin = serverAdmins[i];
			if (admin.equals(thisAdmin)) {
				hasPermission = true;
				break;
			} else {
				valuesToTraverse.addElement(admin);
			}
		}

		if (!hasPermission) {
			if (!isAdminInGroup(thisAdmin, valuesToTraverse, new Vector())) {
				return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);
			}
		}

		// If we got to here, then they are in the admin list for this server
		// Now we just need to verify that they are who they claim to be.
		AbstractResponse verifyResp = verifyIdentity(cRes, crReq, req);
		if (verifyResp != null) {
			return verifyResp;
		}
		// if this NA handle hashes to this server, make a transaction for this
		// operation
		if (thisSite.determineServerNum(req.handle) == thisServerNum) {
			try {
				if (!insertTransaction(req.handle, Transaction.ACTION_HOME_NA)) {
					main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to save HOME-NA transaction.");
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Error committing transaction: " + e);
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
			}
		}

		try {
			storage.setHaveNA(req.handle, true);
		} catch (HandleException e) {
			main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Unable to \"home\" naming authority \""
				+ Util.decodeString(req.handle) + "\" after transaction was logged! - " + e);

			if (e.getCode() == HandleException.STORAGE_RDONLY)
				return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
			else
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
		}
		// add to resolver's local sites
		SiteInfo ss[] = { thisSite };
		resolver.getConfiguration().setLocalSites(new String(req.handle), ss);
		// return success
		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/************************************************************************
	 * Tells the server that it will *not* be responsible for handles under
	 * the specified naming authority any longer.
	 ************************************************************************/
	private final AbstractResponse doUnhomeNA(AbstractRequest req, ChallengeResponse cRes, ChallengeAnswerRequest crReq)
		throws HandleException {
		if (!Util.startsWithCI(req.handle, Common.NA_HANDLE_PREFIX)) {
			return new ErrorResponse(req, AbstractRequest.RC_ERROR, MSG_NOT_A_NA_HANDLE);
		}

		//if there are no challenge or chanllenge answer and there are no authenticated session,
		//create challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req))
			return createChallenge(req);

		boolean hasPermission = false;
		Vector valuesToTraverse = new Vector();

		ValueReference thisAdmin = null;
		if (crReq != null && cRes != null) {
			thisAdmin = new ValueReference(crReq.userIdHandle, crReq.userIdIndex);
		} else {
			//an authenticated session is assumed. if not, time out or no session info available
			//use identityHandle, and index in session info
			ServerSideSessionInfo sssinfo = getSession(req.sessionId);
			if (sssinfo != null) {
				thisAdmin = new ValueReference(sssinfo.identityKeyHandle, sssinfo.identityKeyIndex);
			} else
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
		}

		for (int i = 0; i < serverAdmins.length; i++) {
			ValueReference admin = serverAdmins[i];
			if (admin.equals(thisAdmin)) {
				hasPermission = true;
				break;
			} else {
				valuesToTraverse.addElement(admin);
			}
		}

		if (!hasPermission) {
			if (!isAdminInGroup(thisAdmin, valuesToTraverse, new Vector())) {
				return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);
			}
		}

		// If we got to here, then they are in the admin list for this server
		// Now we just need to verify that they are who they claim to be.
		AbstractResponse verifyResp = verifyIdentity(cRes, crReq, req);
		if (verifyResp != null) {
			return verifyResp;
		}

		if (thisSite.determineServerNum(req.handle) == thisServerNum) {
			try {
				if (!insertTransaction(req.handle, Transaction.ACTION_UNHOME_NA)) {
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Error committing transaction: " + e);
			}
		}

		try {
			storage.setHaveNA(req.handle, false);
		} catch (HandleException e) {
			main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Unable to \"home\" naming authority \""
				+ Util.decodeString(req.handle) + "\" after transaction was logged! - " + e);

			if (e.getCode() == HandleException.STORAGE_RDONLY)
				return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
			else
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
		}
		// remove from resolver's local sites
		resolver.getConfiguration().setLocalSites(new String(req.handle), null);
		// return success
		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/************************************************************************
	 * retrieve the transaction logs starting from a certain date, for all
	 * of the handles that hash according to the hash specification in 
	 * the RetrieveTxnRequest object.  This first authenticates the client
	 * based on the replication administrators listed in the configuration
	 * file.
	 ************************************************************************/
	private final AbstractResponse doRetrieveTxnLog(RetrieveTxnRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		// XXX: should make sure there are transactions to replicate before
		//      checking admin?  or does that leak information?
		//
		// XXX: could probably refactor this authentication code to be shared
		//      with other methods.  would lessen the exposure area for security
		//      bugs.
		// 
		// if there are no challenge or challenge answer, and there is no
		// authenticated session.
		//
		//create challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		try {
			boolean hasPermission = false;
			Vector valuesToTraverse = new Vector();

			ValueReference thisAdmin = null;
			if (crReq != null && cRes != null) {
				thisAdmin = new ValueReference(crReq.userIdHandle, crReq.userIdIndex);
			} else {
				//an authenticated session is assumed
				ServerSideSessionInfo sssinfo = getSession(req.sessionId);
				if (sssinfo != null) {
					thisAdmin = new ValueReference(sssinfo.identityKeyHandle, sssinfo.identityKeyIndex);
				} else
					return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
			}

			for (int i = 0; i < replicationAdmins.length; i++) {
				ValueReference admin = replicationAdmins[i];
				if (admin.equals(thisAdmin)) {
					hasPermission = true;
					break;
				} else {
					valuesToTraverse.addElement(admin);
				}
			}

			if (!hasPermission) {
				// the requestor's user ID is not referred to in the
				// replication admins list, so check server admins
				for (int i = 0; i < serverAdmins.length; i++) {
					ValueReference admin = serverAdmins[i];
					if (admin.equals(thisAdmin)) {
						hasPermission = true;
						break;
					} else {
						valuesToTraverse.addElement(admin);
					}
				}

				if (!isAdminInGroup(thisAdmin, valuesToTraverse, new Vector())) {
					return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);
				}
			}

			// If we got to here, then they are in the admin list for this NA
			// Now we just need to verify that they are who they claim to be.
			AbstractResponse verifyResp = verifyIdentity(cRes, crReq, req);
			if (verifyResp != null) {
				return verifyResp;
			}
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Unable to authenticate retrieve txn req: " + e);
			return new ErrorResponse(req, AbstractMessage.RC_AUTHEN_ERROR, null);
		} finally {

			// after doing something big like retrieving transaction logs, we
			// should garbage collect to free up memory and close open files..
			try {
				System.gc();
				System.runFinalization();
			} catch (Throwable t) {
			}
		}

		// at this point, the replication admin has been authenticated,
		// so we can begin streaming the transactions.  If the requestor
		// is hopelessly out of date, they will be notified in the
		// streaming part of the message.
		String start = (new Date(req.lastQueryDate)).toString();
		String end = (new Date(System.currentTimeMillis())).toString();
		long count = nextTxnId - req.lastTxnId;
		if (count > 0) {
			String msg = "";
			if (req.lastTxnId == 1) {
				msg = "Replicating 1 transaction from [" + start + "] to [" + end + "]";
			} else if (req.lastTxnId > 1) {
				msg = "Replicating " + count + " transactions from [" + start + "] to [" + end + "]";
			} else {
				msg = "Replicating all transactions";
			}
			main.logError(ServerLog.ERRLOG_LEVEL_INFO, msg);
		}

		return new RetrieveTxnResponse(txnQueue, req, false, storage, privateKey);
	}

	/************************************************************************
	 * retrieve the entire contents of the handle database that hash
	 * according to the hash specification in the DumpHandlesRequest.
	 * This first authenticates the client based on the replication 
	 * administrators listed in the configuration file.
	 ************************************************************************/
	private final AbstractResponse doDumpHandles(DumpHandlesRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		//if there are no challenge or challenge answer, and there is no authenticated session,
		//create the challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		try {
			boolean hasPermission = false;
			Vector valuesToTraverse = new Vector();

			ValueReference thisAdmin = null;

			if (crReq != null && cRes != null) {
				thisAdmin = new ValueReference(crReq.userIdHandle, crReq.userIdIndex);
			} else {
				//an authenticated session is assumed
				ServerSideSessionInfo sssinfo = getSession(req.sessionId);
				if (sssinfo != null) {
					thisAdmin = new ValueReference(sssinfo.identityKeyHandle, sssinfo.identityKeyIndex);
				} else
					return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
			}

			for (int i = 0; i < replicationAdmins.length; i++) {
				ValueReference admin = replicationAdmins[i];
				if (admin.equals(thisAdmin)) {
					hasPermission = true;
					break;
				} else {
					valuesToTraverse.addElement(admin);
				}
			}

			if (!hasPermission) {
				// the requestor's user ID is not referred to in the
				// replication admins list, so check server admins
				for (int i = 0; i < serverAdmins.length; i++) {
					ValueReference admin = serverAdmins[i];
					if (admin.equals(thisAdmin)) {
						hasPermission = true;
						break;
					} else {
						valuesToTraverse.addElement(admin);
					}
				}

				if (!isAdminInGroup(thisAdmin, valuesToTraverse, new Vector())) {
					return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);
				}
			}

			// If we got to here, then they are in the admin list for this NA
			// Now we just need to verify that they are who they claim to be.
			AbstractResponse verifyResp = verifyIdentity(cRes, crReq, req);
			if (verifyResp != null)
				return verifyResp;
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Unable to authenticate dump handles request: " + e);
			return new ErrorResponse(req, AbstractMessage.RC_AUTHEN_ERROR, null);
		}

		// at this point, the replication admin has been authenticated,
		// and the requestor is reasonably up to date, so we can begin 
		// streaming the handles.
		return new DumpHandlesResponse(req, storage, txnQueue, privateKey);
	}

	/************************************************************************
	 * verify whether or not the response to the challenge given in the 
	 * request object was "signed" using the specified user's secret key.
	 * Note: currently the ChallengeResponse and ChallengeAnswerRequest
	 * objects are ignored here.  The user ID, challenge and response
	 * are all contained in the VerifyAuthRequest object.
	 ************************************************************************/
	private final AbstractResponse verifyChallenge(VerifyAuthRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		if (!storage.haveNA(Util.getNAHandle(req.handle)))
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE);
		int handleIndex = req.handleIndex;
		byte clumps[][] = storage.getRawHandleValues((caseSensitive ? req.handle : Util.upperCase(req.handle)),
			handleIndex == 0 ? null : new int[] { req.handleIndex }, handleIndex == 0 ? Common.MD5_SECRET_KEY_TYPES
				: null);
		if (clumps == null || clumps.length <= 0) {
			return new VerifyAuthResponse(req, false);
		}

		// Get the encoding type (hash algorithm) of the signature
		// and use that to get the signature.
		byte authSignature[];
		byte digestAlg = req.signedResponse[0];

		boolean oldFormat = ((req.majorProtocolVersion == 5 && req.minorProtocolVersion == 0) || (req.majorProtocolVersion == 2 && req.minorProtocolVersion == 0));

		if (oldFormat) { // the old format - just the md5 digest, no length or alg ID
			digestAlg = Common.HASH_CODE_MD5;
			authSignature = req.signedResponse;

		} else { // new format w/ one byte md5 or sha1 identifiers
			switch (digestAlg) {
			case Common.HASH_CODE_MD5:
				authSignature = new byte[Common.MD5_DIGEST_SIZE];
				System.arraycopy(req.signedResponse, 1, authSignature, 0, Common.MD5_DIGEST_SIZE);
				break;
			case Common.HASH_CODE_SHA1:
				authSignature = new byte[Common.SHA1_DIGEST_SIZE];
				System.arraycopy(req.signedResponse, 1, authSignature, 0, Common.SHA1_DIGEST_SIZE);
				break;
			default:
				// could be an invalid hash type, but for now we'll assume that it is
				// just the old format - no hash type, just 16 bytes of md5
				////// this should be changed to throw an exception once the old
				////// clients are phased out.
				authSignature = req.signedResponse;
				digestAlg = Common.HASH_CODE_MD5;
				/**
				   throw new HandleException(HandleException.MESSAGE_FORMAT_ERROR,
				   "Invalid hash type in secret key signature: "+((int)digestAlg));
				*/
			}
		}

		HandleValue secretKeyValue = new HandleValue();
		for (int valIdx = 0; valIdx < clumps.length; valIdx++) {
			Encoder.decodeHandleValue(clumps[valIdx], 0, secretKeyValue);
			if (handleIndex != 0 && handleIndex != secretKeyValue.getIndex())
				continue;
			if (!secretKeyValue.hasType(Common.STD_TYPE_HSSECKEY))
				continue;

			byte realSignature[] = Util.doDigest(digestAlg, secretKeyValue.getData(), req.nonce, req.origRequestDigest,
				secretKeyValue.getData());

			if (realSignature != null && realSignature.length > 0 && Util.equals(realSignature, authSignature)) {
				return new VerifyAuthResponse(req, true);
			}
		}

		return new VerifyAuthResponse(req, false);
	}

	/************************************************************************
	 * process a delete handle request, with the specified authentication
	 * info (if any).
	 ************************************************************************/
	private final AbstractResponse doDeleteHandle(DeleteHandleRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {

		// make sure that we are supposed to take this handle...
		if (thisSite.servers.length > 1 && thisSite.determineServerNum(req.handle) != thisServerNum) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_WRONG_SERVER_HASH);
		}

		// we might want to check to see if we manage this naming authority...
		// I left this out because we should be able to delete handles
		// that are in the database by mistake.

		// make sure the user has authenticated.  If not, send a challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		// check to see if the given user has permission to delete this
		try {
			// get the admin records from the handle, also check to make sure
			// that the handle exists.
			byte clumps[][] = storage.getRawHandleValues((caseSensitive ? req.handle : Util.upperCase(req.handle)),
				null, Common.ADMIN_TYPES);
			if (clumps == null) {
				return new ErrorResponse(req, AbstractMessage.RC_HANDLE_NOT_FOUND, null);
			}

			AbstractResponse authResp = authenticateUser(req, cRes, crReq, DEL_HANDLE_PERM, clumps);
			if (authResp != null) {
				return authResp;
			}

		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Unable to authenticate delete handle request: " + e);
			return new ErrorResponse(req, AbstractMessage.RC_AUTHEN_ERROR, null);
		}

		try {
			if (!insertTransaction(req.handle, Transaction.ACTION_DELETE_HANDLE)) {
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
			}

			storage.deleteHandle((caseSensitive ? req.handle : Util.upperCase(req.handle)));
		} catch (HandleException e) {
			main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Error committing transaction: " + e);
			switch (e.getCode()) {
			case HandleException.HANDLE_DOES_NOT_EXIST:
				return new ErrorResponse(req, AbstractMessage.RC_HANDLE_NOT_FOUND, null);
			case HandleException.STORAGE_RDONLY:
				return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
			default:
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
			}
		}

		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/** returns the offset of the value with the given index, or
	  * -1 if there is no value with that index. */
	private static final int getHVByIndex(HandleValue values[], int index) {
		for (int i = 0; i < values.length; i++) {
			if (values[i] != null && values[i].getIndex() == index)
				return i;
		}
		return -1;
	}

	/************************************************************************
	 * process a remove handle-value request, with the specified 
	 * authentication info (if any).
	 ************************************************************************/
	private final AbstractResponse doRemoveValue(RemoveValueRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		// make sure that we are supposed to take this handle...
		if (thisSite.servers.length > 1 && thisSite.determineServerNum(req.handle) != thisServerNum) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_WRONG_SERVER_HASH);
		} else if (!storage.haveNA(Util.getNAHandle(req.handle))) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE);
		}

		// make sure the user has authenticated.  If not, send a challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		byte handle[] = (caseSensitive ? req.handle : Util.upperCase(req.handle));

		synchronized (getWriteLock(req.handle)) {

			// get the current values...
			byte rawValues[][] = storage.getRawHandleValues(handle, null, null);

			// decode the current values
			HandleValue values[] = new HandleValue[rawValues.length];
			for (int i = 0; i < rawValues.length; i++) {
				values[i] = new HandleValue();
				Encoder.decodeHandleValue(rawValues[i], 0, values[i]);
			}

			// find the values to be removed, and the permissions needed to remove them
			// if the requestor supplied a non-existent index, then it will return an error.
			boolean needsRemAdminPerm = false;
			boolean needsRemValuePerm = false;
			int toBeRemovedIdxs[] = new int[req.indexes.length];
			for (int i = 0; i < toBeRemovedIdxs.length; i++) {
				toBeRemovedIdxs[i] = getHVByIndex(values, req.indexes[i]);
				;
				if (toBeRemovedIdxs[i] < 0) {
					return new ErrorResponse(req, AbstractMessage.RC_VALUES_NOT_FOUND, null);
				}
				HandleValue val = values[toBeRemovedIdxs[i]];
				if (val.hasType(Common.ADMIN_TYPE))
					needsRemAdminPerm = true;
				else
					needsRemValuePerm = true;
			}

			int neededPerms[];
			if (needsRemValuePerm && needsRemAdminPerm)
				neededPerms = REM_ADM_AND_VAL_PERM;
			else if (needsRemAdminPerm)
				neededPerms = REM_ADM_PERM;
			else
				neededPerms = REM_VAL_PERM;

			// authenticate the user
			AbstractResponse authResp = authenticateUser(req, cRes, crReq, neededPerms, rawValues);
			if (authResp != null) {
				return authResp;
			}

			// take the removed values out of the array
			int removed = 0;
			for (int i = 0; i < toBeRemovedIdxs.length; i++) {
				if (values[toBeRemovedIdxs[i]] != null)
					removed++;
				values[toBeRemovedIdxs[i]] = null;
			}

			// copy the remaining values to a new array
			HandleValue newValues[] = new HandleValue[values.length - removed];
			int j = 0;
			for (int i = 0; i < values.length; i++) {
				if (values[i] != null)
					newValues[j++] = values[i];
			}

			values = newValues;

			try {
				// log the transaction
				if (!insertTransaction(handle, Transaction.ACTION_UPDATE_HANDLE)) {
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}

				// save the updated values to the database
				storage.updateValue(handle, values);

			} catch (HandleException e) {
				main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Error committing transaction: " + e);
				switch (e.getCode()) {
				case HandleException.HANDLE_DOES_NOT_EXIST:
					return new ErrorResponse(req, AbstractMessage.RC_HANDLE_NOT_FOUND, null);
				case HandleException.STORAGE_RDONLY:
					return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
				default:
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}
			}
		}

		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/** Combine the toAppend permissions with the current permissions.
	  * This assumes that the values of the permissions arrays are 
	  * immutable. */
	private static final int[] combinePerms(int current[], int toAppend[]) {
		if (current == null)
			return toAppend;
		if (toAppend == null)
			return current;
		int newPerms[] = new int[current.length + toAppend.length];
		System.arraycopy(current, 0, newPerms, 0, current.length);
		System.arraycopy(toAppend, 0, newPerms, current.length, toAppend.length);
		return newPerms;
	}

	private final AbstractResponse doModifyValue(ModifyValueRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		// make sure that we are supposed to take this handle...
		if (thisSite.servers.length > 1 && thisSite.determineServerNum(req.handle) != thisServerNum) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_WRONG_SERVER_HASH);
		} else if (!storage.haveNA(Util.getNAHandle(req.handle))) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE);
		}

		// make sure the user has authenticated.  If not, send a challenge
		// added checking up with session
		boolean isAnonymous = ((cRes == null || crReq == null) && !authenticatedSession(req));
		boolean needsAuthentication = false;

		byte handle[] = (caseSensitive ? req.handle : Util.upperCase(req.handle));

		////////////////////////////////////////////////////////
		/////// begin synchronized if if-modified-since applies.
		////////////////////////////////////////////////////////

		synchronized (getWriteLock(req.handle)) {

			// get the current values...
			byte rawValues[][] = storage.getRawHandleValues(handle, null, null);

			// decode all of the current values
			HandleValue values[] = new HandleValue[rawValues.length];
			for (int i = 0; i < rawValues.length; i++) {
				values[i] = new HandleValue();
				Encoder.decodeHandleValue(rawValues[i], 0, values[i]);
			}

			boolean needsModAdminPerm = false;
			boolean needsModValuePerm = false;
			boolean needsAdmToValPerm = false;
			boolean needsValToAdmPerm = false;

			boolean oldValIsAdmin;
			boolean newValIsAdmin;
			// find the indexes of the value to be modified.
			int toBeModifiedIdxs[] = new int[req.values.length];
			for (int i = 0; i < toBeModifiedIdxs.length; i++) {
				toBeModifiedIdxs[i] = getHVByIndex(values, req.values[i].getIndex());
				if (toBeModifiedIdxs[i] < 0) {
					return new ErrorResponse(req, AbstractMessage.RC_VALUES_NOT_FOUND, null);
				}
				HandleValue val = values[toBeModifiedIdxs[i]];
				if (!val.getAdminCanWrite()) {
					// if write access is not allowed by administrators, nobody can write!
					return new ErrorResponse(req, AbstractMessage.RC_INSUFFICIENT_PERMISSIONS, MSG_READ_ONLY_VALUE);
				}

				oldValIsAdmin = val.hasType(Common.ADMIN_TYPE);
				newValIsAdmin = req.values[i].hasType(Common.ADMIN_TYPE);

				if (isAnonymous) {
					if (!val.getAnyoneCanWrite()) {
						// if the requestor is anonymous but anonymous write access is not allowed
						return createChallenge(req);
					} else if (oldValIsAdmin || newValIsAdmin) {
						// no anonymous operations are allowed on admin records
						return createChallenge(req);
					}
				}

				if (oldValIsAdmin && newValIsAdmin)
					needsModAdminPerm = true;
				else if (oldValIsAdmin && !newValIsAdmin)
					needsAdmToValPerm = true;
				else if (!oldValIsAdmin && newValIsAdmin)
					needsValToAdmPerm = true;
				else if (!oldValIsAdmin && !newValIsAdmin && !val.getAnyoneCanWrite())
					needsModValuePerm = true;
			}

			int perms[] = null;
			if (needsModAdminPerm)
				perms = combinePerms(perms, MOD_ADM_PERM);
			if (needsModValuePerm)
				perms = combinePerms(perms, MOD_VAL_PERM);
			if (needsAdmToValPerm)
				perms = combinePerms(perms, ADM_TO_VAL_PERM);
			if (needsValToAdmPerm)
				perms = combinePerms(perms, VAL_TO_ADM_PERM);

			// authenticate the user...
			if (perms != null) {
				AbstractResponse authResp = authenticateUser(req, cRes, crReq, perms, rawValues);
				if (authResp != null) {
					return authResp;
				}
			}

			// replace the old values with the new ones, and update the timestamps
			int now = (int) (System.currentTimeMillis() / 1000);
			for (int i = 0; i < toBeModifiedIdxs.length; i++) {
				values[toBeModifiedIdxs[i]] = req.values[i];
				values[toBeModifiedIdxs[i]].setTimestamp(now);
			}

			// check for duplicate index values
			for (int i = 0; i < values.length; i++) {
				for (int j = i + 1; j < values.length; j++) {
					if (values[i].getIndex() == values[j].getIndex()) {
						return new ErrorResponse(req, AbstractMessage.RC_ERROR, Util.encodeString("Index conflict for "
							+ values[j].getIndex()));
					}
				}
			}

			try {
				// log the transaction
				if (!insertTransaction(handle, Transaction.ACTION_UPDATE_HANDLE)) {
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}

				// save the updated value to the database
				storage.updateValue(handle, values);
			} catch (HandleException e) {
				main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Error committing transaction: " + e);
				switch (e.getCode()) {
				case HandleException.HANDLE_DOES_NOT_EXIST:
					return new ErrorResponse(req, AbstractMessage.RC_HANDLE_NOT_FOUND, null);
				case HandleException.STORAGE_RDONLY:
					return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
				default:
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}
			}
		}
		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/************************************************************************
	 * process an add handle-value request, with the specified authentication
	 * info (if any).
	 ************************************************************************/
	private final AbstractResponse doAddValue(AddValueRequest req, ChallengeResponse cRes, ChallengeAnswerRequest crReq)
		throws HandleException {
		// make sure that we are supposed to take this handle...
		if (thisSite.servers.length > 1 && thisSite.determineServerNum(req.handle) != thisServerNum) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_WRONG_SERVER_HASH);
		} else if (!storage.haveNA(Util.getNAHandle(req.handle))) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE);
		}

		for (int i = 0; i < req.values.length; i++) {
			if (req.values[i].getIndex() < 0) {
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INDEXES_MUST_BE_POSITIVE);
			}
		}

		// make sure the user has authenticated.  If not, send a challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		byte handle[] = (caseSensitive ? req.handle : Util.upperCase(req.handle));

		if (req.values == null || req.values.length <= 0)
			return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_EMPTY_VALUE_LIST);

		synchronized (getWriteLock(req.handle)) {
			// get the current values...
			byte rawValues[][] = storage.getRawHandleValues(handle, null, null);

			boolean needsAddAdminPerm = false;
			boolean needsAddValuePerm = false;

			// see what permissions they need... either add-admin, add-value, or both
			for (int i = 0; i < req.values.length; i++) {
				if (req.values[i].hasType(Common.ADMIN_TYPE))
					needsAddAdminPerm = true;
				else
					needsAddValuePerm = true;
			}

			int neededPerms[] = null;
			if (needsAddValuePerm && needsAddAdminPerm)
				neededPerms = ADD_ADM_AND_VAL_PERM;
			else if (needsAddAdminPerm)
				neededPerms = ADD_ADM_PERM;
			else
				neededPerms = ADD_VAL_PERM;

			// authenticate the user...
			AbstractResponse authResp = authenticateUser(req, cRes, crReq, neededPerms, rawValues);
			if (authResp != null) {
				return authResp;
			}

			// combine the to-be-added values with the current values
			HandleValue values[] = new HandleValue[rawValues.length + req.values.length];
			int i = 0;
			for (i = 0; i < rawValues.length; i++) {
				values[i] = new HandleValue();
				Encoder.decodeHandleValue(rawValues[i], 0, values[i]);
			}
			int now = (int) (System.currentTimeMillis() / 1000);
			for (int j = 0; j < req.values.length; j++) {
				req.values[j].setTimestamp(now);
				values[i + j] = req.values[j];
			}

			// check for duplicate index values
			for (i = 0; i < values.length; i++) {
				for (int j = i + 1; j < values.length; j++) {
					if (values[i].getIndex() == values[j].getIndex()) {
						return new ErrorResponse(req, AbstractMessage.RC_VALUE_ALREADY_EXISTS, Util
							.encodeString("Index conflict for " + values[j].getIndex()));
					}
				}
			}

			try {
				// log the transaction
				if (!insertTransaction(handle, Transaction.ACTION_UPDATE_HANDLE)) {
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}

				// save the updated value to the database
				storage.updateValue(handle, values);

			} catch (HandleException e) {
				main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Error committing transaction: " + e);
				switch (e.getCode()) {
				case HandleException.HANDLE_DOES_NOT_EXIST:
					return new ErrorResponse(req, AbstractMessage.RC_HANDLE_NOT_FOUND, null);
				case HandleException.STORAGE_RDONLY:
					return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
				default:
					return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
				}
			}

		}
		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/** 
	 * Used by doCreateHandle and doListHandle to retrieve the NA admin values.
	 * If allowNAAdmins is set to false in config.dct, it will always return an
	 * empty array.
	 *
	 * @param na The NA to retrieve admin values from.
	 * 
	 * @return null on error, otherwise NA admin values.  
	 **/
	private final byte[][] getNAAdminValues(byte na[]) throws HandleException {
		if (!allowNAAdmins)
			return new byte[0][];

		ResolutionRequest authRequest = new ResolutionRequest(na, Common.ADMIN_TYPES, null, null);

		// this must be certified - oh yes!
		authRequest.certify = true;

		// get the admin records from the naming authority handle
		AbstractResponse response = resolver.processRequest(authRequest);

		if (response.getClass() != ResolutionResponse.class) {
			return null;
		}

		return ((ResolutionResponse) response).values;
	}

	/**
	 * Returns null if authentication and authorization was successful and
	 * an ErrorResponse otherwise.
	 *
	 * FIXME: Always returns RC_INVALID_ADMIN on error, even if it should
	 *        return RC_INSUFFICIENT_PERMISSIONS.
	 **/
	private final AbstractResponse authenticateUser(AbstractRequest req, ChallengeResponse challenge,
		ChallengeAnswerRequest response, int operationIDs[], byte values[][]) throws HandleException {
		// set up the identity handle and index here for two cases:
		// 1. for Challenge Answer Request (in response),
		//    the identity is response.userIdHandle and response.userIdIndex
		// 2. for session information 
		//    the identity is in the session info identityHandle, identityIndex

		byte[] identityHandle = null;
		int identityIndex = -1;
		ServerSideSessionInfo sessionInfo = getSession(req.sessionId);

		if (challenge != null && response != null) {
			identityHandle = response.userIdHandle;
			identityIndex = response.userIdIndex;
		} else {
			// there was no challenge/response, so get the client ID from the
			// session information, if any
			if (sessionInfo == null) {
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
			}
			identityHandle = sessionInfo.identityKeyHandle;
			identityIndex = sessionInfo.identityKeyIndex;
		}

		// if the server has been configured to require sessions in order to perform
		// administration then reject any requests that are not contained in a session
		// and are not attempting to set up a session
		if (requireSessions && sessionInfo == null && req.opCode != AbstractMessage.OC_SESSION_SETUP) {
			System.err.println("rejecting non-session request: " + req + "; session: " + getSession(req.sessionId));
			return new ErrorResponse(req, AbstractMessage.RC_INVALID_CREDENTIAL, MSG_SESSION_REQUIRED);
		}

		// look for HS_ADMIN records that give the user permission to perform
		// the requested operation
		boolean hasAdminAccess = false;
		Vector valuesToTraverse = new Vector();
		try {
			HandleValue tmpValue = new HandleValue();
			AdminRecord admin = new AdminRecord();

			if (!allowNAAdmins)
				values = new byte[0][];

			// look for admin values with the proper permissions
			if (values != null) {
				for (int i = 0; i < values.length; i++) {
					try {
						Encoder.decodeHandleValue(values[i], 0, tmpValue);
						if (!tmpValue.hasType(Common.ADMIN_TYPE)) {
							continue;
						}

						// extract the admin record from the handle value
						Encoder.decodeAdminRecord(tmpValue.getData(), 0, admin);

					} catch (Exception e) {
						main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error decoding possible admin value: " + e);
						continue;
					}
					boolean adminRecordIsRelevant = true;
					for (int p = 0; p < operationIDs.length; p++) {
						if (!admin.perms[operationIDs[p]]) { // doesn't have permission
							adminRecordIsRelevant = false;
							break;
						}
					}
					if (!adminRecordIsRelevant) {
						continue;
					}

					// if this admin record refers directly to the requestor's user ID,
					// then they are allowed access (provided their authentication 
					// can be verified).
					if (Util.equals(admin.adminId, identityHandle) && admin.adminIdIndex == identityIndex) {

						// the given administrator handle/index was specifically listed as an
						// administrator
						hasAdminAccess = true;
						break;

					} else {
						// this admin record didn't directly refer to the current user, but
						// it could be a reference to an admin group.
						valuesToTraverse.addElement(new ValueReference(admin.adminId, admin.adminIdIndex));
					}
				}
			}
		} catch (Throwable e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error authenticating: " + e);
		}

		if (!hasAdminAccess && serverAdminFullAccess) {
			// the current client has not already been found in the list of admins, so check
			// the server admins if serverAdminFullAccess flag is turned on in config file
			for (int i = 0; serverAdmins != null && i < serverAdmins.length; i++) {
				try {
					if (Util.equals(identityHandle, serverAdmins[i].handle) && identityIndex == serverAdmins[i].index) {
						hasAdminAccess = true;
						break;
					} else {
						valuesToTraverse.addElement(serverAdmins[i]);
					}
				} catch (Exception e) {
					main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error checking for server admin: " + e);
				}
			}
		}

		try {
			if (hasAdminAccess) {
				// this admin is directly referenced as an administrator (ie no group resolution needed)
				return verifyIdentity(challenge, response, req);

			} else if (isAdminInGroup(new ValueReference(identityHandle, identityIndex), valuesToTraverse, new Vector())) {
				// the administrator is indirectly referenced as part of a group (HS_VLIST)
				return verifyIdentity(challenge, response, req);

			} else {
				// the client is not referenced as an administrator, either directly or indirectly
				return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);

			}
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error authenticating: " + e);
			return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);
		}
	}

	/************************************************************************
	 * process a create handle request, with the specified authentication
	 * info (if any).
	 ************************************************************************/
	private final AbstractResponse doCreateHandle(CreateHandleRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {

		// make sure that we are supposed to take this handle...
		if (thisSite.servers.length > 1 && thisSite.determineServerNum(req.handle) != thisServerNum) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_WRONG_SERVER_HASH);
		} else if (!storage.haveNA(Util.getNAHandle(req.handle))) {
			return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE);
		}

		// make sure the handle is valid utf8
		if (!Util.isValidString(req.handle, 0, req.handle.length)) {
			return new ErrorResponse(req, AbstractMessage.RC_INVALID_HANDLE, MSG_INVALID_ENCODING);
		}

		// make sure the user has authenticated.  If not, send a challenge
		// if an authenticated session is found, don't send a challenge

		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		// check for duplicate handle index values
		for (int i = 0; i < req.values.length; i++) {
			if (req.values[i].getIndex() < 0) {
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INDEXES_MUST_BE_POSITIVE);
			}
			for (int j = i + 1; j < req.values.length; j++) {
				if (req.values[i].getIndex() == req.values[j].getIndex()) {
					return new ErrorResponse(req, AbstractMessage.RC_VALUE_ALREADY_EXISTS, Util
						.encodeString("Index conflict for " + req.values[j].getIndex()));
				}
			}
		}

		try {
			// if this is a sub-naming authority handle, we get the admin information
			// from the parent naming authority.  Otherwise, we get the admin info
			// from the naming authority handle.
			boolean isSubNAHandle = Util.isSubNAHandle(req.handle);
			byte na[] = isSubNAHandle ? Util.getParentNAOfNAHandle(req.handle) : Util.getNAHandle(req.handle);
			byte vals[][] = getNAAdminValues(na);
			if (vals == null) {
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Unable to find admin group while creating handle");
				//ss: allow null admin-values so that server-admin can be used for authentication...
				//return new ErrorResponse(req, AbstractMessage.RC_AUTHEN_ERROR, null);
			}

			// authenticate the user
			AbstractResponse authResp = authenticateUser(req, cRes, crReq, isSubNAHandle ? ADD_SUB_NA_PERM
				: ADD_HANDLE_PERM, vals);
			if (authResp != null)
				return authResp;

		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error while creating handle: " + e);
			return new ErrorResponse(req, AbstractMessage.RC_AUTHEN_ERROR, null);
		}

		// process the new handle values
		int now = (int) (System.currentTimeMillis() / 1000);
		for (int i = 0; req.values != null && i < req.values.length; i++) {
			req.values[i].setTimestamp(now);
		}

		// add the new handle to the database if it isn't already in there
		try {
			if (storage.getRawHandleValues(req.handle, null, null) != null) {
				return new ErrorResponse(req, AbstractMessage.RC_HANDLE_ALREADY_EXISTS, null);
			}

			if (!insertTransaction(req.handle, Transaction.ACTION_CREATE_HANDLE)) {
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
			}

			storage.createHandle((caseSensitive ? req.handle : Util.upperCase(req.handle)), req.values);
		} catch (HandleException e) {
			main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Error committing transaction: " + e);
			switch (e.getCode()) {
			case HandleException.HANDLE_ALREADY_EXISTS:
				return new ErrorResponse(req, AbstractMessage.RC_HANDLE_ALREADY_EXISTS, null);
			case HandleException.STORAGE_RDONLY:
				return new ErrorResponse(req, AbstractMessage.RC_SERVER_BACKUP, MSG_SERVER_BACKUP);
			default:
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
			}
		}
		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	private final boolean haveHandle(byte handle[]) throws HandleException {
		if (!storage.haveNA(Util.getNAHandle(handle)))
			return false;
		if (thisSite.servers.length <= 1)
			return true;
		if (thisSite.determineServerNum(handle) != thisServerNum)
			return false;
		return true;
	}

	/************************************************************************
	 * process a resolution request, with the specified authentication
	 * info (if any).
	 ************************************************************************/
	private final AbstractResponse doResolution(ResolutionRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		// this is a hook to enable returning computed values (server status, etc)
		// from requests for certain handles
		if (enableStatusHandle && Util.equals(req.handle, SERVER_STATUS_HANDLE)) {
			// construct and return a set of handles values containing the status of
			// the server
			ArrayList vals = new ArrayList();

			StringBuffer status = new StringBuffer();
			Runtime jr = Runtime.getRuntime();
			status.append("freemem=").append(jr.freeMemory());
			status.append("; totalmem=").append(jr.totalMemory());
			status.append("; maxmem=").append(jr.maxMemory());
			status.append("; runtime=").append(System.currentTimeMillis() - startTime);
			status.append("; numreqs=").append(numRequests);
			vals.add(new HandleValue(1, SERVER_STATUS_HDL_TYPE, Util.encodeString(status.toString())));

			byte valBytes[][] = new byte[vals.size()][];
			for (int i = 0; i < valBytes.length; i++) {
				HandleValue val = (HandleValue) vals.get(i);
				valBytes[i] = new byte[Encoder.calcStorageSize(val)];
				Encoder.encodeHandleValue(valBytes[i], 0, val);
			}
			return new ResolutionResponse(req, req.handle, valBytes);
		}

		byte clumps[][] = null;
		if (haveHandle(req.handle)) {
			try {
				clumps = storage.getRawHandleValues((caseSensitive ? req.handle : Util.upperCase(req.handle)),
					req.requestedIndexes, req.requestedTypes);
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, String.valueOf(getClass()) + ": error getting values: "
					+ e);
				e.printStackTrace(System.err);
				return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
			}
			if (clumps == null) {
				return new ErrorResponse(req, AbstractMessage.RC_HANDLE_NOT_FOUND, null);
			} else if (clumps.length == 0) {
				return new ErrorResponse(req, AbstractMessage.RC_VALUES_NOT_FOUND, null);
			} else {
				return checkReadAccess(req, clumps, cRes, crReq);
			}
		} else {
			// we don't have the handle, need to resolve it
			if (allowRecursiveQueries && req.recursive) {
				// if we're not responsible for this handle and the recursive
				// flag is set, we should attempt to resolve the handle for the
				// user...
				req.recursionCount++;
				if (req.recursionCount > RECURSION_LIMIT)
					return new ErrorResponse(req, AbstractMessage.RC_RECURSION_COUNT_TOO_HIGH, null);

				req.recursive = false;
				req.clearBuffers();

				return resolver.processRequest(req);
			} else {
				// the request was non-recursive, so we should just return an
				// error instead of resolving the handle ourselves.
				return new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE);
			}
		}

	}

	/************************************************************************
	 * process a list-handles request, with the specified authentication
	 * info (if any).
	 ************************************************************************/
	private final void doListHandles(ResponseMessageCallback callback, ListHandlesRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		// make sure the server allows the list handles permission
		if (!allowListHdls)
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_OPERATION_NOT_SUPPORTED,
				MSG_NEED_LIST_HDLS_PERM));

		// make sure that the given NA handle starts with the correct NA prefix
		if (!Util.startsWithCI(req.handle, Common.NA_HANDLE_PREFIX)) {
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_INVALID_HANDLE, MSG_INVALID_NA_HANDLE));
			return;
		}

		// make sure that we are supposed to take this handle...
		if (!storage.haveNA(req.handle)) {
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_SERVER_NOT_RESP, MSG_NA_NOT_HOMED_HERE));
			return;
		}

		// make sure the user has authenticated.  If not, send a challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			sendResponse(callback, createChallenge(req));
			return;
		}

		try {
			// authenticate the user
			byte vals[][] = getNAAdminValues(req.handle);
			AbstractResponse authResp = authenticateUser(req, cRes, crReq, LIST_HDLS_PERM, vals);
			if (authResp != null) {
				sendResponse(callback, authResp);
				return;
			}
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Auth error on list-handles request: " + e);
			sendResponse(callback, new ErrorResponse(req, AbstractMessage.RC_AUTHEN_ERROR, null));
			return;
		}

		// At this point, the requestor has authenticated as an admin
		// of the NA with permission to list handles.  We will now begin
		// sending back list handle responses...
		ListHandlesResponse response = new ListHandlesResponse(req, null);
		Enumeration listEnum = storage.getHandlesForNA(req.handle);
		byte handles[][] = new byte[LIST_HANDLES_PER_MSG][];
		int numHandles = 0;
		boolean errorSendingResponse = false;
		while (listEnum.hasMoreElements()) {
			handles[numHandles++] = (byte[]) listEnum.nextElement();
			if (numHandles >= LIST_HANDLES_PER_MSG) {
				response.handles = handles;
				response.clearBuffers();
				response.continuous = listEnum.hasMoreElements();
				numHandles = 0;
				if (!errorSendingResponse) {
					try {
						sendResponse(callback, response);
					} catch (Throwable t) {
						errorSendingResponse = true;
						System.err.println("Error sending response to list-handles request: " + t);
					}
				}
			}
		}

		if (numHandles > 0 && !errorSendingResponse) {
			byte tmpHandles[][] = new byte[numHandles][];
			System.arraycopy(handles, 0, tmpHandles, 0, numHandles);
			response.handles = tmpHandles;
			response.clearBuffers();
			response.continuous = false;
			numHandles = 0;
			sendResponse(callback, response);
		}
	}

	/***************************************************************************
	 * Check if the specified user has read access to the given handle values.
	 * If so, then return a resolution response.
	 * Otherwise, return a challenge to the user to authenticate.
	 ***************************************************************************/
	private final AbstractResponse checkReadAccess(ResolutionRequest req, byte clumps[][], ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		if (req.ignoreRestrictedValues) {
			// the request is only asking for the publicly readable values
			int numUnrestricted = 0;
			for (int i = 0; i < clumps.length; i++) {
				if ((Encoder.getHandleValuePermissions(clumps[i], 0) & Encoder.PERM_PUBLIC_READ) != 0)
					numUnrestricted++;
			}
			byte unrestrictedVals[][] = new byte[numUnrestricted][];
			numUnrestricted--;
			for (int i = clumps.length - 1; i >= 0; i--)
				if ((Encoder.getHandleValuePermissions(clumps[i], 0) & Encoder.PERM_PUBLIC_READ) != 0)
					unrestrictedVals[numUnrestricted--] = clumps[i];

			return new ResolutionResponse(req, req.handle, unrestrictedVals);
		}

		// if we got here, the user wants to be authenticated if necessary
		boolean needsauth = false;
		for (int i = 0; i < clumps.length; i++) {
			byte perms = Encoder.getHandleValuePermissions(clumps[i], 0);
			if ((perms & Encoder.PERM_PUBLIC_READ) == 0) {
				if ((perms & Encoder.PERM_ADMIN_READ) == 0) {
					// neither admin nor public read access is allowed...
					return new ErrorResponse(req, AbstractMessage.RC_INSUFFICIENT_PERMISSIONS, null);
				}
				needsauth = true;
				break;
			}
		}

		if (!needsauth) {
			// no authentication needed...
			return new ResolutionResponse(req, req.handle, clumps);

		} else if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			// needs authentication, none provided; send a challenge to authenticate
			return createChallenge(req);
		} else {
			// needs authentication, some provided
			byte adminClumps[][] = storage.getRawHandleValues(
				(caseSensitive ? req.handle : Util.upperCase(req.handle)), Common.ADMIN_INDEXES, Common.ADMIN_TYPES);
			AbstractResponse authResp = authenticateUser(req, cRes, crReq, READ_VAL_PERM, adminClumps);
			if (authResp != null)
				return authResp;
			else
				return new ResolutionResponse(req, req.handle, clumps);
		}
	}

	/*****************************************************************************
	 *
	 *  Get the next transaction ID.  If we are unable to get the next transaction ID
	 *  (for example, if the txn ID server is not responding) then we throw an exception.
	 *
	 */

	private final long retrieveNextTxnId() throws HandleException {
		// we need to get the transaction id from the transaction server.
		long nextTxnId = -1;
		synchronized (TRANSACTION_LOCK) {
			try {
				AbstractResponse resp = resolver.sendRequestToSite(nextTxnIdRequest, thisSite);
				if ((resp != null) && (resp.responseCode == AbstractMessage.RC_SUCCESS))
					nextTxnId = ((NextTxnIdResponse) resp).nextTxnId;
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to acquire next transaction ID: " + e);
				if (e instanceof HandleException)
					throw (HandleException) e;
				throw new HandleException(HandleException.INTERNAL_ERROR, "Unable to acquire next transaction ID: " + e);
			}
		}

		if (nextTxnId < 0) {
			main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to acquire next transaction ID");
			throw new HandleException(HandleException.INTERNAL_ERROR, "Unable to acquire next transaction ID");
		}
		return nextTxnId;
	}

	private final boolean insertTransaction(byte handle[], byte action) {
		// first, we need to get the transaction id from the transaction server.
		long nextTxnId;
		synchronized (TRANSACTION_LOCK) {
			try {
				nextTxnId = getNextTxnId();
			} catch (Throwable e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to acquire next transaction ID: " + e);
				return false;
			}

			if (nextTxnId < 0) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to acquire next transaction ID");
				return false;
			}

			try {
				txnQueue.addTransaction(nextTxnId, handle, action, System.currentTimeMillis());
			} catch (Throwable e) {
				main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, "Unable to insert transaction into queue");
				return false;
			}
		}
		return true;
	}

	private final AbstractResponse createChallenge(AbstractRequest req) throws HandleException {
		ChallengeResponseInfo cri = new ChallengeResponseInfo();
		cri.timeStarted = System.currentTimeMillis();
		cri.challenge = new ChallengeResponse(req);
		cri.originalRequest = req;

		/*
		synchronized (pendingAuthorizations) {
		  cri.sessionId = ++nextAuthId;
		  cri.challenge.sessionId = cri.sessionId;
		  pendingAuthorizations.put(cri.sessionId, cri);
		}
		*/
		synchronized (pendingAuthorizations) {

			//use session id if the req is in a valid session
			if (validSession(req))
				cri.sessionId = req.sessionId;
			else
				cri.sessionId = getNextSessionId();

			cri.challenge.sessionId = cri.sessionId;
			pendingAuthorizations.put(cri.sessionId, cri);
		}

		return cri.challenge;
	}

	private static synchronized int getNextSessionId() {
		return ++nextAuthId;
	}

	/**
	 * Determines if the administrator handle/index combination included in the
	 * admin parameter is listed in a group (aka HS_VLIST) that is included in
	 * the valuesToTraverse Vector (of ValueReference objects).  ValueReferences
	 * from the valuesToTraverse Vector are resolved and the contents of any HS_VLIST
	 * values are added to the valuesToTraverse vector if they aren't already in
	 * valuesTraversed.  If an exact match for the admin ValueReference is found
	 * then this returns true.  Otherwise it returns false.
	 */
	private final boolean isAdminInGroup(ValueReference admin, Vector valuesToTraverse, Vector valuesTraversed) {
		while (valuesToTraverse.size() > 0) {
			ValueReference val = (ValueReference) valuesToTraverse.elementAt(0);

			valuesTraversed.addElement(val);

			ResolutionRequest req = new ResolutionRequest(val.handle, null, new int[] { val.index }, null);
			HandleValue groupValue = null;
			try {
				req.certify = true;
				AbstractResponse response = resolver.processRequest(req);

				if (response.responseCode == AbstractMessage.RC_SUCCESS
					&& response.opCode == AbstractMessage.OC_RESOLUTION) {
					ResolutionResponse resResponse = (ResolutionResponse) response;
					groupValue = new HandleValue();

					for (int v = 0; v < resResponse.values.length; v++) {
						Encoder.decodeHandleValue(resResponse.values[v], 0, groupValue);
						if (!groupValue.hasType(Common.STD_TYPE_HSVALLIST))
							continue;
						ValueReference valuesInGroup[] = Encoder.decodeValueReferenceList(groupValue.getData(), 0);
						for (int i = 0; i < valuesInGroup.length; i++) {
							if (admin.equals(valuesInGroup[i])) {
								return true;
							} else if (!valuesToTraverse.contains(valuesInGroup[i])
								&& !valuesTraversed.contains(valuesInGroup[i])) {
								valuesToTraverse.addElement(valuesInGroup[i]);
							}
						}
					}
				}
			} catch (Throwable e) {
				System.err.println("Error trying to resolve possible group: " + e);
				e.printStackTrace(System.err);
			}
			valuesToTraverse.removeElementAt(0);
		}

		return false;
	}

	/************************************************************************
	 * Verify that the person who signed the response actually is who they
	 * claim to be, and that the given response is a reply to the given
	 * challenge.  Returns null if the requestor's identity was verified.
	 * Otherwise it returns the error message that should be sent back to
	 * the requestor.
	 
	 * Now added verify identity from session info
	 ************************************************************************/
	private final AbstractResponse verifyIdentity(ChallengeResponse cRes, ChallengeAnswerRequest crReq,
		AbstractRequest origReq) throws HandleException {
		if (cRes == null && crReq == null && authenticatedSession(origReq)) {
			// no challenge/response and there apparently was a session established
			ServerSideSessionInfo sssinfo = getSession(origReq.sessionId);
			if (sssinfo == null) {
				return new ErrorResponse(origReq, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
			}

			// the signature of the origReq shall be a HS_MAC types credential
			if (origReq.signature == null || origReq.signature.length <= 0) {
				//send a challenage response
				return new ErrorResponse(origReq, AbstractMessage.RC_INVALID_CREDENTIAL, Util
					.encodeString("Session request missing MAC code."));
			}

			byte[] sessionKey = sssinfo.getSessionKey();

			try {
				if (sessionKey != null && origReq.verifyMessage(sessionKey))
					return null;
			} catch (Exception e) {
				e.printStackTrace();
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error verifying session key:" + e);
			}
			return new ErrorResponse(origReq, AbstractMessage.RC_INVALID_SESSION_KEY, Util
				.encodeString("Session authentication failed."));
		}

		if (crReq != null && Util.equals(crReq.authType, Common.MD5_SECRET_KEY_TYPE)) {
			// there was a response to a challenge and it was based on a secret key

			// we verify secret keys by asking the responsible server if the
			// given response (md5 hash of the secret_key+nonce+request_digest)
			// is valid for the given challenge.

			VerifyAuthRequest vaReq = new VerifyAuthRequest(crReq.userIdHandle, cRes.nonce, cRes.requestDigest,
				cRes.rdHashType, crReq.signedResponse, crReq.userIdIndex, null);

			vaReq.certify = true;

			// if the callers identity handle lives on this server, find it locally
			// instead of talking to ourself via the network.
			AbstractResponse response;
			if (haveHandle(vaReq.handle)) {
				response = verifyChallenge(vaReq, null, null);
			} else {
				response = resolver.processRequest(vaReq);
			}

			if (response instanceof VerifyAuthResponse) {
				if (((VerifyAuthResponse) response).isValid) {

					//if this is a valid session, 
					//set the client authenticated flag to true.
					//for the first time request, MAC wasn't checked, so check here.
					if (validSession(origReq)) {

						setSessionAuthenticated(origReq, crReq, true);

						boolean MACpass = true;
						ServerSideSessionInfo ssinfo = getSession(origReq.sessionId);
						if (ssinfo != null && ssinfo.getSessionKey() != null) {
							try {
								MACpass = origReq.verifyMessage(ssinfo.getSessionKey());
							} catch (Exception e) {
								System.err.println("Error verifying the original request MAC code:" + e);
								MACpass = false;
							}
						}
						if (MACpass)
							return null;
						else
							new ErrorResponse(origReq, AbstractMessage.RC_INVALID_SESSION_KEY, Util
								.encodeString("The session key authentication failed."));
					}

					return null;
				}
			}
			return new ErrorResponse(origReq, AbstractMessage.RC_AUTHENTICATION_FAILED, null);

		} else if (crReq != null
			&& (Util.equals(crReq.authType, Common.STD_TYPE_HSDSAPUBKEY) || Util.equals(crReq.authType,
				Common.PUBLIC_KEY_TYPE))) {
			// there was a response to a challenge and it was based on a public key

			// verify that the challenge response was signed by the private key
			// associated with the administrators public key.

			// first retrieve the public key (checking server signatures, of course)
			ResolutionRequest req = new ResolutionRequest(crReq.userIdHandle, null, new int[] { crReq.userIdIndex },
				null);
			req.certify = true;
			AbstractResponse response = null;
			// if the callers identity handle lives on this server, find it locally
			// instead of talking to ourself via the network.
			if (haveHandle(req.handle)) {
				response = doResolution(req, null, null);
			} else {
				response = resolver.processRequest(req);
			}

			if (response.getClass() == ResolutionResponse.class) {
				ResolutionResponse rresponse = (ResolutionResponse) response;
				HandleValue values[] = rresponse.getHandleValues();
				if (values == null || values.length < 1) {
					return new ErrorResponse(origReq, AbstractMessage.RC_AUTHENTICATION_FAILED, null);
				}
				try {
					// get the algorithm used to sign
					int algNameLen = Encoder.readInt(crReq.signedResponse, 0);

					int offset = 0;
					byte hashAlgId[] = Encoder.readByteArray(crReq.signedResponse, offset);
					offset += Encoder.INT_SIZE + hashAlgId.length;

					// get the actual bytes of the signature
					byte sigBytes[] = Encoder.readByteArray(crReq.signedResponse, offset);
					offset += Encoder.INT_SIZE + sigBytes.length;

					// decode the public key
					PublicKey pubKey = Util.getPublicKeyFromBytes(values[0].getData(), 0);

					boolean verified = false;

					// get a signature object based on the public key
					Signature sig = Signature.getInstance(Util.getSigIdFromHashAlgId(hashAlgId, pubKey.getAlgorithm()));
					sig.initVerify(pubKey);

					// verify the signature
					sig.update(cRes.nonce);
					sig.update(cRes.requestDigest);

					if (sig.verify(sigBytes)) {

						//if this is a valid session, 
						//set the client authenticated flag to true.
						//for the first time request, MAC wasn't checked, so check here.
						if (validSession(origReq)) {

							setSessionAuthenticated(origReq, crReq, true);

							boolean MACpass = true;
							ServerSideSessionInfo ssinfo = getSession(origReq.sessionId);
							if (ssinfo != null && ssinfo.getSessionKey() != null) {
								try {
									MACpass = origReq.verifyMessage(ssinfo.getSessionKey());
								} catch (Exception e) {
									System.err.println("Error verifying the original request MAC code:" + e);
									MACpass = false;
								}
							}
							if (MACpass)
								return null;
							else
								new ErrorResponse(origReq, AbstractMessage.RC_INVALID_SESSION_KEY, Util
									.encodeString("The session key authentication failed."));
						}

						return null;
					} else {
						return new ErrorResponse(origReq, AbstractMessage.RC_AUTHENTICATION_FAILED, null);
					}
				} catch (Exception e) {
					return new ErrorResponse(origReq, AbstractMessage.RC_AUTHENTICATION_FAILED, null);
				}
			} else {
				return new ErrorResponse(origReq, AbstractMessage.RC_AUTHENTICATION_FAILED, null);
			}
		} else {
			return new ErrorResponse(origReq, AbstractMessage.RC_INVALID_CREDENTIAL, null);
		}
	}

	/************************************************************************
	 * Backup the server's database.
	 * This first authenticates the client based on the server 
	 * administrators listed in the configuration file.
	 ************************************************************************/
	private final AbstractResponse doBackup(GenericRequest req, ChallengeResponse cRes, ChallengeAnswerRequest crReq)
		throws HandleException {
		//if the client is not authenticated, send a challenge
		if ((cRes == null || crReq == null) && !authenticatedSession(req)) {
			return createChallenge(req);
		}

		boolean hasPermission = false;
		Vector valuesToTraverse = new Vector();
		ValueReference thisAdmin = null;

		if (crReq != null) {
			thisAdmin = new ValueReference(crReq.userIdHandle, crReq.userIdIndex);
		} else {
			//an authenticated session is preassumed
			ServerSideSessionInfo ssinfo = getSession(req.sessionId);
			if (ssinfo != null) {
				thisAdmin = new ValueReference(ssinfo.identityKeyHandle, ssinfo.identityKeyIndex);
			} else {
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
			}
		}

		for (int i = 0; i < backupAdmins.length; i++) {
			ValueReference admin = backupAdmins[i];
			if (admin.equals(thisAdmin)) {
				hasPermission = true;
				break;
			} else {
				valuesToTraverse.addElement(admin);
			}
		}

		if (!hasPermission) {
			// the requestor's user ID is not referred to in the
			// backup admins list, so check server admins
			for (int i = 0; i < serverAdmins.length; i++) {
				ValueReference admin = serverAdmins[i];
				if (admin.equals(thisAdmin)) {
					hasPermission = true;
					break;
				} else {
					valuesToTraverse.addElement(admin);
				}
			}

			if (!isAdminInGroup(thisAdmin, valuesToTraverse, new Vector())) {
				return new ErrorResponse(req, AbstractMessage.RC_INVALID_ADMIN, null);
			}
		}

		// If we got to here, then they are in the admin list for this server
		// Now we just need to verify that they are who they claim to be.
		AbstractResponse verifyResp = verifyIdentity(cRes, crReq, req);
		if (verifyResp != null) {
			return verifyResp;
		}

		try {
			storage.checkpointDatabase();
		} catch (Exception e) {
			main.logError(ServerLog.ERRLOG_LEVEL_FATAL, "Error backup server: " + e);
			return new ErrorResponse(req, AbstractMessage.RC_ERROR, MSG_INTERNAL_ERROR);
		}

		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	private final AbstractResponse doSessionTerminate(GenericRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {

		//check client authentication later! use session info, for session is still available right now..
		ServerSideSessionInfo ssinfo = getSession(req.sessionId);
		if (ssinfo != null) {

			boolean authenticated = false;
			try {
				authenticated = req.verifyMessage(ssinfo.getSessionKey());
			} catch (Exception e) {
				System.err.println(e.getMessage());
				authenticated = false;
			}

			if (!authenticated) {
				return new ErrorResponse(req, AbstractMessage.RC_INVALID_SESSION_KEY, Util
					.encodeString("Invalid session key."));
			}
			sessions.removeSession(req.sessionId);
			return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
		} else {
			return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, Util
				.encodeString("Can not get session info."));
		}
	}

	private final AbstractResponse doSessionSetup(SessionSetupRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {
		SessionSetupResponse rsp = new SessionSetupResponse(req, null);

		PublicKey pubKey = null; // the exchange key for SessionInfo
		byte sessionKey[] = null; // the exchange key for SessionInfo
		boolean oldClient = !req.hasEqualOrGreaterVersion((byte) 2, (byte) 2);
		int sessionKeyAlg = oldClient ? HdlSecurityProvider.ENCRYPT_ALG_DES : encryptionAlgorithm;

		if (req.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_HDL) {
			if (!useRSA) {
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("KEY_EXCHANGE_CIPHER_HDL not supported"));
			}
			try {
				HandleValue vals[] = resolver.resolveHandle(Util.decodeString(req.exchangeKeyHandle), null,
					new int[] { req.exchangeKeyIndex });
				HandleValue pubkeyval = null;
				for (int i = 0; vals != null && i < vals.length; i++) {
					if (vals[i].hasType(Common.PUBLIC_KEY_TYPE)) {
						pubkeyval = vals[i];
						break;
					}
				}
				if (pubkeyval == null) {
					main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
						"Error initializing session with hdl cipher: no key found.");
					return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
						.encodeString("No key found in key exchange handle."));
				}
				pubKey = Util.getPublicKeyFromBytes(vals[0].getData(), 0);
				sessionKey = HdlSecurityProvider.getInstance().generateSecretKey(sessionKeyAlg);
				byte encryptKey[] = Util.substring(sessionKey, Encoder.INT_SIZE);
				rsp.data = Util.encrypt(pubKey, oldClient ? encryptKey : sessionKey);
				sessionKey = encryptKey;
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error initializing session with hdl cipher: " + e);
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("Error performing hdl cipher key exchange."));
			}
		} else if (req.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_CLIENT) {
			if (!useRSA) {
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("KEY_EXCHANGE_CIPHER_CLIENT not supported"));
			}
			try {
				pubKey = Util.getPublicKeyFromBytes(req.publicKey, 0);
				sessionKey = HdlSecurityProvider.getInstance().generateSecretKey(sessionKeyAlg);
				byte encryptKey[] = Util.substring(sessionKey, Encoder.INT_SIZE);
				rsp.data = Util.encrypt(pubKey, oldClient ? encryptKey : sessionKey);
				sessionKey = encryptKey;
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error initializing client cipher session: " + e);
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("Error performing client cipher key exchange."));

			}
		} else if (req.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_SERVER) {
			if (!useRSA) {
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("KEY_EXCHANGE_CIPHER_SERVER not supported"));
			}
			try {
				rsp.data = Util.getBytesFromPublicKey(sessions.rsaPubKey);
			} catch (Exception e) {
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error initializing server cipher session: " + e);
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("Error initializing server cipher session: " + e));
			}
		} else if (req.keyExchangeMode == Common.KEY_EXCHANGE_DH) {
			try {
				pubKey = Util.getPublicKeyFromBytes(req.publicKey, 0);
				HdlSecurityProvider provider = HdlSecurityProvider.getInstance();
				DHPublicKey pub = (DHPublicKey) pubKey;
				DHParameterSpec dhSpec = pub.getParams();
				KeyPair kp = provider.generateDHKeyPair(dhSpec.getP(), dhSpec.getG());

				DHPrivateKey priv = (DHPrivateKey) kp.getPrivate();
				rsp.data = Util.getBytesFromPublicKey(kp.getPublic());

				if (!oldClient) {
					sessionKey = provider.getKeyFromDH(pub, priv, encryptionAlgorithm);
					sessionKey = Util.substring(sessionKey, Encoder.INT_SIZE);
					sessionKeyAlg = encryptionAlgorithm;
				} else {
					sessionKey = provider.getDESKeyFromDH(pub, priv);
					sessionKeyAlg = encryptionAlgorithm;
				}
			} catch (Exception e) {
				e.printStackTrace();
				main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Error initializing DH session: " + e);
				return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
					.encodeString("Error encoding public session key"));
			}
		} else {
			return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
				.encodeString("Unrecognized key exchange mode"));
		}
		int sessionId = getNextSessionId();
		rsp.sessionId = sessionId;

		ServerSideSessionInfo sinfo = new ServerSideSessionInfo(sessionId, sessionKey, req.identityHandle,
			req.identityIndex, pubKey, req.keyExchangeMode);
		// set other attributes of the session
		sinfo.setEncryptionAlgorithmCode(sessionKeyAlg);
		sinfo.setTimeOut(req.timeout);
		sinfo.setEncryptedMesssageFlag(req.encryptAllSessionMsg);
		sinfo.setAuthenticateMessageFlag(req.authAllSessionMsg);
		sessions.addSession(sinfo);

		// store the request id of SESSION_SETUP_REQUEST into this modified session
		// info
		sinfo.lastRequestId = req.requestId;
		return rsp;
	}

	/** 
	 * client has sent the session key to finish a KEY_EXCHANGE_CIPHER_SERVER.
	 **/
	private final AbstractResponse doKeyExchange(SessionExchangeKeyRequest req, ChallengeResponse cRes,
		ChallengeAnswerRequest crReq) throws HandleException {

		if (!validSession(req)) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Bad server-cipher key exchange request");
			return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, MSG_INVALID_SESSION_OR_TIMEOUT);
		}

		ServerSideSessionInfo sinfo = sessions.getSession(req.sessionId);

		if (sinfo.keyExchangeMode != Common.KEY_EXCHANGE_CIPHER_SERVER) {
			main.logError(ServerLog.ERRLOG_LEVEL_NORMAL, "Bad server-cipher key exchange request");
			return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
				.encodeString("Invalid session id. Session failed."));
		}

		boolean oldClient = !req.hasEqualOrGreaterVersion((byte) 2, (byte) 2);
		byte[] encSessionKey = req.getEncryptedSessionKey();
		byte[] sessionKey = null;

		// decrypt with server rsa private key
		try {
			sessionKey = Util.decrypt(sessions.rsaPrivKey, encSessionKey);
		} catch (Exception e) {
			return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, Util
				.encodeString("Can't decrypt client session key."));
		}

		int sessionKeyAlg = HdlSecurityProvider.ENCRYPT_ALG_DES;
		if (!oldClient) {
			// the caller is capable of encoding the encryption algorithm
			sessionKeyAlg = Encoder.readInt(sessionKey, 0);
			sessionKey = Util.substring(sessionKey, Encoder.INT_SIZE);
		}

		// replace the session key in the session info
		sinfo.setSessionKey(sessionKey);
		sinfo.setEncryptionAlgorithmCode(sessionKeyAlg);
		return new GenericResponse(req, AbstractMessage.RC_SUCCESS);
	}

	/*
	  RSA VERSION

	  private final AbstractResponse doSessionSetup(SessionSetupRequest req,
	                                                ChallengeResponse cRes,
	                                                ChallengeAnswerRequest crReq)
	                                                throws HandleException
	  {
	    
	    //this is possibly a session setup request 
	    //which specify exchange key info (by giving a public key byte array or key
	    //ref) or not to specify the exchange key info. 
	    //on first case, if client provide exchange key, server verify it is a RSA
	    //key, then it will generate the session key, and set RC_SUCCESS in session
	    //setup response.
	    
	    //on second case, the server needs response with RC_SESSION_EXCHANGEKEY and
	    //pass the rsa public key to client in session setup response.
	    boolean validSession = validSession(req);
	  
	    //now, determining the session id, for new session or modify.
	    int sessionid = 0;
	    byte[] sessionKey = null;
	    byte[] identityHandle = null;
	    int identityIndex = -1;
	    boolean oldUseServerRSAKey = false;
	    boolean oldAuthenticatedUser = false;
	    if (validSession) {
	       
	        //a valid session is assumed. otherwise, time out 
	        sessionid = req.sessionId;
	        ServerSideSessionInfo sssinfo = (ServerSideSessionInfo)getSession(sessionid);
	        if (sssinfo != null) {
	          sessionKey = sssinfo.getSessionKey();
	          identityHandle = sssinfo.identityKeyHandle;
	          identityIndex = sssinfo.identityKeyIndex;
	          oldUseServerRSAKey = sssinfo.useServerRSAKey;
	          oldAuthenticatedUser = sssinfo.clientAuthenticated;
	        } else {
	          return new ErrorResponse(req, AbstractMessage.RC_SESSION_TIMEOUT, 
	                                   MSG_INVALID_SESSION_OR_TIMEOUT);  
	        }
	       
	    }  else {
	    
	      //for a new session.
	      sessionid = getNextSessionId(); 
	    }
	    
	    //determining the exchange key. Might changed for modification from client
	    PublicKey exchangeKey = null;
	    boolean useServerRSAKey = false;
	    if (req.getExchangekeyNew() || req.getExchangekeyRefNew())
	    {
	      //if the request provides the exchange key, grab it, and validate it
	      try {
	        exchangeKey = getSessionExchangePublicKey(req); 
	      }
	      catch (HandleException e) {
	        System.err.println("A RSA public key is required for session exchange. Not a RSA key.");
	        if (e.getCode() == HandleException.NEED_RSAKEY_FOR_SESSIONEXCHANGE) {
	          return new ErrorResponse(req, AbstractMessage.RC_NEED_RSAKEY_FOR_SESSIONEXCHANGE,
	                                   Util.encodeString("Need RSA key for exchange session key. Session failed."));
	        } else 
	          return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                     Util.encodeString("Can't get session exchange key. Session failed."));
	      }
	      
	    } else {
	      //the session setup request has no exchange key info
	      //use the server rsa public key
	      exchangeKey = rsaPublicExchangeKey;
	      useServerRSAKey = true;
	    }
	    
	    if (exchangeKey == null) {
	      if (!useServerRSAKey)
	        return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                   Util.encodeString("Can't get session exchange key. Session failed."));
	      else 
	        return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                   Util.encodeString("Server doesn't provide exchange key. Session failed."));
	    }
	     
	    //if server has no private exchange rsakey
	    if (useServerRSAKey && rsaPrivateExchangeKey==null) {
	      return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                     Util.encodeString("Server doesn't provide exchange key. Session failed."));
	    }
	    
	    //get the key from exchange key handle and index
	    //for now it is the same as the identity handle and index
	    byte[] newSessionKeyGened = null;
	    if ((!validSession || (validSession && oldUseServerRSAKey)) 
	        && exchangeKey!= null && !useServerRSAKey) {
	      try {
	        newSessionKeyGened = SessionManager.getGeneratedSecretKey();
	      }
	      catch (Exception e) {
	        return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                                 Util.encodeString("Can't generate session session key."));
	      }
	    }
	    
	    byte[] encryptedNewSessionkey = null;
	    if (newSessionKeyGened != null) {
	      try {
	        encryptedNewSessionkey = Util.encryptSecretKey(exchangeKey, newSessionKeyGened); 
	      }
	      catch (Exception e){
	        return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                           Util.encodeString("Can not encrypt session key. Please check exchange key is RSA algorithm based."));
	      }
	    }
	          
	    //final action:
	    if (!validSession) {   
	      //set up a new session. session key can be null for a 'server RSA key
	      //used' case
	      ServerSideSessionInfo sssinfo = new ServerSideSessionInfo(sessionid, newSessionKeyGened,
	                                                                req.identityHandle,
	                                                                req.identityIndex,
	                                                                exchangeKey,
	                                                                useServerRSAKey);
	      //set other attributes of the session a brand new session info, where its
	      //request id is -1
	      sssinfo.setTimeOut(req.getTimeOut());
	      sssinfo.setEncryptedMesssageFlag(req.encryptAllSessionMsg);
	      sssinfo.setAuthenticateMessageFlag(req.authAllSessionMsg);
	      sessions.addSessionInfo(sssinfo);
	      
	      SessionSetupResponse ssresp = null;
	      try {
	        if (newSessionKeyGened != null) {
	          //put the encrypted session key into session setup response
	          ssresp = new SessionSetupResponse(req, encryptedNewSessionkey);
	        } else {
	            
	          //put server exchange key into session setup response, and set the
	          //rcCode = RC_SESSION_EXCHANGEKEY
	          ssresp = new SessionSetupResponse(req,
	          Util.getBytesFromPublicKey(exchangeKey), 
	                                            true);
	        }
	        ssresp.sessionId = sessionid;
	        return ssresp;     
	      }
	      catch (Exception e){
	        sessions.removeSessionInfo(sessionid);
	        return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                           Util.encodeString("Can not convert rsa public exchange key to bytes. Session failed."));
	      }
	      
	    } else {
	       //replacing the old server session info, with the new one.
	       //session key, session id are not changed.
	       if (newSessionKeyGened != null) sessionKey = newSessionKeyGened;
	       try {
	         ServerSideSessionInfo
	           sssinfoNew = new ServerSideSessionInfo(sessionid, sessionKey,
	                                                   identityHandle,
	                                                   identityIndex,
	                                                   exchangeKey,
	                                                   useServerRSAKey);
	         //set other attributes of the session
	         sssinfoNew.setTimeOut(req.getTimeOut());
	         sssinfoNew.setEncryptedMesssageFlag(req.encryptAllSessionMsg);
	         sssinfoNew.setAuthenticateMessageFlag(req.authAllSessionMsg);
	         
	         //store the request id of SESSION_SETUP_REQUEST into this modified session info
	         sssinfoNew.lastRequestId = req.requestId;
	         
	         //if a new session key is generated, reset the lastRequest id
	         //the client doesn't know the new session key yet.
	         //can't sign or encrypt this request with the new session key
	         if (encryptedNewSessionkey != null) {
	            sssinfoNew.lastRequestId = -1;
	         }
	         
	         //if the old session is authenticated,
	         sssinfoNew.clientAuthenticated = oldAuthenticatedUser;
	    
	         //server only record the session setup option modification
	         //if there is a valid session, don't change session key, or ask client
	         //to generate session key yet; until the session is time out
	         if (sessions.replaceSessionInfo(sessionid, sssinfoNew)) {
	            
	           if (!oldUseServerRSAKey && useServerRSAKey) {
	             //send the RC_SESSION_EXCHANGEKEY as response code, TEST!!!  if
	             //client changed from providing exchange key to use server
	             //exchange key
	             SessionSetupResponse ssresp = new SessionSetupResponse(req, 
	                             Util.getBytesFromPublicKey(exchangeKey), true); 
	             ssresp.sessionId = sessionid;
	             return ssresp;
	           }
	           
	           SessionSetupResponse ssresp = new SessionSetupResponse(req, encryptedNewSessionkey);
	           ssresp.sessionId = sessionid;
	           return ssresp;     
	         }
	         else  {
	           System.err.println("Error modifying session attributes.");
	           return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                             Util.encodeString("Can't update session attributes."));          
	         }
	       }
	       catch (Exception e) {
	         System.err.println("Error modifying session attributes.");
	         return new ErrorResponse(req, AbstractMessage.RC_SESSION_FAILED, 
	                             Util.encodeString("Can't update session attributes.")); 
	       }
	     }
	  }
	  
	  private PublicKey getSessionExchangePublicKey(SessionSetupRequest req) 
	  throws HandleException
	  {
	    
	    byte[] publicKeyExchangeBytes = null;
	    PublicKey exchangeKey = null;
	    if (req.publicKey != null && req.getExchangekeyNew()) {
	      publicKeyExchangeBytes = req.publicKey;
	    }
	    else
	    {
	      HandleValue keyvalue = getValueFromHandleIndex(req.exchangeKeyHandle, req.exchangeKeyIndex);
	      //only RSA key is allowed here
	      if (keyvalue != null && keyvalue.hasType(Common.STD_TYPE_HSPUBKEY)) { 
	        publicKeyExchangeBytes = keyvalue.getData();
	      } else {
	        System.err.println("A session key ref is not a publickey.");
	        throw new HandleException(HandleException.NEED_RSAKEY_FOR_SESSIONEXCHANGE, 
	                                   "Need RSA Public key for exchange session key.");
	      }
	    }
	    
	    try {
	      exchangeKey = Util.getPublicKeyFromBytes(publicKeyExchangeBytes, 0);
	    }
	    catch (Exception e) {
	      System.err.println("Error getting public key for exchange: " + e.getMessage());   
	      return exchangeKey;
	    }
	       
	    if (exchangeKey != null && !(exchangeKey instanceof RSAPublicKey)) {
	       
	        System.err.println("A RSA key is required for session exchange.");
	        throw new HandleException(HandleException.NEED_RSAKEY_FOR_SESSIONEXCHANGE, 
	                                   "Need RSA Public key for exchange session key.");
	    }
	    return exchangeKey;
	  }
	*/

	//used for any request.
	private boolean validSession(AbstractRequest req) {
		if (req.sessionId == 0)
			return false;

		ServerSideSessionInfo sssinfo = getSession(req.sessionId);
		if (sssinfo != null) {
			// possible place to stop replay! 
			// the request Id can not be repeating after certain time, like 2 minutes...
			if (req.requestId > sssinfo.lastRequestId) {
				sssinfo.lastRequestId = req.requestId;
			}
			return true;
		}
		return false;

	}

	//used to check for admin request:
	//if the session has been "challege response" authenticated, return true;
	//otherwise return false
	private boolean authenticatedSession(AbstractRequest req) {
		if (req.sessionId == 0)
			return false;

		ServerSideSessionInfo sssinfo = getSession(req.sessionId);

		if (sssinfo != null) {
			if (sssinfo.isSessionAnonymous())
				return false;

			//possible place to stop replay! 
			//the request Id can not be repeating after certain time, like 2 minutes...
			if (req.requestId > sssinfo.lastRequestId) {
				sssinfo.lastRequestId = req.requestId;
			}

			if (sssinfo.clientAuthenticated) {
				return true;
			}

		}
		return false;
	}

	//set the session given by session id as client authenticated.
	//please take note that all the req.authInfo is null in server side (this method)
	//even for administrative request.
	//this is because the decode message process can't re-produce the authInfo
	//on server side.
	//please see Encoder.java, all decodeMessage methods.
	//we can only compare the auth handle and auth index in challenge answer request
	//and in the session info.
	private void setSessionAuthenticated(AbstractRequest req, ChallengeAnswerRequest caReq, boolean authenticated) {
		ServerSideSessionInfo ssinfo = null;
		if (req != null && req.sessionId > 0) {
			ssinfo = getSession(req.sessionId);
		}
		if (ssinfo != null) {
			if (authenticated) {
				//we have to have the identityHandle and index not null

				if (ssinfo.identityKeyHandle == null || ssinfo.identityKeyIndex < 0) {
					//can not set the authenticated flag
					return; //don't set the authenticated flag to an anonymous session
				} else {
					//if the session has identity handle and index set,
					//check if they match in the request
					if (!Util.equals(ssinfo.identityKeyHandle, caReq.userIdHandle)
						|| ssinfo.identityKeyIndex != caReq.userIdIndex) {
						return; //don't set the authenticated flag to true if the identity doesn't match in the req
					}
				}
			}

			//set the authenticated flag
			ssinfo.clientAuthenticated = authenticated;
		}
		return;
	}

	public ServerSideSessionInfo getSession(int sessionId) {
		if (sessions == null)
			return null;
		return sessions.getSession(sessionId);
	}

	/** Returns an object that can be synchronized in order to avoid performing
	  * conflicting operations on the given handle.  */
	private Object getWriteLock(byte hdl[]) {
		// quickly construct an index into the lockHash which is based on
		// the local part of the handle (case insensitive)
		int idx = 0;
		for (int i = hdl.length - 1; i >= 0; i--) {
			if (hdl[i] == '/')
				break;
			idx += Character.toLowerCase((char) hdl[i]);
		}
		idx = Math.abs(idx);
		return lockHash[idx % lockHash.length];
	}

	@Override
	public final void shutdown() {
		keepRunning = false;
		sessions.shutdown();
		txnQueue.shutdown();
		storage.shutdown();
	}

}
