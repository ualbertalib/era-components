/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import java.security.*;
import java.security.interfaces.*;
import java.io.*;

/**********************************************************************
 * Utility used to generate server keys that can be used to sign
 * certified handle messages.
 * <pre>
 * usage: java net.handle.server.ServerKeyGenerator <algorithm> [<provider>] <publickeyfile> <privatekeyfile> <strength#>
 *
 * </pre>
 *
 **********************************************************************/
public class ServerKeyGenerator
{

  private static final void printUsage() {
    System.err.println("usage: java net.handle.server.ServerKeyGenerator <algorithm> [<provider>] <publickeyfile> <privatekeyfile> <strength#>");
  }


  public static void main(String argv[]) 
    throws Exception
  {
    if(argv.length<4) {
      printUsage();
      System.exit(1);
    }
    int argN = 0;
    String alg = argv[argN++];
    String provider = null;
    if(argv.length>4)
      provider = argv[argN++];
    String pubKeyFile = argv[argN++];
    String privKeyFile = argv[argN++];
    String strengthStr = argv[argN++];
    int strength = Integer.parseInt(strengthStr);
    
    KeyPairGenerator kpg = null;
    if(provider==null)
      kpg = KeyPairGenerator.getInstance(alg);
    else
      kpg = KeyPairGenerator.getInstance(alg, provider);
    
    System.err.print("initializing KeyPairGenerator... ");
    kpg.initialize(strength);
    System.err.println("done");
    
    System.err.print("Generating KeyPair...  ");
    KeyPair keys = kpg.generateKeyPair();
    System.err.println("done");
    
    // read the passphrase and use it to encrypt the private key
    byte secKey[] = Util.getPassphrase("Please enter the private key passphrase: ");
    byte secKey2[] = Util.getPassphrase("Please re-enter the private key passphrase: ");

    if(!Util.equals(secKey, secKey2)) {
      System.err.println("Passphrases do not match!  Keys not saved.");
      return;
    }
    

    // get the private key bytes unencrypted
    PrivateKey priv = keys.getPrivate();
    byte keyBytes[] = Util.getBytesFromPrivateKey((DSAPrivateKey)priv);

    // encrypt them
    
    FileOutputStream dbgOut = new FileOutputStream("./privkey.clear");
    dbgOut.write(keyBytes);
    dbgOut.close();

    byte encKeyBytes[];
    if(secKey==null || secKey.length<=0) {
      encKeyBytes = Util.encrypt(keyBytes, secKey, Common.ENCRYPT_NONE);
    } else {
      encKeyBytes = Util.encryptIfPossible(keyBytes, secKey);
    }
    for(int i=0; i<keyBytes.length; i++) keyBytes[i]=(byte)0;
    for(int i=0; i<secKey.length; i++) secKey[i] = (byte)0;

    FileOutputStream out = new FileOutputStream(privKeyFile);
    out.write(encKeyBytes);
    try { out.close(); } catch (Exception e) {}
    System.out.println("saved private key to "+privKeyFile);

    PublicKey pub = keys.getPublic();
    out = new FileOutputStream(pubKeyFile);
    out.write(Util.getBytesFromPublicKey((DSAPublicKey)pub));
    try { out.close(); } catch (Exception e) {}
    System.out.println("saved public key to "+pubKeyFile);
  }


}
