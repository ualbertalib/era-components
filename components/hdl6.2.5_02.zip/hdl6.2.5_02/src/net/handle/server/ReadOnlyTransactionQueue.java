/**********************************************************************\
 ® COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.util.*;
import java.util.*;
import java.io.*;
import java.lang.reflect.Method;

/***********************************************************************
 * Class responsible for keeping track of the different transaction
 * queue files.  This does the same thing as the TransactionQueue class
 * except it only reads transactions and never writes them.
 *
 * Individual records within each transaction log look something like this:
 <pre>
 &lt;CRLF&gt;&lt;txnID&gt;|&lt;action&gt;|&lt;date&gt;|&lt;hashOnAll&gt;|&lt;hashOnNA&gt;|&lt;hashOnId&gt;|&lt;handle-hex-encoded&gt;|
</pre>
 ***********************************************************************/
public class ReadOnlyTransactionQueue
  implements TransactionQueueInterface
{
  
  private File queueDir;
  private File queueIndexFile;
  private Vector cachedQueueFiles;
  private long indexModDate = 0;
  private Calendar calendar;

  class QueueFileEntry {
    private long startDate;
    private long firstTxnId;
    private int queueNumber;
    private File queueFile = null;

    QueueFileEntry(long startDate, long firstTxnId, int queueNumber) {
      this.startDate = startDate;
      this.firstTxnId = firstTxnId;
      this.queueNumber = queueNumber;
    }

    long getStartDate() { return startDate; }
    long getFirstTxnId() { return firstTxnId; }
    long getQueueNumber() { return queueNumber; }

    synchronized File getQueueFile() {
      if(queueFile==null) {
        queueFile = new File(queueDir, String.valueOf(queueNumber)+".q");
      }
      return queueFile;
    }

    public String toString() {
      return String.valueOf(queueNumber)+"; firsttxn="+firstTxnId+"; startDate="+startDate+
        "; file="+queueFile;
    }
    
    public boolean equals(Object obj) {
      if(obj instanceof QueueFileEntry) {
        if(((QueueFileEntry)obj).getQueueNumber()==queueNumber)
          return true;
      }
      return false;
    }
  }

  public ReadOnlyTransactionQueue(File queueDir) 
    throws Exception 
  {
    this.queueDir = queueDir;
    this.queueIndexFile = new File(queueDir, "index");
    calendar = Calendar.getInstance();
    loadIndex();
  }

  public synchronized long getFirstDate() {
    Vector queueFiles = null;
    try {
      queueFiles = loadIndex();
    } catch (Exception e) {
      System.err.println("Error trying to read queue:  "+e);
      e.printStackTrace(System.err);
      System.err.println("returning value that may cause a reload!");
      return Long.MAX_VALUE;
    }
    if(queueFiles.size()<=0) return Long.MAX_VALUE;
    QueueFileEntry entry = (QueueFileEntry)queueFiles.elementAt(0);
    return entry.startDate;
  }
  
  public synchronized long getLastTxnId() {
    Vector queueFiles = null;
    try {
      queueFiles = loadIndex();
    } catch (Exception e) {
      System.err.println("Error trying to read queue:  "+e);
      e.printStackTrace(System.err);
      System.err.println("returning value that may cause a reload!");
      return Long.MAX_VALUE;
    }
    
    if(queueFiles.size()<=0) return 0;
    long txnId = 0;
    try {
      QueueScanner scanner =
        new QueueScanner(queueFiles, (QueueFileEntry)queueFiles.elementAt(queueFiles.size()-1));
      while(true) {
        Transaction txn = scanner.nextTransaction();
        if(txn!=null) txnId = txn.txnId;
        if(txn==null) break;
      }
    } catch (Exception e) {
      System.err.println("Error getting transaction ID: "+e+"\n   using "+txnId);
    } finally {
      // after doing something big like retrieving transaction logs, we
      // should garbage collect to free up memory and close open files..
      try {
        System.gc();
        System.runFinalization();
      } catch (Throwable t) {}
    }
    return txnId;
  }


  private synchronized int getQueueFileName(Date dt) {
    calendar.setTime(dt);
    return 
      calendar.get(Calendar.YEAR)*10000 +
      calendar.get(Calendar.MONTH)*100 +
      calendar.get(Calendar.DAY_OF_MONTH);
  }

  private synchronized Vector loadIndex()
    throws Exception
  {
    if(!queueIndexFile.exists()) {
      if(cachedQueueFiles==null)
        cachedQueueFiles = new Vector();
      return cachedQueueFiles;
    }
    
    if(queueIndexFile.lastModified()==indexModDate && cachedQueueFiles!=null) {
      return cachedQueueFiles;
    }
    
    Vector queueFiles = new Vector();
    long modDate = queueIndexFile.lastModified();
    BufferedReader reader = new BufferedReader(new FileReader(queueIndexFile));
    while(true) {
      String line = reader.readLine();
      if(line==null) 
        break;
      line = line.trim();
      if(line.length()<=0) 
        continue;
      long startDate = Long.parseLong(StringUtils.fieldIndex(line,'\t',0));
      long firstTxnId = Long.parseLong(StringUtils.fieldIndex(line,'\t',1));
      int queueNumber  = Integer.parseInt(StringUtils.fieldIndex(line,'\t',2));
      queueFiles.addElement(new QueueFileEntry(startDate, firstTxnId, queueNumber));
    }
    cachedQueueFiles = queueFiles;
    indexModDate = modDate;
    return queueFiles;
  }
  
  /** Not implemented in a read-only queue.  Calling this method will throw an exception. */
  public void addQueueListener(TransactionQueueListener l) {
    System.err.println("Warning: listener added to a transaction queue that does not support listeners");
  }
  
  public void removeQueueListener(TransactionQueueListener l) {}
  
  
  /** Log the specified transaction */
  public void addTransaction(long txnId, byte handle[], byte action, long date)
    throws Exception
  {
    throw new HandleException(HandleException.STORAGE_RDONLY,
                              "Transaction queue is read-only");
  }

  /*******************************************************************************
   * Log the specified transaction to the current queue (creating a new queue, if 
   * necessary
   *******************************************************************************/
  protected synchronized void addTransaction(Transaction txn) 
    throws Exception
  {
    throw new HandleException(HandleException.STORAGE_RDONLY,
                              "Transaction queue is read-only");
  }

  private synchronized QueueFileEntry getNextQueue(Vector queueFiles, QueueFileEntry presentQueue) {
    for(int i=queueFiles.size()-2; i>=0; i--) {
      QueueFileEntry qfe = (QueueFileEntry)queueFiles.elementAt(i);
      if(qfe==presentQueue) {
        return (QueueFileEntry)queueFiles.elementAt(i+1);
      }
    }
    
    // the called must have the last queue already...
    return null;
  }

  
  protected int nextField(int currPos, String txnStr)
    throws Exception
  {
    if(currPos>=txnStr.length())
      throw new Exception("No more fields in transaction");
    int i=currPos+1;
    for( ; i<txnStr.length(); i++) {
      if(txnStr.charAt(i)=='|') {
        return i;
      }
    }
    throw new Exception("Invalid transaction record: "+txnStr);
  }

  protected Transaction decodeTransaction(String txnStr) {
    try {
      int sepIdx = -1;
      Transaction txn = new Transaction();
      txn.txnId = 
        Long.parseLong(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.action = 
        (byte)Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.date = 
        Long.parseLong(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.hashOnAll = 
        Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.hashOnNA = 
        Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.hashOnId = 
        Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.handle = 
        Util.encodeHexString(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      return txn;
    } catch (Exception e) {
      System.err.println("Exception decoding transaction: \n  "+txnStr+
                         "\n  "+e);
      e.printStackTrace(System.err);
    }
    return null;
    
  }

  public synchronized void shutdown() { }


  public synchronized TransactionScannerInterface getScanner(long lastTxnID) 
    throws Exception
  {
    Vector queueFiles = loadIndex();
    if(queueFiles.size()<=0) { // shouldn't happen!
      return null;
    }

    QueueFileEntry queueEntry = null;
    for(int i=0; i<queueFiles.size(); i++) {
      QueueFileEntry nextEntry = (QueueFileEntry)queueFiles.elementAt(i);
      if(nextEntry.firstTxnId>=0 && nextEntry.firstTxnId>lastTxnID) {
        if(queueEntry==null) {
          // this is the first daily queue and it doesn't include the last
          // received txn... bad news... the requestor will have to redump
          return new QueueScanner(queueFiles, nextEntry);
        } else {
          // this queue starts with later txn ID than the requestor is
          // asking for, so the previous queue should have what he wants.
          return new QueueScanner(queueFiles, queueEntry);
        }
      }
      queueEntry = nextEntry;
    }
    
    if(queueEntry==null) {
      // no queues found?  shouldn't get here.
      return new QueueScanner(queueFiles, (QueueFileEntry)queueFiles.elementAt(0));
    }

    // return a scanner for the most recent queue
    return new QueueScanner(queueFiles, queueEntry);
  }

  public class QueueScanner
    implements TransactionScannerInterface
  {
    private Vector queueFiles;
    private BufferedReader reader;
    private QueueFileEntry queueFileEntry;
    private long firstDateInLog;

    protected QueueScanner(Vector queueFiles, QueueFileEntry queueFileEntry)
      throws Exception
    {
      this.queueFiles = queueFiles;
      firstDateInLog = queueFileEntry.getStartDate();
      connectToQueue(queueFileEntry);
    }

    public long getFirstDateInLog() {
      return firstDateInLog;
    }
    
    private void connectToQueue(QueueFileEntry nextQueue)
      throws Exception
    {
      queueFileEntry = nextQueue;
      reader = null;
      try {
        File f = queueFileEntry.getQueueFile();
        if(f.exists() && f.canRead()) {
          reader = new BufferedReader(new FileReader(f));
        } else {
          throw new Exception("Cannot access file: "+f);
        }
      } catch (Exception e) {
        throw new Exception("Unable to open transaction log: "+e);
      } finally {
        System.gc();
        System.runFinalization();
      }
    }
    
    public synchronized Transaction nextTransaction() 
      throws Exception
    {
      String line = null;
      do {
        line = reader.readLine();
        if(line==null) {
          // reached end of queue file.  if there are no more queues, we're done.
          // otherwise, start scanning the next queue.
          QueueFileEntry nextQueue = getNextQueue(queueFiles, queueFileEntry);
          if(nextQueue==null) {
            // end of the line... no more queues
            return null;
          } else {
            connectToQueue(nextQueue);
          }
        } else if(line.trim().length()>0) {
          Transaction txn = decodeTransaction(line);
          // skip placeholder transactions..
          if(txn.action!=Transaction.ACTION_PLACEHOLDER) {
            return txn;
          }
        }
      } while(true);
    }


    public void close() {
      try {
        reader.close();
      } catch (Exception e) {}
    }
    
  }


  class Shutdown implements Runnable
  {
    public void run(){
      try {
        shutdown();
      } catch (Throwable t) {
        System.err.println("Error finalizing txn queue: "+t);
      }
    }
  }

}

