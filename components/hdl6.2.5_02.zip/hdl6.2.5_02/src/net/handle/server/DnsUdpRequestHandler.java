/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.dnslib.*;
import net.handle.util.*;
import java.net.*;
import java.util.*;

/**
  *    Description:  A DnsUdpRequestHandler object will handle requests submitted using
  *                  the BIND protocol.  The requests for DNS names will be translated
  *                  into handle names and resolved using the specified handle source
  *                  object.  After the resolution is made, a response is returned
  *                  using the DNS BIND protocol.
*/

public class DnsUdpRequestHandler
  implements Runnable, RequestHandler, DnsUdpConstants, ResponseMessageCallback
{
  public static final boolean DEBUG=true;
  
  private DatagramPacket packet;
  private byte currentHandle[] = null;
  private DNSMessage currentRequest = null;
  private ResolutionRequest hdlRequest =
    new ResolutionRequest(Util.encodeString(""), null, null, null);
  
  private DatagramSocket dsocket;
  private AbstractServer server;
  private Main main;
  private DnsUdpInterface listener;
  
  private Thread handlerThread;
  private int invocations = 0;
  private boolean isActive=true;
  private boolean isRunning=false;
  private boolean logAccesses=false;
  private long recvTime;
  private RequestHandlerPool handlerPool = null;

  private boolean lookForParent = false;
  private String dnsHandlePrefix;

  public DnsUdpRequestHandler(Main main, DatagramSocket dsock, 
                              RequestHandlerPool handlerPool,
                              DnsUdpInterface listener,
                              String dnsToHandlePrefix,
                              boolean logAccesses)
  {
    this.main = main;
    this.server = main.getServer();
    this.dsocket = dsock;
    this.handlerPool = handlerPool;
    this.logAccesses = logAccesses;
    this.listener = listener;
    this.dnsHandlePrefix = dnsToHandlePrefix;

    /*
    DNSCache dnsCache = null;
    if(configuration.containsKey("dns_cache_file")) {
      try {
	dnsCache = DNSCache.getInstance((String)configuration.get("dns_cache_file"));
      } catch (Exception e) {
	main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
		      "Unable to instantiate DNS cache ("+e+"), continuing without cache.");
      }
    }
    */

    handlerThread = new Thread(this);
    handlerThread.start();
  }

  public void resetThread() { }
  
  public synchronized void deactivate() {
    isActive = false;
    resetState();
  }
  
  public int getInvocationCount() {
    return invocations;
  }
  
  public void resetState() {
    isRunning = false;
  }

  public RequestHandler newHandler() {
    return new DnsUdpRequestHandler(main, dsocket, handlerPool, listener,
                                    dnsHandlePrefix, logAccesses);
  }
  
  public synchronized void serviceRequest(DatagramPacket packet, long recvTime) {
    this.packet = packet;
    this.recvTime = recvTime;
    isRunning = true;
    notify();
  }
  
  public void run() {
    while(isActive) {
      byte pkt[] = null;
      int pktLen = 0;
      int offset = 0;
      
      synchronized(this) {
        while(!isRunning && isActive) {
          try {
            wait();
            if(!isRunning) {
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "hdl-udp error: invalid handler thread state");
            }
          } catch (Exception e) {
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                          String.valueOf(getClass())+"Got exception: "+e);
          }
        }
      }
      
      if(!isActive) continue;

      try {
        handleRequest();
      } catch (Exception e) {
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      String.valueOf(this.getClass())+": Exception processing request: "+e);
      } finally {
        // return the handler to the pool.
        //System.err.println("returning to pool...");
        handlerPool.returnHandler(this);
      }
    }
  }
  
  
  /** Translate the DNS style name into a handle. */
  private String convertDNSNameToHandleStr(String dnsName[]) {
    StringBuffer handleName = new StringBuffer(dnsHandlePrefix);
    boolean lastName=false;
    for(int i=dnsName.length-1; i>=0; i--) {
      if(i!=0) {
        handleName.append('.');
      } else {
        handleName.append('/');
      }
      handleName.append(dnsName[i].toUpperCase());
    }
    return handleName.toString();
  }
  
  /** Converts dns request types into handle request types - Currently ignores DNS "class".
   *  <pre> Current DNS->HDL record type mapping
   *  | DNS TYPE  | HANDLE TYPE |
   *  |     A     |  INET_HOST  |
   *  |    NS     |   65555     |
   *  |    MD     |   11003     |
   *  |    MF     |   11004     |
   *  |  CNAME    |   11005     |
   *  |   SOA     |   11006     |
   *  |    MB     |   11007     |
   *  |    MG     |   11008     |
   *  |    MR     |   11009     |
   *  |   NULL    |   11010     |
   *  |   WKS     |   11011     |
   *  |   PTR     |   11012     |
   *  |  HINFO    |   11013     |
   *  |  MINFO    |   11014     |
   *  |    MX     |   11015     |
   *  |   TXT     |   11016     |
   * </pre>
   */
  public byte[] dnsToHandleType(int dnsType, int dnsClass) {
    switch(dnsType) {
      case DNSMessage.TYPE_A:
        return HDL_DNS_TYPE_A;
      case DNSMessage.TYPE_NS:
        return HDL_DNS_TYPE_NS;
      case DNSMessage.TYPE_MD:
        return HDL_DNS_TYPE_MD;
      case DNSMessage.TYPE_MF:
        return HDL_DNS_TYPE_MF;
      case DNSMessage.TYPE_CNAME:
        return HDL_DNS_TYPE_CNAME;
      case DNSMessage.TYPE_SOA:
        return HDL_DNS_TYPE_SOA;
      case DNSMessage.TYPE_MB:
        return HDL_DNS_TYPE_MB;
      case DNSMessage.TYPE_MG:
        return HDL_DNS_TYPE_MG;
      case DNSMessage.TYPE_MR:
        return HDL_DNS_TYPE_MR;
      case DNSMessage.TYPE_NULL:
        return HDL_DNS_TYPE_NULL;
      case DNSMessage.TYPE_WKS:
        return HDL_DNS_TYPE_WKS;
      case DNSMessage.TYPE_PTR:
        return HDL_DNS_TYPE_PTR;
      case DNSMessage.TYPE_HINFO:
        return HDL_DNS_TYPE_HINFO;
      case DNSMessage.TYPE_MINFO:
        return HDL_DNS_TYPE_MINFO;
      case DNSMessage.TYPE_MX:
        return HDL_DNS_TYPE_MX;
      case DNSMessage.TYPE_TXT:
        return HDL_DNS_TYPE_TXT;
      default: 
        return null;
    }
  }


  /**
   * Parse the DNS request from the UDP and convert it to a handle request
   * that is sent to the back-end for processing.
   */
  private void handleRequest() {
    invocations++;
    currentRequest = new DNSMessage(packet.getData(), 0, packet.getLength());
    
    if(DEBUG) {
      System.err.print("\n>>>Got Request: ");
      for(int i=0; i < currentRequest.questions.length; i++) {
        if(i!=0) System.err.print("; ");
        currentRequest.questions[i].printValues(System.err);
      }
    }
    DNSResolver.DEBUG = false;
    currentRequest.recursionAvailable = false;
    
    if(currentRequest.opcode == DNSMessage.OP_QUERY) {  // resolution request
      if(currentRequest.questions==null || currentRequest.questions.length<=0) {
        currentRequest.opcode = DNSMessage.RC_FORMAT_ERROR;
        currentRequest.authAnswer=true;
        currentRequest.setDirty();
        sendResponse(currentRequest);
      } else {
        byte hdlTypeList[][] = new byte[currentRequest.questions.length][];
        String hdlName = null;
        for(int i=0; i<hdlTypeList.length; i++) {
          DNSQuestion dnsQ = currentRequest.questions[i];
          hdlTypeList[i] = dnsToHandleType(dnsQ.qType, dnsQ.qClass);
          if(i==0)
            hdlName = convertDNSNameToHandleStr(dnsQ.qName);
        }
        hdlRequest.handle = Util.encodeString(hdlName);
        hdlRequest.requestedTypes = hdlTypeList;
        hdlRequest.requestedIndexes = null;
        try {
          server.processRequest(hdlRequest, null);
        } catch (HandleException e) {
          main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                        String.valueOf(this.getClass())+": Exception processing request: "+e);
        }
//        // resolve using DNS
//        DNSQuestion firstQuestion = request.questions[0];
//        String dnsName[] = firstQuestion.qName;
//        
//        for(int i=0; i<resolutionOrder.length; i++) {
//          if(resolutionOrder[i]==USE_DNS) {
//            // try to resolve using DNS
//            if(DEBUG) {
//              System.err.println("--Trying to resolve using DNS");
//            } else {
//              //System.err.print('d');
//            }
//            
//            DNSMessage dnsResults=null;
//            try {
//              dnsResults = dnsResolver.resolveNameRecursively(dnsName,
//                                                              firstQuestion.qType,
//                                                              firstQuestion.qClass,
//                                                              responsibleNameServers,0);
//            } catch (Exception dnsException) {
//              if(DEBUG) {
//                System.err.println("Error trying to resolve using DNS: "+dnsException);
//                dnsException.printStackTrace(System.err);
//              }
//            }
//            
//            if(dnsResults!=null) {   // the name was found using DNS
//              request.answers = dnsResults.answers;
//              request.nameServers = dnsResults.nameServers;
//              request.additionalResources = dnsResults.additionalResources;
//              request.isQuery = dnsResults.isQuery;
//              request.authAnswer = false; //dnsResults.authAnswer;
//              request.truncated = dnsResults.truncated;
//              request.recursionAvailable = true;
//              request.responseCode = dnsResults.responseCode;
//              request.setDirty();
//              sendResponse(request);
//              return;
//            }
//          } else {
//            // try to resolve using the handle system
//            if(DEBUG) {
//              System.err.println("--Trying to resolve using handle system: "+
//                                 convertDNSNameToHandle(dnsName));
//            } else {
//              //System.err.print('h');
//            }
//            long requestedType = dnsToHandleType(firstQuestion.qType, firstQuestion.qClass);
//            boolean foundRecord = false;
//            long typesWanted[] = { requestedType, PRIMARY_NAME_SERVER_TYPE };
//            long addressTypesWanted[] = { PRIMARY_NAME_SERVER_TYPE };
//            
//            // try to find the handle, or a handle for one of the parent "domains".
//            ResponsePacketBody returnElements[] = null;
//            String hdlName[] = dnsName;
//            int numTries=0;
//            while (returnElements==null && hdlName.length>0) {
//              try {
//                numTries++;
//                String handleName = convertDNSNameToHandle(hdlName);
//                boolean authenticate = false;
//                if(numTries>1)
//                  returnElements = handleSource.getHandleData(handleName,
//                                                              addressTypesWanted,
//                                                              false);
//                else
//                  returnElements = handleSource.getHandleData(handleName,
//                                                              typesWanted,
//                                                              false);
//              } catch (Exception e) {}
//              if(returnElements!=null && returnElements.length>0) {
//                if(numTries==1)
//                  foundRecord = true;
//                break;
//              }
//              if(!lookForParent) // if we only want an exact match, don't loop.
//                break;
//              
//              String tmpName[] = new String[hdlName.length-1];
//              System.arraycopy(hdlName,1,tmpName,0,tmpName.length);
//              hdlName = tmpName;
//            }
//            
//            // if we didn't get anything, then just forget it...
//            if(returnElements!=null) {
//              server.processRequest(resReq, this);
//              
//              if(foundRecord) { // we found the name...
//                HandleElement requestedElements[] = elements.getElementsOfType(requestedType);
//                DNSResourceRecord requestedRecords[] = new DNSResourceRecord[requestedElements.length];
//                if(requestedRecords.length>0) { // we found the requested record type
//                  for(int a=0; a<requestedRecords.length; a++) {
//                    try {
//                      requestedRecords[a] = 
//                      new DNSResourceRecord(dnsName,firstQuestion.qType,
//                                            firstQuestion.qClass, 864000,
//                                            InetAddress.getByName(new String(requestedElements[a].
//                                                                             handleValue)).getAddress());
//                    } catch (UnknownHostException e) {
//                      if(DEBUG){
//                        System.err.println("Ugly error: "+e);
//                        e.printStackTrace(System.err);
//                      }
//                      main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,"error getting host address: "+e);
//                    }
//                  }
//                  request.answers = requestedRecords;
//                  request.setDirty();
//                  sendResponse(request);
//                  return;
//                } else {  // we only got the server info.
//                  if(responsibleNameServers==null && willNeedNameServers(i))
//                    responsibleNameServers = getNameServers(elements.getElementsOfType(PRIMARY_NAME_SERVER_TYPE));
//                }
//              } else if(returnElements!=null) { // we found a parent of the name...
//                if(responsibleNameServers==null && willNeedNameServers(i))
//                  responsibleNameServers = getNameServers(elements.getElementsOfType(PRIMARY_NAME_SERVER_TYPE));
//              }
//            }
//          }
//        }
        
        System.err.println("no records found.  returning error");
        // none of the resolution methods worked, send a not-found error.
        currentRequest.responseCode = DNSMessage.RC_NAME_ERROR;
        currentRequest.setDirty();
        sendResponse(currentRequest);
      }
    } else if(currentRequest.opcode == DNSMessage.OP_IQUERY) { // inverse resolution request
      System.err.println("Got unexpected OPCODE: OP_IQUERY");
      currentRequest.responseCode = DNSMessage.RC_NOT_IMPLEMENTED;
      currentRequest.setDirty();
      sendResponse(currentRequest);
    } else if(currentRequest.opcode == DNSMessage.OP_STATUS) { // status request
      System.err.println("Got unexpected OPCODE: OP_STATYUS");
      currentRequest.responseCode = DNSMessage.RC_NOT_IMPLEMENTED;
      currentRequest.setDirty();
      sendResponse(currentRequest);
    } else {
      System.err.println("Got unknown OPCODE: "+currentRequest.opcode);
      currentRequest.responseCode = DNSMessage.RC_NOT_IMPLEMENTED;
      currentRequest.setDirty();
      sendResponse(currentRequest);
    }
  }

//  private boolean willNeedNameServers(int currentPosition) {
//    currentPosition++;
//    while(currentPosition<resolutionOrder.length)
//      if(resolutionOrder[currentPosition++]==USE_DNS)
//	return true;
//    return false;  
//  }

  public void printPacket(DatagramPacket pkt) {
    byte buf[] = pkt.getData();
    for(int i=0; i<pkt.getLength(); i++) {
      if(i%16==0 && i!=0) System.err.print("\n");
      if(buf[i]>='a' && buf[i]<='z' ||
         buf[i]>='A' && buf[i]<='Z' ||
         buf[i]=='.')
        System.err.print(" "+((char)(buf[i])));
      else
        System.err.print(" \\"+(buf[i]&0x0ff));
    }
    System.err.print("\n");
  }
  
  public void handleResponse(AbstractResponse response) {
    System.err.println("Need to send DNS response: "+response);
    
    //if(response instanceof ResolutionResponse) {
    //  ResolutionResponse rresponse = (ResolutionResponse)response;
    //  HandleValue values[] = rresponse.getHandleValues();
    //  DNSResourceRecord requestedRecords[] = new DNSResourceRecord[requestedElements.length];
    //}
    
    
    //                if(requestedRecords.length>0) { // we found the requested record type
    //                  for(int a=0; a<requestedRecords.length; a++) {
    //                    try {
    //                      requestedRecords[a] = 
    //                      new DNSResourceRecord(dnsName,firstQuestion.qType,
    //                                            firstQuestion.qClass, 864000,
    //                                            InetAddress.getByName(new String(requestedElements[a].
    //                                                                             handleValue)).getAddress());
    //                    } catch (UnknownHostException e) {
    //                      if(DEBUG){
    //                        System.err.println("Ugly error: "+e);
    //                        e.printStackTrace(System.err);
    //                      }
    //                      main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,"error getting host address: "+e);
    //                    }
    //                  }
    //                  request.answers = requestedRecords;
    //                  request.setDirty();
    //                  sendResponse(request);
    //                  return;
    
    
    
    
    
    
    
    
    if(logAccesses){
      long time = System.currentTimeMillis() - recvTime;
      if(response==null) {
        main.logAccess(ACCESS_TYPE, packet.getAddress(),
                       0, 0, "?", time);
      } else {
        main.logAccess(ACCESS_TYPE, packet.getAddress(),
                       response.opCode,
                       response.responseCode,
                       Util.decodeString(hdlRequest.handle), time);
      }
    }
  }

  private void sendResponse(DNSMessage dnsMessage) {
    InetAddress addr = packet.getAddress();
    int port = packet.getPort();
    byte buf[] = dnsMessage.getPacketBuffer();
    try {
      //System.err.println("");
      //System.err.println("Returning bytes: ");
      //DNSResourceData.printBytes(System.err,buf,0,buf.length);
      dsocket.send(new DatagramPacket(buf,buf.length,addr,port));
      if(DEBUG) {
	System.err.print("<<<Sending Response with "+
			 dnsMessage.answers.length+" answers, "+
			 dnsMessage.nameServers.length+" nameservers, and "+
			 dnsMessage.additionalResources.length+" addt'l resrcs to: ");
	dnsMessage.questions[0].printValues(System.err);
	//dnsMessage.printValues(System.err);
      } else {
	//System.err.print((dnsMessage.answers.length>0 ? 'S':'X'));
      }
      //(new DNSMessage(buf,0,buf.length)).printValues(System.err);
    } catch (java.io.IOException e) {
      main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
		    String.valueOf(this.getClass())+": unable to send response packet to "+addr+":"+port);
    }
  }


}
