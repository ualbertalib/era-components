/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.util.*;
import java.net.*;
import java.util.*;

/**
 *    Description:  Object that listens for UDP-BIND requests and passes them off
 *                  to a DnsUdpRequestHandler.java object to be handled.
 *
 *    @author  Sean Reilly <p>
 *    @see DnsUdpRequestHandler.java
 */

public class DnsUdpInterface
  extends NetworkInterface
  implements DnsUdpConstants
{
  private InetAddress bindAddress;
  private int threadLife = 500;
  private int bindPort = 53;
  private int numThreads = 10;
  private int maxHandlers = 200;
  private boolean logAccesses=false;
  private boolean trackThreads=false;
  private DatagramSocket dsocket = null;
  private boolean keepServing = true;
  private String dnsToHandlePrefix = null;
  
  public DnsUdpInterface(Main main, Hashtable config)
    throws UnknownHostException
  {
    super(main);
    String bindAddressStr = (String)config.get("bind_address");
    if(bindAddressStr==null)
      bindAddress = null;
    else
      bindAddress = InetAddress.getByName(bindAddressStr);
    
    bindPort = Integer.parseInt((String)config.get("bind_port"));
    try {
      numThreads = Integer.parseInt((String)config.get("num_threads"));
    } catch (Exception e) {}
    
    dnsToHandlePrefix = (String)config.get("dns_handle_prefix");
    if(dnsToHandlePrefix==null) dnsToHandlePrefix = "dns/";
    
//    Object resOrderObj = config.get("resolution_order");
//    if(resOrderObj!=null && resOrderObj instanceof Vector) {
//      Vector resOrder = (Vector)resOrderObj;
//      resolutionOrder = new int[resOrder.size()];
//      for(int i=0; i<resOrder.size(); i++) {
//        String item = String.valueOf(resOrder.elementAt(i));
//        if(item.equalsIgnoreCase("dns")) {
//          resolutionOrder[i] = USE_DNS;
//          needsDNSResolver = true;
//        } else {
//          resolutionOrder[i] = USE_HS;
//        }
//      }
//    } else {
//      resolutionOrder = new int[] { USE_HS };
//      needsDNSResolver = false;
//    }
//    
//    if(needsDNSResolver) {
//      try {
//        this.dnsResolver = new DNSResolver(null);
//      } catch (Exception e) {
//        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
//                      "Unable to instantiate DNS resolver: "+e);
//      }
//    }
  }
  
  public byte getProtocol() { return (byte)-1; }
  public int getPort() { return bindPort; };
  
  
  /**
   * Tells the interface to finish up the current operation and
   * stop listening for new connections.
   */
  protected void stopService() {
    keepServing = false;
    try {
      dsocket.close();
    } catch (Exception e) {}
  }
  
  public void serveRequests() {
    try {
      if(bindAddress==null) {
        dsocket = new DatagramSocket(bindPort);
      } else {
        dsocket = new DatagramSocket(bindPort,bindAddress);
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_FATAL,
                    String.valueOf(this.getClass())+
                    ": Error setting up server socket: "+e);
      return;
    }
    
    System.out.println("DNS-LOCAL handle Request Listener:");
    System.out.println("   address: "+(bindAddress==null?"ANY":""+bindAddress));
    System.out.println("      port: "+bindPort);

    RequestHandlerPool handlerPool = new RequestHandlerPool(trackThreads?"DNS":null);
    handlerPool.setHandlerLife(threadLife);
    handlerPool.setMaxPossibleHandlers(maxHandlers);
    System.out.print("Starting DNS request handlers: ");
    for(int threadNum=0; threadNum<numThreads; threadNum++) {
      System.out.print('.');
      handlerPool.addHandler(new DnsUdpRequestHandler(main, dsocket, handlerPool, 
                                                      this, dnsToHandlePrefix,
                                                      logAccesses));
    }
    System.out.println("");
    try { System.out.flush(); } catch (Exception e) {}


    long reqCount = 0;
    long recvTime = 0;
    while(keepServing) {
      try {
        DatagramPacket dPacket =
          new DatagramPacket(new byte[Common.MAX_UDP_PACKET_SIZE],
                             Common.MAX_UDP_PACKET_SIZE);
        dsocket.receive(dPacket);
        recvTime = System.currentTimeMillis(); 

        ((HdlUdpRequestHandler)handlerPool.getHandler()).serviceRequest(dPacket, recvTime);

        if(++reqCount > 1000) {
          needsGC = true;
          reqCount = 0;
        }
                
      } catch (Exception e) {
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      ""+this.getClass()+": Error handling request: "+e);
        e.printStackTrace(System.err);
      }
    }

    try {
      dsocket.close();
    } catch (Exception e) { }
  }
}
