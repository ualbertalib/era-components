/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import java.net.*;
import java.util.*;

/**********************************************************************
 * An HdlUdpRequestHandler object will handle requests submitted using
 * the UDP handle protocol.  The request will be processed using the
 * server object and a response will be returned using the UDP handle
 * protocol.
 **********************************************************************/

public class HdlUdpRequestHandler
  implements Runnable, RequestHandler, ResponseMessageCallback
{
  private DatagramPacket packet;
  private DatagramSocket dsocket;
  private AbstractServer server;
  private Main main;
  private HdlUdpInterface listener;
  
  private Thread handlerThread;
  private int invocations = 0;
  private boolean isActive=true;
  private boolean isRunning=false;
  private boolean logAccesses=false;
  private RequestHandlerPool handlerPool = null;
  private MessageEnvelope envelope = new MessageEnvelope();

  private AbstractRequest currentRequest;
  private long recvTime;

  public static final String ACCESS_TYPE = "UDP:HDL";
  private static final byte[] MSG_MESSAGE_TOO_LONG = 
    Util.encodeString("Message too long");
  private static final byte[] MSG_CANNOT_STREAM_UDP = 
    Util.encodeString("Cannot stream UDP messages");

  
  public HdlUdpRequestHandler(Main main, DatagramSocket dsock, 
                              RequestHandlerPool handlerPool,
                              HdlUdpInterface listener,
                              boolean logAccesses)
  {
    this.main = main;
    this.server = main.getServer();
    this.dsocket = dsock;
    this.handlerPool = handlerPool;
    this.logAccesses = logAccesses;
    this.listener = listener;
    handlerThread = new Thread(this);
    handlerThread.start();
  }
  
  public void resetThread() {
  }
  
  public RequestHandler newHandler() {
    return new HdlUdpRequestHandler(main, dsocket, handlerPool, listener, logAccesses);
  }

  public synchronized void deactivate() {
    isActive = false;
    resetState();
  }
  
  public int getInvocationCount() {
    return invocations;
  }

  public void resetState()
  {
    isRunning = false;
    packet = null;
  }

  public synchronized void serviceRequest(DatagramPacket packet, long recvTime)
  {
    this.packet = packet;
    this.recvTime = recvTime;
    isRunning = true;
    notify();
  }

  public void run() {
    while(isActive) {
      boolean multiPartRequest = false;
      byte pkt[] = null;
      int pktLen = 0;
      int offset = Common.MESSAGE_ENVELOPE_SIZE;

      synchronized(this) {
        while(!isRunning && isActive) {
          try {
            wait();
            if(!isRunning) {
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "hdl-udp error: invalid handler thread state");
            }
          } catch (Exception e) {
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                          String.valueOf(getClass())+"Got exception: "+e);
          }
        }
      }

      if(!isActive) continue;
      
      try {
        pktLen = packet.getLength();
        pkt = packet.getData();

        Encoder.decodeEnvelope(pkt, envelope);

        if(envelope.messageLength > Common.MAX_MESSAGE_LENGTH ||
           envelope.messageLength < 0) {
          handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_ERROR,
                                           MSG_MESSAGE_TOO_LONG));
          continue;
        }

        if(envelope.truncated) {
          // this is one packet in a multi-packet request.
          // we should give the packet to the listener object, who will
          // return a complete HdlUdpPendingRequest object if we are to handle
          // the complete request.  If null is returned, then the request
          // will be given to another handler so we don't have to worry about it.
          HdlUdpPendingRequest req = 
            listener.addMultiPacketListener(envelope, packet, packet.getAddress(), this);

          if(req==null) continue;

          pkt = req.getMessage();
          offset = 0;
        }

        //decrypt incoming request if it says so
        //not implemented yet!!!!
        
        currentRequest =
          (AbstractRequest)Encoder.decodeMessage(pkt, offset, envelope);
        
        String errMsg = listener.canProcessMsg(currentRequest);
        if(errMsg!=null) {
          main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, errMsg);
          handleResponse(new ErrorResponse(currentRequest.opCode,
                                           AbstractMessage.RC_PROTOCOL_ERROR,
                                           Util.encodeString(errMsg)));
          return;
        }

        server.processRequest(currentRequest, this);
        
      } catch (Throwable e) {
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                      String.valueOf(this.getClass())+": Exception processing request: "+e);
      } finally {
        // return the handler to the pool.
        handlerPool.returnHandler(this);
      }
    }
  }

  /****************************************************************************
   * Handle (log) any messages that are reported by the upstream message
   * provider.
   ****************************************************************************/
  public void handleResponseError(String error) {
    main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                  String.valueOf(this.getClass())+": Server error: "+error);
  }

  /****************************************************************************
   * Encode and send the response
   ****************************************************************************/
  public void handleResponse(AbstractResponse response) {
    try {
      byte msg[] = response.getEncodedMessage();

      //when to encrypt? right before sending it out! after the credential portion is formed!
      //encrypt response here if the request asks for encryption
      //and set the flag in envelop if successfull
      boolean encrypted = false;
      if (response.encrypt && response.sessionId > 0){
        ServerSideSessionInfo sssinfo = null;
        if (server instanceof HandleServer) {
          
          sssinfo = ((HandleServer)server).getSession(response.sessionId);
          if (sssinfo != null && sssinfo.lastRequestId > 0) {
        
            try { 
              msg = AbstractMessage.encryptMessage(msg, sssinfo.getSessionKey());
              encrypted = true;
            }
            catch (Exception e) {
              main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Exception encrypting response: "+e);
              System.err.println("Exception encrypting message with session key: " + e.getMessage());
              encrypted = false;
            }        
          } // sssinfo != null
        } else {   
          // serverSessionMan == null 
          main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Session manager not available. Message not encrypted.");
          System.err.println("Session manager not available. Message not encrypted.");
          encrypted = false;
        }
      }
      
      //set the envelop flag for encryption
      envelope.encrypted = encrypted;  
      envelope.messageLength = msg.length;  //get the length after encryption
      envelope.messageId = 0;
      envelope.sessionId = response.sessionId;
      envelope.protocolMajorVersion = response.majorProtocolVersion;
      envelope.protocolMinorVersion = response.minorProtocolVersion;
      
      if(msg.length > Common.MAX_UDP_DATA_SIZE) {
	// split the response into multiple pieces and send it
	int bytesRemaining = msg.length;
	while(bytesRemaining>0) {
	  byte buf[];
	  if(bytesRemaining<=Common.MAX_UDP_DATA_SIZE) {
	    buf = new byte[bytesRemaining+Common.MESSAGE_ENVELOPE_SIZE];
	    System.arraycopy(msg, msg.length - bytesRemaining,
			     buf, Common.MESSAGE_ENVELOPE_SIZE,
			     bytesRemaining);
	  } else {
	    buf = new byte[Common.MAX_UDP_DATA_SIZE+Common.MESSAGE_ENVELOPE_SIZE];
	    System.arraycopy(msg, msg.length - bytesRemaining,
			     buf, Common.MESSAGE_ENVELOPE_SIZE,
			     Common.MAX_UDP_DATA_SIZE);
	  }
	  Encoder.encodeEnvelope(envelope,buf);
	  dsocket.send(new DatagramPacket(buf, buf.length,
                                          packet.getAddress(),
                                          packet.getPort()));
	  bytesRemaining-=Common.MAX_UDP_DATA_SIZE;
	  envelope.messageId++;
	}
      } else {
	// all of the response fits in one packet, so let's send it..
	byte buf[] = new byte[msg.length+Common.MESSAGE_ENVELOPE_SIZE];
	Encoder.encodeEnvelope(envelope, buf);
	System.arraycopy(msg,0,buf,Common.MESSAGE_ENVELOPE_SIZE,msg.length);
	dsocket.send(new DatagramPacket(buf, buf.length,
                                        packet.getAddress(),
                                        packet.getPort()));
        
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                    String.valueOf(this.getClass())+": Exception sending response: "+e);
      e.printStackTrace(System.err);
    }
    if(logAccesses){
      long time = System.currentTimeMillis() - recvTime;
      main.logAccess(ACCESS_TYPE, packet.getAddress(),
                     currentRequest.opCode, 
                     (response != null ? response.responseCode : AbstractMessage.RC_ERROR),
                     Util.decodeString(currentRequest.handle), time);
    }
  }

}

