/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.util.*;
import java.util.*;
import java.io.*;
import java.lang.reflect.Method;

/***********************************************************************
 * Class responsible for keeping track of the different transaction
 * queue files.  The transaction queue is separated into separate
 * files so that it will be easy to wipe out old transactions (just
 * delete the old files).  It also makes replication slightly faster
 * since the entire queue doesn't need to be scanned when starting
 * replication at a certain transaction ID.
 *
 * Individual records within each transaction log look something like this:
 <pre>
 
 &lt;CRLF&gt;&lt;txnID&gt;|&lt;action&gt;|&lt;date&gt;|&lt;hashOnAll&gt;|&lt;hashOnNA&gt;|&lt;hashOnId&gt;|&lt;handle-hex-encoded&gt;|
</pre>
 ***********************************************************************/
public class TransactionQueue
  implements TransactionQueueInterface
{
  
  private File queueDir;
  private File queueIndexFile;
  private Vector queueFiles;
  private Calendar calendar;
  private File lockFile;
  private Vector queueListeners;

  private boolean haveLock = false;
  private boolean initialized = false;
  
  class QueueFileEntry {
    private long startDate;
    private long firstTxnId;
    private int queueNumber;
    private Writer writer = null;
    private File queueFile = null;

    QueueFileEntry(long startDate, long firstTxnId, int queueNumber) {
      this.startDate = startDate;
      this.firstTxnId = firstTxnId;
      this.queueNumber = queueNumber;
    }

    long getStartDate() { return startDate; }
    long getFirstTxnId() { return firstTxnId; }
    long getQueueNumber() { return queueNumber; }

    synchronized File getQueueFile() {
      if(queueFile==null) {
        queueFile = new File(queueDir, String.valueOf(queueNumber)+".q");
      }
      return queueFile;
    }

    synchronized void writeRecord(String record) 
      throws IOException
    {
      if(writer==null) {
        writer = new FileWriter(getQueueFile().getAbsolutePath(), true);
      }
      writer.write(record);
      writer.flush();
    }

    synchronized void close() {
      Writer tmpWriter = writer;
      writer = null;
      if(tmpWriter!=null) {
        try {
          tmpWriter.close();
        } catch (Exception e) {
          System.err.println("Error closing queue writer: "+e);
          e.printStackTrace(System.err);
        }
      }
    }

    public String toString() {
      return String.valueOf(queueNumber)+"; firsttxn="+firstTxnId+"; startDate="+startDate+
        "; file="+queueFile;
    }
    
  }

  public TransactionQueue(File queueDir) 
    throws Exception 
  {
    this.queueDir = queueDir;
    this.lockFile = new File(queueDir, "lock");
    this.queueIndexFile = new File(queueDir, "index");
    this.queueListeners = new Vector();

    calendar = Calendar.getInstance();
    
    getLock();
    
    
    // try release lock on shutdown.  only works on java 1.3 and greater,
    Runtime.getRuntime().addShutdownHook(new Thread(new Shutdown()));
    
    initQueueIndex();
    this.initialized = true;
  }

  public synchronized long getFirstDate() {
    if(queueFiles.size()<=0) return Long.MAX_VALUE;
    QueueFileEntry entry = (QueueFileEntry)queueFiles.elementAt(0);
    return entry.startDate;
  }
  
  public synchronized long getLastTxnId() {
    if(queueFiles.size()<=0) return 0;
    long txnId = 0;
    try {
      QueueScanner scanner =
        new QueueScanner((QueueFileEntry)queueFiles.elementAt(queueFiles.size()-1));
      while(true) {
        Transaction txn = scanner.nextTransaction();
        if(txn!=null) txnId = txn.txnId;
        if(txn==null) break;
      } 
    } catch (Exception e) {

      System.err.println("Error getting transaction ID: "+e+"\n   using "+txnId);

    } finally {

      // after doing something big like retrieving transaction logs, we
      // should garbage collect to free up memory and close open files..
      try {
        System.gc();
        System.runFinalization();
      } catch (Throwable t) {}
    }
    return txnId;
  }

  public void addQueueListener(TransactionQueueListener l) {
    queueListeners.addElement(l);
  }

  public void removeQueueListener(TransactionQueueListener l) {
    queueListeners.removeElement(l);
  }

    
  /******************************************************************
   * Notify any objects that are listening for new transactions
   * that the given transaction has been added to the queue.
   ******************************************************************/
  private void notifyQueueListeners(Transaction txn) {
    for(int i=0; i<queueListeners.size(); i++) {
      try {
        ((TransactionQueueListener)queueListeners.elementAt(i)).transactionAdded(txn);
      } catch (Throwable e) {
        System.err.println("error notifying queue listeners: "+e);
        e.printStackTrace(System.err);
      }
    }
  }

  private synchronized int getQueueFileName(Date dt) {
    calendar.setTime(dt);
    return 
      calendar.get(Calendar.YEAR)*10000 +
      calendar.get(Calendar.MONTH)*100 +
      calendar.get(Calendar.DAY_OF_MONTH);
  }

  private synchronized void initQueueIndex() 
    throws Exception
  {
    queueFiles = new Vector();
    if(!queueIndexFile.exists() || queueIndexFile.length()<=0) {
      // setup the queues for a NEW server
      Transaction dummyTxn = new Transaction();
      dummyTxn.txnId = -1;
      dummyTxn.handle = new byte[0];
      dummyTxn.action = Transaction.ACTION_PLACEHOLDER;
      dummyTxn.hashOnAll = 0;
      dummyTxn.hashOnNA = 0;
      dummyTxn.hashOnId = 0;
      dummyTxn.values = new HandleValue[0];
      addTransaction(dummyTxn);
    } else {
      BufferedReader reader = new BufferedReader(new FileReader(queueIndexFile));
      while(true) {
        String line = reader.readLine();
        if(line==null) 
          break;
        line = line.trim();
        if(line.length()<=0) 
          continue;
        long startDate = Long.parseLong(StringUtils.fieldIndex(line,'\t',0));
        long firstTxnId = Long.parseLong(StringUtils.fieldIndex(line,'\t',1));
        int queueNumber  = Integer.parseInt(StringUtils.fieldIndex(line,'\t',2));
        queueFiles.addElement(new QueueFileEntry(startDate, firstTxnId, queueNumber));
      }
    }
  }

  //
  // XXX: race condition here!  another lock file could be created in between
  //      the check to see if it exists and when it is created.  Not horrible,
  //      since transaction queues are not created very often, but less
  //      than desirable.
  //
  private synchronized void getLock() 
    throws Exception
  {
    if(lockFile.exists()) {
      System.err.println("Error: lock file ("+lockFile+") exists.  If you are sure "+
                         "that another server is not running, remove this file and restart "+
                         "the server");
      throw new Exception("Queue files are locked");
    } else {
      try {
        try {
          new File(lockFile.getParent()).mkdirs();
        } catch (Exception e) {}

        OutputStream out = new FileOutputStream(lockFile);
        out.write("lock".getBytes());
        out.close();
        haveLock = true;
      } catch (Exception e) {
        throw new Exception("Cannot create lock file: "+e);
      }
    }
  }


  private synchronized void releaseLock() {
    if(!haveLock)
      return;
    
    try{
      // Thread.currentThread().dumpStack();
      lockFile.delete();
      haveLock = false;
    } catch (Throwable e) {
      System.err.println("Error removing transaction queue lock file: "+e);
    } finally {
      if(!haveLock) lockFile = null;
    }
  }


  private synchronized QueueFileEntry getCurrentQueue() {
    if(queueFiles.size()<=0) return null;
    return (QueueFileEntry)queueFiles.elementAt(queueFiles.size()-1);
  }


  /** Log the specified transaction */
  public void addTransaction(long txnId, byte handle[], byte action, long date)
    throws Exception
  {
    Transaction txn = new Transaction();
    txn.txnId = txnId;
    txn.handle = handle;
    txn.action = action;
    txn.date = date;
    
    // generate each type of hash for the handle so that we don't have to
    // re-generate it for every retrieve-transaction request.
    txn.hashOnAll = SiteInfo.getHandleHash(handle, SiteInfo.HASH_TYPE_BY_ALL);
    txn.hashOnNA = SiteInfo.getHandleHash(handle, SiteInfo.HASH_TYPE_BY_NA);
    txn.hashOnId = SiteInfo.getHandleHash(handle, SiteInfo.HASH_TYPE_BY_ID);
    
    addTransaction(txn);
    
    notifyQueueListeners(txn);
  }

  /*******************************************************************************
   * Log the specified transaction to the current queue (creating a new queue, if 
   * necessary
   *******************************************************************************/
  protected synchronized void addTransaction(Transaction txn) 
    throws Exception
  {
    // check to see if we should start a new queue
    Date now = new Date();
    int qnum = getQueueFileName(now);
      
    QueueFileEntry currentQueue = getCurrentQueue();

    if(currentQueue==null || qnum > currentQueue.getQueueNumber()) {
      // if we are in a new time period, create a new queue
      currentQueue = createNewQueue(now.getTime(), txn.txnId, qnum);
    }

    currentQueue.writeRecord(encodeTransaction(txn));
  }

  /*****************************************************************************
   * Create and initialize a new transaction queue for transaction on or
   * after the given starting date/time.  This will create the queue file
   * and add an entry for it into the queue index file.
   *****************************************************************************/
  private synchronized QueueFileEntry createNewQueue(long startDate, long firstTxnId, int queueNum) 
    throws Exception
  {
    closeCurrentQueue();
    FileWriter writer = new FileWriter(queueIndexFile.getAbsolutePath(), true);
    QueueFileEntry newQueue = new QueueFileEntry(startDate, firstTxnId, queueNum);
    String record = 
      String.valueOf(startDate)+'\t'+
      String.valueOf(firstTxnId)+'\t'+
      String.valueOf(queueNum)+"\t\n";
    writer.write(record);
    writer.close();
    queueFiles.addElement(newQueue);
    return newQueue;
  }
  
  private synchronized void closeCurrentQueue() 
    throws Exception
  {
    QueueFileEntry qfe = getCurrentQueue();
    if(qfe!=null) qfe.close();
  }

  private synchronized QueueFileEntry getNextQueue(QueueFileEntry presentQueue) {
    for(int i=queueFiles.size()-2; i>=0; i--) {
      QueueFileEntry qfe = (QueueFileEntry)queueFiles.elementAt(i);
      if(qfe==presentQueue) {
        return (QueueFileEntry)queueFiles.elementAt(i+1);
      }
    }
    
    // the called must have the last queue already...
    return null;
  }

  
  protected String encodeTransaction(Transaction txn) {
    StringBuffer sb = new StringBuffer();
    sb.append(txn.txnId);
    sb.append('|');
    sb.append((int)txn.action);
    sb.append('|');
    sb.append(txn.date);
    sb.append('|');
    sb.append(txn.hashOnAll);
    sb.append('|');
    sb.append(txn.hashOnNA);
    sb.append('|');
    sb.append(txn.hashOnId);
    sb.append('|');
    sb.append(Util.decodeHexString(txn.handle, false));
    sb.append('|');
    sb.append('\n');
    return sb.toString();
  }

  protected int nextField(int currPos, String txnStr)
    throws Exception
  {
    if(currPos>=txnStr.length())
      throw new Exception("No more fields in transaction");
    int i=currPos+1;
    for( ; i<txnStr.length(); i++) {
      if(txnStr.charAt(i)=='|') {
        break;
      }
    }
    return i;
  }

  protected Transaction decodeTransaction(String txnStr) 
  {
    try {
      int sepIdx = -1;
      Transaction txn = new Transaction();
      txn.txnId = 
        Long.parseLong(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.action = 
        (byte)Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.date = 
        Long.parseLong(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.hashOnAll = 
        Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.hashOnNA = 
        Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.hashOnId = 
        Integer.parseInt(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      txn.handle = 
        Util.encodeHexString(txnStr.substring(sepIdx+1, sepIdx=nextField(sepIdx,txnStr)));
      return txn;
    } catch (Exception e) {
      System.err.println("Exception decoding transaction: \n  "+txnStr+
                         "\n  "+e);
      e.printStackTrace(System.err);
    }
    return null;
    
  }

  public void finalize() {
    try {
      shutdown();
    } catch (Throwable t) {
      System.err.println("Error finalizing txn queue: "+t);
    }
  }

  public synchronized void shutdown() {
    if(!initialized)
      return;
    try {
      closeCurrentQueue();
    } catch (Throwable e) {
      System.err.println("Error shutting down transaction queue: "+e);
    }
    releaseLock();
  }


  public synchronized TransactionScannerInterface getScanner(long lastTxnID) 
    throws Exception
  {
    if(queueFiles.size()<=0) { // shouldn't happen!
      return null;
    }

    QueueFileEntry queueEntry = null;
    for(int i=0; i<queueFiles.size(); i++) {
      QueueFileEntry nextEntry = (QueueFileEntry)queueFiles.elementAt(i);
      if(nextEntry.firstTxnId>=0 && nextEntry.firstTxnId>lastTxnID) {
        if(queueEntry==null) {
          // this is the first daily queue and it doesn't include the last
          // received txn... bad news... the requestor will have to redump
          return new QueueScanner(nextEntry);
        } else {
          // this queue starts with later txn ID than the requestor is
          // asking for, so the previous queue should have what he wants.
          return new QueueScanner(queueEntry);
        }
      }
      queueEntry = nextEntry;
    }
    
    if(queueEntry==null) {
      // no queues found?  shouldn't get here.
      return new QueueScanner((QueueFileEntry)queueFiles.elementAt(0));
    }

    // return a scanner for the most recent queue
    return new QueueScanner(queueEntry);
  }

  public class QueueScanner
    implements TransactionScannerInterface
  {
    private BufferedReader reader;
    private QueueFileEntry queueFileEntry;
    private long firstDateInLog;

    protected QueueScanner(QueueFileEntry queueFileEntry)
      throws Exception
    {
      firstDateInLog = queueFileEntry.getStartDate();
      connectToQueue(queueFileEntry);
    }

    public long getFirstDateInLog() {
      return firstDateInLog;
    }
    
    private void connectToQueue(QueueFileEntry nextQueue)
      throws Exception
    {
      queueFileEntry = nextQueue;
      reader = null;
      try {
        File f = queueFileEntry.getQueueFile();
        if(f.exists() && f.canRead()) {
          reader = new BufferedReader(new FileReader(f));
        } else {
          throw new Exception("Cannot access file: "+f);
        }
      } catch (Exception e) {
        throw new Exception("Unable to open transaction log: "+e);
      } finally {
        System.gc();
        System.runFinalization();
      }
    }
    
    public synchronized Transaction nextTransaction() 
      throws Exception
    {
      String line = null;
      do {
        line = reader.readLine();
        if(line==null) {
          // reached end of queue file.  if there are no more queues, we're done.
          // otherwise, start scanning the next queue.
          QueueFileEntry nextQueue = getNextQueue(queueFileEntry);
          if(nextQueue==null) {
            // end of the line... no more queues
            return null;
          } else {
            connectToQueue(nextQueue);
          }
        } else if(line.trim().length()>0) {
          Transaction txn = decodeTransaction(line);
          // skip placeholder transactions..
          if(txn.action!=Transaction.ACTION_PLACEHOLDER) {
            return txn;
          }
        }
      } while(true);
    }


    public void close() {
      try {
        reader.close();
      } catch (Exception e) {}
    }
    
  }
  
  
  class Shutdown implements Runnable
  {
    public void run(){
      try {
        shutdown();
      } catch (Throwable t) {
        System.err.println("Error finalizing txn queue: "+t);
      }
    }
  }

}

