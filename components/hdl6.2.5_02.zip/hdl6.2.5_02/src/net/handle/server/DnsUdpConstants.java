/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;

public interface DnsUdpConstants {
  public static final int PRIMARY_NAME_SERVER_TYPE = 65555;
  public static final int FIRST_DNS_TYPE = 11000;
  public static final String DEFAULT_DNS_HANDLE_PREFIX = "dns";
  public static final int MAX_DNS_NAME_LENGTH = 1024;
  public static final int USE_HS=0, USE_DNS=1;
  public static final String ACCESS_TYPE = "UDP:DNS";
  public static final int MAX_MESSAGE_SIZE = 512;

  public static final byte[] HDL_DNS_TYPE_A = Util.encodeString("DNS_A");
  public static final byte[] HDL_DNS_TYPE_NS = Util.encodeString("DNS_NS");
  public static final byte[] HDL_DNS_TYPE_MD = Util.encodeString("DNS_MD");
  public static final byte[] HDL_DNS_TYPE_MF = Util.encodeString("DNS_MF");
  public static final byte[] HDL_DNS_TYPE_CNAME = Util.encodeString("DNS_CNAME");
  public static final byte[] HDL_DNS_TYPE_SOA = Util.encodeString("DNS_SOA");
  public static final byte[] HDL_DNS_TYPE_MB = Util.encodeString("DNS_MB");
  public static final byte[] HDL_DNS_TYPE_MG = Util.encodeString("DNS_MG");
  public static final byte[] HDL_DNS_TYPE_MR = Util.encodeString("DNS_MR");
  public static final byte[] HDL_DNS_TYPE_NULL = Util.encodeString("DNS_NULL");
  public static final byte[] HDL_DNS_TYPE_WKS = Util.encodeString("DNS_WKS");
  public static final byte[] HDL_DNS_TYPE_PTR = Util.encodeString("DNS_PTR");
  public static final byte[] HDL_DNS_TYPE_HINFO = Util.encodeString("DNS_HINFO");
  public static final byte[] HDL_DNS_TYPE_MINFO = Util.encodeString("DNS_MINFO");
  public static final byte[] HDL_DNS_TYPE_MX = Util.encodeString("DNS_MX");
  public static final byte[] HDL_DNS_TYPE_TXT = Util.encodeString("DNS_TXT");
}

