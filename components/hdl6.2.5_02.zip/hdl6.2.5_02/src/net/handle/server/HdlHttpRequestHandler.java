/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.util.*;
import java.net.*;
import java.util.*;
import java.io.*;
import java.text.*;

/**********************************************************************
 * An HdlHttpRequestHandler object will handle requests submitted using
 * the handle protocol within an HTTP wrapper.  The request will be
 * processed using the server object and a response will be returned
 * using the handle protocol within an HTTP response.
 *
 * This object actually handles many types of HTTP request.  The type of
 * the request is determined by the Content-Type header of the request.
 * If the Content-Type header is application/x-hdl-message then the
 * contents of the HTTP request (the POSTed body part) are assumed to
 * be a normal HDL protocol message.  For any other content type, the request
 * is assumed to be an HTTP GET with the requested handle (and URI parameters)
 * in the first line of the request.
 *
 * Likewise, the type of the response is determined by the "Accept"
 * header of the request.  If the Accept header is "application/x-hdl-message"
 * then the response is encoded as an HTTP response containing a normal
 * HDL protocol message.  For any other value of the Accept header, an HTTP
 * response is returned with an HTML representation of the response from the
 * handle system.  This HTML response also includes each URL handle value of
 * the response in the HTTP response associated with a "Location" header that
 * causes browsers to redirect to the returned URL.
 * 
 **********************************************************************/

public class HdlHttpRequestHandler
  implements Runnable, RequestHandler, ResponseMessageCallback
{
  private static final int DEFAULT_MAX_MESSAGE_LENGTH = 1024;

  public static final int MF_HDL = 0;
  public static final int MF_HTML = 1;
  
  private Socket socket = null;
  private long recvTime;  // time a request came in
  private AbstractRequest currentHdlRequest;
  private String currentHtmlLogAccessHdl;
  private String currentHtmlLogAccessType;
  private AbstractServer server;
  private HdlHttpRequestHandler handler;
  private HtmlResponder htmlResponder;
  private Main main;
  
  private boolean showHtmlPage = true;
  private boolean authRequest = false;
  private boolean suppressRedirect = false;
  private boolean followAliases = false;
  private int aliasCount = 5;
  private int responseType;
  private int requestType;
  private String redirectSuffix = "";
  private String currentHdl = "";
  
  private boolean sfxEnabled = false;
  private String sfxCookieName = null;
  private boolean suppressSFXRedirect = false;
  private boolean sfxAwareClient = false;
  private String sfxBaseURL = null;
  private String sfxID = null;
  
  private HTTPCookie cookies = new HTTPCookie();
  
  private Thread handlerThread;
  private boolean isRunning = false;
  private boolean isActive = true;
  private int invocations = 0;
  private boolean logAccesses = false;
  private RequestHandlerPool handlerPool = null;
  private MessageEnvelope envelope = new MessageEnvelope();
  private Hashtable headers = new Hashtable();
  private byte envelopeBuf[] = new byte[Common.MESSAGE_ENVELOPE_SIZE];
  private byte messageBuf[] = new byte[DEFAULT_MAX_MESSAGE_LENGTH];
  private HdlHttpInterface interfc;

  public static final String ACCESS_TYPE = "HTTP:HDL";
  public static final String ACCESS_TYPE_SFX = "HTTP:HDL:SFX";
  public static final byte MSG_INVALID_MSG_SIZE[] =
  Util.encodeString("Invalid message length");
  public static final byte MSG_INVALID_REQUEST[] =
  Util.encodeString("Invalid request");

  private static final String HTTP_ACCEPT_HDR = "ACCEPT";
  private static final String HTTP_CONTENT_TYPE_HDR = "CONTENT-TYPE";
  private static final String HTTP_HOST_HDR = "HOST";
    
  private static final String HDL="hdl";
  private static final String HDL_TYPE="type";
  private static final String AUTH_FLAG="auth"; 
  private static final String SUPPRESS_REDIRECT="noredirect";
  private static final String DONT_FOLLOW_ALIASES="ignore_aliases";
  private static final String URLAPPEND="urlappend";

  // handle system pages will be the default
  private static String queryPageDefault = null;
  private static Vector errorPageDefault = null;
  private static Vector responsePageDefault = null;

  // virtual host pages comes here
  // each virtual host stores as key (String, i.g. "dx.doi.org"), and 
  // value (ArrayList, for page contents: "query_page"->String, "error_page", Vector, and "reqponse_page", Vector)
  private static Hashtable virtualHostsPages = null;
  private static final int VIRTUAL_HOST_QUERY_PAGE_IDX    = 0;
  private static final int VIRTUAL_HOST_ERROR_PAGE_IDX    = 1;
  private static final int VIRTUAL_HOST_RESPONSE_PAGE_IDX = 2;
  private static final String VIRTUAL_HOST_HOSTNAME = "hostname";    //in config.dct
  private static final String VIRTUAL_HOST_QUERY_PAGE = "query_page"; 
  private static final String VIRTUAL_HOST_ERROR_PAGE = "error_page";
  private static final String VIRTUAL_HOST_RESPONSE_PAGE = "response_page";

  // this set of variables will be used when in print response, query and error on run time.
  // either it is the virtual pages if the host name matchs any of the virtual hosts
  // defined in config.dct; if not, the default pages will be used.  
  private String queryPage = null;
  private Vector errorPage = new Vector();
  private Vector responsePage = new Vector();

  private static final String HANDLE_TOKEN = "HANDLE_TOKEN";
  private static final String TRACE_TOKEN = "TRACE_TOKEN";
  private static final String ERROR_TOKEN = "ERROR_TOKEN";
  private static final String VALUES_TOKEN = "VALUES_TOKEN";

  //for putting out more descriptive error messages
  private int resolutionError = 0;
  private final static int ERROR_SERVICE_NOTFOUND = 1;
  private final static int ERROR_CANNOT_CONNECT_SERVER = 3;
  private final static int ERROR_HANDLE_NOT_EXIST = 2;
  private final static int ERROR_VALUES_NOT_FOUND = 4;
  private final static int ERROR_UNKNOWN = 100;
  private Exception originalException = null;
  
  // strip the leading "doi:" or "hdl:" off
  private final static String DOI_PROTOCOL = "doi:";
  private final static String HDL_PROTOCOL = "hdl:";
  private final static int    DOI_PROTOCOL_LENGTH = 4;
  
  public HdlHttpRequestHandler(Main main, HdlHttpInterface ifc, 
                               RequestHandlerPool handlerPool,
                               boolean logAccesses, String sfxCookieName,
                               String queryPageFile,
                               String responsePageFile, String errorPageFile,
                               Vector virtualHosts)
  {
    this.interfc = ifc;
    if (this.queryPageDefault == null){
      loadHTML(queryPageFile, responsePageFile, errorPageFile, virtualHosts);
    }
    init(main, handlerPool, logAccesses, sfxCookieName);
  }

  public HdlHttpRequestHandler(Main main, HdlHttpInterface ifc, 
                               RequestHandlerPool handlerPool,
                               boolean logAccesses, String sfxCookieName)
  {
    this.interfc = ifc;
    if (queryPageDefault == null) loadHTML(null, null, null, null);
    init(main, handlerPool, logAccesses, sfxCookieName);
  }

  private void init(Main main, RequestHandlerPool handlerPool, 
                    boolean logAccesses, String sfxCookieName)
  {
    this.main = main;
    this.server = main.getServer();
    this.handler = this;
    this.handlerPool = handlerPool;
    this.htmlResponder = new HtmlResponder();
    this.logAccesses = logAccesses;
    this.sfxEnabled = sfxCookieName!=null;
    this.sfxCookieName = sfxCookieName;
    handlerThread = new Thread(this);
    handlerThread.setDaemon(true);
    handlerThread.start();
  }
     
  /**
   * Loads in the HTML template pages including virtual host template pages.  
   **/
  private void loadHTML(String queryPageFile, 
                        String responsePageFile, String errorPageFile,
                        Vector virtualHosts){
    //load default query page
    queryPageDefault = loadQueryPage(queryPageFile, "default");

    // read the default error page, and store it in errorPageDefault
    errorPageDefault = loadErrorPage(errorPageFile, "default");

    // read the default response page, and store it in responsePageDefault
    responsePageDefault = loadResponsePage(responsePageFile, "default");
  
    // load virtual host pages here if there is any and put into virtualHostPages
    virtualHostsPages = new Hashtable();
    for (int i=0; virtualHosts!=null && i<virtualHosts.size(); i++) {
      // remember the Vector comes in has the structure
      // each entry is a Hashtable, to store the 
      // "hostname", "query_page", "response_page" and "error_page"
     
      Hashtable ht = (Hashtable)virtualHosts.elementAt(i);

      String hostname = (String)ht.get(VIRTUAL_HOST_HOSTNAME);
      if (hostname == null || hostname.length() == 0) {
        System.err.println("The vitual host name missing in the configuration!");
        continue;   // no virtual host entry can be formed
      }

      // we will transfer into another structure
      // in where each hostname corresponds to an array list.
      // this array list has three entries:
      // element 0 --> String, same type and usage as queryPageDefault;
      // element 1 --> Vector, same type and usage as errorPageDefault;
      // element 2 --> Vector, same type and usage as responsePageDefault

      String virtualQuery = loadQueryPage((String)ht.get(VIRTUAL_HOST_QUERY_PAGE), hostname);
      Vector virtualError = loadErrorPage((String)ht.get(VIRTUAL_HOST_ERROR_PAGE), hostname);
      Vector virtualResponse = loadResponsePage((String)ht.get(VIRTUAL_HOST_RESPONSE_PAGE), hostname);
         
      if (virtualQuery != null && virtualQuery.length() > 0 &&
          virtualError != null && virtualResponse != null) {
        
        Vector virtualPages = new Vector();
        virtualPages.insertElementAt(virtualQuery, VIRTUAL_HOST_QUERY_PAGE_IDX);  //the real content on the page. not the file name anymore
        virtualPages.insertElementAt(virtualError, VIRTUAL_HOST_ERROR_PAGE_IDX);  //same here
        virtualPages.insertElementAt(virtualResponse, VIRTUAL_HOST_RESPONSE_PAGE_IDX); //same here

        // add to the class variable holder
        virtualHostsPages.put(hostname.trim(), virtualPages);
      }
    }
  }

  /**
   * Helper for loadHTML(). 
   **/
  private String loadStream(InputStream in) throws Exception {
     byte b[] = new byte[1024];
     int len;
     StringBuffer sb = new StringBuffer();
     while (true){
       len = in.read(b);
       if (len == -1) break;
       sb.append((new String(b)).substring(0, len));
     }
     return sb.toString();
   }

  /**
   * Helper for loadHTML(). load query page from a file name.
  **/
  private String loadQueryPage(String queryPageFile, String whichhost) {
    InputStream in;
    String queryPage;
    try {
      if (queryPageFile != null) in = new FileInputStream(queryPageFile);
      else in = getClass().getResourceAsStream("/net/handle/server/html/query.html");
      queryPage = loadStream(in);
    }
    catch (Exception e){
      queryPage = "Page not found!";
      System.err.println("Error loading query page for " + whichhost + " host!"); 
    }
    return queryPage;
  } 

  /** 
   * Helper for loadHTML() too. load error page vector
  **/
  private Vector loadErrorPage(String errorPageFile, String whichhost) {

    InputStream in = null; 
    Vector errorPage = new Vector();
    // read in error page and tokenize
    try {
      if (errorPageFile != null) in = new FileInputStream(errorPageFile);
      else in = getClass().getResourceAsStream("/net/handle/server/html/error.html");
      String s = loadStream(in);
      int pos = 0;
      int next = 0;
      while (pos < s.length()){
        next = s.indexOf("${", pos);
        if (next == -1){ 
          errorPage.addElement(s.substring(pos));
          break;
        }
        errorPage.addElement(s.substring(pos, next));
        if (s.startsWith("${ERROR}", next)){
          errorPage.addElement(ERROR_TOKEN);
          pos = next + 8;
        }
        else if (s.startsWith("${HANDLE}", next)){
          errorPage.addElement(HANDLE_TOKEN);
          pos = next + 9;
        }
        else if (s.startsWith("${TRACE}", next)){
          errorPage.addElement(TRACE_TOKEN);
          pos = next + 8;
        }
        else if (s.startsWith("${", next)) { // Some other string with $
          int posRightP = s.indexOf("}", next+2);
          String token = "";
          if (posRightP != -1) {
            // found the right paratethis
            token = s.substring(next, posRightP+1);
          } else {
            // not found, skip the ${, keep the rest in the file 
            token = "${";
          }

          if (token.length() > 2) {
            errorPage.addElement(token.substring(2, token.length() -1));
            pos = next + token.length();
          } else {
            pos = next + 2;
          } 
        }
      }
    }
    catch (Exception e){
      errorPage.removeAllElements();
      errorPage.addElement("Page not found!");
      System.err.println("Error loading error page for " + whichhost + " host!"); 
    }
    return errorPage;
  }

  /**
   * Also a helper for loadHTML. load response page file into vector
  **/
  private Vector loadResponsePage(String responsePageFile, String whichhost) {
    
    InputStream in; 
    Vector responsePage = new Vector();
    // read in response page and tokenize
    try {
      if (responsePageFile != null) in = new FileInputStream(responsePageFile);
      else in = getClass().getResourceAsStream("/net/handle/server/html/response.html");
      String s = loadStream(in);
      int pos = 0;
      int next = 0;
      while (pos < s.length()){
        next = s.indexOf("${", pos);
        if (next == -1){
          responsePage.addElement(s.substring(pos));
          break;
        }
        responsePage.addElement(s.substring(pos, next));
        if (s.startsWith("${HANDLE}", next)){
          responsePage.addElement(HANDLE_TOKEN);
          pos = next + 9;
        }
        else if (s.startsWith("${VALUES}", next)){
          responsePage.addElement(VALUES_TOKEN);
          pos = next + 9;
        }
        else if (s.startsWith("${", next)) { // Some other string with $
         // responsePage.addElement("${");
         // pos += next + 2;
          int posRightP = s.indexOf("}", next+2);
          String token = "";
          if (posRightP != -1) {
            // found the right paratethis
            token = s.substring(next, posRightP+1);
          } else {
            // not found, skip the  ${, then keep whatever in the file
            token = "${";
          }

          if (token.length() > 2) {
            responsePage.addElement(token.substring(2, token.length() -1));
            pos = next + token.length();
          } else {
            pos = next + 2;
          }
        }
      }
    }
    catch (Exception e){
      responsePage.removeAllElements();
      responsePage.addElement("Page not found!");
      System.err.println("Error loading response page for " + whichhost + " host!");
    }
    return responsePage;
  }

  public RequestHandler newHandler() {
    return new HdlHttpRequestHandler(main, interfc, handlerPool, logAccesses, sfxCookieName);
  }

  public int getInvocationCount() {
    return invocations;
  }

  public void deactivate() {
    isActive = false;
    resetState();
  }
  
  public void resetState()
  {
    isRunning = false;
    if(socket!=null) {
      try { socket.close(); } catch (Exception e){}
    }
  }

  public synchronized void serviceRequest(Socket socket, long recvTime)
  {
    this.socket = socket;
    this.recvTime = recvTime;
    isRunning = true;
    invocations++;
    notify();
  }


  public void run() {
    while(isActive) {
      authRequest = false;
      showHtmlPage = true;
      suppressRedirect = false;
      followAliases = false;
      aliasCount = 5;
      suppressSFXRedirect = false;
      sfxAwareClient = false;
      sfxBaseURL = null;
      sfxID = null;
      headers.clear();
      cookies.clear();
      resolutionError = 0;
      originalException = null;
      redirectSuffix = "";
      queryPage = null;
      errorPage = null;
      responsePage = null;
      currentHtmlLogAccessHdl = "NA";
      currentHtmlLogAccessType = ACCESS_TYPE;
      currentHdlRequest = null;
      
      synchronized(this) {
        while(!isRunning && isActive) {
          try {
            wait();
            if(!isRunning) {
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "hdl-http error: invalid handler thread state");
            }
          } catch (Exception e) {
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                          String.valueOf(getClass())+"Got exception: "+e);
          }
        }
      }

      if(!isActive) continue;
      
      DataInputStream in = null;
      try {
        in = new DataInputStream(new BufferedInputStream(socket.getInputStream(),512));

        // read the first line
        String firstLine = in.readLine();
        if(firstLine==null || firstLine.trim().length()<=0) continue;
        int spcIdx = firstLine.indexOf(' ');
        if(spcIdx<0) continue;

        // read the headers...
        String line;
        String headerKey;
        String headerVal;
        while(true) {
          line = in.readLine();
          if(line==null)
            throw new HandleException(HandleException.MESSAGE_FORMAT_ERROR,
                                      "Unexpected end of headers");

          if(line.length()<=0)
            break;

          int colIdx = line.indexOf(':');
          if(colIdx>=0) {
            headerKey = line.substring(0, colIdx).toUpperCase();
            headerVal = line.substring(colIdx+1);
          } else {
            headerKey = line.toUpperCase();
            headerVal = "";
          }
          if(sfxEnabled && headerKey.equals("COOKIE")) {
            cookies.parseRequestHeader(headerVal);
          }
          headers.put(headerKey, headerVal);
        }

        // figure out what type of response to send...
        boolean returnHdl;
        responseType =
          determineResponseType((String)headers.get(HTTP_ACCEPT_HDR));
        requestType =
          determineRequestType((String)headers.get(HTTP_CONTENT_TYPE_HDR));

        // figure out virtual host is requesting from ..., could be like hdl.handle.net:8000
        String hostname = (String)headers.get(HTTP_HOST_HDR);
           
        if (hostname != null && hostname.length() > 0) {
          // strip the port number if there is any,
          int idxPort = hostname.indexOf(":");
          String hostNameWoPort = (idxPort != -1) ? hostname.substring(0, idxPort) : hostname;
          hostNameWoPort = hostNameWoPort.trim();

          if (virtualHostsPages.containsKey(hostNameWoPort)) {
            queryPage = (String)((Vector)virtualHostsPages.get(hostNameWoPort)).elementAt(VIRTUAL_HOST_QUERY_PAGE_IDX);
            errorPage = (Vector)((Vector)virtualHostsPages.get(hostNameWoPort)).elementAt(VIRTUAL_HOST_ERROR_PAGE_IDX);
            responsePage = (Vector)((Vector)virtualHostsPages.get(hostNameWoPort)).elementAt(VIRTUAL_HOST_RESPONSE_PAGE_IDX);
          }
        }
        if (queryPage == null || queryPage.length() == 0 || 
            errorPage == null || errorPage.size() ==0 || 
            responsePage == null || responsePage.size() == 0) {
          // if there is no matching virtual host name, use default
          queryPage = queryPageDefault;
          errorPage = errorPageDefault;
          responsePage = responsePageDefault;
        }

        switch(requestType) {
          case MF_HDL:
            handleHdlRequest(in);
            break;
          case MF_HTML:
            handleHtmlRequest(firstLine, in);
            break;
          default: 
            handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                             AbstractMessage.RC_ERROR,
                                             MSG_INVALID_REQUEST));
           
        }
      } catch (Throwable e) {
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
          String.valueOf(this.getClass())+": Exception processing request: "+e);
      } finally {
        if(in!=null) {
          try { in.close(); } catch (Throwable e) {}
          in = null;
        }
        // return the handler to the pool.
        handlerPool.returnHandler(this);
      }
    }
  }

  /** Decode the request for a handle from the HTTP request parameters
      and return the result of processing the request in an AbstractResponse.
      This is the method that gets called when clients are using a web browser
      to directly query this server.  This returns null if no valid handle
      request could be determined from the HTTP request.   */
  private final void handleHtmlRequest(String firstLine, InputStream in)
    throws Exception
  {
    int r, n=0;
    followAliases = true;

    String method= StringUtils.fieldIndex(firstLine,' ',0).trim().toUpperCase();
    try {
      if(method.equals("GET") || method.equals("HEAD")) {
        authRequest = false;
        showHtmlPage = method.equals("GET");
        suppressRedirect = false;
        
        String uri = StringUtils.fieldIndex(firstLine,' ',1).trim();
        if(uri.startsWith("/"))
          uri = uri.substring(1).trim();

        if(uri.length()<=0){
          handleResponse(null);
          return;
        }
         
        if(uri.startsWith("openurl?")) {
          doOpenURLResolution(uri.substring(8));  
        } else {
          doResolution(uri); 
        }
      } else { // method.equals("POST")
        showHtmlPage = true;
        authRequest = false;
        suppressRedirect = false;

        // this is a POST request - read the URL-encoded parameters from the
        // input stream
        int contentLength = 0;
        if(headers.containsKey("CONTENT-LENGTH")) {
          contentLength = Integer.parseInt(((String)headers.get("CONTENT-LENGTH")).trim());
        } else {
          // no content length??? shouldn't happen on a POST
          handleResponse(null);
        }
        
        StringBuffer sb = new StringBuffer();
        int ich;
        for(int i=0; i<contentLength; i++) {
          ich = in.read();
          if(ich<0)
            break;
          sb.append((char)ich);
        }
        String postData = sb.toString();
        
        Vector typeVect = null;

        String pairData;
        String paramName;
        String paramValue;
        int idx = -1;
        int tmpIdx;
        int eqIndex;
        while(true) {
          tmpIdx = postData.indexOf('&',idx+1);
          
          if(tmpIdx<0)
            pairData = postData.substring(idx+1);
          else
            pairData = postData.substring(idx+1, tmpIdx);

          eqIndex = pairData.indexOf('=');
          if(eqIndex<0) {
            paramName = StringUtils.decodeURL(pairData);
            paramValue = "";
          } else {
            paramName = StringUtils.decodeURL(pairData.substring(0, eqIndex));
            paramValue = StringUtils.decodeURL(pairData.substring(eqIndex+1));
          }

          if(paramName.equals(HDL)) {
            currentHdl = paramValue;
            // if we want to trim the trailing spaces in handle string, do here
            currentHdl = currentHdl.trim();
            if (currentHdl.length()>=DOI_PROTOCOL_LENGTH && 
                (currentHdl.substring(0, DOI_PROTOCOL_LENGTH).equalsIgnoreCase(DOI_PROTOCOL) || 
                 currentHdl.substring(0, DOI_PROTOCOL_LENGTH).equalsIgnoreCase(HDL_PROTOCOL)) ) {
              currentHdl = currentHdl.substring(DOI_PROTOCOL_LENGTH);
            }
          } else if(paramName.equals(HDL_TYPE)) {
            if(typeVect==null) typeVect = new Vector();
            typeVect.addElement(paramValue);
          } else if(paramName.equals(AUTH_FLAG)) {
            authRequest = true;
          } else if(paramName.equals(SUPPRESS_REDIRECT)) {
            suppressRedirect = true;
          } else if(paramName.equals(DONT_FOLLOW_ALIASES)) {
            followAliases = false;
          }
          
          if(tmpIdx<0) // this was the last name/value pair
            break;
          
          idx = tmpIdx;
        }
        
        if(currentHdl==null || currentHdl.length()<=0) {
          handleResponse(null);
          return;
        }
        
        byte typesWanted[][] = null;
        if(typeVect!=null && typeVect.size()>0)
          typesWanted = new byte[typeVect.size()][];
        for(int i=0; typesWanted!=null && i<typesWanted.length; i++)
          typesWanted[i] = Util.encodeString((String)typeVect.elementAt(i));
        
        int indexesWanted[] = null;
        
        currentHtmlLogAccessHdl = currentHdl;
        currentHtmlLogAccessType = ACCESS_TYPE;
        ResolutionRequest req = 
              new ResolutionRequest(Util.encodeString(currentHdl),
                                    typesWanted, indexesWanted, null);
        req.recursive = true;
        req.authoritative = authRequest;
        server.processRequest(req, htmlResponder);
      }
    }
    catch (Exception e) {
      originalException = e;
      resolutionError = ERROR_UNKNOWN;
      if (e instanceof HandleException) {
        HandleException he = (HandleException)e;
        if (he.getCode() == HandleException.SERVICE_NOT_FOUND )
           resolutionError = ERROR_SERVICE_NOTFOUND;
        else if (he.getCode() == HandleException.CANNOT_CONNECT_TO_SERVER) {
           resolutionError = ERROR_CANNOT_CONNECT_SERVER;
        }
      }
      
      //go ahead send out html message in case of exception for resolution
      handleResponse(null);
    }
  }

  /** Class used as a callback to catch responses so that we can optionally
      intercept HS_ALIAS values and follow the redirects. */
  private class HtmlResponder
    implements ResponseMessageCallback
  {
    ResolutionRequest originalRequest = null;

    public void handleResponse(AbstractResponse message) {
      try {

        if(followAliases && message!=null &&
           message.opCode==AbstractResponse.OC_RESOLUTION &&
           message.responseCode==AbstractResponse.RC_SUCCESS) {
             
          HandleValue values[] = ((ResolutionResponse)message).getHandleValues();
          for(int i=0; i<values.length; i++) {
            if(values[i].hasType(Common.STD_TYPE_HSALIAS)) {
              if(--aliasCount<=0){
                // quick & dirty way to avoid alias loops
                main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                              "Alias count exceeded for "+currentHdl);
                // followAliases = false;
              }
              ResolutionRequest req = new ResolutionRequest(values[i].getData(),
                                                            null, null, null);
              req.takeValuesFrom(message);
              req.recursive = true;
              server.processRequest(req, this);
              return;
            }
          }
        }
      } catch (Exception e) {
        main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                      "Error following alias: "+e);
      }
      handler.handleResponse(message);
    }
  }
  
  /** parse the handle and request parameters from given OpenURL request
   * string 
   **/
  private final void doOpenURLResolution(String openURLQuery)
    throws Exception 
  {
    Hashtable params = new Hashtable();
    int ampIdx = -1;
    int sectionStart;
    int eqIdx;
    do {
      sectionStart = ampIdx+1;
      ampIdx = openURLQuery.indexOf('&', sectionStart);
      String section = (ampIdx<0) ? openURLQuery.substring(sectionStart) :
                                    openURLQuery.substring(sectionStart, ampIdx);
      eqIdx = section.indexOf('=');
      if(eqIdx<0)
        params.put(StringUtils.decodeURLIgnorePlus(section), "");
      else
        params.put(StringUtils.decodeURLIgnorePlus(section.substring(0,eqIdx)),
                   StringUtils.decodeURLIgnorePlus(section.substring(eqIdx+1)));
    } while(ampIdx>=0);

    String hdl = (String)params.get("id");
    if(hdl==null) hdl = "";
    if(hdl.startsWith("hdl:") || hdl.startsWith("doi:"))
      hdl = hdl.substring(4);
    currentHdl = hdl;
    
    // check if we are talking to an SFX/OpenURL-aware client...
    if(sfxEnabled) {
      if(cookies.containsCookie(sfxCookieName)) {
        sfxBaseURL = cookies.getCookieVal(sfxCookieName);
        sfxAwareClient = sfxBaseURL!=null;
        sfxID = hdl.trim();
        suppressSFXRedirect = params.containsKey("nosfx");
      }
    }
    
    // prepare for the logAccess in handleHtmlResponse
    if(sfxAwareClient && !suppressSFXRedirect) {
      currentHtmlLogAccessHdl = hdl+"|"+sfxBaseURL;
      currentHtmlLogAccessType = ACCESS_TYPE_SFX;
    } else {
      currentHtmlLogAccessHdl = hdl;
      currentHtmlLogAccessType = ACCESS_TYPE;
    }

    ResolutionRequest req = new ResolutionRequest(Util.encodeString(hdl),
                                                  null, null, null);
    req.recursive = true;
    server.processRequest(req, htmlResponder);

  }
    
  /** parse the handle and request parameters from given string include form
   * selection resolve the handle and return the response */
  private final void doResolution(String handle)
    throws Exception 
  {
    // parse type from text of form
    ParameterSet parameters = ParameterParser.parseHandleURI(handle);
    String paramArr[] = parameters.getHandleParametersByName("type");

    currentHdl = parameters.handle;
    
    //currentHdl = StringUtils.decodeURLIgnorePlus(handle);
    
    // if we want to strip the trailing spaces of the handle, do here
    //currentHdl = currentHdl.trim();
   
    if (currentHdl.length()>=DOI_PROTOCOL_LENGTH && 
        (currentHdl.substring(0, DOI_PROTOCOL_LENGTH).equalsIgnoreCase(DOI_PROTOCOL) || 
         currentHdl.substring(0, DOI_PROTOCOL_LENGTH).equalsIgnoreCase(HDL_PROTOCOL)) ) {
      currentHdl = currentHdl.substring(DOI_PROTOCOL_LENGTH);
    } 
    // check if we are talking to an SFX/OpenURL-aware client...
    if(sfxEnabled) {
      for(Enumeration hdrs=headers.keys(); hdrs.hasMoreElements();) {
        String key = (String)hdrs.nextElement();
        if(key.equals("COOKIE")) {
          cookies.parseRequestHeader(((String)headers.get(key)).trim());
        }
      }
      if(cookies.containsCookie(sfxCookieName)) {
        sfxBaseURL = cookies.getCookieVal(sfxCookieName);
        sfxAwareClient = sfxBaseURL!=null;
        sfxID = handle.trim();
        suppressSFXRedirect = parameters.containsHandleParameter("nosfx");
      }
    }

    byte typesWanted[][] = null;
    if(paramArr!=null && paramArr.length > 0) {
      typesWanted = new byte[paramArr.length][];
      for(int i=0; i<typesWanted.length; i++) {
        typesWanted[i] = Util.encodeString(paramArr[i]);
      }
    }
    
    String indexes[] = parameters.getHandleParametersByName("index");
    int indexesWanted[] = null;
    if(indexes!=null && indexes.length > 0) {
      indexesWanted = new int[indexes.length];
      for(int i=0; i<indexes.length; i++) {
        try {
          indexesWanted[i] = Integer.parseInt(indexes[i]);
        } catch (Exception e) {
          indexesWanted[i] = 0;
        }
      }
    }
    
    // get the redirect and authRequest flag
    String noredirect[] = parameters.getHandleParametersByName(SUPPRESS_REDIRECT);
    if (noredirect!=null && noredirect.length>0) 
       suppressRedirect = true;

    // get the authoritive request
    String authReq[] = parameters.getHandleParametersByName(AUTH_FLAG);
    if (authReq!=null && authReq.length>0)
       authRequest = true;

    // get the alieas
    String followAli[] = parameters.getHandleParametersByName(DONT_FOLLOW_ALIASES);
    if (followAli!= null && followAli.length>0)
       followAliases = false; 
    
    // prepare for the logAccess in handleHtmlResponse
    if(sfxAwareClient && !suppressSFXRedirect) {
      currentHtmlLogAccessHdl = handle+"|"+sfxBaseURL;
      currentHtmlLogAccessType = ACCESS_TYPE_SFX;
    } else {
      currentHtmlLogAccessHdl = handle;
      currentHtmlLogAccessType = ACCESS_TYPE;
    }

    ResolutionRequest req = new ResolutionRequest(Util.encodeString(currentHdl),
                                                  typesWanted, indexesWanted, null);
    req.recursive = true;
    redirectSuffix = parameters.getLocalParameterString();
    if (redirectSuffix.length() > 0) redirectSuffix = "?"+redirectSuffix;
    if (redirectSuffix.length() == 0){
      // try new style redirect suffix
      String urlappend[] = parameters.getHandleParametersByName(URLAPPEND);
      if (urlappend.length > 0){  
        redirectSuffix = StringUtils.decodeURLIgnorePlus(urlappend[0]);
      }
    }
    server.processRequest(req, htmlResponder);
  }

  /** Decode the HDL encoded request from the input stream and return the
      result of processing the request in an AbstractResponse. */
  private final void handleHdlRequest(InputStream in)
    throws Exception
  {
    int r, n=0;

    // ignore extra newline char, if necessary
    r = in.read();
    if(r!='\n' && r!='\r') {
      envelopeBuf[0] = (byte)r;
      n++;
    }

    // receive and parse the message envelope
    while(n < Common.MESSAGE_ENVELOPE_SIZE &&
          (r=in.read(envelopeBuf, n, Common.MESSAGE_ENVELOPE_SIZE-n))>=0)
      n += r;

    if(n < Common.MESSAGE_ENVELOPE_SIZE) {
      // not all of the envelope was received...
      handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                       AbstractMessage.RC_ERROR,
                                       MSG_INVALID_MSG_SIZE));
      return;
    }
    
    Encoder.decodeEnvelope(envelopeBuf, envelope);
    
    if(envelope.messageLength > Common.MAX_MESSAGE_LENGTH ||
       envelope.messageLength < 0) {
      handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                       AbstractMessage.RC_ERROR,
                                       MSG_INVALID_MSG_SIZE));
      return;
    }
    
    // increase the messageBuf size if necessary
    if(messageBuf.length < envelope.messageLength)
      messageBuf = new byte[envelope.messageLength];

    // receive the rest of the message
    r = n = 0;
    while(n<envelope.messageLength &&
          (r=in.read(messageBuf, n, envelope.messageLength-n))>=0)
      n += r;
    
    if(n<envelope.messageLength)
      throw new HandleException(HandleException.MESSAGE_FORMAT_ERROR,
                                "Expecting "+envelope.messageLength+" bytes, "+
                                "only received "+n);
                                
    //decrypt incoming request if it says so
    if (envelope.encrypted) {
      if (envelope.sessionId > 0) {
        ServerSideSessionInfo sssinfo = null;
        if (server instanceof HandleServer) {
          
          sssinfo = ((HandleServer)server).getSession(envelope.sessionId);
          if (sssinfo != null) {
        
            try { 
              messageBuf = AbstractMessage.decryptMessage(messageBuf, sssinfo.getSessionKey());
            }
            catch (Exception e) {
              main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "Exception decrypting request: "+e);
              System.err.println("Exception decrypting request with session key: " + e.getMessage());
              handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_FAILED,
                                           Util.encodeString("Exception decrypting request with session key " + e)));
              return;
            }        
          } else {
            // sssinfo == null or request id < 0
            main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                            "Session information not available. Request message not decrypted.");
            System.err.println("Session information not available. Request message not decrypted.");
            handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_FAILED,
                                           Util.encodeString("Session manager not available. Unable to decrypt request message.")));
            return;
          }
        } else {   
          // serverSessionMan == null 
          main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                        "Session manager not available. Request message not decrypted.");
          System.err.println("Session manager not available. Request message not decrypted.");
          handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_FAILED,
                                           Util.encodeString("Session manager not available. Unable to decrypt request message.")));
   
          return;
        }
      } else {
        main.logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                        "Invalid session id. Request message not decrypted.");
        System.err.println("Invalid session id. Request message not decrypted.");
        handleResponse(new ErrorResponse(AbstractMessage.OC_RESERVED,
                                           AbstractMessage.RC_SESSION_FAILED,
                                           Util.encodeString("Invalid session id. Unable to decrypt request message.")));
        return;
      }
    }

    currentHdlRequest =
      (AbstractRequest)Encoder.decodeMessage(messageBuf, 0, envelope);
    
    String errMsg = interfc.canProcessMsg(currentHdlRequest);
    if(errMsg!=null) {
      main.logError(ServerLog.ERRLOG_LEVEL_REALBAD, errMsg);
      handleResponse(new ErrorResponse(currentHdlRequest.opCode,
                                       AbstractMessage.RC_PROTOCOL_ERROR,
                                       Util.encodeString(errMsg)));
      return;
      
    }
    
    server.processRequest(currentHdlRequest, this);
    
  }
  
  private final int determineRequestType(String contentType) {
    if(contentType==null) return MF_HTML;
    contentType = contentType.toUpperCase();
    if(contentType.indexOf(Common.HDL_MIME_TYPE.toUpperCase())>=0) return MF_HDL;
    return MF_HTML;
  }
  
  private final int determineResponseType(String acceptsValue) {
    if(acceptsValue==null) return MF_HTML;
    acceptsValue = acceptsValue.toUpperCase();
    if(acceptsValue.indexOf(Common.HDL_MIME_TYPE.toUpperCase())>=0) return MF_HDL;
    return MF_HTML;
  }
  
  /****************************************************************************
   * Handle (log) any messages that are reported by the upstream message
   * provider.
   ****************************************************************************/
  public void handleResponseError(String error) {
    main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                  String.valueOf(this.getClass())+": Server error: "+error);
  }

  public final void handleResponse(AbstractResponse response) {
    switch(responseType) {
      case MF_HDL:
        handleHdlResponse(response);
        break;
      case MF_HTML:
      default:
        handleHtmlResponse(response);
    }
  }

  private void handleHtmlResponse(AbstractResponse response) {
    BufferedWriter out = null;
    OutputStream ostr;

    try {
      try {
        ostr = socket.getOutputStream();
      }
      catch (Exception e){
        // connection closed prematurely-- don't log error
        try { socket.close(); }
        catch (IOException ee) {}
        return;
      }

      out = new BufferedWriter(new OutputStreamWriter(ostr, "UTF8"));

      // If this client is OpenURL-aware, redirect the user to
      // the SFX server for this handle - unless they indicated
      // that they want to suppress that kind of redirect.
      if(sfxEnabled && sfxAwareClient && !suppressSFXRedirect && sfxBaseURL!=null) {
        showHtmlPage = false;
        String uri[] = { sfxBaseURL+'?'+"id=doi:"+URLEncoder.encode(sfxID) };
        printRedirect(uri, out);
      } else if(response!=null && 
                response.opCode==AbstractMessage.OC_RESOLUTION &&
                response.responseCode==AbstractMessage.RC_SUCCESS) {
        
        // we found a value for the requested handle... return it
        HandleValue values[] = ((ResolutionResponse)response).getHandleValues();
        String uris[] = new String[values.length];

        // print a 'Location:' redirect for any URL values that were found
        if(!suppressRedirect) {
          for(int i=values.length-1; values!=null && i>=0; i--) {
            if(values[i].hasType(Common.STD_TYPE_URL)) {
              showHtmlPage = false;
              uris[i] = Util.decodeString(values[i].getData())+redirectSuffix;
            }
          }
        }
        if (showHtmlPage) printHtmlResponse(response, out);
        else printRedirect(uris, out);
      } else { // Error in resolution or query page requested
        printHtmlResponse(response, out);
      }
      out.flush();

      long respTime = System.currentTimeMillis() - recvTime;
      if(logAccesses && response != null){
          main.logAccess(currentHtmlLogAccessType, socket.getInetAddress(),
                         AbstractMessage.OC_RESOLUTION,
                         response.responseCode,
                         currentHtmlLogAccessHdl,
                         respTime);
      }
       
      socket.close();
    } catch (IOException e) {
       main.logError(ServerLog.ERRLOG_LEVEL_EVERYTHING,
           String.valueOf(this.getClass())+": Exception sending html response: "+e);
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
       String.valueOf(this.getClass())+": Exception sending html response: "+e);
      e.printStackTrace();
    } finally {
      if(out!=null) {
        try { out.flush(); } catch (Exception e) {}
        try { out.close(); } catch (Exception e) {}
      }
    }
  }

  private final void printRedirect(String uris[], Writer out) 
    throws IOException {
    out.write("HTTP/1.1 302 Moved Temporarily\n");
    out.write("Content-type: text/html; charset=utf-8\n");
    for (int i=0; i<uris.length; i++){
      if (uris[i] != null) out.write("Location: "+uris[i]+"\n");
    }
    out.write("\n<HTML><HEAD><TITLE>Handle Redirect</TITLE></HEAD>");
    out.write("\n<BODY><A HREF=\""+uris[0]+"\">");
    out.write(uris[0]+"</A></BODY></HTML>");
  }

  private final void printErrorPage(Writer out) throws IOException
  {
    String title;
    String trace = "";
    if (resolutionError== ERROR_HANDLE_NOT_EXIST){
       title = "Not Found";
    }
    else if (resolutionError==ERROR_SERVICE_NOTFOUND) {
       int index = currentHdl.indexOf("/");
       String na = (index != -1) ? currentHdl.substring(0, index) : currentHdl;
       title = "Naming Authority [" + na + "] Not Found"; 
    }
    else if (resolutionError == ERROR_CANNOT_CONNECT_SERVER){
       title = "Cannot Connect to Server";
    }
    else {
      title = "System Error";
      if(originalException != null) {
        trace = "<p><p>The original error: "+originalException;
      }
    }


    int pos = 0;
    int next = 0;
    for (Enumeration e = errorPage.elements(); e.hasMoreElements();){
      Object o = e.nextElement();
      if (o == ERROR_TOKEN){
        out.write(htmlEscape(title));
        pos = next + 8;
      }
      else if (o == HANDLE_TOKEN){
        out.write(htmlEscape(currentHdl));
        pos = next + 9;
      }
      else if (o == TRACE_TOKEN){
        out.write(htmlEscape(trace));
        pos = next + 8;
      }
      // //insert your own token string here.
      // else if (o == MYTOKEN) {
      //   out.write(htmlEscape(replacementForMyToken))
      //   pos = next + strlen(o) + 3;
      // }
      else {
        out.write((String)o);
        pos += next + 2;
      }
    }
    out.flush();
  }  

  private static final String htmlEscape(String str) {
    if(str==null) return "null";
    StringBuffer sb = new StringBuffer("");
    int sz = str.length();
    int idx = 0;
    for(int i=0; i<sz; i++) {
      char ch = str.charAt(i);
      if(ch=='<') sb.append("&lt;");
      else if(ch=='>') sb.append("&gt;");
      else if(ch=='"') sb.append("&quot;");
      else sb.append(ch);
    }
    return sb.toString();
  }
    
  private final void printHtmlResponse(AbstractResponse resp, Writer out)
    throws IOException
  {
    out.write("HTTP/1.0 200 OK\n");
    out.write("Content-type: text/html; charset=utf-8\n\n");
    if(resp == null) {
      // null response indicates that there was no valid request... display
      // query form or error has occured ...
      if (resolutionError == 0) out.write(queryPage);
      else {
        printErrorPage(out);
      }
      out.flush();
      return;
    }
    else if (resp instanceof ErrorResponse && resp.responseCode == AbstractMessage.RC_VALUES_NOT_FOUND){
      // the values requested not found. use response pages instead of error page.
    }
    else if(resp instanceof ErrorResponse){
      // print out friendly message
      if (resp.responseCode == AbstractMessage.RC_HANDLE_NOT_FOUND){
        resolutionError = ERROR_HANDLE_NOT_EXIST;
      }
      else {
        resolutionError = ERROR_UNKNOWN;
      }
      printErrorPage(out);
      out.flush();
      return;        
    }    
        
    // handle the ErrorResponse with RC_VALUES_NOT_FOUND error
    // use response page with message saying "No values found"
    if (resp instanceof ErrorResponse && resp.responseCode == AbstractMessage.RC_VALUES_NOT_FOUND) {
      if (currentHdl == null) {
        //current hdl shall not be null here
        resolutionError = ERROR_UNKNOWN;
        printErrorPage(out);
        out.flush();
        return; 
      } 
      int pos = 0;
      int next = 0;
      for (Enumeration e = responsePage.elements(); e.hasMoreElements();) {
        Object o = e.nextElement();
        if (o == HANDLE_TOKEN){
          out.write(htmlEscape(currentHdl));
          pos = next + 9;
        }
        else if (o == VALUES_TOKEN){
          out.write("<tr><td align=CENTER><b>No values found for requested types.</td></tr>");
 
          pos = next + 9;
        }
        else {
          out.write((String)o);
        }
      }
      out.flush();
      return;
    }
 
    ResolutionResponse rresp;
    HandleValue values[] = null;
    try {
      rresp = (ResolutionResponse)resp;
      values = rresp.getHandleValues();
    }
    catch (Exception e){
      originalException = e;
      resolutionError = ERROR_UNKNOWN;
      printErrorPage(out);
      out.flush();
      return;        
    }
    // print response page
    int pos = 0;
    int next = 0;
    for (Enumeration e = responsePage.elements(); e.hasMoreElements();) {
      Object o = e.nextElement();
      if (o == HANDLE_TOKEN){
        out.write(htmlEscape(Util.decodeString(rresp.handle)));
        pos = next + 9;
      }
      else if (o == VALUES_TOKEN){
        if (values!=null && values.length > 0) {
          // write out the "type" row
          out.write("<tr><td align=CENTER>Index</td><td align=CENTER>Type</td><td align=CENTER>Timestamp" +
                    "</td><td align=CENTER>Data</td></tr>");
        } else {
          // use same output for an ErrorResponse with VALUES_NOT_FOUND response code
          // don't know why certian time returns RC_SUCCESS with 0 values, sometimes returns ErrorResponse
          // with VALUES_NOT_FOUND response code
          out.write("<tr><td align=CENTER><b>No values found for requested types.</td></tr>");
        }     

        for(int i=0; values!=null && i<values.length; i++) {
          String dataStr = values[i].getDataAsString();
          String typeStr = values[i].getTypeAsString();
          String timeStampStr = values[i].getNicerTimestampAsString();

          out.write("<tr "+ (i%2==0? "bgcolor=\"#dddddd\"" : "bgcolor=\"#ffffff\"") +
                    "><td align=CENTER><b>"+values[i].getIndex()+"</b></td>"+
                    "<td align=CENTER><b>"+htmlEscape(typeStr)+"</b></td>");

          out.write("<td nowrap>"+htmlEscape(timeStampStr) + "</td>");
          if(values[i].hasType(Common.STD_TYPE_URL))    //URL
            out.write("<td><a href=\""+ dataStr+"\">"+
                      htmlEscape(dataStr)+"</a></td>");
          else if(values[i].hasType(Common.STD_TYPE_EMAIL))    //EMAIL
            out.write("<td><a href=\"mailto:"+ dataStr+"\">"+
                      htmlEscape(dataStr)+"</a></td>");
          else out.write("<td>"+htmlEscape(dataStr)+"</td>");

          out.write("</tr>\n");
        }
        pos = next + 9;
      }
      // //insert your own token string here.
      // else if (o == MYTOKEN) {
      //   out.write(htmlEscape(replacementForMyToken))
      //   pos = next + strlen(o) + 3;
      // }
      else {
        out.write((String)o);
      }
    }
    out.flush();
  }
    
  
  /****************************************************************************
   * Encode and send the response
   ****************************************************************************/
  private void handleHdlResponse(AbstractResponse response) {
    OutputStream out = null;
    try {
      byte msg[] = response.getEncodedMessage();

      //when to encrypt? right before sending it out! after the credential
      //portion is formed!  encrypt response here if the request asks for
      //encryption and set the flag in envelop if successful
      boolean encrypted = false;
      if (response.encrypt && response.sessionId > 0){
        ServerSideSessionInfo sssinfo = null;
        if (server instanceof HandleServer) {
          
          sssinfo = ((HandleServer)server).getSession(response.sessionId);
          if (sssinfo != null && sssinfo.lastRequestId > 0) {
        
            try { 
              msg = AbstractMessage.encryptMessage(msg, sssinfo.getSessionKey());
              encrypted = true;
            }
            catch (Exception e) {
              main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Exception encrypting response: "+e);
              System.err.println("Exception encrypting message with session key: " + e.getMessage());
              encrypted = false;
            }        
          } // sssinfo != null
        } else {   
          // serverSessionMan == null 
          main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                            "Session manager not available. Message not encrypted.");
          System.err.println("Session manager not available. Message not encrypted.");
          encrypted = false;
        }
      }
      
      // set the envelop flag for encryption
      envelope.encrypted = encrypted;
      envelope.messageLength = msg.length;  //use the length after encryption
      envelope.messageId = 0;
      envelope.sessionId = response.sessionId;
      envelope.protocolMajorVersion = response.majorProtocolVersion;
      envelope.protocolMinorVersion = response.minorProtocolVersion;
      
      Encoder.encodeEnvelope(envelope, envelopeBuf);
      
      out = new BufferedOutputStream(socket.getOutputStream(),512);

      out.write(Util.encodeString("HTTP/1.0 200 OK\r\n"));
      out.write(Util.encodeString("Content-length: "+(envelopeBuf.length+msg.length)+"\r\n"));
      out.write(Util.encodeString("Content-type: "+Common.HDL_MIME_TYPE+"\r\n"));
      out.write(Util.encodeString("\r\n"));
      out.write(envelopeBuf);
      out.write(msg);

      // move logAccess() to here 
      long respTime = System.currentTimeMillis() - recvTime;
      if(logAccesses) {
        if (currentHdlRequest!=null)  
          main.logAccess(ACCESS_TYPE, socket.getInetAddress(),
                         currentHdlRequest.opCode, 
                         (response != null ? response.responseCode : AbstractMessage.RC_ERROR),
                         Util.decodeString(currentHdlRequest.handle), respTime);
      }

      // if the response is "streamable," send the streamed part...
      if(response.streaming) {
        response.streamResponse(out);
      }
    } catch (Exception e) {
      main.logError(ServerLog.ERRLOG_LEVEL_NORMAL,
                    String.valueOf(this.getClass())+": Exception sending response: "+e);
      e.printStackTrace(System.err);
    } finally {
      if(out!=null) {
        try { out.flush(); } catch (Exception e) {}
        try { out.close(); } catch (Exception e) {}
      }
    }
  }

}
