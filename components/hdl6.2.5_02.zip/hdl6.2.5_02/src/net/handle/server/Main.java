/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;
import net.handle.util.*;
import java.util.*;
import java.net.*;
import java.io.*;

/*******************************************************************************
 *
 * Main class: instantiates a server and listeners, and starts them all.  This
 * class is invoked on the command-line and reads the configuration file.
 *
 ******************************************************************************/

public class Main {
  private AbstractServer server;
  private Vector interfaces;
  private StreamTable configTable;
  private File serverDir;
  private static ServerLog logger;
  private ThreadGroup interfaceThreadGroup = null;
  private HandleResolver resolver = null;
  private static final String CACHE_STORAGE_FILE = "cache.jdb";
  private Object gcLock = new Object();
  
  private static void printUsage() {
    System.err.println("Usage: <program-name> <config-directory>");
  }
  
  public static void main(String argv[]) {
    String configDirStr = null;
    
    if ((argv == null) || (argv.length != 1)) {
      printUsage();
      return;
    }
    
    if (!Util.checkJavaVersion())
      return;
    
    configDirStr = argv[0];            // The only argument is the config-dir name
    
    Main main = null;
    
    StreamTable configTable = new StreamTable();
    // Get, check serverDir
    File serverDir = new File(configDirStr);
    
    if (!((serverDir.exists()) && (serverDir.isDirectory()))) {
      System.err.println("Invalid configuration directory: " + configDirStr + ".");
      return;
    }
    
    // Load configTable from the config file
    try {
      configTable.readFromFile(new File(serverDir, HSG.CONFIG_FILE_NAME));
    } catch (Exception e) {
      System.err.println("Error reading configuration: " + e);
      return;
    }
    
    // Create the Main server object and start it
    try {
      main = new Main(serverDir, configTable);
      main.initialize();
      main.start();
    } catch (Exception e) {
      e.printStackTrace(System.err);
      System.out.println("Error: " + e.getMessage());
      System.out.println("       (see the error log for details.)\n");
      System.out.println("Shutting down...");
      System.err.println("Shutting down...");
      try { main.shutdown(); } catch (Exception e2) { /* Ignore */ }
      System.exit(0);
    }
  }
  
  /**
   * Constructor for the Main object
   */
  public Main(File serverDir, StreamTable configTable)
    throws Exception
  {
    this.serverDir = serverDir;
    this.configTable = configTable;
    logger = new ServerLog(serverDir, configTable);
  }

  /**
   * Get the resolver that should be used to resolve all handles.
   * This resolver may be configured to avoid UDP or perhaps send
   * resolution requests through an HTTP proxy.
   */

  public HandleResolver getResolver() {
    return this.resolver;
  }
  
  /**
   * Create a server object, and all of the interface objects based on
   * the configuration.
   */
  public File getConfigDir() {
    return serverDir;
  }

  /**
   * Create a server object, and all of the interface objects based on
   * the configuration.
   */
  public void initialize()
    throws Exception
  {
    System.runFinalizersOnExit(true);
    
    // Configure the resolver
    this.resolver = new HandleResolver();
    
    if (configTable.containsKey("tcp_timeout")) {
      int timeout = Integer.parseInt((String)configTable.get("tcp_timeout"));
      this.resolver.setTcpTimeout(timeout);
    }
    
    this.resolver.setCheckSignatures(true);
    this.resolver.traceMessages = configTable.containsKey("trace_resolution");
    try {
      File cacheFile = new File(getConfigDir(), CACHE_STORAGE_FILE);
      if (cacheFile.exists())
        cacheFile.delete();
      
      Cache cache = new JDBCache(cacheFile);
      this.resolver.setCache(cache);
    } catch (Exception e) {
      System.err.println("Warning: Cannot create handle cache (" + e + ").");
      e.printStackTrace(System.err);
    }
    
    if (configTable.containsKey("no_udp_resolution"))
      resolver.setPreferredProtocols(new int[] { Interface.SP_HDL_TCP,
                                                 Interface.SP_HDL_HTTP });
    // Create the server object
    server = AbstractServer.getInstance(this, configTable);
    
    interfaces = new Vector();
    // Get the list of listeners
    Object obj = configTable.get(HSG.INTERFACES);
    if ( (obj == null)
         || (!(obj instanceof Vector))
         || (((Vector)obj).size() < 1)) {
      throw new Exception("No \"" + HSG.INTERFACES + "\" specified!");
    }

    Vector frontEndLabels = (Vector)obj;
    for (int i = 0; i < frontEndLabels.size(); i++) {
      String frontEndLabel = String.valueOf(frontEndLabels.elementAt(i));
      NetworkInterface ifc = NetworkInterface.getInstance(this, frontEndLabel,
                                                          configTable);
      interfaces.addElement(ifc);
    }
  }

  /**
   * Get the server object that handles requests sent to this server
   */
  public AbstractServer getServer() {
    return server;
  }

  /**
   * Start all of the listener threads and begin taking requests
   */
  public void start() {
    interfaceThreadGroup = new ThreadGroup("Network Interfaces");
    
    for (int i = 0; i < interfaces.size(); i++) {
      NetworkInterface interfc = (NetworkInterface)interfaces.elementAt(i);
      Thread t = new Thread(interfaceThreadGroup, interfc);
      t.start();
    }
    // Create thread to run garbage collector
    // after enough requests have been served
    Runnable r = new Runnable() {
      public void run() {
        while (interfaces.size() > 0) {
          // See if any of the interfaces need to be reset
          
          boolean needsGC = false;
          
          for (int i = interfaces.size()-1; i >= 0; i--) {
            if (((NetworkInterface)interfaces.elementAt(i)).needsGC()) {
              needsGC = true;
              break;
            }
          }
              
          if (needsGC) {                  // If necessary...
            System.gc();             // ...run the GC,...
            System.runFinalization();
            
            // ...then reset the gc counters
            
            for (int i = interfaces.size()-1; i >= 0; i--) {
              ((NetworkInterface)interfaces.elementAt(i)).resetGC();
            }
          }
          
          // wait 30 seconds and check again
          try {
            synchronized(gcLock) {
              if(interfaces.size()<=0) return;;
              gcLock.wait(30000);
            }
          } catch (Exception e) { /* Ignore */ }
        }
      }
    };
    
    Thread t = new Thread(r);
    t.setDaemon(true);
    t.start();
    
    // add a hook to safely shut down the interfaces, loggers, and databases
    // when exiting.
    Runtime.getRuntime().addShutdownHook(new Thread() {
      public void run() {
        cleanUp();
      }
    });
  }
  
  /**
   * Bring down all interfaces, save any files, shutdown the server, and exit.
   * (I.e., does not return.)
   */
  public void shutdown() {
    System.exit(0);
  }
  
  private void cleanUp() {
    logError(ServerLog.ERRLOG_LEVEL_INFO,
             "Shutting down server at "+(new java.util.Date()));
    
    // Shut down all listeners
    while (interfaces.size() > 0) {
      NetworkInterface interfc = (NetworkInterface)interfaces.elementAt(0);
      interfaces.removeElementAt(0);
      try {
        interfc.stopRunning();
      } catch (Throwable e) {
        logError(ServerLog.ERRLOG_LEVEL_REALBAD,
                 "unable to shut down interface " + interfc + "; reason: " + e );
      }
    }
    
    try {
      synchronized(gcLock) { gcLock.notifyAll(); }
    } catch (Throwable e) {}
    
    // Try to stop all threads (in case the above didn't work)
    try { interfaceThreadGroup.stop(); } catch (Throwable t) { /* Ignore */ }
    
    try {   // Shut down the server
      server.shutdown();
    } catch (Exception e) {
      String msg = "Exception shutting down handle server :" + e;
      logError(ServerLog.ERRLOG_LEVEL_REALBAD, msg);
      System.err.println(msg);
      e.printStackTrace(System.err);
    }
    
    if (logger != null) {
      try {
        logger.shutdown();
      } catch (Exception e) {
        System.err.println("Error shutting down logger: " + e);
      }
    }
  }
  
  
  /**
   * Write the specified access record to the log
   */
  public void logAccess(String accesssType, InetAddress addr,
                        int opCode, int rsCode, String message, long time) {
    if (logger == null) {
      System.out.println("Access: type=" + accesssType + "; addr="
                         + addr.getHostAddress() + "; opCode: " + opCode
                         + "; respCode: " + rsCode
                         + "; message: " + message + "; " + time + "ms");
    } else {
      logger.logAccess(accesssType, addr, opCode, rsCode, message, time);
    }
  }

  /**
   * Write the specified error record to the log
   */
  public void logError(int level, String message) {
    if (logger == null)
      System.err.println("Error: level=" + level + "; message: " + message);
    else
      logger.logError(level, message);
  }

}
