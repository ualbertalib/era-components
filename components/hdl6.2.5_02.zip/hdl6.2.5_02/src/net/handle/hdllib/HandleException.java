/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

public class HandleException extends Exception {
  public static final int INVALID_VALUE = 0;
  public static final int INTERNAL_ERROR = 1;
  public static final int SERVICE_NOT_FOUND = 2;
  public static final int NO_ACCEPTABLE_INTERFACES = 3;
  public static final int UNKNOWN_PROTOCOL = 4;
  public static final int HANDLE_ALREADY_EXISTS = 5;
  public static final int MESSAGE_FORMAT_ERROR = 6;
  public static final int CANNOT_CONNECT_TO_SERVER = 7;
  public static final int UNABLE_TO_AUTHENTICATE = 8;
  public static final int HANDLE_DOES_NOT_EXIST = 9;
  public static final int SECURITY_ALERT = 10;
  public static final int CONFIGURATION_ERROR = 11;
  public static final int REPLICATION_ERROR = 12;
  public static final int MISSING_OR_INVALID_SIGNATURE = 13;
  public static final int MISSING_CRYPTO_PROVIDER = 14;
  public static final int SERVER_ERROR = 15;
  public static final int UNKNOWN_ALGORITHM_ID = 16;
  public static final int GOT_EXPIRED_MESSAGE = 17;
  public static final int STORAGE_RDONLY = 18;
  public static final int UNABLE_TO_SIGN_REQUEST = 19;
  public static final int INVALID_SESSION_EXCHANGE_PRIVKEY = 20;
  public static final int NEED_RSAKEY_FOR_SESSIONEXCHANGE = 21;
  public static final int NEED_PUBLICKEY_FOR_SESSIONIDENTITY = 22;
  public static final int SESSION_TIMEOUT = 23;
  public static final int INCOMPLETE_SESSIONSETUP = 24;
  public static final int SERVER_CANNOT_PROCESS_SESSION = 25;
  public static final int ENCRYPTION_ERROR = 26;

  public static final String getCodeStr(int c) {
    switch(c) {
      case INVALID_VALUE: return "INVALID_VALUE";
      case INTERNAL_ERROR: return "INTERNAL_ERROR";
      case SERVICE_NOT_FOUND: return "SERVICE_NOT_FOUND";
      case NO_ACCEPTABLE_INTERFACES: return "NO_ACCEPTABLE_INTERFACES";
      case UNKNOWN_PROTOCOL: return "UNKNOWN_PROTOCOL";
      case HANDLE_ALREADY_EXISTS: return "HANDLE_ALREADY_EXISTS";
      case MESSAGE_FORMAT_ERROR: return "MESSAGE_FORMAT_ERROR";
      case CANNOT_CONNECT_TO_SERVER: return "CANNOT_CONNECT_TO_SERVER";
      case UNABLE_TO_AUTHENTICATE: return "UNABLE_TO_AUTHENTICATE";
      case HANDLE_DOES_NOT_EXIST: return "HANDLE_DOES_NOT_EXIST";
      case SECURITY_ALERT: return "SECURITY_ALERT";
      case CONFIGURATION_ERROR: return "CONFIGURATION_ERROR";
      case REPLICATION_ERROR: return "REPLICATION_ERROR";
      case UNKNOWN_ALGORITHM_ID: return "UNKNOWN_ALGORITHM_ID";
      case MISSING_OR_INVALID_SIGNATURE: return "MISSING_OR_INVALID_SIGNATURE";
      case MISSING_CRYPTO_PROVIDER: return "MISSING_CRYPTO_PROVIDER";
      case SERVER_ERROR: return "SERVER_ERROR";
      case GOT_EXPIRED_MESSAGE: return "GOT_EXPIRED_MESSAGE";
      case STORAGE_RDONLY: return "STORAGE_RDONLY";
      case UNABLE_TO_SIGN_REQUEST: return "UNABLE_TO_SIGN_REQUEST";
      case INVALID_SESSION_EXCHANGE_PRIVKEY: return "INVALID_SESSION_EXCHANGE_PRIVKEY";
      case NEED_RSAKEY_FOR_SESSIONEXCHANGE: return "NEED_RSAKEY_FOR_SESSIONEXCHANGE";
      case NEED_PUBLICKEY_FOR_SESSIONIDENTITY: return "NEED_PUBLICKEY_FOR_SESSIONIDENTITY";
      case SESSION_TIMEOUT: return "SESSION_TIMEOUT";
      case INCOMPLETE_SESSIONSETUP: return "INCOMPLETE_SESSIONSETUP";
      case SERVER_CANNOT_PROCESS_SESSION: return "SERVER_CANNOT_PROCESS_SESSION";
      case ENCRYPTION_ERROR: return "ENCRYPTION_ERROR";
      default: return "UNKNOWN_ERROR("+c+")";
    }
  }

  private int code;

  public HandleException(int code) {
    super();
    this.code = code;
  }

  public HandleException(int code, String message) {
    super(message);
    this.code = code;
  }

  public int getCode() { return code; }


  public String toString() {
    String msg = getMessage();
    if (msg == null) msg = "";
    return "HandleException ("+getCodeStr(code)+") "+msg;
  }
}
