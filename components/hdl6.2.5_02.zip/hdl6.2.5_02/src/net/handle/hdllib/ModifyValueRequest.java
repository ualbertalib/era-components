/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/******************************************************************************
 * Request used to modify a value of an existing handle.  Holds the handle
 * as well as the value to be modified.  The value that will be modified
 * on the server is the one that has the same ID as the value in this
 * message.
 ******************************************************************************/

public class ModifyValueRequest
  extends AbstractRequest
{

  public HandleValue values[];


  public ModifyValueRequest(byte handle[], HandleValue value,
                            AuthenticationInfo authInfo) {
    this(handle, new HandleValue[]{value}, authInfo);
  }

  public ModifyValueRequest(byte handle[], HandleValue values[], 
                            AuthenticationInfo authInfo) {
    super(handle, AbstractMessage.OC_MODIFY_VALUE, authInfo);
    this.values = values;
    this.isAdminRequest = true;
  }

}
