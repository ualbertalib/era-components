/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.net.*;
import java.io.*;
import java.util.*;
import java.security.*;
import javax.crypto.interfaces.DHPublicKey;
import javax.crypto.interfaces.DHPrivateKey;
import net.handle.security.*;
import net.handle.util.LRUCacheTable;


/** Responsible for locating and retrieving the value of handles using
 *  a caching server, or on the internet.
 */
public class HandleResolver {
  public boolean traceMessages = false;

  private static final byte HTTP_ACCEPT_HEADER[] =
    Util.encodeString("Accept: "+Common.HDL_MIME_TYPE+"\r\n");
  private static final byte HTTP_AGENT_HEADER[] =
    Util.encodeString("User-Agent: CNRI-HCL 2.0\r\n");
  private static final byte HTTP_CONTENT_TYPE_HEADER[] =
    Util.encodeString("Content-Type: "+Common.HDL_MIME_TYPE+"\r\n");
  private static final byte HTTP_NEWLINE[] =
    Util.encodeString("\r\n");
  
  private static int nextRequestId = 1;
  private static int globalMessageId = Math.abs((new java.util.Random()).nextInt());

  private Random random;  // used for sessions
  
  private Configuration config = Configuration.defaultConfiguration();
  
  private int preferredProtocols[] = { Interface.SP_HDL_UDP, 
                                       Interface.SP_HDL_TCP,
                                       Interface.SP_HDL_HTTP };

  private ClientSessionTracker resolverSessions = null;
  private int maxUDPDataSize = Common.MAX_UDP_DATA_SIZE;
  private Cache secureCache = null;
  private Cache cache = null;
  private int udpRetryScheme[] = { 1000, 2000, 3000 };

  // timeout used for normal hdl-tcp and hdl-http connections(1 minute)
  private int tcpTimeout = 60000;

  // true if this resolver should check for and verify
  // signatures on responses to requests that have the
  // 'certify' bit set.
  private boolean checkSignatures = true;
  
  // keep performance data for sites
  private LRUCacheTable responseTimeTbl = new LRUCacheTable(64);
  
  // for servers that support more than just DES (protocol >= 2.2) when the client generates the key
  private int preferredEncryptionAlgorithm = HdlSecurityProvider.ENCRYPT_ALG_DES;


  public HandleResolver(){
    setCache(new MemCache());
    setCertifiedCache(new MemCache());
  }

  /*****************************************************************************
   *
   * Return a copy of preferredProtocols[], wherein protocols are listed in
   * order of preference.  For use by methods which do not have access to the
   * private int-array.
   *
   */

  public int[] protocolsByPreference()
  {
   int protocolList[] = new int[preferredProtocols.length];

       for (int i = 0; i < preferredProtocols.length; i++)
           protocolList[i] = preferredProtocols[i];

       return protocolList;
  }

  /*****************************************************************************
   *
   * This method releases all of the session tracked by the given
   *  session tracker.
   *
   */ 

 /* FIXME - not finished...
  public void releaseSessions(ClientSessionTracker sessionTracker)
    throws HandleException
  {
    ClientSideSessionInfo sessions[] = sessionTracker.getAllSessions();

    for(int i=0; sessions!=null && i<sessions.length; i++) {
      try {
        releaseSession(sessions[i], 
                       sessionTracker.getAuthenticationInfo(sessions[i]));
                       sessionTracker.removeSession(sessions[i]);
        
      } catch (Exception e) {
        System.err.println("Warning: unable to release or remove session: "
                           +sessions[i]);
      }
    }
  }
*/

  /** Close down the given session.  This closes the session with
      the server so that it cannot be used anymore and frees up some
      resources.  The given authentication info is used to send a close-
      session request to the server. */
 /* FIXME - I haven't finished this one yet...
  public void releaseSession(ClientSideSessionInfo sessionInfo, AuthenticationInfo authInfo)
    throws HandleException
  {
    throw new HandleException(HandleException.INTERNAL_ERROR,
                              "Release Session Not Implemented");

    // send SESSION_TERMINATE request to server
    AbstractResponse response = null;
      
    for (int i=0; i<sessions.length; i++) {
      GenericRequest sessionTermReq = new GenericRequest(Common.BLANK_HANDLE,
                                                         AbstractMessage.OC_SESSION_TERMINATE,
                                                         authInfo);
      //set the session id from session info
      sessionTermReq.sessionId = csinfo.sessionId;
        
      try {
        //sign the request with MAC code using session key
        sessionTermReq.signMessage(csinfo.sessionKey);
      }
      catch (Exception e){
        System.err.println("Can not sign message for SESSION_TERMINATE request." + e.getMessage());  
        if (e instanceof HandleException){
          throw (HandleException)e;
        } else {
          throw new HandleException(HandleException.UNABLE_TO_SIGN_REQUEST,
                                  "Uanle to sign session termination request: " + e);
        }
      }
        
      //use latest version as version number 
      sessionTermReq.majorProtocolVersion = Common.MAJOR_VERSION;
      sessionTermReq.minorProtocolVersion = Common.MINOR_VERSION;
      
      try {
        response = sendRequestToServer(sessionTermReq, csinfo.server);
        if ((response.opCode == AbstractMessage.OC_SESSION_TERMINATE &&
          response.responseCode == AbstractMessage.RC_SUCCESS)    ||
          response.responseCode == AbstractMessage.RC_SESSION_TIMEOUT) {
               
          //remove the client session info anyway.
          //force the system establish a new session next time
          clientSessionMan.removeSessionInfo(csinfo.server, authInfo, csinfo.sessionId);
        
        }
      }
      catch (HandleException e) {
        msg += "server: " + csinfo.server.toString() + " ";
        sessionTerminateFail = true;
      }
    }
      
    if (sessionTerminateFail) {
      // do something here
      System.err.println(msg);
    }
    
    //releasing session failure really doesn't matter, because the server then will time out
    //all un-used sessions
    return;
  }
*/
  
  /** this method will retrieve the handle values by the given handle/index pair
      Now only used to retrieve public key data in veryfying the session setup
      data.
  */
  public byte[] retrieveHandleIndexData(byte handle[], int index) throws Exception{   
    // first retrieve the public key (checking server signatures, of course)
    ResolutionRequest req = new ResolutionRequest(handle, null,
                                                  new int[] { index },
                                                  null);
    req.certify = true;
    
    AbstractResponse response = this.processRequest(req);
    
    if(!(response instanceof ResolutionResponse))
      throw new Exception("Unable to verify resolve the handle/index \n"+response);
    
    HandleValue values[] = ((ResolutionResponse)response).getHandleValues();
    if(values==null || values.length < 1)
      throw new Exception("The index specified does not exist\n");
    
    // return the value data
    return values[0].getData();
  }
 
  /** create a new session setup object using any existing session information
      that may be around.
  */ 
  private SessionSetupRequest createSessionSetupRequest(
                                                  AuthenticationInfo authInfo,
                                                  SessionSetupInfo options)
    throws HandleException
  {
    if(options == null) {
      throw new HandleException(HandleException.INVALID_VALUE,
              "Cannot create session setup request with null SessionSetupInfo");
    }

    SessionSetupRequest ssreq=new SessionSetupRequest();
    ssreq.keyExchangeMode = options.keyExchangeMode;
    if (authInfo != null) {
      ssreq.identityHandle = authInfo.getUserIdHandle();
      ssreq.identityIndex = authInfo.getUserIdIndex();
    }
    
    if (options.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_HDL){
      ssreq.exchangeKeyHandle = options.exchangeKeyHandle;
      ssreq.exchangeKeyIndex = options.exchangeKeyIndex;
    } 
    else if (options.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_CLIENT ||
             options.keyExchangeMode == Common.KEY_EXCHANGE_DH){
      ssreq.publicKey = options.publicExchangeKey;
    } 

    ssreq.certify = true;
    ssreq.encrypt = false;
    ssreq.returnRequestDigest = true;
    ssreq.majorProtocolVersion = Common.MAJOR_VERSION;
    ssreq.minorProtocolVersion = Common.MINOR_VERSION;
    
    // session set up request can not be encrypted, because there is no session
    // key setup yet encrypted? authenticated? timeout?
    ssreq.encryptAllSessionMsg = options.encrypted;
    ssreq.authAllSessionMsg = options.authenticated;
    if (options.timeout > 0) 
      ssreq.timeout = options.timeout;
    return ssreq; 
  }
  
  /** retrieve the session option for a specific authenticated user.
      if auth is null, the anonymous session option will be returned.
  public SessionSetupInfo retrieveUserSessionOption(AuthenticationInfo auth) {
    if (clientSessionMan != null) {
      return clientSessionMan.getUserSessionOption(auth);
    } else
      return null;
  }
  */
  
  private synchronized int getNextRequestId() {
    return nextRequestId++;
  }
  
  /** Gives the resolver a Cache object to use when resolving.
    * When sending requests, the cache will be checked for the
    * handle instead of always using the network.  Setting the
    * cache object to null will cause the resolver to not use
    * any cache.
    */
  public void setCache(Cache cache) {
    if(this.secureCache!=null && this.secureCache==cache)
      throw new RuntimeException("Error:  attempt to set the certified and regular cache to the same value");
    this.cache = cache;
  }
  
  /** Gives the resolver a Cache object to use for certified resolutions.
    * When sending certified resolution requests, this cache will be 
    * checked for the handle instead of always using the network.  Setting the
    * cache object to null will cause the resolver to not use any cache for
    * certified resolutions.  Note:  It is important to never use the same
    * cache (or backing storage) for the certified and regular cache.  Doing
    * so could poison the certified cache with uncertified values.
    */
  public void setCertifiedCache(Cache cache) {
    if(this.cache!=null && this.cache==cache)
      throw new RuntimeException("Error:  attempt to set the certified and regular cache to the same value");
    this.secureCache = cache;
  }

  /** Clear any caches being used by this resolver */
  public void clearCaches()
    throws Exception
  {
    Cache c;
    c = secureCache;
    if(c!=null) c.clear();
    c = cache;
    if(c!=null) c.clear();
  }
  
  /*************************************************************
   * Gives the resolver a session tracker object to use when
   * resolving.  When sending administrative requests and the
   * resolver's session tracker is non-null, it is used to
   * establish (or continue) a session with whatever server is
   * being communicated with.  Note: If there is a sessionInfo
   * or session tracker already associated with a request, then
   * the resolver's session tracker is ignored.
   * Warning:  If this resolver is going to be used in several
   * administrative contexts (ie with several different admin IDs)
   * because authenticated sessions could possibly be used by a
   * different administrator than was intended.
   *************************************************************/
  public void setSessionTracker(ClientSessionTracker sessionTracker) {
    this.resolverSessions = sessionTracker;
  }

  /** Returns the current default session tracker. */
  public ClientSessionTracker getSessionTracker() {
    return this.resolverSessions;
  }

  /*************************************************************
   * Set the configuration used for resolution.  This configuration
   * indicates whether requests are processed using a network
   * cache (ala DNS) or if we talk directly to the handle system.
   *************************************************************/
  public void setConfiguration(Configuration config) {
    this.config = config;
  }

  /********************************************************************
   * Set the protocols and the order of preference used for resolution
   * For every server that this resolver talks to, it attempts to
   * communicate via the given protocols either until it succeeds or
   * all attempts to communicate fail.  If a client is behind a firewall
   * and not using a caching server then it would be best to set the
   * preferred protocols to Interface.SP_HDL_TCP and Interface.SP_HDL_HTTP
   * since the Interface.SP_HDL_UDP will probably just get blocked by
   * firewalls and be a big waste of time.
   ********************************************************************/
  public void setPreferredProtocols(int prefProtocols[]) {
    this.preferredProtocols = new int[prefProtocols.length];
    System.arraycopy(prefProtocols, 0, this.preferredProtocols, 0, preferredProtocols.length);
  }
  
  
  /** Set the maximum size of the data part of a message before it is
    * split into multiple messages when using UDP. */
  public void setMaxUDPDataSize(int newMaxUDPDataSize) {
    this.maxUDPDataSize = newMaxUDPDataSize;
  }
  
  
  /** Return the maximum size of the data part of a message before it is
    * split into multiple messages when using UDP. */
  public int getMaxUDPDataSize() {
    return this.maxUDPDataSize;
  }
  
  
  /*************************************************************
   * Get the resolution configuration
   *************************************************************/
  public Configuration getConfiguration() {
    return this.config;
  }
  
  /*****************************************************************
   * Set how long to wait for responses to TCP and HTTP requests.
   *****************************************************************/
  public void setTcpTimeout(int newTcpTimeout) {
    this.tcpTimeout = newTcpTimeout;
  }

  /*****************************************************************
   * Get how long to wait for responses to TCP requests.
   *****************************************************************/
  public int getTcpTimeout() {
    return this.tcpTimeout;
  }

  /*******************************************************************
   * Get the array that specifies how long to wait for responses to
   * each UDP request.  The length of this array will indicate how
   * many UDP requests to send before giving up.  The default scheme
   * is something like {1000, 2000, 3000} which is 1 second, 2 seconds,
   * 3 seconds.
   *******************************************************************/
  public int[] getUdpRetryScheme() {
    int urs[] = new int[udpRetryScheme.length];
    System.arraycopy(udpRetryScheme, 0, urs, 0, urs.length);
    return urs;
  }
  
  /*******************************************************************
   * Set the array that specifies how long to wait for responses to
   * each UDP request.  The length of this array will indicate how
   * many UDP requests to send before giving up.  The default scheme
   * is something like {1000, 2000, 3000} which is 1 second, 2 seconds,
   * 3 seconds.
   *******************************************************************/
  private void setUdpRetryScheme(int[] newudpRetryScheme) {
    udpRetryScheme = null;
    udpRetryScheme = new int[newudpRetryScheme.length];
    System.arraycopy(newudpRetryScheme, 0, udpRetryScheme, 0, udpRetryScheme.length);
  }
  
  /*************************************************************
   * Set whether or not this object should check the signatures
   * of server responses to certified requests.  The default
   * is to check signatures and throw an exception if a signature
   * to any certified message is missing or invalid.
   *************************************************************/
  public void setCheckSignatures(boolean checkSigs) {
    this.checkSignatures = checkSigs;
  }

  /************************************************************************
   * Locate and return the values of the given handle that have the
   * specified types or indexes.  This method simply creates a
   * ResolutionRequest object from the given parameters and calls
   * processRequest with that request object.  The requested handle
   * values are then extracted from the response and returned (or an
   * exception is thrown if there was an error).
   * 
   * Creating your own ResolutionRequest objects and calling processRequest
   * directly allows more flexibility since you can set the certified,
   * authoritative, and recursive flags of the request.
   *
   * When specifying both a set of types or indexes, a server will
   * return all handle values that have the requested types as well
   * as all handle values that have the requested indexes.  Essentially,
   * the union of the set of handles with the requested types and the 
   * set of handles with the requested indexes is returned.  An empty
   * index or type list indicates that any index or type is acceptable.
   *
   * The following examples describe how the type and index lists are
   * used in resolutions:
   *<pre>
   *  Type-List       Index List       Returns
   *   [ URL ]         [ 0, 12 ]       Any URL values, as well as values
   *                                    with indexes 0 and 12 if they exist.
   *   [ ]             [ 1 ]           The value with index one only
   *   [ EMAIL ]       [ ]             Any values with type EMAIL
   *   [ ]             [ ]             All of the values associated with the
   *                                    given handle
   *</pre>
   *
   *********************************************************************************/
  public HandleValue[] resolveHandle(String sHandle, String sTypes[], int indexes[]) 
    throws HandleException
  {
    if(sTypes==null) sTypes = new String[0];
    if(indexes==null) indexes = new int[0];

    // convert the types and handle to UTF8 byte-strings
    byte types[][] = new byte[sTypes.length][];
    byte handle[];

    handle = Util.encodeString(sHandle);
    for(int i=0; i<sTypes.length; i++)
      types[i] = Util.encodeString(sTypes[i]);

    AbstractResponse response =
      processRequest(new ResolutionRequest(handle,types,indexes,null), null);

    if(response.responseCode==AbstractMessage.RC_HANDLE_NOT_FOUND) {
      throw new HandleException(HandleException.HANDLE_DOES_NOT_EXIST);
    } else  if (response instanceof ErrorResponse){
      String msg = Util.decodeString( ((ErrorResponse)response).message );
      
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                AbstractMessage.getResponseCodeMessage(response.responseCode)+": "+msg);
    }

    HandleValue values[] = ((ResolutionResponse)response).getHandleValues();
    if(values==null)
      return null;
    if(sTypes.length<=0 && indexes.length<=0)
      return values;

    int numValues = values.length;
    for(int i=0; i<values.length; i++) {
      if((sTypes.length>0 && Util.isInArray(types, values[i].type)) ||
         (indexes.length>0 && Util.isInArray(indexes, values[i].index)))
        continue;
      values[i] = null;
      numValues--;
    }

    if(numValues==values.length) {
      return values;
    }
    HandleValue filteredVals[] = new HandleValue[numValues];
    int j = 0;
    for(int i=0; i<values.length; i++) {
      if(values[i]!=null)
        filteredVals[j++] = values[i];
    }
    return filteredVals;
  }    

  public HandleValue[] resolveHandle(String sHandle) 
    throws HandleException
  {
    return this.resolveHandle(sHandle, null, null);
  }

  /************************************************************************
   * This method sends the given request to the handle system using
   * the currently configured method (global resolution, resolution
   * against a caching server, etc), and returns the response.  If
   * a Cache object is available it will be used if the request is
   * a ResolutionRequest and the authoritative flag of the request
   * is not set.
   *
   * The AbstractResponse object that is returned can be either an ErrorResponse
   * or a ResolutionResponse object.  Check the responseCode of the AbstractResponse
   * (or use the instanceof keyword) to determine if the response can safely be casted
   * to a ResolutionResponse or not.  If you determine that the response is a
   * ResolutionResponse then you can cast the response and call getHandleValues() on
   * it.
   *
   * The following is an example that requests all of the URL values associated
   * with the handle 10.1000/12, and prints them to System.out.
   *
   * <pre>
   * HandleResolver resolver = new HandleResolver();
   * AbstractResponse aResponse = resolver.resolveHandle("10.1000/12",
   *                                                    new String[]{"URL"},
   *                                                    null);
   * if(aResponse.responseCode==AbstractMessage.RC_SUCCESS) {
   *   ResolutionResponse response = (ResolutionResponse)aResponse;
   *   HandleValue values[] = response.getHandleValues();
   *   System.out.println("Received values: ");
   *   for(int i=0; i<values.length; i++) {
   *     System.out.println(String.valueOf(values[i]));
   *   }
   * }
   * </pre>
   *                  
   *
   ************************************************************************/
  public AbstractResponse processRequest(AbstractRequest req,
                                         ResponseMessageCallback callback) 
    throws HandleException
  {
    // need to send request here, based on current configuration
    switch(config.getResolutionMethod()) {
      case Configuration.RM_WITH_CACHE:
        if(!req.isAdminRequest && !req.requiresConnection && req.ignoreRestrictedValues) {
          // only request that will definitely not result in authentication
          // should go through local cache/resolver servers
          SiteInfo cacheSites[] = config.getCacheSites();
          if(cacheSites!=null && cacheSites.length>0) {
            return sendRequestToService(req, config.getCacheSites(),
                                        true, callback);
          }
        }
      case Configuration.RM_GLOBAL:
      default:
        return processRequestGlobally(req, callback);
    }
  }

  /***********************************************************************
   * Shortcut to processRequest(req, null);
   ***********************************************************************/
  public AbstractResponse processRequest(AbstractRequest req)
    throws HandleException
  {
    return processRequest(req, null);
  }

  /**********************************************************************
   * Send the following request (usually a resolution request) to
   * the handle system.  First, a message is sent to the global
   * service to find the local service for the naming authority.  
   * Then that service is queried for the handle.  This bypasses
   * the use of a caching server.
   * 
   **********************************************************************/
  private AbstractResponse processRequestGlobally(AbstractRequest req,
                                                  ResponseMessageCallback callback) 
    throws HandleException
  {
    return sendRequestToService(req, findLocalSites(req), true, callback);
  }

  /***********************************************************************
   * Shortcut to processRequestGlobally(req, null);
   ***********************************************************************/
  public AbstractResponse processRequestGlobally(AbstractRequest req)
    throws HandleException
  {
    return processRequestGlobally(req, null);
  }

  /**********************************************************************
   * Get the site information for the service that is responsible for
   * this handle while at the same time populating the namespace 
   * information, if the trackNamespace flag is set in the request.
   **********************************************************************/
  public SiteInfo[] findLocalSites(AbstractRequest req)
    throws HandleException 
  {
    // start by adding the namespace of the root service, since that is our starting point
    req.setNamespace(config.getGlobalNamespace());
    
    // Check for explicit local sites in configuration
    SiteInfo sites[] = config.getLocalSites(Util.getNAHandle(req.handle));
    if (sites !=null) {
      // If there are local sites, we will have no NamespaceInfo for the resolution
      // Perhaps we should do a global resolution in order to get some?
      return sites;
    }
    
    // if the handle is under the root namespace (0) then it gets resolved by
    // the global service
    if(Util.startsWithCI(req.handle, Common.GLOBAL_NA_PREFIX) ||
       Util.startsWithCI(req.handle, Common.GLOBAL_NA)) {
      return config.getGlobalSites();
    }
    
    // for all non-global handles we find their local service by resolving any
    // prefixes (and optionally delegated namespaces) in order to determine the
    // responsible service
    ResolutionRequest resReq = new ResolutionRequest(Util.getNAHandle(req.handle),
                                                     Common.LOCATION_TYPES, null, null);
    
    resReq.takeValuesFrom(req);
    resReq.authoritative = false; // don't require authoritative resolution for NA and siteinfo
    resReq.sessionInfo = null;  // don't use session for NA resolution
    resReq.sessionTracker = null;  // don't use session for NA resolution
    resReq.recursionCount = (short)(req.recursionCount);
    
    // to enable delegation, everything between here and END DELEGATION LOOP should 
    // be added to a do-while loop that iterates over sub-namespaces
    resReq.recursionCount++;
    
    // send request for prefix information with a normal resolution request
    AbstractResponse resResponse = processRequest(resReq, null);
    if(resResponse.responseCode==AbstractResponse.RC_SUCCESS) {
      HandleValue values[] = ((ResolutionResponse)resResponse).getHandleValues();
      
      // extract any namespace information.  If none, then the parent namespace
      // still applies
      NamespaceInfo nsInfo = Util.getNamespaceFromValues(values);
      if(nsInfo!=null) req.setNamespace(nsInfo);
      
      // extract any SiteInfo records and return them
      sites = Util.getSitesFromValues(values);
      if(sites!=null && sites.length<=0) sites = null;
      
      if(sites==null) {
        // extract, resolve and return any SiteInfo records referenced by 
        // service handles.
        HandleValue srvHdlValue = null;
        for(int i=0; values!=null && i<values.length; i++) {
          if(Util.equals(values[i].type, Common.SERVICE_HANDLE_TYPE)) {
            srvHdlValue = values[i];
            break;
          }
        }
        
        if(srvHdlValue!=null) {
          // resolve the service handle
          ResolutionRequest svcReq = new ResolutionRequest(srvHdlValue.data,
                                                           Common.SITE_INFO_TYPES,
                                                           null, null);
          svcReq.takeValuesFrom(req);
          svcReq.authoritative = false; // don't require authoritative resolution for NA and siteinfo
          AbstractResponse svcRes = processRequest(svcReq, null);
          if(svcRes.responseCode==AbstractMessage.RC_SUCCESS) {
            // note:  namespace information in service handles are purposefully ignored
            sites = Util.getSitesFromValues(((ResolutionResponse)svcRes).getHandleValues());
          }
        }
      }
      
      
    }
    
    // END DELEGATION LOOP
    
    if(sites==null) {
      throw new HandleException(HandleException.SERVICE_NOT_FOUND,
                                "Unable to find service for handle "+
                                Util.decodeString(req.handle)+
                                "; prefix resolution response: "+resResponse);
    }
    return sites;
  }

  
  public final AbstractResponse sendRequestToService(AbstractRequest req,
                                                     SiteInfo sites[],
                                                     ResponseMessageCallback callback)
    throws HandleException
  {
    return sendRequestToService(req, sites, false, callback);
  }
  
  /***********************************************************************
   * Shortcut to sendRequestToService(AbstractRequest, SiteInfo[], null);
   ***********************************************************************/
  public AbstractResponse sendRequestToService(AbstractRequest req, SiteInfo sites[])
    throws HandleException
  {
    return sendRequestToService(req, sites, null);
  }

  /**********************************************************************
   * Send the specified request to the given service and return
   * the result.  If the given request is a ResolutionRequest the
   * cache is checked for the requested values before the message
   * is sent.  If cacheResult is true and we receive a resolution
   * response, then the result is stored in the cache for later use.
   * The cacheResult parameter is supplied so that calling the public
   * method sendRequestToService doesn't cache results.  This is important
   * because if the wrong service is queried for a handle, we don't want
   * to cache the result because it could affect other queries.
   **********************************************************************/
  private AbstractResponse sendRequestToService(AbstractRequest req,
                                                SiteInfo sites[],
                                                boolean cacheResult,
                                                ResponseMessageCallback callback) 
    throws HandleException
  {
    boolean isCacheable = false;
    byte handle[] = null;
    byte types[][] = null;
    int indexes[] = null;
    
    // use the regular or certified cache, determined by the certify request flag
    Cache cache = req.certify ? this.secureCache : this.cache;
    
    //  check cache for resolution requests
    if(cache!=null && req.opCode==AbstractMessage.OC_RESOLUTION) {
      ResolutionRequest rreq = (ResolutionRequest)req;
      handle = rreq.handle;
      types = rreq.requestedTypes;
      indexes = rreq.requestedIndexes;
      boolean ignoreRestricted = rreq.ignoreRestrictedValues;
      
      // response is only cacheable if cacheResult is true and
      // ignoreRestrictedValues is not set.
      if (cacheResult && ignoreRestricted) {
        isCacheable = true;
      }
      
      if(!req.authoritative && ignoreRestricted) {
        // if the request has the authoritative flag, or is for 
        // restricted values, bypass the cache
        try {
          byte cachedVals[][] = cache.getCachedValues(handle, types, indexes);
          if(cachedVals!=null) {
            return new ResolutionResponse(req, req.handle, cachedVals);
          }
        } catch (Throwable e) {
          System.err.println("Cache get error: "+e);
          e.printStackTrace(System.err);
        }
      }
    }
    
    AbstractResponse resp = null;

    //==========================================================================

    boolean requestSent = false;
    
    // if the request is an admin message or is authoritative,
    // it should only be sent to the primary site.

    if (req.isAdminRequest || req.authoritative) {
      for (int p = 0; ((p < preferredProtocols.length) && (!(requestSent))); p++) {
        for (int i = 0; i < sites.length; i++) {
          if (sites[i].isPrimary) {
            try {
              resp = sendRequestToSite(req, sites[i], preferredProtocols[p], callback);
              if (resp != null)
                requestSent = true; // Leave outer "for" loop 
              // after breaking from this one
              
            } catch (HandleException e) {
              // If it's the last one we can try,
              // pass the exception to the caller.
              
              if (p == (preferredProtocols.length - 1))
                throw e;
            }
            break;          // There's only 1 primary, leave the loop.
          }
        }
        
      }
      if (!(requestSent)) {
        throw new HandleException(HandleException.NO_ACCEPTABLE_INTERFACES,
                                  "Cannot contact an acceptable interface");
      }
    } else {
      // set response time value in sites
      for (int i = 0; sites!=null && i < sites.length; i++) {
        if (sites[i].servers==null || sites[i].servers.length == 0)
          continue;
        String ip = sites[i].servers[0].getAddressString();
        Long l = (Long)responseTimeTbl.get(ip);
        if (l == null)
          sites[i].responseTime = 0;
        else sites[i].responseTime = l.longValue();
      }
      
      // reorder sites based on performance
      sites = Util.orderSitesByPreference(sites);
      
      // try all the sites, using the preferred protocol at each
      for (int p = 0;  p < preferredProtocols.length && !requestSent ; p++) {
        for (int i=0; i<sites.length; i++) {
          try {
            resp = sendRequestToSite(req, sites[i], preferredProtocols[p], callback);
            if (resp != null) {
              requestSent = true;   // Leave outer "for" loop after breaking from this one
              break;
            }
          } catch (HandleException e) {
            // If it's the last one we can try,
            // pass the exception to the caller.
            
            if ( (p == preferredProtocols.length - 1) && (i == sites.length - 1) )
              throw e;
          }
        }
      }
      
      if (!(requestSent)) {
        throw new HandleException(HandleException.NO_ACCEPTABLE_INTERFACES,
                                  "Cannot contact an acceptable interface" );
      }
    }
    
    //= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
    
    if ((isCacheable) && (resp.responseCode==AbstractResponse.RC_SUCCESS)) {
      try {
        cache.setCachedValues(handle, ((ResolutionResponse)resp).getHandleValues(), types, indexes);
      } catch (Throwable e) {
        System.err.println("Cache set error: " + e);
        e.printStackTrace(System.err);
      }
    }
    
    if(isCacheable && resp.responseCode==AbstractResponse.RC_SUCCESS) {
      try {
        cache.setCachedValues(handle, ((ResolutionResponse)resp).getHandleValues(), types, indexes);
      } catch (Throwable e) {
        System.err.println("Cache set error: "+e);
        e.printStackTrace(System.err);
      }
    }

    // When a global server is retired, it should return
    // RC_OUT_OF_DATE_SITE_INFO for a while.  This will cause clients to
    // upgrade their root_info.  
    //
    // Note: A less disruptive way to cause clients to update the root info
    // is to increment the serial numbers of one of the root siteinfo records.
    if (resp != null) {
      if (resp.responseCode == AbstractResponse.RC_OUT_OF_DATE_SITE_INFO)
        config.refreshRootInfoFromNet();
      return resp;
    }
  
    throw new HandleException(HandleException.SERVICE_NOT_FOUND,
                              "No acceptable site found in service");
  }

  /** 
    * Sends the given request to the appropriate server in the given site and
    * returns the response.  This will try to contact the appropriate server by
    * trying each of the preferred protocols, in order.
    */
  public AbstractResponse sendRequestToSite(AbstractRequest req, SiteInfo site)
    throws HandleException
  {
    AbstractResponse resp = null; 
    
    for (int p = 0; p < preferredProtocols.length; p++) {
      try {
        resp = sendRequestToSite(req, site, preferredProtocols[p]);
        break;
      } catch (Exception e) {
        // Ignore the exception except on the last time we can try.
        if (p == preferredProtocols.length - 1) {
          // No more to try: throw.
          if(e instanceof HandleException)
            throw (HandleException)e;
          else
            throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                      "Unable to contact site on any interfaces: "+e);
        }
      }
    }
    
    if(resp==null) {
      throw new HandleException(HandleException.NO_ACCEPTABLE_INTERFACES,
                                "Cannot contact an acceptable interface" );
    }
    return resp;
  }
  
  
  
  /** 
    * Shortcut to sendRequestToSite(AbstractRequest, site, protocol, null);
    */
  public AbstractResponse sendRequestToSite(AbstractRequest req, SiteInfo site,
                                            int protocol)
    throws HandleException
  {
    return sendRequestToSite(req, site, protocol, null);
  }
  
  /*****************************************************************************
   */

  public AbstractResponse sendRequestToSite(AbstractRequest req,
                                            SiteInfo site,
                                            int protocol,
                                            ResponseMessageCallback callback) 
         throws HandleException 
  {
    req.siteInfoSerial = site.serialNumber;

                           // check if we're communicating with an older server.
                           // If so, use their protocol version

    if ( (site.majorProtocolVersion == 5 && site.minorProtocolVersion == 0)
         || (site.majorProtocolVersion < Common.MAJOR_VERSION)
         || ((site.majorProtocolVersion == Common.MAJOR_VERSION)
             && (site.minorProtocolVersion < Common.MINOR_VERSION) ) ) {
      req.majorProtocolVersion = site.majorProtocolVersion;
      req.minorProtocolVersion = site.minorProtocolVersion;
    } else {
      req.majorProtocolVersion = Common.MAJOR_VERSION;
      req.minorProtocolVersion = Common.MINOR_VERSION;
    }
    
    long time1 = System.currentTimeMillis();

    AbstractResponse response;

    try {
      response = sendRequestToServerByProtocol(req,
                                               site.determineServer(req.handle),
                                               protocol, callback);
      
      if (site.isRoot && response!=null && (response.siteInfoSerial > req.siteInfoSerial)) {
        this.config.notifyRootInfoOutdated();
      }
    } catch (HandleException e) {
      throw e;
    } finally {
      long time2 = System.currentTimeMillis();
      site.responseTime = time2 - time1;
      Long l = new Long(time2 - time1);
      responseTimeTbl.put(site.servers[0].getAddressString(), l);
    }
   
    return response;
  }

  /***********************************************************************
   * Shortcut to sendRequestToServer(AbstractRequest, ServerInfo, null);
   ***********************************************************************/

  public AbstractResponse sendRequestToServer(AbstractRequest req, ServerInfo server)
    throws HandleException
  {
    return sendRequestToServer(req, server, null);
  }


  /*****************************************************************************
   *
   * Wrapper around sendRequestToServerByProtocol(), which used to have this
   * name and signature.  This is invoked by the code which formerly invoked
   * the older method.
   *
   */

  public AbstractResponse sendRequestToServer(AbstractRequest req,
                                              ServerInfo server,
                                              ResponseMessageCallback callback)
    throws HandleException
  {
    AbstractResponse response = null;
    
    for (int p = 0; p < preferredProtocols.length; p++) {
      response = sendRequestToServerByProtocol(req, server,
                                               preferredProtocols[p],
                                               callback); // Might throw exception
      if (response != null)
        return response;
    }
    
    throw new HandleException(HandleException.NO_ACCEPTABLE_INTERFACES,
                              "There were no acceptable interfaces to server: " + server);
  }

  /*****************************************************************************
   *
   * Sends the given request to the specified server by the given protocol,
   * if supported.  Also, if there is a ClientSideSessionInfo or
   * ClientSessionTracker object associated with the request then a session
   * will be created (if necessary) and used to send the message.
   *
   * This was formerly sendRequestToServer(), with the 3-argument signature
   * of the "wrapper" function above.  The "for each protocol" loop has been
   * moved to the wrapper (and replaced with a passed-in specific protocol)
   * so that this function can be called without the loop by methods having
   * the loop themselves.
   *
   */

  public AbstractResponse sendRequestToServerByProtocol(AbstractRequest req,
                                                        ServerInfo server,
                                                        int protocolToUse,
                                                        ResponseMessageCallback callback) 
    throws HandleException 
  {
    ServerInfo origServer = server;
    AbstractResponse response = null;
    Exception exception = null;
    Interface interfce = null;
    ClientSideSessionInfo sessionInfo = req.sessionInfo;
    ClientSessionTracker sessionTracker = null;

    // If there is a session tracker associated with the request, use it.

    sessionTracker = req.sessionTracker;

    // If not, and there is a session tracker for this resolver, use it.
    
    if (sessionTracker == null && req.isAdminRequest)
      sessionTracker = resolverSessions;

    if (sessionInfo != null && sessionInfo.hasExpired())
      sessionInfo = null;
    
    // Figure out if we should be using a session to send this message or not.
    // if this is a session-setup request, skip this part to avoid a stack overflow
    if (sessionTracker != null && req.opCode!=AbstractMessage.OC_SESSION_SETUP) {
      // There is a session tracker for this request, so get
      // the session for this request, if one already exists.
      
      sessionInfo = sessionTracker.getSession(server, req.authInfo);
      
      if (sessionInfo == null) {
        // No session has been setup yet...set up
        // a session now, if the setup info exists
        
        SessionSetupInfo setupInfo = sessionTracker.getSessionSetupInfo();
        
        if (setupInfo != null) {
          try {
            sessionInfo = setupSessionWithServer(req.authInfo,
                                                 setupInfo,
                                                 server, callback);
            sessionTracker.putSession(sessionInfo, server, req.authInfo);
          } catch (Exception e) {
            String msg = "Error setting up session: " + e;
            throw new HandleException(HandleException.INTERNAL_ERROR, msg);
          }
        }
      } else {
        // Session already exists; if there is a change in
        // session setup, modify session attribute with server
        
        SessionSetupInfo setupInfo = sessionTracker.getSessionSetupInfo();
        if (setupInfo != null && ClientSessionTracker.sessionOptionChanged(sessionInfo, setupInfo)) {
          try {
            ClientSideSessionInfo newSessionInfo;
            newSessionInfo = setupSessionWithServer(req.authInfo,
                                                    setupInfo, server,
                                                    sessionInfo, callback);
            sessionInfo = newSessionInfo;
            sessionTracker.removeSession(sessionInfo);
            sessionTracker.putSession(newSessionInfo,server,req.authInfo);
          } catch (Exception e) {
            String msg = "Error modifying session: " + e;
            throw new HandleException(HandleException.INTERNAL_ERROR,msg);
          }
        }                                                  // option changed
      }                                                // has a session info
    }                 // End "(sessionInfo != null || sessionTracker != null)"

    if (sessionInfo != null) {
      // if there is a session, sign the message after obtaining
      // the session id and sessionKey, process the original request

      req.sessionId = sessionInfo.sessionId;
      
      // Make sure that the message has the certify and encrypt flag set if
      // the session requires them
      req.certify = req.certify || sessionInfo.getAuthenticateMessageFlag();
      req.encrypt = req.encrypt || sessionInfo.getEncryptedMesssageFlag();
      
      // If authentication info is not empty, attach MAC code for request
      if (req.authInfo != null) {
        try {
          req.signMessage(sessionInfo.getSessionKey());
        } catch (Exception e) {
          if (e instanceof HandleException)
            throw (HandleException)e;
          throw new HandleException(HandleException.UNABLE_TO_SIGN_REQUEST,
                                    "Unable to sign original request with session key: " + e );
        }
      }
    }
    
    // if there is a session, store it with the
    // request so that the response can be verified
    req.sessionInfo = sessionInfo;
    
    // Try to resolve using the given protocol
    
    // Get the server's interface that can handle the request
    // by the desired protocol.  Assume there's only 1.
    
    interfce = server.interfaceWithProtocol(protocolToUse, req);
    
    if (interfce != null) {
      // There is a workable interface
      response = null;
      
      try { response = sendRequestToInterface(req,server,interfce,callback); }
      catch (Exception e) { exception = e; }
      // If there was a session timeout,
      // remove the session and continue ???
      
      if ( response!=null && response.responseCode == AbstractMessage.RC_SESSION_TIMEOUT) {
        if ((sessionInfo != null) && (sessionTracker != null)) {
          sessionTracker.removeSession(sessionInfo);
          sessionInfo = null;

          // FIXME:  This should start a new session.
          //i--;  
          //continue;
          
          // the i-- is so that this interface is
          // tried again without the session info
        }
      }
      
      if (response != null && response.getClass() == ChallengeResponse.class) {
        // Got challenge, must authenticate
        if (req.authInfo == null)
          throw new HandleException(HandleException.UNABLE_TO_AUTHENTICATE,
                                    "No authentication info provided");
        //if (traceMessages) 
        //  System.err.println("got challenge: " + response);
        
        // get the authInfo object to sign the challenge
        
        ChallengeResponse challResponse = (ChallengeResponse)response;
        byte sig[] = req.authInfo.authenticate(challResponse, req);
        
        // set the response to null again so that the challenge
        // doesn't get sent back to the caller if we get an
        // exception while responding to the challenge.
        
        int challengeSessionID = response.sessionId;
        
        response = null;
        try { // send a response to the challenge back to the same interface
          ChallengeAnswerRequest answer = 
            new ChallengeAnswerRequest(req.authInfo.getAuthType(),
                                       req.authInfo.getUserIdHandle(),
                                       req.authInfo.getUserIdIndex(),
                                       sig, req.authInfo);
          answer.takeValuesFrom(req);
          
          // link our response with the server's challenge
          
          answer.sessionId = challengeSessionID;
          answer.sessionInfo = req.sessionInfo; 
          response = sendRequestToInterface(answer, server,
                                            interfce, callback);
        } catch (Exception e) {
          exception = e;
        }
      }                                                    // Got challenge
      
      if(response!=null)
        return response;                                            // Success
      
    }                                                    // interfce not null
    
    if (exception != null) {
      if (exception instanceof HandleException)
        throw (HandleException)exception;
      // else...
      exception.printStackTrace();
      throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                "Got Exception: " + exception);
    }
    
    return null;
  }

  //============================================================================

  /**
   * Create a new session.
   **/
  public ClientSideSessionInfo setupSessionWithServer(
                                               AuthenticationInfo authInfo,
                                               SessionSetupInfo sessionOptions,
                                               ServerInfo server,
                                               ResponseMessageCallback callback)
    throws Exception
  {
    return setupSessionWithServer(authInfo,sessionOptions,server,null,callback);
  }


  /** Initiates and returns a session with the given server using the
      given authentication information.  
      
      @param currSession If non null, that session will be modified.

      Note: Security check!  Since session information is stored in the handle
      resolve, users of this code must be _very_ careful not to pass the
      HandleResolver object around to untrusted code.  A better way to do
      this might be to make the session stuff not happen automatically and
      have public methods for starting, finishing, and using sessions.
      AbstractRequest objects should have session objects associated with
      them just like regular authentication information.
  */
  public ClientSideSessionInfo setupSessionWithServer(AuthenticationInfo authInfo,
                                                      SessionSetupInfo sessionOptions,
                                                      ServerInfo server,
                                                      ClientSideSessionInfo currSession,
                                                      ResponseMessageCallback callback)
    throws Exception
  {
    AbstractResponse response = null;
    
    byte[] sessionKey = null;
    int sessionKeyAlg = HdlSecurityProvider.ENCRYPT_ALG_DES;
    
    byte[] identityHandle = null;
    int identityIndex = -1;
    if (authInfo != null){
      identityHandle = authInfo.getUserIdHandle();
      identityIndex = authInfo.getUserIdIndex();
    }
    
    // send a new session set up request to server
    SessionSetupRequest sessionsetupReq = createSessionSetupRequest(authInfo, 
                                                                sessionOptions);
    
    if (currSession != null){
      sessionsetupReq.sessionId = currSession.sessionId;
      sessionsetupReq.sessionInfo = currSession;
    }
    
    sessionsetupReq.certify = true;
    
    int oldTcpTimeout = getTcpTimeout();
    int oldUdpRetryScheme[] = getUdpRetryScheme();
    
    
    try { // try block with a finally that sets stuff back to the way it was..
      HdlSecurityProvider provider = HdlSecurityProvider.getInstance();
      
      //// Note: this is not good to do in a multi-threaded app.  It would be
      //// nice if a better way were found.
      setTcpTimeout(180000);   //session tcp time out, use 3 minutes
      setUdpRetryScheme(new int[] { 180000 });  // 3 minutes, udp session setup
      
      // send the session setup request.  If the server doesn't support
      // sessions an exception will be thrown here, and the resolve should
      // revert to using regular challenge/response authentication.
      response = sendRequestToServer(sessionsetupReq, server, null);

      if (response == null || !(response instanceof SessionSetupResponse)
           || response.responseCode != response.RC_SUCCESS) {
        throw new HandleException(HandleException.SERVER_CANNOT_PROCESS_SESSION, response.toString());
      }
      
      SessionSetupResponse ssresp = (SessionSetupResponse)response;
      if (ssresp.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_CLIENT ||
          ssresp.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_HDL) {
        // decrypt the session key here using the private key corresponding to
        // the public key that we just sent the server
        sessionKey = Util.decrypt(sessionOptions.privateExchangeKey, ssresp.data);
        
        if(ssresp.hasEqualOrGreaterVersion((byte)2, (byte)2)) {
          // the server is capable of encoding the encryption algorithm
          sessionKeyAlg = Encoder.readInt(sessionKey, 0);
          byte tmp[] = new byte[sessionKey.length-Encoder.INT_SIZE];
          System.arraycopy(sessionKey, Encoder.INT_SIZE, tmp, 0, tmp.length);
          sessionKey = tmp;
        }
      } else if (ssresp.keyExchangeMode == Common.KEY_EXCHANGE_CIPHER_SERVER){
        // the server has responded with its public key.  we should
        // generate a secret key and send it to the server encrypted with the
        // public key.
        
        byte[] pubExchangeKey = ssresp.data;
        byte[] encryptKey;
        
        // if the server is doesn't support the 2.2 protocol, the key algorithm
        // must be DES and the algorithm not encoded as part of the session key
        // message
        boolean oldServer = !ssresp.hasEqualOrGreaterVersion((byte)2, (byte)2);
        sessionKeyAlg = oldServer ? HdlSecurityProvider.ENCRYPT_ALG_DES : preferredEncryptionAlgorithm;
        sessionKey = HdlSecurityProvider.getInstance().generateSecretKey(sessionKeyAlg);
        encryptKey = Util.substring(sessionKey, Encoder.INT_SIZE);
        if(oldServer) sessionKey = encryptKey;
        
        PublicKey serverRSAPubKey=Util.getPublicKeyFromBytes(pubExchangeKey, 0);
        byte key[] = Util.encrypt(serverRSAPubKey, encryptKey);
        
        // send another session exchange key request to give the server the
        // secret key that was encrypted using the servers public key.
        SessionExchangeKeyRequest sekr = new SessionExchangeKeyRequest(key);
        sekr.takeValuesFrom(sessionsetupReq);
        
        // temporarily turn off the flag, until the global server is updated
        // with the latest, then turn on
        // sekr.returnRequestDigest = false; // the global has been updated
        
        sekr.encrypt = false;
        sekr.sessionId = ssresp.sessionId;
        AbstractResponse rsp = sendRequestToServer(sekr, server, null);
        
        if (rsp == null || rsp.responseCode!=AbstractResponse.RC_SUCCESS)
          throw new HandleException(HandleException.SERVER_CANNOT_PROCESS_SESSION,
                                    "Server cipher key exchange failed.");
        
        if(ssresp.hasEqualOrGreaterVersion((byte)2, (byte)2)) {
          // trim the algorithm from the front of the session key for our own use
          sessionKey = Util.substring(sessionKey, Encoder.INT_SIZE);
        }
      } else if (ssresp.keyExchangeMode == Common.KEY_EXCHANGE_DH){
        DHPublicKey pub = 
          (DHPublicKey)Util.getPublicKeyFromBytes(ssresp.data, 0);
        sessionKey = provider.getDESKeyFromDH(pub,
                                              (DHPrivateKey)sessionOptions.privateExchangeKey);
      } else { // if we get here, then we don't understand the servers response
        throw new HandleException(HandleException.SERVER_CANNOT_PROCESS_SESSION,
                                  "Unknown key exchange mode");
      }
    } finally {
      // reset tcp and udp timeout
      setTcpTimeout(oldTcpTimeout);
      setUdpRetryScheme(oldUdpRetryScheme);
    }
    
    // at this point the session key has been exchanged.
    // create a session info object here and return it
    ClientSideSessionInfo csinfo = 
      new ClientSideSessionInfo(response.sessionId, sessionKey, 
                                identityHandle, identityIndex, server);
    csinfo.setEncryptionAlgorithmCode(sessionKeyAlg);
    csinfo.takeValuesFromOption(sessionOptions);
    
    return csinfo;
  }




  /***********************************************************************
   * Shortcut to sendRequestToInterface(AbstractRequest, ServerInfo,
   *                                    Interface, null);
   ***********************************************************************/
  public AbstractResponse sendRequestToInterface(AbstractRequest req,
                                                 ServerInfo server,
                                                 Interface interfce)
    throws HandleException
  {
    return sendRequestToInterface(req, server, interfce, null);
  }

  public AbstractResponse sendRequestToInterface(AbstractRequest req,
                                                 ServerInfo server,
                                                 Interface interfce,
                                                 ResponseMessageCallback callback) 
    throws HandleException 
  {
    // If the request is 'certified', then associate the servers' public
    // key with the request so that the response can be certified.
    if(req.certify && checkSignatures) {
      req.serverPubKey = null;
      req.serverPubKeyBytes = server.publicKey;
    }
    
    try {
      InetAddress addr = server.getInetAddress();

      int port = interfce.port;
      AbstractResponse response = null;
      switch(interfce.protocol) {
        case Interface.SP_HDL_UDP:
          response = sendHdlUdpRequest(req, addr, port, callback);
          break;
        case Interface.SP_HDL_TCP:
          response = sendHdlTcpRequest(req, addr, port, callback);
          break;
        case Interface.SP_HDL_HTTP:
          response = sendHttpRequest(req, addr, port, callback);
        break;
        default:
          throw new HandleException(HandleException.UNKNOWN_PROTOCOL,
                                    "unknown protocol: "+interfce.protocol);
      }

      if(response!=null) {
        if(response.responseCode==AbstractMessage.RC_ERROR) {
          throw new HandleException(HandleException.SERVER_ERROR,
                                    Util.decodeString(((ErrorResponse)response).message));
        } else if(response.expiration < System.currentTimeMillis()/1000) {
          throw new HandleException(HandleException.GOT_EXPIRED_MESSAGE);
        }
      }
      return response;
    } catch (UnknownHostException e) {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Unknown host - should never happen!");
    }
  }


  /**
   * Verify response message with the pre-established session key.
   * use InetAddress and authInfo in request to locate the session information.
   * AuthInfo in request and InetAddress (equivalent to addr in serverInfo) can
   * locate the session information, i.g. session id, session key.
   */
  private final boolean verifyResponse(AbstractRequest req, AbstractResponse response, InetAddress addr)
    throws HandleException
  {
    
    boolean veriPass = false;
    if (req == null || response == null || addr == null) return false;

    if (response.sessionId > 0) {
      try {
        if (req.sessionInfo != null) {
          veriPass = response.verifyMessage(req.sessionInfo.getSessionKey());
        }
      }
      catch (Exception e){
        if (e instanceof HandleException) {
          if ( ((HandleException)e).getCode() == HandleException.UNKNOWN_ALGORITHM_ID) {
            //there is one case that server will sign with private signature,
            //but the client side has overdated session info
            //System.err.println("Invalid session key or not available.");
            //System.err.println("class name " + response.getClass().getName()
            //+ " from "+ addr.getHostAddress());
            veriPass = false;
          } else
            throw (HandleException)e;
        } else 
          throw new HandleException(
                HandleException.MISSING_OR_INVALID_SIGNATURE,
                "Error verifying MAC code: " + e);
    
      }
    }
    
    return veriPass;
  }
    
    
  /** This function verifies the integrity of a response given the request
      that it is for.  The public key of the server is attached to the
      request so that this can verify the signature of the response.  This
      function also checks the digest of the request that was included
      (if requested) in the response. */
  private static final void verifyResponse(AbstractRequest req, AbstractResponse response)
    throws HandleException
  {
  
    if(req.serverPubKey==null && req.serverPubKeyBytes==null) {
      throw new HandleException(HandleException.SECURITY_ALERT,
                                "Unable to verify certified message: no pubkey associated with request");
    }
    
    // the request was certified so we should verify the signature here
    PublicKey pubKey = req.serverPubKey;
    try {
      if(pubKey==null) {
        pubKey = req.serverPubKey = Util.getPublicKeyFromBytes(req.serverPubKeyBytes, 0);
      }
    } catch (Exception e) {
      throw new HandleException(HandleException.INVALID_VALUE,
                                "Unable to extract public key: "+e);
    }
    
    try {
      if(!response.verifyMessage(pubKey)) {
        throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                                  "Verification failed.");
      }
    } catch (Exception e) {
       e.printStackTrace();
      throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                                "Unable to verify signature: '"+e.getMessage()+
                                "' for message: "+response);
    }

    // Make sure that the server is responding to the request as we sent it.
    // This is because our request could have been modified on its way to
    // the server since requests aren't signed.  We get around that by having
    // the server include a digest of the original request with its response.
    if(req.returnRequestDigest) {
      byte requestDigest[] =
        Util.doDigest(response.rdHashType, req.getEncodedMessageBody());
      if(!Util.equals(requestDigest, response.requestDigest)) {
        throw new HandleException(HandleException.SECURITY_ALERT,
                                  "Message came back with invalid request digest.");
      }
    }
  }
  

  /***********************************************************************
   * Shortcut to sendHdlUdpRequest(req, addr, port, null);
   ***********************************************************************/
  public AbstractResponse sendHdlUdpRequest(AbstractRequest req,
                                            InetAddress addr, 
                                            int port)
    throws HandleException
  {
    return sendHdlUdpRequest(req, addr, port, null);
  }
  
  public AbstractResponse sendHdlUdpRequest(AbstractRequest req,
                                            InetAddress addr, 
                                            int port,
                                            ResponseMessageCallback callback) 
    throws HandleException
  {
    
    addr = config.mapLocalAddress(addr);
      
    DatagramSocket socket = null;

    MessageEnvelope sndEnvelope = new MessageEnvelope();
    if(req.majorProtocolVersion>0 && req.minorProtocolVersion>=0) {
      sndEnvelope.protocolMajorVersion = req.majorProtocolVersion;
      sndEnvelope.protocolMinorVersion = req.minorProtocolVersion;
    }

    // get a unique (within this JVM anyway) message ID
    if(globalMessageId<0) globalMessageId=0;
    sndEnvelope.requestId = globalMessageId++;
    sndEnvelope.sessionId = req.sessionId;
    req.requestId = sndEnvelope.requestId;
    
    // get the encoded message (including header body and signature,
    // but not the envelope) and create a set of udp packets from it
    byte requestBuf[] = req.getEncodedMessage();
    
    // encrypt the request if the encrypt flag is set and a session has been established
    if (req.encrypt) {
      if(req.sessionInfo==null) 
        throw new HandleException(HandleException.INCOMPLETE_SESSIONSETUP,
                                  "Cannot encrypt messages without a session");
      requestBuf = req.sessionInfo.encryptBuffer(requestBuf, 0, requestBuf.length);
    }
    
    sndEnvelope.messageLength = requestBuf.length;
    
    int numPackets = sndEnvelope.messageLength / maxUDPDataSize;
    if((sndEnvelope.messageLength % maxUDPDataSize) != 0)
      numPackets++;

    if(numPackets==0) {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Cannot send empty request");
    }
    DatagramPacket packets[] = new DatagramPacket[numPackets];
    int bytesRemaining = sndEnvelope.messageLength;
    
    sndEnvelope.truncated = numPackets > 1;
    
    for(int packetNum=0; packetNum<numPackets; packetNum++) {
      int thisPacketSize = Math.min(maxUDPDataSize, bytesRemaining);
      byte buf[] = new byte[thisPacketSize+Common.MESSAGE_ENVELOPE_SIZE];
      sndEnvelope.messageId = packetNum;
      Encoder.encodeEnvelope(sndEnvelope, buf);
      System.arraycopy(requestBuf, requestBuf.length - bytesRemaining,
                       buf, Common.MESSAGE_ENVELOPE_SIZE, buf.length-Common.MESSAGE_ENVELOPE_SIZE);
      packets[packetNum] = new DatagramPacket(buf, buf.length, addr, port);
      bytesRemaining -= thisPacketSize;
    }
    
    // create the socket, set the timeout value
    try {
      socket = new DatagramSocket();
    } catch (Exception e) {
      try { socket.close(); } catch (Exception e2){}
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                String.valueOf(e)+" setting SO timeout");
    }

    MessageEnvelope rcvEnvelope = new MessageEnvelope();
    long whenToTimeout;

    Exception lastException = null;
    try {
      for(int attempt=0; attempt < udpRetryScheme.length; attempt++) {

        if(traceMessages) {
          System.err.println("  sending HDL-UDP request ("+req+") to "+
                             addr.getHostAddress()+':'+port);
        }

        // send out each request packet
        try {
          socket.setSoTimeout(udpRetryScheme[attempt]);
          for(int packet = 0; packet < packets.length; packet++) {
            socket.send(packets[packet]);
          }
          whenToTimeout = System.currentTimeMillis() + udpRetryScheme[attempt];
        } catch (Exception e) {
          throw new HandleException(HandleException.INTERNAL_ERROR,
                                  String.valueOf(e)+" sending UDP request to "+
                                    addr.getHostAddress());
        }

        // loop, waiting for packets until the timeout is reached or
        // we have all of the packets, whichever comes first.
        byte returnMessage[] = null;
        boolean packetsReceived[] = null;
        boolean haveAllPackets = false;
        while(!haveAllPackets && System.currentTimeMillis() <= whenToTimeout) {
          DatagramPacket rspnsPkt =
            new DatagramPacket(new byte[maxUDPDataSize + Common.MESSAGE_ENVELOPE_SIZE],
                               maxUDPDataSize + Common.MESSAGE_ENVELOPE_SIZE);

          try {
            socket.receive(rspnsPkt);
            if(rspnsPkt.getLength()<=0) continue;
            
            // need to decode the envelop data...
            byte rspnsPktData[] = rspnsPkt.getData();
            int rspnsPktDataLen = rspnsPkt.getLength();

            Encoder.decodeEnvelope(rspnsPktData, rcvEnvelope);

            // if we got someone else's packet, ignore it.
            if(rcvEnvelope.requestId != req.requestId) continue;

            if(packetsReceived==null) {
              int numPkts =
                rcvEnvelope.messageLength / maxUDPDataSize;
              if((rcvEnvelope.messageLength % maxUDPDataSize) != 0)
                numPkts++;
              packetsReceived = new boolean[numPkts];
              for(int pr=0; pr<packetsReceived.length; pr++)
                packetsReceived[pr] = false;
              returnMessage = new byte[rcvEnvelope.messageLength];
            }

            packetsReceived[rcvEnvelope.messageId] = true;
            System.arraycopy(rspnsPktData, Common.MESSAGE_ENVELOPE_SIZE,
                             returnMessage,
                             rcvEnvelope.messageId*maxUDPDataSize,
                             rspnsPktDataLen-Common.MESSAGE_ENVELOPE_SIZE);
            haveAllPackets = true;
            for(int pr=0; pr<packetsReceived.length; pr++) {
              if(!packetsReceived[pr]) {
                haveAllPackets = false;
                pr = packetsReceived.length;
              }
            }

            if(haveAllPackets) {
           
              // decrypt the message using pre-established session information
              if (rcvEnvelope.encrypted) {
                // try session key decryption first ...
                ClientSideSessionInfo sessionInfo = req.sessionInfo;
                if(sessionInfo==null)
                  throw new HandleException(HandleException.INCOMPLETE_SESSIONSETUP,
                                            "Cannot decrypt message without a session");
                
                if(traceMessages)
                  System.err.println("Decrypting UDP message: "+rcvEnvelope);
                
                if(sessionInfo==null) 
                  returnMessage = sessionInfo.decryptBuffer(returnMessage, 0, returnMessage.length);
              }
              
              // parse the message
              AbstractResponse response =
                (AbstractResponse)Encoder.decodeMessage(returnMessage, 0, rcvEnvelope);
              
              if(traceMessages)
                System.err.println("    received HDL-UDP response: "+response);
              
              if(req.certify && checkSignatures) {
                // verify the signature of the response
                try {
                  boolean veriPass = false;
                  if (response.sessionId > 0) 
                    //verify with session key first...
                    veriPass = verifyResponse(req, response, addr);
                  
                  //if session key verification fails, use server private key to verify
                  if (!veriPass) 
                    verifyResponse(req, response);
                  
                } catch (HandleException he){
                  throw he;  
                }
              }
              
              if(callback!=null) {
                callback.handleResponse(response);
              }
              return response;
            }
          } catch (Exception e) {
            lastException = e;
           }
        }
      }
    } finally {
      if(socket!=null) {
        try { socket.close(); } catch (Exception e){}
      }
    }

    if(lastException!=null) {
      if(lastException instanceof HandleException)
        throw (HandleException)lastException;
      else
        throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                  addr+": "+lastException.toString());
    }
    throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                              "Unable to connect to server: "+addr);
  }

  
  /***********************************************************************
   * Shortcut to sendHdlTcpRequest(req, addr, port, null);
   ***********************************************************************/
  public AbstractResponse sendHdlTcpRequest(AbstractRequest req,
                                            InetAddress addr, 
                                            int port)
    throws HandleException
  {
    return sendHdlTcpRequest(req, addr, port, null);
  }


  
  
  public AbstractResponse sendHdlTcpRequest(AbstractRequest req,
                                            InetAddress addr,
                                            int port,
                                            ResponseMessageCallback callback)
    throws HandleException
  {
    Socket socket = null;
    OutputStream out = null;
    InputStream in = null;

    addr = config.mapLocalAddress(addr);
    
    MessageEnvelope sndEnvelope = new MessageEnvelope();
    if(req.majorProtocolVersion>0 && req.minorProtocolVersion>=0) {
      sndEnvelope.protocolMajorVersion = req.majorProtocolVersion;
      sndEnvelope.protocolMinorVersion = req.minorProtocolVersion;
    }
    
    // get a unique (within this JVM anyway) message ID
    if(globalMessageId<0) globalMessageId=0;
    sndEnvelope.requestId = globalMessageId++;
    sndEnvelope.sessionId = req.sessionId;
    req.requestId = sndEnvelope.requestId;
    
    
    // get the encoded message, including the header and signature but not the envelope
    byte requestBuf[] = req.getEncodedMessage();
    
    // request may choose to encrypt itself here if session available.
    if (req.encrypt) {
      if(req.sessionInfo==null) 
        throw new HandleException(HandleException.INCOMPLETE_SESSIONSETUP,
                                  "Cannot encrypt messages without a session");
      requestBuf = req.sessionInfo.encryptBuffer(requestBuf, 0, requestBuf.length);
    }
    
    sndEnvelope.messageLength = requestBuf.length;
    
    if(traceMessages)
      System.err.println("  sending HDL-TCP request ("+req+") to "+
                         addr.getHostAddress()+':'+port);
    
    // create the socket, set the timeout value
    try {
      socket = TimedConnection.getSocket(addr, port, tcpTimeout);
      socket.setSoTimeout(tcpTimeout);
      socket.setSoLinger(false,0);
    } catch (Exception e) {
      try { socket.close(); } catch (Exception e2){}
      throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                addr+": "+String.valueOf(e));
    } 

    MessageEnvelope rcvEnvelope = new MessageEnvelope();
    long whenToTimeout;

    AbstractResponse response = null;
    try {
      // send out the request...
      byte envBuf[] = new byte[Common.MESSAGE_ENVELOPE_SIZE];
      try {
        out = socket.getOutputStream();
        Encoder.encodeEnvelope(sndEnvelope, envBuf);
        out.write(envBuf, 0, Common.MESSAGE_ENVELOPE_SIZE);
        out.write(requestBuf, 0, requestBuf.length);
        out.flush();
        in = socket.getInputStream();
      } catch (Exception e) {
        throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                  String.valueOf(e)+" sending TCP request to "+
                                  addr.getHostAddress());
      }

      int r, n;
      
      while(true) {
        n = 0;
        // read the envelope from the socket
        while(n<Common.MESSAGE_ENVELOPE_SIZE &&
              (r=in.read(envBuf,n,Common.MESSAGE_ENVELOPE_SIZE-n))>=0)
          n += r;
        
        // decode the envelope
        Encoder.decodeEnvelope(envBuf, rcvEnvelope);

        // if we got someone else's packet, there is something *really* wrong
        if(rcvEnvelope.requestId != req.requestId) 
          throw new HandleException(HandleException.SECURITY_ALERT,
                                    "Message came back with different ID: "+
                                    req.requestId+"!="+rcvEnvelope.requestId);
        
        // read the message body+header from the socket
        byte messageBuf[] = new byte[rcvEnvelope.messageLength];
        n=0;
        while(n<rcvEnvelope.messageLength &&
              (r=in.read(messageBuf, n, rcvEnvelope.messageLength-n))>=0)
          n += r;
        
        
        // decrypt the received message
        if (rcvEnvelope.encrypted){
          ClientSideSessionInfo csinfo = req.sessionInfo;
          if(csinfo==null)
            throw new HandleException(HandleException.INCOMPLETE_SESSIONSETUP,
                                      "Cannot decrypt messages without a session");
          
          if(traceMessages)
            System.err.println("Decrypting TCP message: "+rcvEnvelope);

          messageBuf = csinfo.decryptBuffer(messageBuf, 0, messageBuf.length);
        }
        
        // parse the response message
        response = (AbstractResponse)Encoder.decodeMessage(messageBuf, 0, rcvEnvelope);
        
        
        if(response.streaming) {
          response.stream = in;
        }
        
        
        if(req.certify && checkSignatures) {
            
          // verify the signature of the response
          try {
            boolean veriPass = false;
            if (response.sessionId > 0){
              // verify with session key first...
              veriPass = verifyResponse(req, response, addr);
            }
            // if session key verification fails, use server private key to
            // verify
            if (!veriPass) verifyResponse(req, response);
            
          }
          catch (HandleException he){
            throw he;  
          }
        }

        if(traceMessages)
          System.err.println("    received HDL-TCP response: "+response);
        
        if(callback!=null && response.responseCode==AbstractMessage.RC_SUCCESS){
          callback.handleResponse(response);
        } else {
          // there is no callback, just return this message
          return response;
        }
        
        // If there are no more messages, notify the callback, and return
        // the current (ie the last) message.
        if(!response.continuous) {
          return response;
        }
      }
    } catch (IOException e) {
      if(traceMessages)
        e.printStackTrace(System.err);
      throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                "Error talking to "+addr.getHostAddress());
    } finally {
      if(socket!=null && (response==null || !response.streaming)) {
        try { in.close(); } catch (Exception e){}
        try { out.close(); } catch (Exception e){}
        try { socket.close(); } catch (Exception e){}
      }
    }
  }

  private static final String encodeHandleAsUri(byte handle[]) {
    return "/"+URLEncoder.encode(Util.decodeString(handle));
  }

  /***********************************************************************
   * Shortcut to sendHttpRequest(req, addr, port, null);
   ***********************************************************************/
  public AbstractResponse sendHttpRequest(AbstractRequest req,
                                          InetAddress addr, 
                                          int port)
    throws HandleException
  {
    return sendHttpRequest(req, addr, port, null);
  }
  
  public AbstractResponse sendHttpRequest(AbstractRequest req,
                                          InetAddress addr,
                                          int port,
                                          ResponseMessageCallback callback)
    throws HandleException
  {
    Socket socket = null;
    OutputStream out = null;
    InputStream in = null;

    addr = config.mapLocalAddress(addr);
    
    MessageEnvelope sndEnvelope = new MessageEnvelope();
    if(req.majorProtocolVersion>0 && req.minorProtocolVersion>=0) {
      sndEnvelope.protocolMajorVersion = req.majorProtocolVersion;
      sndEnvelope.protocolMinorVersion = req.minorProtocolVersion;
    }

    // get a unique (within this JVM anyway) message ID
    if(globalMessageId<0) globalMessageId=0;
    sndEnvelope.requestId = globalMessageId++;
    sndEnvelope.sessionId = req.sessionId;
    req.requestId = sndEnvelope.requestId;

    
    // get the encoded message (including header and signature, 
    // but not the envelope, and create a set of udp packets from it
    byte requestBuf[] = req.getEncodedMessage();
    sndEnvelope.messageLength = requestBuf.length;
    
    if(traceMessages)
      System.err.println("  sending HDL-HTTP request ("+req+") to "+
                         addr.getHostAddress()+':'+port);
    // create the socket, set the timeout value
    try {
      socket = TimedConnection.getSocket(addr, port, tcpTimeout);
      socket.setSoTimeout(tcpTimeout);
    } catch (Exception e) {
      try { socket.close(); } catch (Exception e2){}
      throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                addr.getHostAddress()+": "+String.valueOf(e));
    }

    MessageEnvelope rcvEnvelope = new MessageEnvelope();
    long whenToTimeout;

    AbstractResponse response = null;
    try {
      // send out the request...
      byte envBuf[] = new byte[Common.MESSAGE_ENVELOPE_SIZE];
      try {
        out = new BufferedOutputStream(socket.getOutputStream(), 512);
        Encoder.encodeEnvelope(sndEnvelope, envBuf);
        out.write(Util.encodeString("POST "+encodeHandleAsUri(req.handle)+" HTTP/1.0\r\n"));
        out.write(HTTP_ACCEPT_HEADER);
        out.write(HTTP_AGENT_HEADER);
        out.write(HTTP_CONTENT_TYPE_HEADER);
        out.write(Util.encodeString("Content-Length: "+(envBuf.length + requestBuf.length)+"\r\n"));
        out.write(HTTP_NEWLINE);
        
        out.write(envBuf, 0, Common.MESSAGE_ENVELOPE_SIZE);
        out.write(requestBuf, 0, requestBuf.length);
        out.flush();
        in = new BufferedInputStream(socket.getInputStream(), 512);
      } catch (Exception e) {
        throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                  String.valueOf(e)+" sending HTTP request to "+
                                  addr.getHostAddress());
      }

      // read the headers
      java.util.Hashtable headers = new java.util.Hashtable();
      DataInputStream din = new DataInputStream(in);
      while(true) {
        String line = din.readLine();
        if(line==null)
          throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                            addr.getHostAddress()+
                            ": Unexpected end of HTTP message during headers");
        line = line.trim();
        if(line.length()<=0)
          break;
        int colIdx = line.indexOf(';');
        if(colIdx<0) {
          headers.put(line.toUpperCase(),"");
        } else {
          headers.put(line.substring(0, colIdx), line.substring(colIdx+1));
        }
      }

      int r, n=0;
      
      while(true) {
        // read the envelope from the socket
        n = 0;
        while(n<Common.MESSAGE_ENVELOPE_SIZE &&
              (r=in.read(envBuf,n,Common.MESSAGE_ENVELOPE_SIZE-n))>=0)
          n += r;
        
        // decode the envelope
        Encoder.decodeEnvelope(envBuf, rcvEnvelope);
        
        // if we got someone else's packet, there is something *really* wrong
        if(rcvEnvelope.requestId != req.requestId) 
          throw new HandleException(HandleException.SECURITY_ALERT,
                                    "Message came back with different ID: "+
                                    req.requestId+"!="+rcvEnvelope.requestId);
        
        // read the message body+header from the socket
        byte messageBuf[] = new byte[rcvEnvelope.messageLength];
        n=0;
        while(n<rcvEnvelope.messageLength &&
              (r=in.read(messageBuf, n, rcvEnvelope.messageLength-n))>=0)
          n += r;

        // decrypt message if the session requires encryption
        if (rcvEnvelope.encrypted) {
          if (rcvEnvelope.sessionId > 0) {
            //try to decrypt with session key ...
            ClientSideSessionInfo csinfo = req.sessionInfo;
            if(csinfo==null) {
              throw new HandleException(HandleException.INCOMPLETE_SESSIONSETUP,
                                        "Cannot encrypt messages without a session");
            }
            
            messageBuf = csinfo.decryptBuffer(messageBuf, 0, messageBuf.length);
          } else {
            throw new HandleException(HandleException.SECURITY_ALERT,
                                      "Invalid response session id.  Cannot decrypt response.");
          }
        }
        
        response = (AbstractResponse)Encoder.decodeMessage(messageBuf, 0, rcvEnvelope);
        
        if(response.streaming) {
          response.stream = in;
          //response.socket = socket;
        }
        
        if(req.certify && checkSignatures) {
          // verify the signature of the response
          try {
            boolean veriPass = false;
            if (response.sessionId > 0) 
              //verify with session key first...
              veriPass = verifyResponse(req, response, addr);
                  
            // if session key verification fails, use server private key to
            // verify
            if (!veriPass) 
              verifyResponse(req, response);
          }
          catch (HandleException he){
            throw he;  
          }
        }
        
        if(callback!=null) {
          callback.handleResponse(response);
        } else {
          // there is no callback, just return this message
          return response;
        }
        
        // If there are no more messages, notify the callback, and return
        // the current (ie the last) message.
        if(!response.continuous) {
          return response;
        }
      }
    } catch (IOException e) {
      if(traceMessages)
        e.printStackTrace(System.err);
      throw new HandleException(HandleException.CANNOT_CONNECT_TO_SERVER,
                                "Error talking to "+addr.getHostAddress());
    } finally {
      if(socket!=null && (response==null || !response.streaming)) {
        try { in.close(); } catch (Exception e){}
        try { out.close(); } catch (Exception e){}
        try { socket.close(); } catch (Exception e){}
      }
    }
  }

}
