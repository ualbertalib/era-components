/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/** Generic response without any fields or parameters
 */

public class GenericResponse extends AbstractResponse {

  public GenericResponse() {
    super();
  }

  public GenericResponse(int opCode, int responseCode) {
    super(opCode, responseCode);
  }

  public GenericResponse(AbstractRequest req, int responseCode)
    throws HandleException
  {
    super(req,responseCode);
  }

}
