/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/***********************************************************************
 * Interface for the transaction queue scanner that is used as a
 * callback from messages like DumpHandlesRequest.
 ***********************************************************************/

public interface TransactionScannerInterface {
  public long getFirstDateInLog();
  public Transaction nextTransaction() throws Exception;
  public void close();
}


