/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.security.*;
import java.io.*;

/***************************************************************************
 * Response used to send all handles in the database to a replicated site/server.
 * This response is used for server&lt;-&gt;server (or replicator&lt;-&gt;server)
 * communication.
 ***************************************************************************/

public class DumpHandlesResponse extends AbstractResponse {
  // - settings used only on the server side -
  public DumpHandlesRequest req = null;

  // used on the server side as a source for the handle data
  private HandleStorage storage = null;
  private TransactionQueueInterface queue = null;
  private PrivateKey sourcePrivKey = null;

  private static final byte END_TRANSMISSION_RECORD = 0;
  private static final byte HANDLE_RECORD = 1;
  private static final byte NAMING_AUTH_RECORD = 2;
  
  /***************************************************************
   * Constructor for the server side.
   ***************************************************************/
  public DumpHandlesResponse(DumpHandlesRequest req,
                             HandleStorage storage,
                             TransactionQueueInterface queue,
                             PrivateKey sourcePrivKey)
    throws HandleException
  {
    super( req, AbstractMessage.RC_SUCCESS);
    this.req = req;
    this.storage = storage;
    this.queue = queue;
    this.streaming = true;
    this.sourcePrivKey = sourcePrivKey;
  }

  /***************************************************************
   * Constructor for the client side.
   ***************************************************************/
  public DumpHandlesResponse() {
    super(AbstractMessage.OC_RETRIEVE_TXN_LOG, AbstractMessage.RC_SUCCESS);
    this.streaming = true;
  }


  /**********************************************************************
   * Process the incoming stream and call the given callback for every
   * handle that is retrieved.  
   **********************************************************************/
  public void processStreamedPart(DumpHandlesCallback callback, PublicKey sourceKey) 
    throws HandleException
  {
    if(stream==null) {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Response stream not found");
    }

    int threadPriority = Thread.currentThread().getPriority();

    // downgrade this threads priority so that request handler threads
    // don't starve.
    /*
    try {
      Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
    } catch (Exception e) {
      System.err.println("Unable to downgrade thread priority: "+e);
    }
    */

    try {
      // get a signature object based on the public key
      SignedInputStream sin = new SignedInputStream(sourceKey, stream);
      DataInputStream in = new DataInputStream(sin);
      int dataVersion = in.readInt();

      // verify the signature for the header information
      if(!sin.verifyBlock()) {
        throw new HandleException(HandleException.SECURITY_ALERT,
                                  "Invalid signature on replication stream");
      }
      
      while(true) {
        byte recordType = in.readByte();
        if(recordType==END_TRANSMISSION_RECORD) {
          long date = in.readLong();
          long txnId = in.readLong();

          // verify the signature for this record
          if(!sin.verifyBlock()) {
            throw new HandleException(HandleException.SECURITY_ALERT,
                                      "Invalid signature on replication stream");
          }

          callback.finishProcessing(date,txnId);
          return;
        } else if(recordType==HANDLE_RECORD) {
          // get the record information...

          // read the handle name
          byte handleBytes[] = new byte[in.readInt()];
          in.readFully(handleBytes);

          // read the number of values
          HandleValue values[] = new HandleValue[in.readInt()];

          // read each of the values
          for(int i=0; i<values.length; i++) {
            byte valueBytes[] = new byte[in.readInt()];
            in.readFully(valueBytes);
            values[i] = new HandleValue();
            Encoder.decodeHandleValue(valueBytes, 0, values[i]);
          }

          // verify the signature for this record
          if(!sin.verifyBlock()) {
            throw new HandleException(HandleException.SECURITY_ALERT,
                                      "Invalid signature on replication stream");
          }

          // pass the retrieved handle to the callback
          callback.addHandle(handleBytes, values);
        } else if(recordType==NAMING_AUTH_RECORD) {
          byte naHandle[] = new byte[in.readInt()];
          in.readFully(naHandle);
          
          // verify the signature for this record
          if(!sin.verifyBlock()) {
            throw new HandleException(HandleException.SECURITY_ALERT,
                                      "Invalid signature on replication stream");
          }

          callback.addNamingAuthority(naHandle);
        } else {
          throw new HandleException(HandleException.INVALID_VALUE,
                                    "Unknown transmission record type: "+recordType);
        }
        Thread.yield();
      }
    } catch (Exception e) {
      System.err.println(">>> Exception receiving dump: "+e);
      e.printStackTrace(System.err);
      if(e instanceof HandleException)
        throw (HandleException)e;
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Exception receiving handle dump: "+e);
    } finally {
      if(stream!=null) {
        try { stream.close(); } catch (Exception e) {}
      }
      try {
        Thread.currentThread().setPriority(threadPriority);
      } catch (Exception e) {
        System.err.println("Unable to upgrade thread priority: "+e);
      }
    }
  }



  /***********************************************************************
   * Write the response to the specified output stream.  This will
   * send all of the handles that hash to the requestor beginning with
   * the specified transaction ID.  This method is typically called
   * on the server side.
   ***********************************************************************/
  public void streamResponse(java.io.OutputStream outStream)
    throws HandleException
  { 
    int threadPriority = Thread.currentThread().getPriority();

    // downgrade this threads priority so that request handler threads
    // don't starve.
    /*
    try {
      Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
    } catch (Exception e) {
      System.err.println("Unable to downgrade thread priority: "+e);
    }
    */

    // need to get all of the handles
    try {
      // use our private key to sign the response stream
      SignedOutputStream sout = new SignedOutputStream(sourcePrivKey, outStream);
      DataOutputStream out = new DataOutputStream(sout);
      
      // send a 4-byte data format version number
      out.writeInt(1);
      
      sout.signBlock();
      
      storage.scanHandles(new HdlForwarder(out, sout, false));
      storage.scanNAs(new HdlForwarder(out, sout, true));

      // write the ending summary record...
      out.writeByte(END_TRANSMISSION_RECORD);
      
      // Write the date that the requestor should use as the lastQueryDate 
      // for their next RetrieveHandlesRequest to this server.
      // This is needed because if there are no transactions in a while,
      // we don't want the receiver to have to redump the entire database.
      out.writeLong(System.currentTimeMillis());

      // Write the transaction ID that the requestor should use as the 
      // lastTransactionID for their next RetrieveHandlesRequest to this server.
      out.writeLong(queue.getLastTxnId());

      // sign this record
      sout.signBlock();
      
      out.flush();
      Thread.yield();
    } catch (Exception e) {
      // the replication stream can be broken in the middle... no biggie
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Exception sending transactions: "+e);
    } finally {
      try {
        Thread.currentThread().setPriority(threadPriority);
      } catch (Exception e) {
        System.err.println("Unable to upgrade thread priority: "+e);
      } 
   }
  }

  private class HdlForwarder 
    implements ScanCallback 
  {
    private boolean scanningNAs;
    private DataOutputStream out;
    private SignedOutputStream sout;
    
    public HdlForwarder(DataOutputStream out, SignedOutputStream sout, boolean scanningNAs) {
      this.out = out;
      this.sout = sout;
      this.scanningNAs = scanningNAs;
    }

    /***************************************************************************
     * Called by database scanner and will forward the handle and its value
     * over the connection.
     ***************************************************************************/
    public void scanHandle(byte handle[]) 
      throws HandleException
    {
      if(!scanningNAs &&
         req.serverNum!=SiteInfo.determineServerNum(handle, req.rcvrHashType, req.numServers)) {
        // this handle doesn't belong on the requesting server, so don't send it
        return;
      }

      try {
        
        if(scanningNAs) {
          out.write(NAMING_AUTH_RECORD);
          out.writeInt(handle.length);
          out.write(handle);
        } else {
          out.write(HANDLE_RECORD);
          
          byte values[][] = storage.getRawHandleValues(handle, null, null);
          
          out.writeInt(handle.length);
          out.write(handle);
          
          out.writeInt(values.length);
          
          for(int i=0; i<values.length; i++) {
            out.writeInt(values[i].length);
            out.write(values[i]);
          }
        }
        
        // sign this record...
        sout.signBlock();
        
      } catch (Exception e) {
        if(e instanceof HandleException)
          throw (HandleException)e;
        throw new HandleException(HandleException.INTERNAL_ERROR,
                                  String.valueOf(e));
      }
    }
  }
  
}
