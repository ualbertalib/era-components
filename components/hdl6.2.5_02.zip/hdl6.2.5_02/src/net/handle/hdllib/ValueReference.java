/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;


public class ValueReference
{
  public byte handle[];
  public int index;

  public ValueReference() {}

  public ValueReference(byte handle[], int index) 
  {
    this.handle = handle;
    this.index = index;
  }

  public boolean equals(Object o) {
    if(o==null || o.getClass()!=ValueReference.class) return false;
    ValueReference v = (ValueReference)o;
    return (v.index==index) && (Util.equals(v.handle, handle));
  }

  public String toString() {
    return String.valueOf(index)+':'+Util.decodeString(handle);
  }
}
