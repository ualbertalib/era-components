/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.util.*;


/** A ParameterSet describes the parameters of a handle URI.
 */
public class ParameterSet {
  private static final String DEFAULT_DEFAULT_TYPE="type";
  private static final String DEFAULT_HANDLE_TYPE="type";
  private static final String DEFAULT_LOCAL_TYPE="type";

  private ParameterPair defaultParamList[];
  private ParameterPair handleParamList[];
  private ParameterPair localParamList[];

  public String toString() {
    StringBuffer sb = new StringBuffer(handle);

    if(defaultParamList!=null) {
      sb.append(" default[");
      for(int i=0; i<defaultParamList.length; i++) {
        if(i!=0) sb.append(", ");
        sb.append(String.valueOf(defaultParamList[i]));
      }
      sb.append("]");
    }
    
    if(handleParamList!=null) {
      sb.append(" handle[");
      for(int i=0; i<handleParamList.length; i++) {
        if(i!=0) sb.append(", ");
        sb.append(String.valueOf(handleParamList[i]));
      }
      sb.append("]");
    }
    
    if(localParamList!=null) {
      sb.append(" local[");
      for(int i=0; i<localParamList.length; i++) {
        if(i!=0) sb.append(", ");
        sb.append(String.valueOf(localParamList[i]));
      }
      sb.append("]");
    }
    return sb.toString();
  }
  
  public String handle;
  public ParameterSet(String handle, 
                      ParameterPair defaultParamList[],
                      ParameterPair handleParamList[],
                      ParameterPair localParamList[]) {
    this.handle = handle;
    this.defaultParamList = defaultParamList;
    this.handleParamList = handleParamList;
    this.localParamList = localParamList;
  }

  public ParameterSet(String handle, ParameterPair handleParamList[]) {
    this.handle = handle;
    this.handleParamList = handleParamList;
  }

  public String[] getLocalParametersByName(String name) {
    return getParametersByName(name, localParamList, DEFAULT_LOCAL_TYPE);
  }
  public String[] getDefaultParametersByName(String name) {
    return getParametersByName(name, defaultParamList, DEFAULT_DEFAULT_TYPE);
  }
  public String[] getHandleParametersByName(String name) {
    return getParametersByName(name, handleParamList, DEFAULT_HANDLE_TYPE);
  }
  public String getLocalParameterString(){
    return getParameterString(localParamList);
  }
  public String getHandleParameterString(){
    return getParameterString(handleParamList);
  }
  public String getDefaultParameterString(){
    return getParameterString(defaultParamList);
  }

  private String getParameterString(ParameterPair params[]){
    if (localParamList == null) return "";
    StringBuffer buf = new StringBuffer();
    for (int i=0; i<params.length; i++){
      buf.append(params[i].name);
      buf.append("=");
      buf.append(params[i].value);
      if (i != params.length-1) buf.append(";");
    }
    return buf.toString();
  }
  
  public boolean containsHandleParameter(String name) {
    return containsParameter(name, handleParamList);
  }

  private static final String[] getParametersByName(String name,
                                                    ParameterPair pairs[],
                                                    String defaultName)
  {
    if(pairs==null || pairs.length<=0)
      return new String[0];
    Vector values = new Vector();
    boolean isDefaultName = name.equals(defaultName);
    for(int i=0;i<pairs.length;i++) {
      if((isDefaultName && pairs[i].name.length()==0) || 
         pairs[i].name.equals(name))
        values.addElement(pairs[i].value);
    }
    String valueArray[] = new String[values.size()];
    for(int i=0;i<valueArray.length;i++)
      valueArray[i] = (String)values.elementAt(i);
    return valueArray;
  }

  private boolean containsParameter(String name, ParameterPair pairs[]) {
    if(pairs==null || pairs.length<=0)
      return false;
    for(int i=pairs.length-1; i>=0; i--)
      if(pairs[i].name.equals(name))
        return true;
    return false;
  }
}
