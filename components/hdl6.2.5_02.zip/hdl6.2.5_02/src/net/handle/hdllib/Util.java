/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import net.handle.security.*;
import java.math.BigInteger;
import java.security.*;
import java.security.spec.*;
import java.security.interfaces.*;
import java.io.*;
import javax.crypto.spec.*;
import javax.crypto.interfaces.*;

public abstract class Util {

  private static MessageDigest md5[] = null;
  private static int nextMD5Idx;

  private static MessageDigest sha1[] = null;
  private static int nextSHA1Idx;
  
  private static boolean keyFactoryInitialized = false;
  private static Object keyFactoryInitLock = new Object();
  private static KeyFactory dsaKeyFactory = null;
  private static KeyFactory rsaKeyFactory = null;
  
  static {
    md5 = new MessageDigest[10];
    try {
      for(int i=0; i<md5.length; i++) {
        md5[i] = MessageDigest.getInstance("MD5");
        md5[i].reset();
      }
      nextMD5Idx = md5.length-1;
    } catch (NoSuchAlgorithmException e) {
      md5 = null;
    }

    try {
      sha1 = new MessageDigest[10];
      for(int i=0; i<sha1.length; i++) {
        sha1[i] = MessageDigest.getInstance("SHA-1");
        sha1[i].reset();
      }
      nextSHA1Idx = sha1.length-1;
    } catch (NoSuchAlgorithmException e) {
      sha1 = null;
    }
  }

  private static final char HEX_VALUES[] = {'0','1','2','3','4','5','6','7',
                                            '8','9','A','B','C','D','E','F'};

  public static final boolean looksLikeBinary(byte buf[]) {
    if(buf==null) return true;
    // 0x20 <= x < 0x80
    for(int i=0; i<buf.length; i++) {
      byte b = buf[0];
      if(b<0x20 || b>=0x80 || b<=0x00)
        return true;
    }
    return false;
  }

  public static final byte[] duplicateByteArray(byte buf[]) {
    if(buf==null) return null;
    byte newbuf[] = new byte[buf.length];
    System.arraycopy(buf, 0, newbuf, 0, newbuf.length);
    return newbuf;
  }
  
  public static final String decodeHexString(byte buf[], int offset, int len, boolean formatNicely)
  {
    if(buf==null || buf.length<=0) return "";
    StringBuffer sb = new StringBuffer();
    for(int i=offset; i<offset+len; i++) {
      if(formatNicely && i>0 && (i%16)==0)  sb.append('\n');
      sb.append(HEX_VALUES[ ( buf[i]&0xF0 ) >>> 4 ] );
      sb.append(HEX_VALUES[ ( buf[i]&0xF ) ] );
    }
    return sb.toString();
  }

  public static final String decodeHexString(byte buf[], boolean formatNicely){
    return decodeHexString(buf, 0, buf.length, formatNicely); 
  }
    
  public static final byte[] encodeHexString(String s) {
    s = s.toUpperCase().trim();
    byte buf[] = new byte[s.length()/2+1];
    for(int i=0; i<buf.length; i++) buf[i] = (byte)0;

    int i=0;
    boolean lowNibble = false;
    
    char ch;
    for(int c=0; c<s.length(); c++) {
      ch = s.charAt(c);
      if(ch>='0' && ch<='9') {
        if(lowNibble)
          buf[i++] |= ch-'0';
        else
          buf[i] = (byte)((ch-'0')<<4);
        lowNibble = !lowNibble;
      } else if(ch>='A' && ch<='F') {
        if(lowNibble)
          buf[i++] |= ch-'A'+10;
        else
          buf[i] = (byte)((ch-'A'+10)<<4);
        lowNibble = !lowNibble;
      }
    }
    byte realBuf[];
    if(!lowNibble) {
      realBuf = new byte[i];
    } else {
      realBuf = new byte[i+1];
    }
    System.arraycopy(buf,0,realBuf,0,realBuf.length);
    return realBuf;
    
  }

  /** Encoded the specified string into a byte array */
  public static final byte[] encodeString(String s)
  {
    try {
      return s.getBytes(Common.TEXT_ENCODING);
    } catch (Exception e) {
      System.err.println(e);
    }
    return s.getBytes();
  }

  public static final String decodeString(byte buf[])
  {
    if(buf==null || buf.length==0) return "";
    try {
      return new String(buf, Common.TEXT_ENCODING);
    } catch (Exception e) {
      System.err.println(e);
    }
    return new String(buf);
  }


  public static final String decodeString(byte buf[], int offset, int len)
  {
    if(buf==null || buf.length==0) return "";
    try {
      return new String(buf, offset, len, Common.TEXT_ENCODING);
    } catch (Exception e) {
      System.err.println(e);
    }
    return new String(buf, offset, len);
  }


  /** Returns true is the given byte array represents a valid
      text string in the encoding used by the handle system (utf8). */
  public static final boolean isValidString(byte buf[], int offset, int len) {
    int byte2mask = 0x00;  // should be unsigned???
    int c;
    
    int trailing = 0;  // trailing (continuation) bytes to follow
    int i = offset;

    while(i < len) {
      c = buf[i++];
      if(trailing != 0) {
        if((c&0xC0) == 0x80) { // Does trailing byte follow UTF-8 format?
          if(byte2mask != 0)         // Need to check 2nd byte for proper range?
            if((c & byte2mask) != 0)      // Are appropriate bits set?
              byte2mask=0x00;
            else
              return false;
          trailing--;
        } else {
          return false;
        }
      } else {
        if((c&0x80) == 0x00) {
          continue;      // valid 1 byte UTF-8
        } else if ((c&0xE0) == 0xC0) {           // valid 2 byte UTF-8
          if ((c&0x1E) != 0)                     // Is UTF-8 byte in
            // proper range?
            trailing =1;
          else
            return false;
        } else if ((c&0xF0) == 0xE0) {           // valid 3 byte UTF-8
          if ((c&0x0F) == 0)                // Is UTF-8 byte in
            // proper range?
            byte2mask=0x20;              // If not set mask
          // to check next byte
          trailing = 2;
        } else if ((c&0xF8) == 0xF0) {           // valid 4 byte UTF-8
          if ((c&0x07) == 0)                // Is UTF-8 byte in
            // proper range?
            
            byte2mask=0x30;              // If not set mask
          // to check next byte
          trailing = 3;
        } else if ((c&0xFC) == 0xF8) {           // valid 5 byte UTF-8
          if ((c&0x03) == 0)                // Is UTF-8 byte in
            // proper range?
            byte2mask=0x38;              // If not set mask
          // to check next byte
          trailing = 4;
        } else if ((c&0xFE) == 0xFC) {          // valid 6 byte UTF-8
          if ((c&0x01) == 0)                // Is UTF-8 byte in
            // proper range?
            byte2mask=0x3C;              // If not set mask
          // to check next byte
          trailing = 5;
        } else {
          return false;
        }
      }
    }
    return trailing == 0;
  }


  /** Get the authority handle that applies to the specified handle */
  public static final byte[] getNAHandle(byte handle[]) {
    int slashIndex = indexOf(handle, (byte)'/');
    if(slashIndex>=0) {
      byte naHandle[] = new byte[slashIndex + Common.NA_HANDLE_PREFIX.length];
      System.arraycopy(Common.NA_HANDLE_PREFIX, 0, naHandle, 0, Common.NA_HANDLE_PREFIX.length);
      System.arraycopy(handle, 0, naHandle, Common.NA_HANDLE_PREFIX.length, 
                       slashIndex);
      upperCaseInPlace(naHandle);
      return naHandle;
    } else {
      byte naHandle[] = new byte[Common.NA_HANDLE_PREFIX.length + handle.length];
      System.arraycopy(Common.NA_HANDLE_PREFIX, 0, naHandle, 0, Common.NA_HANDLE_PREFIX.length);
      System.arraycopy(handle, 0, naHandle, Common.NA_HANDLE_PREFIX.length, handle.length);
      upperCaseInPlace(naHandle);
      return naHandle;
    }
  }
  
  /** Get the authority handle that applies to the specified handle */
  public static final String getNAHandle(String handle) {
    if(handle==null) return new String(Common.ROOT_HANDLE);
    if(handle.startsWith("0."))
      return new String(Common.ROOT_HANDLE);
    
    int slashIndex = handle.indexOf('/');
    if(slashIndex>=0) {
      return "0.NA/"+handle.substring(0, slashIndex).toUpperCase();
    } else {
      return "0.NA/"+handle.toUpperCase();
    }
  }
  
  public static final boolean isSubNAHandle(byte handle[]) {
    if(Util.startsWithCI(handle,Common.NA_HANDLE_PREFIX)) {
      byte dot = (byte)'.';
      for(int i = Common.NA_HANDLE_PREFIX.length; i<handle.length; i++) {
        if(handle[i]==dot)
          return true;
      }
    }
    return false;
  }

  /** Get the parent naming authority handle for the given naming authority
    * handle.  The given handle MUST be a naming authority handle. */
  public static final byte[] getParentNAOfNAHandle(byte naHandle[]) {
    int parentEndIdx = naHandle.length-1;
    int slashIdx = indexOf(naHandle, (byte)'/');
    byte dot = (byte)'.';
    while(parentEndIdx>slashIdx) {
      if(naHandle[parentEndIdx]==dot) {
        parentEndIdx--;
        break;
      }
      parentEndIdx--;
    }
    byte parentNAHandle[] = new byte[Common.NA_HANDLE_PREFIX.length + (parentEndIdx-slashIdx)];
    int loc = 0;
    System.arraycopy(Common.NA_HANDLE_PREFIX, 0, parentNAHandle, 
                     loc, Common.NA_HANDLE_PREFIX.length);
    System.arraycopy(naHandle, slashIdx+1, parentNAHandle, 
                     Common.NA_HANDLE_PREFIX.length, (parentEndIdx-slashIdx));
    return parentNAHandle;
  }

  /** Get only the naming authority part of this handle. */
  public static final byte[] getNAPart(byte handle[]) {
    int slashIndex = indexOf(handle, (byte)'/');
    return slashIndex<0 ? handle : substring(handle,0,slashIndex);
  }

  /** Get only the identifier part of this handle. */
  public static final byte[] getIDPart(byte handle[]) {
    int slashIndex = indexOf(handle, (byte)'/');
    return slashIndex<0 ? new byte[0] : substring(handle, slashIndex+1, handle.length);
  }


  public static final boolean startsWith(byte b1[], byte b2[]) {
    if(b1.length<b2.length) return false;
    for(int i=0; i<b2.length; i++)
      if(b1[i]!=b2[i]) return false;
    return true;
  }


  /**********************************************************************
   * compare the two arrays.  If they are the same true is returned.
   **********************************************************************/
  public static final boolean equals(byte b1[], byte b2[]) {
    if(b1==null && b2==null) return true;
    if(b1==null || b2==null) return false;
    if(b1.length!=b2.length) return false;
    for(int i=0; i<b1.length; i++)
      if(b1[i]!=b2[i]) return false;
    return true;
  }

  /**********************************************************************
   * compare the two arrays starting at the given index. If they are
   * the same true is returned.
   **********************************************************************/
  public static final boolean equals(byte b1[], int b1Start, byte b2[], int b2Start) {
    if(b1==null && b2==null) return true;
    if(b1==null || b2==null) return false;
    if( (b1.length - b1Start) != (b2.length - b2Start)) return false;
    for(; b1Start < b1.length; b1Start++, b2Start++)
      if(b1[b1Start] != b2[b2Start]) return false;
    return true;
  }

  public static final byte CASE_DIFF = 'A'-'a';

  /**********************************************************************
   * create and return an upper-case copy of the given UTF8 byte array
   **********************************************************************/
  public static final byte[] upperCase(byte b[]) {
    if(b==null || b.length==0) return new byte[0];
    int sz = b.length;
    byte b2[] = new byte[sz];
    System.arraycopy(b, 0, b2, 0, sz);

    for(int i=sz-1; i>=0; i--) {
      if(b2[i]>='a' && b2[i]<='z')
        b2[i] += CASE_DIFF;
    }
    return b2;
  }

  /**********************************************************************
   * Convert all of the characters in the given utf-8 byte array 
   * to upper case.  Return the same array.
   **********************************************************************/
  public static final byte[] upperCaseInPlace(byte b[]) 
  {
    if(b==null || b.length==0) return b;
    for(int i=0; i<b.length; i++) {
      if(b[i]>='a' && b[i]<='z')
        b[i] += CASE_DIFF;
    }
    return b;
  }


  /** Determine if the first parameter equals the second 
   *  parameter in a case insensitive comparison. */
  public static final boolean equalsCI(byte b1[], byte b2[]) {
    if(b1==null && b2==null) return true;
    if(b1==null || b2==null) return false;
    return equalsCI(b1, b1.length, b2, b2.length);
  }

  /** Determine if the first parameter equals the second parameter
      in a case insensitive manner over the given length. */
  public static final boolean equalsCI(byte b1[], int b1Len, byte b2[], int b2Len) {
    if(b1==null && b2==null) return true;
    if(b1==null || b2==null) return false;
    if(b1Len!=b2Len || b1Len>b1.length || b2Len>b2.length) return false;
    
    byte byte1, byte2;
    for(int i=0; i<b1Len; i++) {
      byte1 = b1[i];
      byte2 = b2[i];
      if(byte1==byte2) continue;
      if(byte1>='a' && byte1<='z') byte1 += CASE_DIFF;
      if(byte2>='a' && byte2<='z') byte2 += CASE_DIFF;
      if(byte1!=byte2) return false;
    }
    return true;
  }
  
  /** Determine if the first parameter begins with the second 
   *  parameter in a case insensitive comparison. */
  public static final boolean startsWithCI(byte b1[], byte b2[]) {
    if(b1.length<b2.length) return false;
    byte byte1, byte2;
    for(int i=0; i<b2.length; i++) {
      byte1 = b1[i];
      byte2 = b2[i];
      if(byte1==byte2) continue;
      if(byte1>='a' && byte1<='z') byte1 += CASE_DIFF;
      if(byte2>='a' && byte2<='z') byte2 += CASE_DIFF;
      if(byte1!=byte2) return false;
    }
    return true;
  }

  /** determine if the second UTF8 encoded parameter begins 
   *  with the second parameter in a case sensitive comparison. */
  public static final byte[] substring(byte b[], int i1) {
    return substring(b,i1,b.length);
  }

  public static final byte[] substring(byte b[], int i1, int i2) {
    byte rb[] = new byte[i2-i1];
    System.arraycopy(b,i1,rb,0,i2-i1);
    return rb;
  }

  public static final int indexOf(byte b[], byte ch) {
    for(int i=0; i<b.length; i++) {
      if(b[i]==ch) return i;
    }
    return -1;
  }
  
  public static final int countValuesOfType(HandleValue values[], byte type[]) {
    if(values==null) return 0;
    int matches = 0;
    for(int i=0; i<values.length; i++) {
      if(equals(values[i].type, type)) {
        matches++;
      }
    }
    return matches;
  }
  
  /** Returns true if there is an element in the array that this value
   *  "starts with".  
   *  For example:
   *
   *  isParentInArray( { "url", "email", "public_key" }, "url.us" ) returns true
   *  isParentInArray( { "url.jp", "email", "public_key" }, "url" ) returns false
   *
   */
  public static final boolean isParentTypeInArray(byte a[][], byte val[]) {
    if(a==null) return false;
    if(val==null || val.length<=0) return false;

    for(int i=a.length-1; i>=0; i--) {
      byte queryType[] = a[i];
      if(queryType.length>0 && queryType[queryType.length-1]=='.') {
        // look for a prefix match
        if(startsWithCI(val, queryType))
          return true;

        // check for an exact match of just the prefix
        if(equalsCI(queryType, queryType.length-1, val, val.length))
          return true;
        
      } else {
        // looking for an exact match for this type
        if(equalsCI(queryType, val))
          return true;
      }
    }
    
    return false;
  }


  /**********************************************************************
   * returns true if the given int value is in the specified array.
   **********************************************************************/
  public static final boolean isInArray(int a[], int val) {
    if(a==null) return false;
    for(int i=0; i<a.length; i++)
      if(a[i]==val) return true;
    return false;
  }

  /**********************************************************************
   * returns true if the given byte array is contained in the
   * specified byte array array.
   **********************************************************************/
  public static final boolean isInArray(byte a[][], byte val[]) {
    if(a==null) return false;
    for(int i=0; i<a.length; i++)
      if(Util.equals(a[i],val)) return true;
    return false;
  }


  /**********************************************************************
   * Extract and return all of the SiteInfo records from the given list
   * of handle values.  Returns null if no site values were found.
   **********************************************************************/
  public static SiteInfo[] getSitesFromValues(HandleValue values[]) {
      
    // extract and return the SiteInfo records (if any)
    int numSites = countValuesOfType(values, Common.SITE_INFO_TYPE);
    if(numSites>0) {
      int siteNum = 0;
      SiteInfo sites[] = new SiteInfo[numSites];
      for(int i=0; i<values.length; i++) {
        if(Util.equals(values[i].type, Common.SITE_INFO_TYPE)) {
          sites[siteNum] = new SiteInfo();
          try{ 
            Encoder.decodeSiteInfoRecord(values[i].data, 0, sites[siteNum]);
            siteNum++;
          } catch (Throwable e) {
            System.err.println("Error decoding site record: "+e);
            e.printStackTrace(System.err);
            sites[siteNum] = null;
          }
        }
      }
      return sites;
    }
    return null;
  }

  
  /**
   * Extract and return the namespace information contained in the given 
   * handle values.  If there are multiple values with type HS_NAMESPACE then
   * the one with the lowest index value will be used.  If no valid namespace
   * values are encountered then this will return null.
   */
  public static NamespaceInfo getNamespaceFromValues(HandleValue values[]) {
    NamespaceInfo nsInfo = null;
    int currentNSIdx = 0;
    for(int i=0; values!=null && i<values.length; i++) {
      if(values[i]==null) continue;
      if(values[i].hasType(Common.NAMESPACE_INFO_TYPE)) {
        if(nsInfo==null || values[i].index < currentNSIdx) {
          try {
            nsInfo = new NamespaceInfo(values[i]);
            currentNSIdx = values[i].index;
          } catch (HandleException e) {
            System.err.println("Error decoding namespace info: "+e);
          }
        }
      }
    }
    return nsInfo;
  }


  
  /**************************************************************************
   * rearranges the given sites in a more efficient order so that resolution
   * from the current location should tend to access the faster sites first.
   * If a preferred site is listed in the server configuration file, it is
   * accessed first.
   **************************************************************************/
  public static final SiteInfo[] orderSitesByPreference(SiteInfo sites[]) {
    if(sites==null) return new SiteInfo[0];
    java.util.Random r = new java.util.Random();
    int randomIdx = 0;
    float randomNum = 0;
    float ranges[] = new float[sites.length];
    
    // sort sites by response times using BubbleSort
    for(int j=1; j<sites.length; j++){
      for(int k=0; k<sites.length-1; k++){
        if(sites[k].responseTime > sites[k+1].responseTime){
          SiteInfo temp = sites[k];
          sites[k] = sites[k+1];
          sites[k+1] = temp;
        }
      }
    }
    // specify ranges based on site response times
    if(sites[0].responseTime == 0) sites[0].responseTime = 1;
    if(sites[sites.length -1].responseTime == 0) {
      sites[sites.length -1].responseTime = 1;
    }
    
    ranges[0] = (float)(10.0*sites[sites.length -1].responseTime/sites[0].responseTime);
    
    for(int i=1; i<sites.length; i++){
      if(sites[i].responseTime == 0) sites[i].responseTime = 1;
      ranges[i] = ranges[i-1] + (float)(10.0*sites[sites.length -1].responseTime/sites[i].responseTime);
    }
    // whichever range the random number falls in will specify which site gets
    // accessed first
    randomNum = (float)Math.abs(r.nextInt())% ranges[sites.length-1];
    for(int i=0; i<sites.length; i++){
      if(randomNum <= ranges[i]){
        randomIdx = i;
        break;
      }
    }
    if(randomIdx != 0){
      SiteInfo temp = sites[0];
      sites[0] = sites[randomIdx];
      sites[randomIdx] = temp;
    }
    
    
    //if a preferred site is given, this site is accessed first
    String preferredGlobal = System.getProperty("hdllib.preferredGlobal");
    if(preferredGlobal !=  null){
      for(int j=0; j<sites.length; j++){
        for(int i=0; i<sites[j].servers.length; i++){
          if(preferredGlobal.equals(sites[j].servers[i].getAddressString())){
            SiteInfo temp = sites[0];
            sites[0] = sites[j];
            sites[j] = temp;
          }
        }
      }
    }
    return sites;
  }


  /**********************************************************************
   *  Get a passphrase from the user.
   **********************************************************************/
  /*
  public static final byte getPassphrase()
    throws Exception
  {
    return getPassphrase("Please enter the private key passphrase: ");
  }
  */


  /**********************************************************************
   *  Get a passphrase from the user.
   **********************************************************************/
  public static final byte[] getPassphrase(String prompt) 
    throws Exception
  {
    byte passphrase[] = new byte[2048];
    int charIdx=0;

    // read any characters that may already be entered but not read
    long endTime = System.currentTimeMillis() + 1000; // only read for a maximum of one second
    while(System.currentTimeMillis()<endTime && System.in.available()>0)
      System.in.read();

    System.out.println(prompt);
    System.out.println("Note: Your passphrase will be displayed as it is entered");
    System.out.flush();
    while(true) {
      int input = System.in.read();
      if(input<0 || input=='\n' || input=='\r') break;
      passphrase[charIdx++] = (byte)input;
    }
    byte secKey[] = new byte[charIdx];
    System.arraycopy(passphrase,0,secKey,0,charIdx);
    for(int i=0; i<passphrase.length; i++) passphrase[i] = (byte)0;
    return secKey;
  }

  
  /** Get the ID that the handle system uses to identify the hash algorithm
    * used in the given signature algorithm descriptor.  */
  public static byte[] getHashAlgIdFromSigId(String signatureAlgorithm) 
    throws HandleException
  {
    if(signatureAlgorithm.startsWith("SHA"))
      return Common.HASH_ALG_SHA1;
    else if(signatureAlgorithm.startsWith("MD5"))
      return Common.HASH_ALG_MD5;
    throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                              "Unknown signature algorithm: "+signatureAlgorithm);
  }

  public static String getSigIdFromHashAlgId(byte hashAlgId[], String sigKeyType) 
    throws HandleException
  {
    if(Util.equals(hashAlgId, Common.HASH_ALG_SHA1))
      return "SHA1with"+sigKeyType;
    else if(Util.equals(hashAlgId, Common.HASH_ALG_MD5))
      return "MD5with"+sigKeyType;
    throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                              "Unknown hash algorithm ID: "+Util.decodeString(hashAlgId));
  }

  public static byte[] getBytesFromPrivateKey(PrivateKey key)
    throws Exception
  {
    if(key instanceof DSAPrivateKey) {
      DSAPrivateKey dsaKey = (DSAPrivateKey)key;
      byte x[] = dsaKey.getX().toByteArray();
      DSAParams params = dsaKey.getParams();
      byte p[] = params.getP().toByteArray();
      byte q[] = params.getQ().toByteArray();
      byte g[] = params.getG().toByteArray();
      byte enc[] = new byte[Encoder.INT_SIZE*5 + Common.KEY_ENCODING_DSA_PRIVATE.length +
                           x.length + p.length + q.length + g.length];
      int loc = 0;
      loc += Encoder.writeByteArray(enc, loc, Common.KEY_ENCODING_DSA_PRIVATE);
      loc += Encoder.writeByteArray(enc, loc, x);
      loc += Encoder.writeByteArray(enc, loc, p);
      loc += Encoder.writeByteArray(enc, loc, q);
      loc += Encoder.writeByteArray(enc, loc, g);
      return enc;
    } else if (key instanceof RSAPrivateKey) {
      RSAPrivateKey rsaKey = (RSAPrivateKey)key;
      if (rsaKey instanceof RSAPrivateCrtKey) {
        //instance is a RSA Private Crt key
        RSAPrivateCrtKey rsacrtKey = (RSAPrivateCrtKey)rsaKey;
        byte x[]   = rsacrtKey.getModulus().toByteArray();
        byte ex[]  = rsacrtKey.getPrivateExponent().toByteArray();
        byte pubEx[] = rsacrtKey.getPublicExponent().toByteArray();
        byte p[]   = rsacrtKey.getPrimeP().toByteArray();
        byte q[]   = rsacrtKey.getPrimeQ().toByteArray();
        byte exP[] = rsacrtKey.getPrimeExponentP().toByteArray();
        byte exQ[] = rsacrtKey.getPrimeExponentQ().toByteArray();
        byte coeff[] = rsacrtKey.getCrtCoefficient().toByteArray();

        byte enc[] = new byte[Encoder.INT_SIZE*9 + Common.KEY_ENCODING_RSACRT_PRIVATE.length +
                              x.length + ex.length +
                              pubEx.length + p.length + q.length +
                              exP.length + exQ.length + coeff.length];
        int loc = 0;
        loc += Encoder.writeByteArray(enc, loc, Common.KEY_ENCODING_RSACRT_PRIVATE);
        loc += Encoder.writeByteArray(enc, loc, x);
        loc += Encoder.writeByteArray(enc, loc, pubEx);
        loc += Encoder.writeByteArray(enc, loc, ex);
        loc += Encoder.writeByteArray(enc, loc, p);
        loc += Encoder.writeByteArray(enc, loc, q);
        loc += Encoder.writeByteArray(enc, loc, exP);
        loc += Encoder.writeByteArray(enc, loc, exQ);
        loc += Encoder.writeByteArray(enc, loc, coeff);
        return enc;
      } else {
        //just a RSA private Key
        byte x[] = rsaKey.getModulus().toByteArray();
        byte y[] = rsaKey.getPrivateExponent().toByteArray();
        byte enc[] = new byte[Encoder.INT_SIZE*3 + Common.KEY_ENCODING_RSA_PRIVATE.length +
                               x.length + y.length ];
        int loc = 0;
        loc += Encoder.writeByteArray(enc, loc, Common.KEY_ENCODING_RSA_PRIVATE);
        loc += Encoder.writeByteArray(enc, loc, x);
        loc += Encoder.writeByteArray(enc, loc, y);                           
        return enc;
      }
    } else {
      throw new HandleException(HandleException.INVALID_VALUE,
                                "Unknown private key type: \""+key+'"');
    }
  }
  
  
  private static final void initKeyFactories() {
    if(!keyFactoryInitialized) {
      synchronized(keyFactoryInitLock) {
        if(!keyFactoryInitialized) {
          try {
            dsaKeyFactory = KeyFactory.getInstance("DSA");
          } catch (Exception e) {
            System.err.println("Error acquiring DSA key factory: "+e);
          }
          try {
            rsaKeyFactory = KeyFactory.getInstance("RSA");
          } catch (Exception e) {
            System.err.println("Error acquiring RSA key factory: "+e);
          }
          keyFactoryInitialized = true;
        }
      }
    }
  }
  
  public static PrivateKey getPrivateKeyFromBytes(byte pkBuf[], int offset)
    throws Exception
  {
    initKeyFactories();
    
    byte keyType[] = Encoder.readByteArray(pkBuf, offset);
    offset += Encoder.INT_SIZE + keyType.length;
    if(Util.equals(keyType, Common.KEY_ENCODING_DSA_PRIVATE)) {
      byte x[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + x.length;
      byte p[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + p.length;
      byte q[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + q.length;
      byte g[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + g.length;
      if(dsaKeyFactory==null) 
        throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                  "DSA encryption not available");
      DSAPrivateKeySpec keySpec = new DSAPrivateKeySpec(new BigInteger(1, x),
                                                        new BigInteger(1, p),
                                                        new BigInteger(1, q),
                                                        new BigInteger(1, g));
      return dsaKeyFactory.generatePrivate(keySpec);
    } else if (Util.equals(keyType, Common.KEY_ENCODING_RSA_PRIVATE)) {
      byte m[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + m.length;
      byte exp[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + exp.length;
      if(rsaKeyFactory==null) 
        throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                  "DSA encryption not available");
      RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(new BigInteger(1, m),
                                                        new BigInteger(1, exp));
      return rsaKeyFactory.generatePrivate(keySpec);
    } else if (Util.equals(keyType, Common.KEY_ENCODING_RSACRT_PRIVATE)) {
      byte n[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + n.length;
      byte pubEx[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + pubEx.length;
      byte ex[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + ex.length;
      byte p[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + p.length;
      byte q[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + q.length;
      byte exP[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + exP.length;
      byte exQ[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + exQ.length;
      byte coeff[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + coeff.length;
      if(rsaKeyFactory==null) 
        throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                  "DSA encryption not available");
      RSAPrivateCrtKeySpec keySpec = 
        new RSAPrivateCrtKeySpec(new BigInteger(1, n),
                                 new BigInteger(1, pubEx),
                                 new BigInteger(1, ex),
                                 new BigInteger(1, p),
                                 new BigInteger(1, q),
                                 new BigInteger(1, exP),
                                 new BigInteger(1, exQ),
                                 new BigInteger(1, coeff));
      return rsaKeyFactory.generatePrivate(keySpec);
    }
    throw new HandleException(HandleException.INVALID_VALUE,
                              "Unknown format for private key: \""+
                              Util.decodeString(keyType)+'"');
  }

  public static byte[] getBytesFromPublicKey(PublicKey key)
    throws Exception
  {
    int flags = 0;
    if(key instanceof DSAPublicKey) {
      DSAPublicKey dsaKey = (DSAPublicKey)key;
      byte y[] = dsaKey.getY().toByteArray();
      DSAParams params = dsaKey.getParams();
      byte p[] = params.getP().toByteArray();
      byte q[] = params.getQ().toByteArray();
      byte g[] = params.getG().toByteArray();
      byte enc[] = new byte[Encoder.INT_SIZE*5 + Common.KEY_ENCODING_DSA_PUBLIC.length +
                           2 + y.length + p.length + q.length + g.length];
      int loc = 0;
      loc += Encoder.writeByteArray(enc, loc, Common.KEY_ENCODING_DSA_PUBLIC);
      loc += Encoder.writeInt2(enc, loc, flags); // 2 octets reserved for future use
      loc += Encoder.writeByteArray(enc, loc, q);
      loc += Encoder.writeByteArray(enc, loc, p);
      loc += Encoder.writeByteArray(enc, loc, g);
      loc += Encoder.writeByteArray(enc, loc, y);
      return enc;
    } else if ( key instanceof RSAPublicKey)  {
      RSAPublicKey rsaKey = (RSAPublicKey)key;
      byte m[] = rsaKey.getModulus().toByteArray();
      byte ex[] = rsaKey.getPublicExponent().toByteArray();
      byte enc[] = new byte[Encoder.INT_SIZE*4 + m.length + ex.length + 2 +
                            Common.KEY_ENCODING_RSA_PUBLIC.length];
      int loc = 0;
      loc += Encoder.writeByteArray(enc, loc, Common.KEY_ENCODING_RSA_PUBLIC);
      loc += Encoder.writeInt2(enc, loc, flags); // 2 octets reserved for future use
      loc += Encoder.writeByteArray(enc, loc, ex);
      loc += Encoder.writeByteArray(enc, loc, m);                           
      return enc;  
    } else if (key instanceof DHPublicKey){
      DHPublicKey dhKey = (DHPublicKey)key;
      DHParameterSpec dhSpec = dhKey.getParams();
      byte y[] = dhKey.getY().toByteArray();
      byte p[] = dhSpec.getP().toByteArray();
      byte g[] = dhSpec.getG().toByteArray();
      byte enc[] = new byte[y.length+g.length+p.length+Encoder.INT_SIZE*4
                            +Common.KEY_ENCODING_DH_PUBLIC.length+2];
      int offset=Encoder.writeByteArray(enc, 0, Common.KEY_ENCODING_DH_PUBLIC);
      offset += Encoder.writeInt2(enc, offset, flags); // 2 octets reserved 
      offset += Encoder.writeByteArray(enc, offset, y); 
      offset += Encoder.writeByteArray(enc, offset, p); 
      offset += Encoder.writeByteArray(enc, offset, g); 
      return enc;
    } else {
      throw new HandleException(HandleException.INVALID_VALUE,
                                "Unknown public key type: \""+key+'"');
    }
  }

  public static PublicKey getPublicKeyFromFile(String filename)
    throws Exception
  {
    File f = new File(filename);
    FileInputStream in = new FileInputStream(f);  
    byte buf[] = new byte[(int)f.length()];
    in.read(buf);
    return getPublicKeyFromBytes(buf, 0);
  }
  
  public static PublicKey getPublicKeyFromBytes(byte pkBuf[], int offset)
    throws Exception
  {
    initKeyFactories();
    
    byte keyType[] = Encoder.readByteArray(pkBuf, offset);
    offset += Encoder.INT_SIZE + keyType.length;
    int flags = Encoder.readInt2(pkBuf, offset); // currently not used... reserved
    offset += Encoder.INT2_SIZE;
    if(Util.equals(keyType, Common.KEY_ENCODING_DSA_PUBLIC)) {
      byte q[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + q.length;
      byte p[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + p.length;
      byte g[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + g.length;
      byte y[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + y.length;
      
      initKeyFactories();
      if(dsaKeyFactory==null) 
        throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                  "DSA encryption not available");
      DSAPublicKeySpec keySpec = new DSAPublicKeySpec(new BigInteger(1, y),
                                                      new BigInteger(1, p),
                                                      new BigInteger(1, q),
                                                      new BigInteger(1, g));
      return dsaKeyFactory.generatePublic(keySpec);
    } else if (Util.equals(keyType, Common.KEY_ENCODING_RSA_PUBLIC)) {
      byte ex[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + ex.length;
      byte m[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + m.length;
      
      initKeyFactories();
      if(rsaKeyFactory==null) 
        throw new HandleException(HandleException.ENCRYPTION_ERROR,
                                  "RSA encryption not available");
      RSAPublicKeySpec keySpec = new RSAPublicKeySpec(new BigInteger(1, m),
                                                      new BigInteger(1, ex));
      return rsaKeyFactory.generatePublic(keySpec);
    } else if (Util.equals(keyType, Common.KEY_ENCODING_DH_PUBLIC)) {
      
      byte y[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + y.length;
      byte p[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + p.length;
      byte g[] = Encoder.readByteArray(pkBuf, offset);
      offset += Encoder.INT_SIZE + g.length;
      return new DHPublicKeyImpl(new BigInteger(1, y), new BigInteger(1, p),
                                 new BigInteger(1, g));
    } 
    throw new HandleException(HandleException.INVALID_VALUE,
                              "Unknown format for public key: \""+
                              Util.decodeString(keyType)+'"');
  }



  /********************************************************************
   * Encrypt the given set of bytes using the specified secret key and 
   * the default encryption algorithm.
   ********************************************************************/
  public static byte[] encrypt(byte cleartext[], byte secretKey[])
    throws Exception
  {
    return encrypt(cleartext, secretKey, Common.ENCRYPT_DES_ECB_PKCS5);
  }

  /******************************************************************
   * Encrypt the given set of bytes using the specified secret key
   * and encryption algorithm.
   ******************************************************************/
  public static byte[] encrypt(byte cleartext[], byte secretKey[], int encType) 
    throws Exception
  {
    if(secretKey!=null) 
      secretKey = doMD5Digest(secretKey);
    
    HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();

    byte enc[];
    byte enc2[];
    switch(encType) {
      case Common.ENCRYPT_DES_ECB_PKCS5:
        if(cryptoProvider==null) {
          throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                    "Encryption engine missing");
        }
    
        enc = cryptoProvider.encrypt_DES_ECB_PKCS5(cleartext, 0, 
                                                   cleartext.length, 
                                                   secretKey);
        enc2 = new byte[enc.length + Encoder.INT_SIZE];
        Encoder.writeInt(enc2, 0, encType);
        System.arraycopy(enc, 0, enc2, Encoder.INT_SIZE, enc.length);
        return enc2;
      case Common.ENCRYPT_NONE: 
        System.err.println("Warning: data not encrypted");
        enc2 = new byte[cleartext.length + Encoder.INT_SIZE];
        Encoder.writeInt(enc2, 0, encType);
        System.arraycopy(cleartext, 0, enc2, Encoder.INT_SIZE, cleartext.length);
        return enc2;
      default:
        throw new HandleException(HandleException.UNKNOWN_ALGORITHM_ID, 
                                  "Unknown algorithm ID: "+encType);
    }
  }


  /********************************************************************
   * I know, I know, "encrypt if possible?!?!".  Yes, this is for 
   * storing private keys, and if the crypto library isn't available,
   * then we will just store the private key in the clear (with a 
   * warning to stderr of course).
   ********************************************************************/
  public static byte[] encryptIfPossible(byte cleartext[], byte secretKey[])
    throws Exception
  {
    try {
      return encrypt(cleartext, secretKey, Common.ENCRYPT_DES_ECB_PKCS5);
    } catch (HandleException e) {
      if(e.getCode()==HandleException.MISSING_CRYPTO_PROVIDER) {
        return encrypt(cleartext, secretKey, Common.ENCRYPT_NONE);
      }
      throw e;
    }
  }


  /********************************************************************
   * Returns true is the given ciphertext requires a secret key to be
   *    decrypted (ie if the encryption algorithm is ENCRYPT_NONE).
   ********************************************************************/
  public static final boolean requiresSecretKey(byte ciphertext[])
    throws Exception
  {
    int encryptionType = Encoder.readInt(ciphertext, 0);
    if(encryptionType==Common.ENCRYPT_NONE)
      return false;
    return true;
  }
  

  /******************************************************************
   * Decrypt the given set of bytes using the specified secret key
   ******************************************************************/
  public static byte[] decrypt(byte ciphertext[], byte secretKey[]) 
    throws Exception
  {
    if(secretKey!=null) 
      secretKey = doMD5Digest(secretKey);
    HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();
    
    int encryptionType = Encoder.readInt(ciphertext, 0);
    switch(encryptionType) {
      case Common.ENCRYPT_DES_ECB_PKCS5:
        if(cryptoProvider==null) {
          throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                    "Encryption engine missing");
        }
        try {
          return cryptoProvider.decrypt_DES_ECB_PKCS5(ciphertext, Encoder.INT_SIZE,
                                                      ciphertext.length - Encoder.INT_SIZE,
                                                      secretKey);
        } catch (javax.crypto.BadPaddingException e){
          e.printStackTrace(System.err);
          throw new Exception("Incorrect passphrase");
        }
      case Common.ENCRYPT_NONE:
        byte cleartext[] = new byte[ciphertext.length-Encoder.INT_SIZE];
        System.arraycopy(ciphertext, Encoder.INT_SIZE, cleartext, 0, cleartext.length);
        return cleartext;
      default:
        throw new HandleException(HandleException.INVALID_VALUE,
                                  "Unknown encryption type code: "+encryptionType);
    }
  }


  private static final synchronized MessageDigest getSHA1Digest()
    throws HandleException
  {
    if(sha1==null)
      throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,"SHA1 algorithm not found");
    synchronized (sha1) {
      nextSHA1Idx = nextSHA1Idx<=0 ? sha1.length-1 : nextSHA1Idx-1;
      return sha1[nextSHA1Idx];
    }
  }

  public static final byte[] doSHA1Digest(byte buf[]) 
    throws HandleException
  {
    MessageDigest digest = getSHA1Digest();
    synchronized(digest) {
      return digest.digest(buf);
    }
  }

  public static final byte[] doSHA1Digest(byte buf1[], byte buf2[], byte buf3[], byte buf4[])
    throws HandleException
  {
    MessageDigest digest = getSHA1Digest();
    synchronized(digest) {
      digest.update(buf1);
      digest.update(buf2);
      digest.update(buf3);
      digest.update(buf4);
      return digest.digest();
    }
  }

  private static final synchronized MessageDigest getMD5Digest()
    throws HandleException
  {
    if(md5==null)
      throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,"MD5 algorithm not found");
    synchronized (md5) {
      nextMD5Idx = nextMD5Idx<=0 ? md5.length-1 : nextMD5Idx-1;
      return md5[nextMD5Idx];
    }
  }

  public static final byte[] doMD5Digest(byte buf[]) 
    throws HandleException
  {
    MessageDigest digest = getMD5Digest();
    synchronized(digest) {
      return digest.digest(buf);
    }
  }

  public static final byte[] doMD5Digest(byte buf1[], byte buf2[], byte buf3[], byte buf4[])
    throws HandleException
  {
    MessageDigest digest = getMD5Digest();
    synchronized(digest) {
      digest.update(buf1);
      digest.update(buf2);
      digest.update(buf3);
      digest.update(buf4);
      return digest.digest();
    }
  }

  public static final byte[] doDigest(byte digestAlg, byte buf1[], byte buf2[], byte buf3[], byte buf4[])
    throws HandleException
  {
    switch(digestAlg) {
      case Common.HASH_CODE_SHA1:
        return doSHA1Digest(buf1, buf2, buf3, buf4);
      case Common.HASH_CODE_MD5:
      case Common.HASH_CODE_MD5_OLD_FORMAT:
        return doMD5Digest(buf1, buf2, buf3, buf4);
      default:
        throw new HandleException(HandleException.INVALID_VALUE, "Invalid hash type: "+((int)digestAlg));
    }
  }

  public static final byte[] doDigest(byte digestType, byte buf[])
    throws HandleException
  {
    switch(digestType) {
      case Common.HASH_CODE_SHA1:
        return doSHA1Digest(buf);
      case Common.HASH_CODE_MD5:
      case Common.HASH_CODE_MD5_OLD_FORMAT:
        return doMD5Digest(buf);
      default:
        throw new HandleException(HandleException.INVALID_VALUE,"Invalid hash type: "+((int)digestType));
    }
  }

  
  public static void sortNumberArray (Number a[]) {
    quicksortAscending(a,0,a.length-1);
  }

  private static void quicksortAscending(Number a[], int first, int last ) {
    int piv_index;
    if ( first < last ) { 
      piv_index = partitionAscending(a, first, last );
      quicksortAscending(a, first, piv_index - 1 );
      quicksortAscending(a, piv_index, last );
    }
  }

  private static int partitionAscending(Number a[], int first, int last ) {
    Number pivot, temp;
    pivot = a[ (first + last) / 2 ];
    while ( first <= last ) {
      while ( a[first].doubleValue() < pivot.doubleValue() )
	++first;
      
      while ( a[last].doubleValue() > pivot.doubleValue() )
	--last;
      
      if ( first <= last ) {
	temp = a[first];
	a[first] = a[last];
	a[last] = temp;
	++first;  
	--last;
      }
    }
    return (first);
  }

  /** encrypt with Public key */
  public static byte[] encrypt(PublicKey encryptingKey, byte secretKey[])
  throws Exception
  {
    HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();
    if (cryptoProvider==null) {
      throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                "Encryption/Key generation engine missing");
    }
    
    return cryptoProvider.encrypt_RSA_ECB_PKCS1(secretKey, 0, 
                         secretKey.length, (RSAPublicKey)encryptingKey);
  }

  /** convert a file into a byte stream */
  public static byte[] getBytesFromFile(String file){
    return getBytesFromFile(new File(file));
  }
  
  public static byte[] getBytesFromFile(File file){
    byte[] rawKey = null;
    try{
      rawKey = new byte[(int)file.length()];
      InputStream in = new FileInputStream(file);
      int n =0; int r=0;
      while(n<rawKey.length && (r=in.read(rawKey, n, rawKey.length-n))>0)
        n +=r;
      in.close();
    }catch(Exception e){
      e.printStackTrace(System.err); 
    }
    return rawKey;
  }
  
  /** write byte array into a given file name */
  public static boolean writeBytesToFile(String file, byte keyBytes[]){
    return writeBytesToFile(new File(file), keyBytes);
  }

  public static boolean writeBytesToFile(File file, byte keyBytes[]){
    FileOutputStream out= null;
	try{
	   
	  out = new FileOutputStream(file);
	  out.write(keyBytes);
	  out.close();	
	  return true;
	}
	catch (Exception e)
	{
      e.printStackTrace(System.err);
	  return false;
	}
  }
 
  
  /** check that a given PublicKey and a given PrivateKey are a pair */
  public static boolean isMatchingKeyPair(PublicKey pubkey, PrivateKey privkey)
    throws HandleException
  {
    if (pubkey == null && privkey != null) return false;
    if (pubkey != null && privkey == null) return false;
    if (pubkey == null && privkey == null) return true;

    // compute the signature of the message bytes
    try {
      byte toBeSigned[] = new byte[2048];
      new java.util.Random().nextBytes(toBeSigned);
      Signature sig = Signature.getInstance(privkey.getAlgorithm());
      sig.initSign(privkey);
      sig.update(toBeSigned);
      byte signatureBytes[] = sig.sign();

      Signature vsig = Signature.getInstance(pubkey.getAlgorithm());
      sig.initVerify(pubkey);
      sig.update(toBeSigned);
      return sig.verify(signatureBytes);
    } catch (Exception e) {
      if (e instanceof HandleException) {
        throw (HandleException)e;
      } else {
        throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                                  "Error checking keys: "+e);
      }
    }
  }
  

  // both sever and client can call this method to decrypt the session key
  // with RSA private key.
  // the encryptedSessionKey byte array is encrypted with RSA public key.
  public static byte[] decrypt(PrivateKey privKey, byte[] ciphertext)
    throws HandleException
  {
    HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();
    if (cryptoProvider==null) {
      throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                "Encryption/Key generation engine missing. Session failed.");
    }
        
    if (privKey!= null && privKey instanceof RSAPrivateKey) {
      try {      
        return cryptoProvider.decrypt_RSA_ECB_PKCS1(ciphertext, 0, 
                                                    ciphertext.length,
                                                    (RSAPrivateKey)privKey);
      } catch (Exception e) {
        throw new HandleException(HandleException.INTERNAL_ERROR,
                                  "Error decrypting: "+e);
      }
    } else {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Unsupported key for decrypt: "+privKey);
    }
  }

 public static boolean checkJavaVersion() {
  String version = System.getProperty("java.version").substring(0, 3);

  if (HSG.HS_JAVA_VERSION.compareTo(version) > 0)
     {  // Required version later than installed version
      System.err.println(  "\nError: Java version " + HSG.HS_JAVA_VERSION + " or greater is required; "
                         + "this is version " + version + ".\n"
                         + "See " + HSG.HS_JAVA_DOWNLOAD_SITE + " to obtain an up-to-date version.\n"
                        );
      return false;
     }
  return true;
 }
}
