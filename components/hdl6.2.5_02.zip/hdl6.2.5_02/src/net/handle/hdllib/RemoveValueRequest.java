/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/******************************************************************************
 * Request used to remove a value from an existing handle.  Holds the handle
 * and the index of the value to be deleted.
 ******************************************************************************/

public class RemoveValueRequest
  extends AbstractRequest
{

  public int indexes[];

  public RemoveValueRequest(byte handle[], int index, 
                            AuthenticationInfo authInfo) {
    this(handle, new int[]{index}, authInfo);
  }

  public RemoveValueRequest(byte handle[], int indexes[],
                            AuthenticationInfo authInfo) {
    super(handle, AbstractMessage.OC_REMOVE_VALUE, authInfo);
    this.indexes = indexes;
    this.isAdminRequest = true;
  }

}
