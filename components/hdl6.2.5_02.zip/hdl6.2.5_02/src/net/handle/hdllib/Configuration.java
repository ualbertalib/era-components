/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.io.*;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;

public class Configuration {
  private static Configuration defaultConfig = null;
  public static final int RM_GLOBAL = 0;
  public static final int RM_WITH_CACHE = 1;
  
  /** Get the current default configuration. */
  public synchronized static final Configuration defaultConfiguration() {
    if(defaultConfig == null) {
      defaultConfig = new Configuration();
    }
  
    return defaultConfig;
  }

  private HandleValue globalValues[] = null;
  private HandleValue cacheValues[] = null;
  private SiteInfo globalSites[] = null;
  private NamespaceInfo globalNamespace = null;
  private SiteInfo cacheSites[] = null;
  private HashMap localSites = null;
  private HashMap localAddresses = null;
  private int resolutionMethod = RM_GLOBAL;
  private boolean autoRefreshRootInfo = true;

  private File configDir = null;
  private File userDir = null;
  private File globalValuesFile = null;
  private boolean updatingRootInfo = false;
  private Vector rootInfoNotifications = null;


  private Configuration() {
    // set the directory where all of the generic config files (including 
    // the global site values) will be stored.  By default, $HOME/.handle/
    try {
      configDir = new File(".");
      String userDirName = System.getProperty("user.home");
      if(userDirName==null) {
        // if the user has no "home" directory, use the current directory..
        userDir = new File(System.getProperty("user.dir",File.separator));
      } else {
        userDir = new File(userDirName);
      }
      
      // create a file object for our config dir based on the "home" directory
      configDir = new File(userDir, ".handle");
      configDir.mkdirs();

      // the file that holds the global service information
      globalValuesFile = new File(configDir, "root_info");

      // If the global site values aren't in the config dir, load the default
      // values (and copy them to the config dir so that they can be used
      // later).
      if(globalValuesFile.exists() && globalValuesFile.canRead()) {
        // load the values from the users' config file
        FileInputStream in = new FileInputStream(globalValuesFile);
        setGlobalValues(Encoder.decodeGlobalValues(in));
        try { in.close(); } catch (Exception e) {}
      } else {
        // load the default global values that comes with this code
        InputStream in = 
          getClass().getResourceAsStream("/net/handle/etc/root_info");
        setGlobalValues(Encoder.decodeGlobalValues(in));
        try { in.close(); } catch (Exception e) {}
      }

      SiteInfo newSites[] = Util.getSitesFromValues(globalValues);
      if(newSites!=null) {
        globalSites = newSites;
	for(int i=globalSites.length-1; i>=0; i--) {
	  globalSites[i].isRoot = true;
	}
      }

    } catch(Exception e) {
      e.printStackTrace(System.err);
      System.err.println("Had trouble finding your \"home\" directory and/or your "+
                         "configuration settings.  Will use \""+configDir+".\"  ");
    }


    try { // try to load the local cache/resolver service information

      // the file that holds the global service information
      File cacheValuesFile = new File(configDir, "resolver_service");

      if(cacheValuesFile.exists() && cacheValuesFile.canRead()) {
        // load the values from the users' config file
        FileInputStream in = new FileInputStream(cacheValuesFile);
        try {
          cacheValues = Encoder.decodeGlobalValues(in);
        } finally {
          try { in.close(); } catch (Exception e) {}
        }
      }

      if(cacheValues!=null) {
        cacheSites = Util.getSitesFromValues(cacheValues);
        if(cacheSites!=null && cacheSites.length>0)
          resolutionMethod = RM_WITH_CACHE;
      }
    } catch (Exception e) {
      e.printStackTrace(System.err);
      System.err.println("Unable to load local cache/resolver service information:  "+e);
    }


    try { // try to load the local cache/resolver site information
      if(cacheSites==null || cacheSites.length<=0) {
        // no local service was loaded, let's see if there is a siteinfo that
        // points to a local cache/resolver
        File cacheSiteFile = new File(configDir, "resolver_site");
        if(cacheSiteFile.exists() && cacheSiteFile.canRead()) {
          FileInputStream in = new FileInputStream(cacheSiteFile);
          try {
            byte siteBuf[] = new byte[(int)cacheSiteFile.length()];
            int r, n=0;
            while(n<siteBuf.length && (r=in.read(siteBuf, n, siteBuf.length-n))>=0)
              n += r;
            SiteInfo cacheSite = new SiteInfo();
            Encoder.decodeSiteInfoRecord(siteBuf, 0, cacheSite);
            cacheSites = new SiteInfo[] { cacheSite };
            if(cacheSites!=null) {
              resolutionMethod = RM_WITH_CACHE;
            }
          } finally {
            try { in.close(); } catch (Exception e) {}
          }
        }
      }
    } catch (Exception e) {
      e.printStackTrace(System.err);
      System.err.println("Unable to load local cache/resolver site information.  "+
                         "Will use global resolution");
    }

    // Try to load a list of naming authorities for which all
    // messages (including admin messages) should go through the
    // cache/resolver site.
    try { 
      if(cacheSites!=null && cacheSites.length>0) {
        File localNAFile = new File(configDir, "local_nas");
        if(localNAFile.exists() && localNAFile.canRead()) {
          BufferedReader rdr = 
          new BufferedReader(new InputStreamReader(new FileInputStream(localNAFile),
                                                   "UTF8"));
          try {
            String line;
            while(true) {
              line = rdr.readLine();
              if(line==null) break;
              line = line.trim();
              if(line.length()<=0) continue;
              if(localSites==null) localSites = new HashMap();
              localSites.put(line.toUpperCase().trim(), cacheSites);
            }
          } finally {
            try { rdr.close(); } catch (Exception e) {}
          }
        }
      }
      
    } catch (Exception e) {
      e.printStackTrace(System.err);
      System.err.println("Error loading local naming authority list.");
    } 
    
    // the file that holds the local service information
    File localSitesFile = new File(configDir, "local_info");
    if (localSitesFile.exists() && localSitesFile.canRead()) {
      try { 
        FileInputStream f = new FileInputStream(localSitesFile);
        localSites = Encoder.decodeLocalSites((InputStream)f);
        f.close();
      }
      catch (Exception e) {
        System.err.println("Error reading "+localSitesFile.getPath()); 
        if (localSites == null) localSites = new HashMap(0);
      }
    } else {
      // try to find local_info in the jar file
      try { 
        InputStream in = 
          getClass().getResourceAsStream("/net/handle/etc/local_info");
        if(in!=null) {
          localSites = Encoder.decodeLocalSites(in);
        }
      } catch (Exception e) {
        System.err.println("warning: unable to read local info: "+e);
      }
    }
    if(localSites==null)
      localSites = new HashMap(0);
    
    File localAddressesFile = new File(configDir, "local_addresses");
    if(localAddressesFile.exists() && localAddressesFile.canRead()) {
      FileInputStream fi = null;
      try {
        fi = new FileInputStream(localAddressesFile);
        setLocalAddressMap(Encoder.decodeLocalAddresses(fi));
      } catch (Exception e) {
        System.err.println("Error reading local address map: "+e);
        e.printStackTrace(System.err);
        setLocalAddressMap(null);
      } finally {
        try { fi.close(); } catch (Exception e) {}
      }
    }
    
  }

  public void setLocalSites(String na, SiteInfo sites[]){
    localSites.put(na.toUpperCase(), sites);
  }

  public void setLocalSites(byte na[], SiteInfo sites[]){
    localSites.put(Util.decodeString(na).toUpperCase(), sites);
  }

  /**
   * Sets a map that converts IP addresses to alternate addresses.
   * This is used to map IP addresses that are viewable outside of
   * firewalls to IP addresses that are accessibile from inside a
   * firewall.  This wouldn't be necessary if every NAT firewall/router
   * weren't completely stupid.
   * The localAddrMap parameter should map InetAddress objects or their
   * String representation.
   */
  public synchronized void setLocalAddressMap(Map localAddrMap) {
    if(localAddrMap==null) {
      localAddresses = null;
    } else {
      // go through the mapping and convert the keys to Strings,
      // and the values to InetAddress objects (if necessary)

      HashMap tmp = new HashMap();
      for(Iterator it=localAddrMap.keySet().iterator(); it.hasNext(); ) {
        Object key = it.next();
        if(key==null) continue;
        Object val = localAddrMap.get(key);
        if(val==null) continue;

        try {
          if(key instanceof InetAddress)
            key = ((InetAddress)key).getHostAddress();
          
          if(!(val instanceof InetAddress))
            val = InetAddress.getByName(String.valueOf(val)); 
          tmp.put(key, val);
        } catch (Exception e) {
          System.err.println("Invalid local address: "+key+" -> "+val);
        }
      }
      localAddresses = tmp;
    }
  }

  /**
   * Saves the local address map to the appropriate configuration file
   */
  public synchronized void saveLocalAddressMap()
    throws IOException
  {
    HashMap localAddr = localAddresses;
    File localAddressesFile = new File(configDir, "local_addresses");
    if(localAddr==null) {
      if(localAddressesFile.exists())
        localAddressesFile.delete();
    } else {
      FileOutputStream fo = null;
      try {
        fo = new FileOutputStream(localAddressesFile);
        Encoder.writeLocalAddresses(localAddr, fo);
      } catch (Exception e) {
        System.err.println("Error saving local address map: "+e);
      } finally {
        try { fo.close(); } catch (Exception e) {}
      }
    }      
  }

  
  /**
   * Gets the mapping of addresses to local addresses
   */
  public synchronized Map getLocalAddressMap() {
    return localAddresses;
  }

  
  /**
   * If the given address appears in the local address map return the
   * address to which it is mapped.  Otherwise, return the given parameter.
   */
  public InetAddress mapLocalAddress(InetAddress addr) {
    HashMap local = localAddresses;
    if(local==null) return addr;
    
    Object val = local.get(addr.getHostAddress());
    if(val!=null) {
      try {
        if(val instanceof InetAddress) {
          return (InetAddress)val;
        } else {
          return InetAddress.getByName(String.valueOf(val));
        }
      } catch (Exception e) {
        System.err.println("Invalid address map: "+addr+" -> "+val);
      }
    }
    return addr;
  }
  
  public SiteInfo[] getLocalSites(String na){
    return (SiteInfo[])localSites.get(na.toUpperCase());
  }

  public SiteInfo[] getLocalSites(byte na[]){
    return (SiteInfo[])localSites.get(Util.decodeString(na).toUpperCase());
  }

  public synchronized void setGlobalValues(HandleValue globalValues[]) {
    this.globalValues = globalValues;
    this.globalNamespace = Util.getNamespaceFromValues(globalValues);
  }

  public void setGlobalValuesFile(File newGlobalValuesFile) {
    this.globalValuesFile = newGlobalValuesFile;
  }

  /********************************************************************
   * save the default global values in the users' config directory
   *********************************************************************/
  public void saveGlobalValues() {
    System.err.println("Saving global values to: "+globalValuesFile);
    try {
      OutputStream out = new FileOutputStream(globalValuesFile);
      out.write(Encoder.encodeGlobalValues(globalValues));
      try { out.close(); } catch (Exception e) {}
    } catch (Exception e) {
    }
  }

  public void setConfigDir(File newConfigDir) {
    this.configDir = newConfigDir;
  }

  public File getConfigDir() {
    return configDir;
  }

  public HandleValue[] getGlobalValues() {
    return globalValues;
  }
  
  public NamespaceInfo getGlobalNamespace() {
    return globalNamespace;
  }

  public void setGlobalSites(SiteInfo globalSites[]) {
    this.globalSites = globalSites;
    for(int i=this.globalSites.length-1; i>=0; i--) {
      this.globalSites[i].isRoot = true;
    }
  }

  public SiteInfo[] getGlobalSites() {
    return globalSites;
  }

  public void setCacheSites(SiteInfo cacheSites[]) {
    this.cacheSites = cacheSites;
  }

  public SiteInfo[] getCacheSites() {
    return cacheSites;
  }

  public int getResolutionMethod() {
    return resolutionMethod;
  }

  public void setResolutionMethod(int resolutionMethod) {
    this.resolutionMethod = resolutionMethod;
  }

  public synchronized void addRootInfoListener(RootInfoListener listener) {
    if(rootInfoNotifications==null)
      rootInfoNotifications = new Vector();
    rootInfoNotifications.addElement(listener);
  }

  public synchronized void removeRootInfoListener(RootInfoListener listener) {
    if(rootInfoNotifications==null)
      return;
    rootInfoNotifications.removeElement(listener);
  }

  public synchronized void notifyRootInfoOutdated() {
    if(rootInfoNotifications!=null && rootInfoNotifications.size()>0) {
      for(Enumeration enumeration=rootInfoNotifications.elements(); enumeration.hasMoreElements();) {
	((RootInfoListener)enumeration.nextElement()).rootInfoOutOfDate(this);
      }
    } else {
      if(!updatingRootInfo) {
	updatingRootInfo = true;
	Thread t = new Thread(new Runnable() {
	    public void run() {
	      try {
		refreshRootInfoFromNet();
	      } catch (Exception e) {
		System.err.println("Error refreshing root info: "+e);
		e.printStackTrace(System.err);
	      } finally {
		updatingRootInfo = false;
	      }
	    }
	  });
	t.start();
      }
    }
  }


  public void refreshRootInfoFromNet()
    throws HandleException
  {
    HandleResolver resolver = new HandleResolver();
    resolver.setCheckSignatures(true); // should already be set, but just to be safe

    ResolutionRequest req = new ResolutionRequest(Common.ROOT_HANDLE, null, null, null);

    // the request *must* be certified, otherwise all security is compromised
    req.certify = true;

    AbstractResponse resp = resolver.processRequest(req);
    if(resp.responseCode!=AbstractMessage.RC_SUCCESS) {
      throw new HandleException(HandleException.INTERNAL_ERROR, "Unable to query root info");
    }
    
    ResolutionResponse rresp = (ResolutionResponse)resp;
    HandleValue newValues[] = rresp.getHandleValues();
    SiteInfo newSites[] = Util.getSitesFromValues(globalValues);
    if(newSites!=null && newSites.length>0) {
      setGlobalValues(newValues);
      setGlobalSites(newSites);
      saveGlobalValues();
    } else {
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Unable to extract root site information");
    }
  }

}


