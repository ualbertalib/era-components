/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;


public class ResolutionResponse extends AbstractResponse {

  public byte handle[];
  public byte values[][];
  
  public ResolutionResponse(byte handle[], byte values[][]) 
  {
    super(OC_RESOLUTION, AbstractMessage.RC_SUCCESS);
    this.handle = handle;
    this.values = values;
  }

  public ResolutionResponse(AbstractRequest req, byte handle[],
                            byte clumps[][])
    throws HandleException
  {
    super(req, AbstractMessage.RC_SUCCESS);
    this.handle = handle;
    this.values = clumps;
  }
  

  public HandleValue[] getHandleValues() 
    throws HandleException
  {
    HandleValue retValues[] = new HandleValue[values.length];
    for(int i=0; i<retValues.length; i++) {
      retValues[i] = new HandleValue();
      Encoder.decodeHandleValue(values[i],0,retValues[i]);
    }
    return retValues;
  }
  
  public String toString() {
    StringBuffer sb = new StringBuffer(super.toString());
    sb.append(' ');
    if(handle==null)
      sb.append(String.valueOf(handle));
    else
      sb.append(new String(handle));
    sb.append("\n");
    
    if(values!=null) {
      try {
	HandleValue vals[] = getHandleValues();
	for(int i=0; i<vals.length; i++) {
	  sb.append("   ");
          sb.append(String.valueOf(vals[i]));
	  sb.append('\n');
	}
      } catch (HandleException e) {}
    }
    return sb.toString();
  }

}
