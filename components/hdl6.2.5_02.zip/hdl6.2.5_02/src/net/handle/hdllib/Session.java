/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.net.Socket;
import javax.crypto.SecretKey;

public class Session {

  public Socket socket;
  public SecretKey secretKey=null;
  public ServerInfo server;
}
