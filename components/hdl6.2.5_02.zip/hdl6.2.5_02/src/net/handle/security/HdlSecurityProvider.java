/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security;

import java.security.*;
import java.security.interfaces.*;
//import java.security.cert.*;
//import java.security.spec.*;
import java.math.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.crypto.interfaces.*;

public abstract class HdlSecurityProvider 
{
  public static final int ENCRYPT_ALG_DES = 1;
  public static final int ENCRYPT_ALG_DESEDE = 2;
  public static final int ENCRYPT_ALG_AES = 3;
  
  private static HdlSecurityProvider instance = null;
  
  static final String DEFAULT_PROVIDER = "net.handle.security.provider.GenericProvider";
  
  public static final HdlSecurityProvider getInstance() {
    if(instance !=null) {
      return instance;
    }
    String clssName = System.getProperty("handle.security.provider_class", null);
    if(clssName!=null) {
      try {
        Class klass = Class.forName(clssName);
        Object obj = klass.newInstance();
        if(obj instanceof HdlSecurityProvider) {
          instance = (HdlSecurityProvider)obj;
          return instance;
        }
        System.err.println("Security provider ("+clssName+") not found");
      } catch (Exception e) {
        System.err.println("Security provider ("+clssName+") not found; reason: "+e);
      }
      return null;
    }
    return (instance = new net.handle.security.provider.GenericProvider());
  }

  
  /** Construct and return a Cipher object, initialized to either decrypt or
    * encrypt using the given algorithm and secret key.  The direction parameter
    * must be either Cipher.ENCRYPT_MODE or Cipher.DECRYPT_MODE.  The algorithm 
    * parameter should be one of the HdlSecurityProvider.ENCRYPT_ALG_* constants.
    */
  public abstract Cipher getCipher(int algorithm, byte secretKey[], int direction) 
    throws Exception;

  /** Generate and encode a secret key for use with the given algorithm */
  public abstract byte[] generateSecretKey(int keyAlg) 
    throws Exception;
    
  
  /** encrypt a chunk of data using the DES/ECB/PKCS5 algorith/padding/encoding
    * @deprecated use getCipher() instead and re-use the returned Cipher object 
    */
  public abstract byte[] encrypt_DES_ECB_PKCS5(byte cleartext[], int offset, int len,
                                               byte secretKey[]) 
    throws Exception;
  
  /** decrypt a chunk of data using the DES/ECB/PKCS5 algorith/padding/encoding
    * @deprecated use getCipher() instead and re-use the returned Cipher object 
    */
  public abstract byte[] decrypt_DES_ECB_PKCS5(byte ciphertext[], int offset, int len,
                                               byte secretKey[])
    throws Exception;
  
  
  public KeyPair generateRSAKeyPair(int keySize)
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }
    
  public byte[] encrypt_RSA_ECB_PKCS1(byte cleartext[], int offset, 
                                               int len, RSAPublicKey publicKey)
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }
  
  public byte[] decrypt_RSA_ECB_PKCS1(byte ciphertext[], int offset, 
                                              int len, RSAPrivateKey privateKey)
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }

  public byte[] sign_RSA_MD5_PKCS1(byte ciphertext[], int offset, 
                                             int len, RSAPrivateKey privateKey)
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }

  public boolean verify_RSA_MD5_PKCS1(byte plaintext[], 
                                               int offset, int len,
                                               byte signature[], 
                                               RSAPublicKey publicKey) 
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }
  
  public byte[] sign_RSA_SHA1_PKCS1(byte ciphertext[], int offset, 
                                             int len, RSAPrivateKey privateKey)
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }

  public boolean verify_RSA_SHA1_PKCS1(byte plaintext[], 
                                                int offset, int len,
                                                byte signature[],
                                                RSAPublicKey publicKey)
    throws Exception
  {
    throw new NoSuchAlgorithmException("RSA not supported.");
  }

  /*  --- not needed, DSA is provided by the default java security provider --- 
  public PublicKey getDSAPublicKey(BigInteger y, BigInteger p, BigInteger q, BigInteger g);

  public PrivateKey getDSAPrivateKey(BigInteger x, BigInteger p, BigInteger q, BigInteger g);
  */

  public KeyPair generateDHKeyPair(int keySize) throws Exception {
    throw new NoSuchAlgorithmException("Diffie-Hellman key exchange not supported.");
  }

  public KeyPair generateDHKeyPair(BigInteger p, BigInteger g) throws Exception{
    throw new NoSuchAlgorithmException("Diffie-Hellman key exchange not supported.");
  }
  
  public byte[] getDESKeyFromDH(DHPublicKey pub, DHPrivateKey priv)
    throws Exception
  {
    throw new NoSuchAlgorithmException("Diffie-Hellman key exchange not supported");
  }

  /** Using the given diffie-hellman key pair, generate a secret key with the given
    * algorithm.  The first four bytes of the secret key will identify the algorithm
    * for the secret key (DES, AES, DESede) */
  public byte[] getKeyFromDH(DHPublicKey pub, DHPrivateKey priv, int algorithm) 
    throws Exception
  {
    throw new NoSuchAlgorithmException("Diffie-Hellman key exchange not supported");
  }
  
}
