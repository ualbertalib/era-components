/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security.provider;

import net.handle.security.*;
import net.handle.hdllib.Encoder;

import java.io.*;
import java.math.*;
import java.security.*;
import java.security.interfaces.*;
import java.security.spec.KeySpec;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.crypto.interfaces.*;

/**
 * An implementation of the net.handle.HDLSecurityProvider interface
 * that uses the Sun JCE implementation. 
 */
public final class SunJceHdlSecurityProvider
  extends HdlSecurityProvider
{
  private static MessageDigest md5digest = null;
  private static MessageDigest sha1digest = null;
  
  Cipher rsaCipher; 

  public SunJceHdlSecurityProvider() throws Exception {
    // int i = Security.addProvider(new com.sun.crypto.provider.SunJCE());
    int i = Security.insertProviderAt(new com.sun.crypto.provider.SunJCE(), 1);
  }
    
  /** Construct and return a Cipher object, initialized to either decrypt or
    * encrypt using the given algorithm and secret key.  The direction parameter
    * must be either Cipher.ENCRYPT_MODE or Cipher.DECRYPT_MODE.  The algorithm 
    * parameter should be one of the HdlSecurityProvider.ENCRYPT_ALG_* constants.
    */
  public Cipher getCipher(int algorithm, byte secretKey[], int direction) 
    throws Exception
  {
    Cipher cipher = null;
    SecretKey key = null;
    
    String keyAlg;
    String cipherAlg;
    
    KeySpec spec;
    switch(algorithm) {
      case HdlSecurityProvider.ENCRYPT_ALG_DES:
        keyAlg = "DES";
        cipherAlg = "DES/ECB/PKCS5Padding";
        spec = new DESKeySpec(secretKey);
        break;
      case HdlSecurityProvider.ENCRYPT_ALG_AES:
        keyAlg = "AES";
        cipherAlg = "AES";
        spec = new SecretKeySpec(secretKey, "AES");
        break;
      case HdlSecurityProvider.ENCRYPT_ALG_DESEDE:
        keyAlg = "DESede";
        cipherAlg = "DESede/ECB/PKCS5Padding";
        spec = new DESedeKeySpec(secretKey);
        break;
      default:
        throw new Exception("Invalid encryption algorithm code: "+algorithm);
    }

    SecretKeyFactory factory = SecretKeyFactory.getInstance(keyAlg);
    key = factory.generateSecret(spec);
    cipher = Cipher.getInstance(cipherAlg);
    cipher.init(direction, key);
    return cipher;
  }


  private KeyGenerator aesKeygen = null;
  private KeyGenerator desKeygen = null;
  private KeyGenerator desedeKeygen = null;
  
  /** Generate and encode a secret key for use with the given algorithm */
  public byte[] generateSecretKey(int keyAlg) 
    throws Exception
  {
    KeyGenerator kgen = null;
    synchronized(this) {
      switch(keyAlg) {
        case ENCRYPT_ALG_DES:
          if(desKeygen==null)
            desKeygen = KeyGenerator.getInstance("DES");
          kgen = desKeygen;
          break;
        case ENCRYPT_ALG_DESEDE:
          if(desedeKeygen==null)
            desedeKeygen = KeyGenerator.getInstance("DESEDE");
          kgen = desedeKeygen;
          break;
        case ENCRYPT_ALG_AES:
          if(aesKeygen==null)
            aesKeygen = KeyGenerator.getInstance("AES");
          kgen = aesKeygen;
          break;
        default:
          throw new Exception("Invalid encryption algorithm code: "+keyAlg);
      }
    }
    byte tmp[] = kgen.generateKey().getEncoded();
    
    // put the encoded key into an array that uses the first four bytes to list
    // the key algorithm
    byte encKey[] = new byte[tmp.length + Encoder.INT_SIZE];
    Encoder.writeInt(encKey, 0, keyAlg);
    System.arraycopy(tmp, 0, encKey, Encoder.INT_SIZE, tmp.length);
    return encKey;
  }
  
  
  /** @deprecated use the getEncryptCipher and getDecryptCipher methods now that 
    * the java crypto API, and therefore the Cipher class, is standard and 
    * included in java 1.4 and higher.  Using a returned Cipher object will be
    * vastly more efficient than calling this method, which constructs a new
    * Cipher every time. */
  public byte[] encrypt_DES_ECB_PKCS5(byte cleartext[], int offset, int len, 
                                      byte secretKey[])
    throws Exception
  {
    Cipher cipher =
      getCipher(HdlSecurityProvider.ENCRYPT_ALG_DES, secretKey, Cipher.ENCRYPT_MODE);
    return cipher.doFinal(cleartext, offset, len);
  }


  /** @deprecated use the getEncryptCipher and getDecryptCipher methods now that 
    * the java crypto API, and therefore the Cipher class, is standard and 
    * included in java 1.4 and higher.  Using a returned Cipher object will be
    * vastly more efficient than calling this method, which constructs a new
    * Cipher every time. */
  public byte[] decrypt_DES_ECB_PKCS5(byte ciphertext[], int offset, int len,
                                      byte secretKey[])
    throws Exception
  {
    Cipher cipher =
      getCipher(HdlSecurityProvider.ENCRYPT_ALG_DES, secretKey, Cipher.DECRYPT_MODE);
    return cipher.doFinal(ciphertext, offset, len);
  }

  private static byte[] md5hash(byte bytesToHash[], int offset, int len) 
    throws Exception
  {
    if(md5digest==null) {
      md5digest = MessageDigest.getInstance("MD5");
    }
    synchronized(md5digest) {
      md5digest.reset();
      md5digest.update(bytesToHash, offset, len);
      byte toReturn[] = md5digest.digest();
      md5digest.reset();
      return toReturn;
    }
  }

  public byte[] getDESKeyFromDH(DHPublicKey pub, DHPrivateKey priv) 
    throws Exception {
    KeyFactory kf = KeyFactory.getInstance("DH");

    DHParameterSpec dhSpec = priv.getParams();
    DHPrivateKeySpec privSpec = 
          new DHPrivateKeySpec(priv.getX(), dhSpec.getP(), dhSpec.getG());

    dhSpec = pub.getParams();
    DHPublicKeySpec pubSpec = 
          new DHPublicKeySpec(pub.getY(), dhSpec.getP(), dhSpec.getG());
    
    KeyAgreement ka = KeyAgreement.getInstance("DH");
    ka.init(kf.generatePrivate(privSpec));
    ka.doPhase(kf.generatePublic(pubSpec), true);
    SecretKey secretKey = ka.generateSecret("DES");
    return secretKey.getEncoded(); 
  }
  
  /** Using the given diffie-hellman key pair, generate the secret key with the
    * algorithm ID (ENCRYPT_ALG_DES, ENCRYPT_ALG_AES or ENCRYPT_ALG_DESEDE) in the
    * first four bytes of the array */
  public byte[] getKeyFromDH(DHPublicKey pub, DHPrivateKey priv, int algorithm) 
    throws Exception
  {
    KeyFactory kf = KeyFactory.getInstance("DH");
    
    DHParameterSpec dhSpec = priv.getParams();
    DHPrivateKeySpec privSpec = 
      new DHPrivateKeySpec(priv.getX(), dhSpec.getP(), dhSpec.getG());
    
    dhSpec = pub.getParams();
    DHPublicKeySpec pubSpec = 
      new DHPublicKeySpec(pub.getY(), dhSpec.getP(), dhSpec.getG());
    
    KeyAgreement ka = KeyAgreement.getInstance("DH");
    ka.init(kf.generatePrivate(privSpec));
    ka.doPhase(kf.generatePublic(pubSpec), true);
    
    String algStr;
    switch(algorithm) {
      case HdlSecurityProvider.ENCRYPT_ALG_DES:
        algStr = "DES";
        break;
      case HdlSecurityProvider.ENCRYPT_ALG_AES:
        algStr = "AES";
        break;
      case HdlSecurityProvider.ENCRYPT_ALG_DESEDE:
        algStr = "DESede";
        break;
      default:
        throw new Exception("Unknown algorithm code: "+algorithm);
    }
    byte rawKey[] = ka.generateSecret(algStr).getEncoded();
    byte key[] = new byte[rawKey.length + Encoder.INT_SIZE];
    Encoder.writeInt(key, 0, algorithm);
    System.arraycopy(rawKey, 0, key, Encoder.INT_SIZE, rawKey.length);
    return key;
  }
  
  
  
  
  public KeyPair generateDHKeyPair(int keySize) throws Exception {
    KeyPairGenerator kpg = KeyPairGenerator.getInstance("DH");
    kpg.initialize(keySize);
    KeyPair kp = kpg.generateKeyPair();
    return kp;
  }

  public KeyPair generateDHKeyPair(BigInteger p, BigInteger g) 
  throws Exception
  {
    KeyPairGenerator kpg = KeyPairGenerator.getInstance("DH");
    kpg.initialize(new DHParameterSpec(p, g));
    KeyPair kp = kpg.generateKeyPair();
    return kp;
  }
  
  
  public static void main(String argv[]) 
    throws Exception
  {
    byte toEncrypt[] = "Hello, there".getBytes();
    SunJceHdlSecurityProvider provider = new SunJceHdlSecurityProvider();
    byte secKey[] = provider.generateSecretKey(HdlSecurityProvider.ENCRYPT_ALG_DES);
    System.err.println("Secret key: "+net.handle.hdllib.Util.decodeHexString(secKey, false));
    byte encrypted[] = provider.encrypt_DES_ECB_PKCS5(toEncrypt, 0, toEncrypt.length,
                                                      secKey);
    System.err.println("Encrypted: "+net.handle.hdllib.Util.decodeHexString(encrypted,false));
    System.err.println("Un-encrypted: "+new String(provider.decrypt_DES_ECB_PKCS5(encrypted,0, encrypted.length, secKey)));

  }
  
}

