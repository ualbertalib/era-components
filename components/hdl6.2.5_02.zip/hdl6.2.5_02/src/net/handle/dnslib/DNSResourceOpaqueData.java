/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;

/** class that holds the data from a resource record.
  * This class is meant to be subclassed by objects that understand
  * the format of the record data.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
 */

public class DNSResourceOpaqueData extends DNSResourceData {

  protected byte resourceData[]=null;

  public DNSResourceOpaqueData() {
    this(new byte[0], 0, 0);
  }

  public DNSResourceOpaqueData(byte data[], int offset, int length) {
    decodeData(data,offset,length);
  }

  /** Read the data from the specified buffer, starting at <code>offset</code>
    * and continuing for <code>length</code> bytes. */
  public void decodeData(byte data[], int offset, int length) {
    resourceData = new byte[length];
    System.arraycopy(data,offset,resourceData,0,length);
  }
  
  /** Write the data to the specified buffer, starting at
    * <code>offset</code>.  This should be overridden by
    * subclasses. Returns the number of bytes written.  */
  public int encodeData(byte data[], int offset, Hashtable nameTable) {
    System.arraycopy(resourceData,0,data,offset,resourceData.length);
    return resourceData.length;
  }

  /** return a string representation of the resource data. */
  public String toString() {
    StringBuffer sb = new StringBuffer();
    for(int i=0; i<resourceData.length; i++) {
      if(i%16==0 && i!=0) sb.append("\n");
      if(resourceData[i]>='a' && resourceData[i]<='z' ||
	 resourceData[i]>='A' && resourceData[i]<='Z' ||
	 resourceData[i]>='0' && resourceData[i]<='9' ||
	 resourceData[i]=='.') {
	sb.append(' ');
	sb.append((char)(resourceData[i]));
      } else {
	sb.append(" \\");
	sb.append((resourceData[i]&0x0ff));
      }
    }
    return sb.toString();
  }

  public static void printBytes(java.io.PrintStream out, byte buf[], int offset, int length) {
    for(int i=offset; i<(offset+length); i++) {
      if((i-offset)%16==0 && i!=offset) out.print("\n");
      if(buf[i]>='a' && buf[i]<='z' ||
	 buf[i]>='A' && buf[i]<='Z' ||
	 buf[i]>='0' && buf[i]<='9' ||
	 buf[i]=='.')
	out.print(" "+((char)(buf[i])));
      else
	out.print(" \\"+(buf[i]&0x0ff));
    }
    out.print("\n");
  }
  
}
