/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;
import java.net.*;

/**
  * class that holds the data from a "SOA" type resource record.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
  * @see DNSResourceData
 */

public class DNSResourceSOAData extends DNSResourceData {

  protected String pnsName[];
  protected String rName[];
  protected long serial;
  protected long refresh;
  protected long retry;
  protected long expire;
  protected long minimum;

  public DNSResourceSOAData() {
    pnsName = new String[0];
    rName = new String[0];
    serial=0;
    refresh=86400;  // one day
    retry=3600;     // one hour
    expire=86400*2; // two days
    minimum=3600;   // one hour
  }
  
  public DNSResourceSOAData(byte data[], int offset, int length) {
    decodeData(data,offset,length);
  }

  public void decodeData(byte data[], int offset, int length) {
    Vector names = new Vector();
    offset+=DNSResourceRecord.readNameFromPointer(data,offset,names);
    pnsName = new String[names.size()];
    for(int i=0; i<pnsName.length; i++)
      pnsName[i] = (String)names.elementAt(i);
    names.removeAllElements();
    offset+=DNSResourceRecord.readNameFromPointer(data,offset,names);
    rName = new String[names.size()];
    for(int i=0;i<rName.length; i++)
      rName[i] = (String)names.elementAt(i);
    serial = 0;
    serial |= (data[offset++]&0x00ff)<<24;
    serial |= (data[offset++]&0x00ff)<<16;
    serial |= (data[offset++]&0x00ff)<<8;
    serial |= (data[offset++]&0x00ff);

    refresh  = (data[offset++]&0x00ff)<<24;
    refresh |= (data[offset++]&0x00ff)<<16;
    refresh |= (data[offset++]&0x00ff)<<8;
    refresh |= (data[offset++]&0x00ff);
    retry  = (data[offset++]&0x00ff)<<24;
    retry |= (data[offset++]&0x00ff)<<16;
    retry |= (data[offset++]&0x00ff)<<8;
    retry |= (data[offset++]&0x00ff);
    expire = (data[offset++]&0x00ff)<<24;
    expire |= (data[offset++]&0x00ff)<<16;
    expire |= (data[offset++]&0x00ff)<<8;
    expire |= (data[offset++]&0x00ff);
    minimum  = (data[offset++]&0x00ff)<<24;
    minimum |= (data[offset++]&0x00ff)<<16;
    minimum |= (data[offset++]&0x00ff)<<8;
    minimum |= (data[offset++]&0x00ff);
  }

  public int encodeData(byte data[], int location, Hashtable nameTable) {
    int origLoc = location;
    location+=DNSResourceRecord.writeNameToPointer(pnsName,data,location, nameTable);
    location+=DNSResourceRecord.writeNameToPointer(rName,data,location, nameTable);
    data[location++] = (byte)((serial&0xff000000)>>24);
    data[location++] = (byte)((serial&0x00ff0000)>>16);
    data[location++] = (byte)((serial&0x0000ff00)>>8);
    data[location++] = (byte) (serial&0x000000ff);

    data[location++] = (byte)((refresh&0xff000000)>>24);
    data[location++] = (byte)((refresh&0x00ff0000)>>16);
    data[location++] = (byte)((refresh&0x0000ff00)>>8);
    data[location++] = (byte) (refresh&0x000000ff);

    data[location++] = (byte)((retry&0xff000000)>>24);
    data[location++] = (byte)((retry&0x00ff0000)>>16);
    data[location++] = (byte)((retry&0x0000ff00)>>8);
    data[location++] = (byte) (retry&0x000000ff);

    data[location++] = (byte)((expire&0xff000000)>>24);
    data[location++] = (byte)((expire&0x00ff0000)>>16);
    data[location++] = (byte)((expire&0x0000ff00)>>8);
    data[location++] = (byte) (expire&0x000000ff);

    data[location++] = (byte)((minimum&0xff000000)>>24);
    data[location++] = (byte)((minimum&0x00ff0000)>>16);
    data[location++] = (byte)((minimum&0x0000ff00)>>8);
    data[location++] = (byte) (minimum&0x000000ff);
    return location-origLoc;
  }

  /** return a string representation of the name server data. */
  public String toString() {
    return ""+
      "primary NS: "+DNSResolver.convertDNSNameToString(pnsName)+
      "\n   contact: "+DNSResolver.convertDNSNameToString(rName)+
      "\n    serial: "+serial+
      "\n   refresh: "+refresh+
      "\n     retry: "+retry+
      "\n    expire: "+expire+
      "\n   minimum: "+minimum;
  }

}
