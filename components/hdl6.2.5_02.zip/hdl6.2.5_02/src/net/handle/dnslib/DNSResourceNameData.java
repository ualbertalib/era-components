/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;
import java.net.*;

/** class that holds the data from a "CNAME" type resource record.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
  * @see DNSResourceData
 */

public class DNSResourceNameData extends DNSResourceData {

  protected String cName[]=null;
  

  public DNSResourceNameData() {
    cName = new String[0];
  }
  
  public DNSResourceNameData(byte data[], int offset, int length) {
    decodeData(data,offset,length);
  }

  public void decodeData(byte data[], int offset, int length) {
    Vector names = new Vector();
    DNSResourceRecord.readNameFromPointer(data,offset,names);
    cName = new String[names.size()];
    for(int i=0; i<cName.length; i++) {
      cName[i] = (String)names.elementAt(i);
    }
  }

  /** Write the data to the specified buffer, starting at
    * <code>offset</code> */
  public int encodeData(byte data[], int offset, Hashtable nameTable) {
    return DNSResourceRecord.writeNameToPointer(cName, data, offset, nameTable);
  }

  public String[] getName() { return cName; }

  /** return a string representation of the name server data. */
  public String toString() {
    return DNSResolver.convertDNSNameToString(cName);
  }

}
