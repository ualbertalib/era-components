/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.Hashtable;

/** Object definition that represents a DNS request/response packet.<br>
  * The description of the message format is defined in rfc1035, and
  * looks like this (from rfc1035, section 4.1):
  *    <pre>
  *
  *    4.1. Format
  *    
  *    All communications inside of the domain protocol are carried in a single
  *    format called a message.  The top level format of message is divided
  *    into 5 sections (some of which are empty in certain cases) shown below:
  *    
  *    +---------------------+
  *    |        Header       |
  *    +---------------------+
  *    |       Question      | the question for the name server
  *    +---------------------+
  *    |        Answer       | RRs answering the question
  *    +---------------------+
  *    |      Authority      | RRs pointing toward an authority
  *    +---------------------+
  *    |      Additional     | RRs holding additional information
  *    +---------------------+
  *    
  *    The header section is always present.  The header includes fields that
  *    specify which of the remaining sections are present, and also specify
  *    whether the message is a query or a response, a standard query or some
  *    other opcode, etc.
  *    
  *    The names of the sections after the header are derived from their use in
  *    standard queries.  The question section contains fields that describe a
  *    question to a name server.  These fields are a query type (QTYPE), a
  *    query class (QCLASS), and a query domain name (QNAME).  The last three
  *    sections have the same format: a possibly empty list of concatenated
  *    resource records (RRs).  The answer section contains RRs that answer the
  *    question; the authority section contains RRs that point toward an
  *    authoritative name server; the additional records section contains RRs
  *    which relate to the query, but are not strictly answers for the
  *    question.
  *    
  *
  *      0  1  2  3  4  5  6  7  8  9  0  1  2  3  4  5
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *    |                      ID                       |
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *    |QR|   Opcode  |AA|TC|RD|RA|   Z    |   RCODE   |
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *    |                    QDCOUNT                    |
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *    |                    ANCOUNT                    |
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *    |                    NSCOUNT                    |
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *    |                    ARCOUNT                    |
  *    +--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
  *
  *where:
  *
  *ID              A 16 bit identifier assigned by the program that
  *                generates any kind of query.  This identifier is copied
  *                the corresponding reply and can be used by the requester
  *                to match up replies to outstanding queries.
  *
  *QR              A one bit field that specifies whether this message is a
  *                query (0), or a response (1).
  *
  *OPCODE          A four bit field that specifies kind of query in this
  *                message.  This value is set by the originator of a query
  *                and copied into the response.  The values are:
  *
  *                0               a standard query (QUERY)
  *
  *                1               an inverse query (IQUERY)
  *
  *                2               a server status request (STATUS)
  *
  *                3-15            reserved for future use
  *
  *AA              Authoritative Answer - this bit is valid in responses,
  *                and specifies that the responding name server is an
  *                authority for the domain name in question section.
  *
  *                Note that the contents of the answer section may have
  *                multiple owner names because of aliases.  The AA bit
  *                corresponds to the name which matches the query name, or
  *                the first owner name in the answer section.
  *
  *TC              TrunCation - specifies that this message was truncated
  *                due to length greater than that permitted on the
  *                transmission channel.
  *
  *RD              Recursion Desired - this bit may be set in a query and
  *                is copied into the response.  If RD is set, it directs
  *                the name server to pursue the query recursively.
  *                Recursive query support is optional.
  *
  *RA              Recursion Available - this be is set or cleared in a
  *                response, and denotes whether recursive query support is
  *                available in the name server.
  *
  *Z               Reserved for future use.  Must be zero in all queries
  *                and responses.
  *
  *RCODE           Response code - this 4 bit field is set as part of
  *                responses.  The values have the following
  *                interpretation:
  *
  *                0               No error condition
  *
  *                1               Format error - The name server was
  *                                unable to interpret the query.
  *
  *                2               Server failure - The name server was
  *                                unable to process this query due to a
  *                                problem with the name server.
  *
  *                3               Name Error - Meaningful only for
  *                                responses from an authoritative name
  *                                server, this code signifies that the
  *                                domain name referenced in the query does
  *                                not exist.
  *
  *                4               Not Implemented - The name server does
  *                                not support the requested kind of query.
  *
  *                5               Refused - The name server refuses to
  *                                perform the specified operation for
  *                                policy reasons.  For example, a name
  *                                server may not wish to provide the
  *                                information to the particular requester,
  *                                or a name server may not wish to perform
  *                                a particular operation (e.g., zone
  *                                transfer) for particular data.
  *
  *                6-15            Reserved for future use.
  *
  *
  *		
  *TYPEs:
  *     TYPE            value and meaning
  *     A               1 a host address
  *     NS              2 an authoritative name server
  *     MD              3 a mail destination (Obsolete - use MX)
  *     MF              4 a mail forwarder (Obsolete - use MX)
  *     CNAME           5 the canonical name for an alias
  *     SOA             6 marks the start of a zone of authority
  *     MB              7 a mailbox domain name (EXPERIMENTAL)
  *     MG              8 a mail group member (EXPERIMENTAL)
  *     MR              9 a mail rename domain name (EXPERIMENTAL)
  *     NULL            10 a null RR (EXPERIMENTAL)
  *     WKS             11 a well known service description
  *     PTR             12 a domain name pointer
  *     HINFO           13 host information
  *     MINFO           14 mailbox or mail list information
  *     MX              15 mail exchange
  *     TXT             16 text strings
  *     
  *CLASSes:
  *    IN              1 the Internet
  *    CS              2 the CSNET class (Obsolete - used only for examples in
  *                      some obsolete RFCs)
  *    CH              3 the CHAOS class
  *    HS              4 Hesiod [Dyer 87]
  *
  * </pre>
 */


public class DNSMessage {

  public static final byte OP_QUERY = 0, OP_IQUERY = 1, OP_STATUS = 2;
  public static final byte RC_OK = 0, RC_FORMAT_ERROR = 2, RC_NAME_ERROR = 3,
    RC_NOT_IMPLEMENTED = 4, RC_REFUSED = 5;
  public static final int TYPE_A=1, TYPE_NS=2, TYPE_MD=3, TYPE_MF=4, TYPE_CNAME=5,
    TYPE_SOA=6, TYPE_MB=7, TYPE_MG=8, TYPE_MR=9, TYPE_NULL=10, TYPE_WKS=11, TYPE_PTR=12,
    TYPE_HINFO=13, TYPE_MINFO=14, TYPE_MX=15, TYPE_TXT=16;
  public static final int CLASS_IN=1, CLASS_CS=2, CLASS_CH=3, CLASS_HS=4;
  
  public char id;
  public boolean isQuery;
  public byte opcode;
  public boolean authAnswer;
  public boolean truncated;
  public boolean recursionDesired;
  public boolean recursionAvailable;
  public byte responseCode;
  public DNSQuestion questions[];
  public DNSResourceRecord answers[];
  public DNSResourceRecord nameServers[];
  public DNSResourceRecord additionalResources[];

  private byte packetBuffer[] = null;

  public DNSMessage() {}

  /** Construct a DNSMessage object from the given packet buffer. */
  public DNSMessage(byte buf[], int offset, int length) {
    packetBuffer = new byte[length];
    System.arraycopy(buf,offset,packetBuffer,0,length);

    this.id = (char)((buf[offset++] & 0xff) << 8);
    this.id = (char)(this.id | (buf[offset++]&0xff));
    this.isQuery = (buf[offset]&0x80)!=0;
    this.opcode = (byte)((buf[offset] >>> 3) & 0xf);
    this.authAnswer = (buf[offset] & 0x4)!=0;
    this.truncated = (buf[offset] & 0x2)!=0;
    this.recursionDesired = (buf[offset++] & 0x1)!=0;
    this.recursionAvailable = (buf[offset] & 0x80)!=0;
    this.responseCode = (byte)(buf[offset++] & 0xf);
    int numQ = (buf[offset++] & 0xff) << 8;
    numQ = numQ | (buf[offset++]&0xff);
    if(numQ<0 || numQ>256) {
      System.err.println("Error:  invalid number of questions: "+numQ);
      return;  //// Could throw an exception here...
    }
    int numA = (buf[offset++] & 0xff) << 8;
    numA = numA | (buf[offset++]&0xff);
    if(numA<0 || numA>256) {
      System.err.println("Error:  invalid number of answers: "+numA);
      return;  //// Could throw an exception here...
    }
    int numNS = (buf[offset++] & 0xff) << 8;
    numNS = numNS | (buf[offset++]&0xff);
    if(numNS<0 || numNS>256) {
      System.err.println("Error:  invalid number of NS's: "+numNS);
      return;  //// Could throw an exception here...
    }
    int numAR = (buf[offset++] & 0xff) << 8;
    numAR = numAR | (buf[offset++]&0xff);
    if(numAR<0 || numAR>256) {
      System.err.println("Error:  invalid number of additional resources: "+numAR);
      return;  //// Could throw an exception here...
    }
    this.questions = new DNSQuestion[numQ];
    this.answers = new DNSResourceRecord[numA];
    this.nameServers = new DNSResourceRecord[numNS];
    this.additionalResources = new DNSResourceRecord[numAR];
    for(int i=0; i<numQ; i++) {
      this.questions[i] = new DNSQuestion();
      offset += this.questions[i].decode(buf,offset);
    }
    for(int i=0; i<numA; i++) {
      this.answers[i] = new DNSResourceRecord();
      offset += this.answers[i].decode(buf,offset);
    }
    for(int i=0; i<numNS; i++) {
      this.nameServers[i] = new DNSResourceRecord();
      offset += this.nameServers[i].decode(buf,offset);
    }
    for(int i=0; i<numAR; i++) {
      this.additionalResources[i] = new DNSResourceRecord();
      offset += this.additionalResources[i].decode(buf,offset);
    }
  }

  /** Tells the message that some of the values have changed, so
    * that the next time the packet buffer is requested, it is
    * regenerated. */
  public void setDirty() {
    packetBuffer=null;
  }

  /** Gets the original packet buffer that this message was created with.
    * If this message wasn't created using a packet buffer, one is constructed,
    * and returned.
    */
  public synchronized byte[] getPacketBuffer() {
    if(packetBuffer!=null)
      return packetBuffer;
    return buildPacketBuffer();
  }

  /** construct a packet buffer and return it. */
  public synchronized byte[] buildPacketBuffer() {
    if(questions==null)
      questions = new DNSQuestion[0];
    if(answers==null)
      answers = new DNSResourceRecord[0];
    if(nameServers==null)
      nameServers= new DNSResourceRecord[0];
    if(additionalResources==null)
      additionalResources = new DNSResourceRecord[0];
    int msgSize = 1024; // the maximum size of the header - it's actually about 512
    packetBuffer = new byte[msgSize];
    Hashtable nameTable = new Hashtable();
    try {
      int loc = 0;
      packetBuffer[loc++] = (byte)((id&0xff00)>>8);
      packetBuffer[loc++] = (byte)(id&0x00ff);
      packetBuffer[loc++] = (byte)((isQuery?0x80:0) | (opcode&0xf)<<3 |
				   (authAnswer?0x4:0) | (truncated?0x2:0) | (recursionDesired?0x1:0));
      packetBuffer[loc++] = (byte)((recursionAvailable?0x80:0) | responseCode&0xf);
      packetBuffer[loc++] = (byte)((questions.length&0xff00)>>8);
      packetBuffer[loc++] = (byte)(questions.length&0xff);
      packetBuffer[loc++] = (byte)((answers.length&0xff00)>>8);
      packetBuffer[loc++] = (byte)(answers.length&0xff);
      packetBuffer[loc++] = (byte)((nameServers.length&0xff00)>>8);
      packetBuffer[loc++] = (byte)(nameServers.length&0xff);
      packetBuffer[loc++] = (byte)((additionalResources.length&0xff00)>>8);
      packetBuffer[loc++] = (byte)(additionalResources.length&0xff);
      for(int i=0; i<questions.length; i++) {
	loc+=questions[i].encode(packetBuffer,loc,nameTable);
      }
      for(int i=0; i<answers.length; i++) {
	loc+=answers[i].encode(packetBuffer,loc,nameTable);
      }
      for(int i=0; i<nameServers.length; i++) {
	loc+=nameServers[i].encode(packetBuffer,loc,nameTable);
      }
      for(int i=0; i<additionalResources.length; i++) {
	loc+=additionalResources[i].encode(packetBuffer,loc,nameTable);
      }
    } catch (IndexOutOfBoundsException e) {
      // set the truncated flag
      packetBuffer[2] = (byte)(packetBuffer[2] | 0x2);
    }
    return packetBuffer;
  }

  /** Print the values of this message in a human-readable way */
  public void printValues(java.io.PrintStream out) {
    out.println(" id="+(int)id);
    out.println(" isQuery="+isQuery);
    out.println(" opcode="+opcode);
    out.println(" authAnswer="+authAnswer);
    out.println(" truncated="+truncated);
    out.println(" recursionDesired="+recursionDesired);
    out.println(" recursionAvailable="+recursionAvailable);
    out.println(" responseCode="+responseCode);
    /*
      out.println(" numQuestions="+questions+" -> "+((questions!=null)?questions.length:-1));
      out.println(" numAnswers="+answers+" -> "+((answers!=null)?answers.length:-1));
      out.println(" numNameServers="+nameServers+" -> "+((nameServers!=null)?nameServers.length:-1));
      out.println(" numAdditionalResrcs="+additionalResources+" -> "+((additionalResources!=null)?additionalResources.length:-1));
    */
    out.println(" QUESTIONS:");
    for(int i=0; i<questions.length; i++) {
      questions[i].printValues(out);
    }

    out.println(" ANSWERS:");
    for(int i=0; i<answers.length; i++) {
      answers[i].printValues(out);
    }

    out.println(" NAMESERVERS:");
    for(int i=0; i<nameServers.length; i++) {
      nameServers[i].printValues(out);
    }

    out.println(" ADDITIONAL RESOURCES:");
    for(int i=0; i<additionalResources.length; i++) {
      additionalResources[i].printValues(out);
    }
  }
  
}
