/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.net.*;
import java.util.*;
import java.io.File;
import net.handle.jdb.*;
//import com.sleepycat.db.*;


/**
  *    Description:  Used to cache DNSMessages, indexed by a case insensitive name,
  *                  type and class.
  *
  *    @author Sean Reilly;
  *    @see DNSResolver
  *
*/

public class DNSCache implements Runnable {
  private String messageDBFile = "dns_cache.jdb";
  //private Db messageTable = null;
  private DBHash messageTable = null;
  private Thread cacheThread = null;

  private static final long defaultTTL = 86400; // default TTL - one day

  private static DNSCache staticInstance = null;

  /** Create a cache with the specified file name, or if a cache already exists,
    * return that one.  NOTE: the value of cacheFile is only used if a cache
    * does not currently exist and one must be created. */
  public static synchronized DNSCache getInstance(String cacheFile) throws Exception {
    if(staticInstance==null)
      staticInstance = new DNSCache(cacheFile);
    return staticInstance;
  }

  /** construct a new DNS cache using the specified Berkeley DB file.
    * @exception Exception if the cache could not be created/initialized
    */
  public DNSCache(String cacheFile)
    throws Exception {
      messageDBFile = cacheFile;
      messageTable = new DBHash(new File(messageDBFile),2000,1000);
      cacheThread = new Thread(this);
      cacheThread.start();
  }

  /** get the data associated with a dns name.
    * @exception Exception if there was an error accessing the cache
    * @return the message associated with the given name/type/class, or null if the name wasn't found
    * @param dnsName the name to query the cache for
    * @param dnsType the type of record desired
    * @param dnsClass the class of record desired
    */
  public DNSMessage getDNSMessage(String dnsName, int dnsType, int dnsClass) 
    throws Exception {
      dnsName = dnsName.toUpperCase();
      try {
	byte tmp[] = dnsName.toUpperCase().getBytes(); 
	byte bkey[] = new byte[tmp.length+4];
	System.arraycopy(tmp,0,bkey,0,tmp.length);
	bkey[tmp.length+0] = (byte)((dnsType&0x00FF00)>>8);
	bkey[tmp.length+1] = (byte) (dnsType&0x00FF);
	bkey[tmp.length+2] = (byte)((dnsClass&0x00FF00)>>8);
	bkey[tmp.length+3] = (byte) (dnsClass&0x00FF);
	byte results[] = messageTable.getValue(bkey);
	if(results!=null) {
	  return new DNSMessage(results,0,results.length-8);
	}
      } catch (Exception e) {
	System.err.println("Exception getting dns message: "+e);
	e.printStackTrace(System.err);
      }
      return null;
  }

  /** Store the data associated with this name, type, and class.
    * @exception Exception if there was an error accessing the cache
    * @param dnsName the DNS name of the record
    * @param dnsType the type of record
    * @param dnsClass the class of record
    */
  public void setMessageData(String dnsName, int dnsType, int dnsClass, DNSMessage dnsMessage) 
    throws Exception {
      
      // create the key
      dnsName = dnsName.toUpperCase();
      byte tmp[] = dnsName.getBytes();
      byte bkey[] = new byte[tmp.length+4];
      System.arraycopy(tmp,0,bkey,0,tmp.length);
      bkey[tmp.length+0] = (byte)((dnsType&0x00FF00)>>8);
      bkey[tmp.length+1] = (byte)(dnsType&0x00FF);
      bkey[tmp.length+2] = (byte)((dnsClass&0x00FF00)>>8);
      bkey[tmp.length+3] = (byte)(dnsClass&0x00FF);

      // create the data record
      byte tmpMessage[] = dnsMessage.getPacketBuffer();
      byte message[] = new byte[tmpMessage.length+8];
      System.arraycopy(tmpMessage,0,message,0,tmpMessage.length);

      long currentTime = (new Date()).getTime()/1000;
      int dateoffset = tmpMessage.length;
      message[dateoffset+0] = (byte)((currentTime>>>56)&0xFF);
      message[dateoffset+1] = (byte)((currentTime>>>48)&0xFF);
      message[dateoffset+2] = (byte)((currentTime>>>40)&0xFF);
      message[dateoffset+3] = (byte)((currentTime>>>32)&0xFF);
      message[dateoffset+4] = (byte)((currentTime>>>24)&0xFF);
      message[dateoffset+5] = (byte)((currentTime>>>16)&0xFF);
      message[dateoffset+6] = (byte)((currentTime>>>8)&0xFF);
      message[dateoffset+7] = (byte)((currentTime)&0xFF);

      messageTable.setValue(bkey,message);
      sync();
  }
  

  /** Write any changes in the cache to the disk. */
  public void sync() {
    // this is irrelevant when using the JDB
  }


  private void purgeOldRecords() {
    try {
      //System.err.println(">>>>>Purging cached data<<<<<");
      for(Enumeration enumeration=messageTable.getEnumerator();enumeration.hasMoreElements();) {
	try {
	  byte keydata[][] = (byte[][])enumeration.nextElement();
	  byte key[] = keydata[0];
	  byte data[] = keydata[1];
	  DNSMessage message = new DNSMessage(data, 0, data.length-8);
	  if(message.answers==null || message.answers.length<=0) {
	    messageTable.deleteValue(key);
	    continue;
	  }

	  int dateoffset = data.length-8;
	  long currentTime = (new Date()).getTime()/1000;
	  long insertionTime = 
	    (((long)data[dateoffset+0])&0x000000ff)<<56 |
	    (((long)data[dateoffset+1])&0x000000ff)<<48 | 
	    (((long)data[dateoffset+2])&0x000000ff)<<40 | 
	    (((long)data[dateoffset+3])&0x000000ff)<<32 |
	    (((long)data[dateoffset+4])&0x000000ff)<<24 |
	    (((long)data[dateoffset+5])&0x000000ff)<<16 | 
	    (((long)data[dateoffset+6])&0x000000ff) <<8 | 
	    (((long)data[dateoffset+7])&0x000000ff);


	  //System.err.println(">>>>Checking item to be purged: ");
	  //message.printValues(System.err);
	  long minTimeout = message.answers[0].ttl;
	  for(int i=1; i<message.answers.length; i++) {
	    if(minTimeout<message.answers[i].ttl)
	      minTimeout = message.answers[i].ttl;
	  }
	  
	  if(insertionTime + minTimeout < currentTime) {
	    //System.err.println("Purged DNS record: "+DNSResolver.convertDNSNameToString(message.questions[0].qName));
	    messageTable.deleteValue(key);
	    sync();
	  }


	} catch (Exception e) {
	  System.err.println("Exception checking record TTL: "+e);
	  e.printStackTrace(System.err);
	}
      }
    } catch (Exception e) {
      System.err.println("Exception scanning records to purge: "+e);
      e.printStackTrace(System.err);
    }
  }

  /** Run the thread that purges old cache records. */
  public void run() {
    while(true) {
      try {
	purgeOldRecords();
      } catch (Throwable t) {
	System.err.println("Exception in cache thread: "+t);
	t.printStackTrace(System.err);
      }

      try {

	// wait a minute...
	Thread.currentThread().sleep(60000);

      } catch (Throwable t) {
	System.err.println("Exception in cache thread: "+t);
	t.printStackTrace(System.err);
      }
    }
  }
  

  /** Save any unsaved data and do cleanup. */
  public void shutdown() {
    try {
      messageTable.close();
    } catch (Exception e) {}
  }


}
