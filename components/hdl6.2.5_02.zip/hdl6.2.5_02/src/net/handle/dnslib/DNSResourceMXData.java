/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;
import java.net.*;

/** class that holds the data from an "MX" type resource record.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
  * @see DNSResourceData
 */

public class DNSResourceMXData extends DNSResourceData {

  protected String exchangeName[];
  protected int preference;

  public DNSResourceMXData() {
    exchangeName = new String[0];
    preference = 0;
  }
  
  public DNSResourceMXData(byte data[], int offset, int length) {
    decodeData(data,offset,length);
  }

  public void decodeData(byte data[], int offset, int length) {
    preference  = (data[offset++]&0x00ff)<<8;
    preference |= (data[offset++]&0x00ff);
    Vector names = new Vector();
    offset+=DNSResourceRecord.readNameFromPointer(data,offset,names);
    exchangeName = new String[names.size()];
    for(int i=0; i<exchangeName.length; i++)
      exchangeName[i] = (String)names.elementAt(i);
  }

  public int encodeData(byte data[], int location, Hashtable nameTable) {
    int origLoc = location;
    data[location++] = (byte)((preference&0xff00)>>8);
    data[location++] = (byte) (preference&0x00ff);
    location+=DNSResourceRecord.writeNameToPointer(exchangeName,data,location, nameTable);
    return location-origLoc;
  }

  /** return a string representation of the name server data. */
  public String toString() {
    return "  exchange: "+DNSResolver.convertDNSNameToString(exchangeName)+
      ";  preference: "+preference;
  }

}
