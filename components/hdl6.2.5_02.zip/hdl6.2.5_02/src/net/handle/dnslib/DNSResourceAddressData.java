/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;
import java.net.*;

/** class that holds the data from a "A" type resource record.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
  * @see DNSResourceData
 */

public class DNSResourceAddressData extends DNSResourceOpaqueData {

  public DNSResourceAddressData() {
    super();
  }

  public DNSResourceAddressData(byte data[], int offset, int length) {
    super(data, offset, length);
  }
  
  public InetAddress getAddress() throws UnknownHostException {
    return InetAddress.getByName(""+(resourceData[0]&0x00ff)+
				 "."+(resourceData[1]&0x00ff)+
				 "."+(resourceData[2]&0x00ff)+
				 "."+(resourceData[3]&0x00ff));
  }

  public void setAddress(InetAddress address) {
    resourceData = address.getAddress();
  }
}
