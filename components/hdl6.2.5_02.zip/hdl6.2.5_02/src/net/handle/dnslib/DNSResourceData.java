/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;

/** class that holds the data from a resource record.
  * This class is meant to be subclassed by objects that understand
  * the format of the record data.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
 */

public abstract class DNSResourceData {

  /** Read the data from the specified buffer, starting at <code>offset</code>
    * and continuing for <code>length</code> bytes. */
  public abstract void decodeData(byte data[], int offset, int length);
  
  /** Write the data to the specified buffer, starting at
    * <code>offset</code>.  This should be overridden by
    * subclasses. Returns the number of bytes written.  */
  public abstract int encodeData(byte data[], int offset, Hashtable nameTable);



  public static void printBytes(java.io.PrintStream out, byte buf[], int offset, int length) {
    for(int i=offset; i<(offset+length); i++) {
      if((i-offset)%16==0 && i!=offset) out.print("\n");
      if(buf[i]>='a' && buf[i]<='z' ||
	 buf[i]>='A' && buf[i]<='Z' ||
	 buf[i]>='0' && buf[i]<='9' ||
	 buf[i]=='.')
	out.print(" "+((char)(buf[i])));
      else
	out.print(" \\"+(buf[i]&0x0ff));
    }
    out.print("\n");
  }
  
}
