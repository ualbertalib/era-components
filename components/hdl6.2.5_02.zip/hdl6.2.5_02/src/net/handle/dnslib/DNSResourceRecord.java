/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;

/**
 * class that defines a Resource Record (rfc1035, section 4.1.3).
 */

public class DNSResourceRecord {
  public String qName[];    // domain name to which this record pertains
  public int qType;   // ie: "A" for address, "NS" for name server...
  public int qClass;  // ie: "IN" for internet
  public int ttl;    // 32 bit time-to-live
  public DNSResourceData rdata; // data describing this resource - dependent on qClass and qType.

  public DNSResourceRecord(String qName[], int qType, int qClass, int ttl, byte rdata[]) {
    this.qName = qName;
    this.qType = qType;
    this.qClass = qClass;
    this.ttl = ttl;
    this.rdata = readData(qType, rdata, 0, rdata.length);
  }

  private DNSResourceData readData(int type, byte buf[], int offset, int length) {
    /*
      TYPE_A=1, TYPE_NS=2, TYPE_MD=3, TYPE_MF=4, TYPE_CNAME=5,
      TYPE_SOA=6, TYPE_MB=7, TYPE_MG=8, TYPE_MR=9, TYPE_NULL=10, TYPE_WKS=11, TYPE_PTR=12,
      TYPE_HINFO=13, TYPE_MINFO=14, TYPE_MX=15, TYPE_TXT=16;
    */
    if(buf==null)
      buf = new byte[0];
    //System.err.println("RR type: "+type);
    switch(qType) {
    case DNSMessage.TYPE_A:
      return new DNSResourceAddressData(buf, offset, length);
    case DNSMessage.TYPE_NS:
    case DNSMessage.TYPE_CNAME:
    case DNSMessage.TYPE_PTR:
      return new DNSResourceNameData(buf, offset, length);
    case DNSMessage.TYPE_SOA:
      return new DNSResourceSOAData(buf, offset, length);
    case DNSMessage.TYPE_HINFO:
     System.err.println("RR record of HINFO type: "+qType);
      return new DNSResourceHInfoData(buf, offset, length);
    case DNSMessage.TYPE_MX:
      return new DNSResourceMXData(buf, offset, length);
    default:
      System.err.println("RR record of unknown type: "+qType);
      return new DNSResourceOpaqueData(buf, offset, length);
    }
  }

  public DNSResourceRecord() {
    this.qName = null;
    this.qType = -1;
    this.qClass = -1;
    this.ttl = 0;
    this.rdata = new DNSResourceOpaqueData();
  }

  /** Construct a new DNSResourceRecord object and parse the values
    * from the given buffer, beginning at <code>offset</code>
    */
  public DNSResourceRecord(byte buf[], int offset) {
    decode(buf, offset);
  }

  /** Parse the values from the given buffer, beginning at 
    * <code>offset</code>.  Returns the number of bytes read.
    */
  public int decode(byte buf[], int offset) {
    int origLoc = offset;

    // - ouch! heavy operation here...
    Vector nameVect = new Vector();
    offset += readNameFromPointer(buf,offset,nameVect);
    qName = new String[nameVect.size()];
    for(int i=0; i<qName.length; i++) {
      qName[i] = (String)nameVect.elementAt(i);
    }
    qType = ((buf[offset++]&0xff)<<8) | (buf[offset++]&0xff);
    qClass = ((buf[offset++]&0xff)<<8) | (buf[offset++]&0xff);
    ttl = ((buf[offset++]&0xff)<<24) | ((buf[offset++]&0xff)<<16) 
      | ((buf[offset++]&0xff)<<8) | (buf[offset++]&0xff);
    int dataLen = ((buf[offset++]&0x00ff)<<8) | (buf[offset++]&0x00ff);
    rdata = readData(qType,buf,offset,dataLen);
    offset+=dataLen;
    return offset-origLoc;
  }
  
  /** write this question into the specified DNS message, and return
      the number of bytes written. */
  public int encode(byte msgBuf[], int location, Hashtable nameTable) {
    int origLoc = location;
    
    location+=writeNameToPointer(qName,msgBuf,location,nameTable);

    msgBuf[location++] = (byte)((qType & 0xff00)>>8);
    msgBuf[location++] = (byte)(qType & 0x00ff);
    msgBuf[location++] = (byte)((qClass & 0xff00)>>8);
    msgBuf[location++] = (byte)(qClass & 0x00ff);

    msgBuf[location++] = (byte)((ttl&0xff000000)>>24);
    msgBuf[location++] = (byte)((ttl&0x00ff0000)>>16);
    msgBuf[location++] = (byte)((ttl&0x0000ff00)>>8);
    msgBuf[location++] = (byte) (ttl&0x000000ff);

    int rdataLen = rdata.encodeData(msgBuf,location+2,nameTable);
    msgBuf[location++] = (byte)((rdataLen&0x00ff00)>>8);
    msgBuf[location++] = (byte) (rdataLen&0x0000ff);
    location += rdataLen;
    
    return location-origLoc;
  }
  
  public void printValues(java.io.PrintStream out) {
    String name = "null";
    if(qName!=null) {
      name = "";
      for(int i=0;i<qName.length;i++) {
	name = name+qName[i]+'.';
      }
    }
    out.println("name=\""+name+"\" type="+qType+" class="+qClass+" ttl="+ttl+" rdata="+rdata);
  }

  public static int writeNameToPointer(String domainName[], byte buf[], 
				       int offset, Hashtable nameTable) {
    int origOffset=offset;
    for(int i=0; i<domainName.length; i++) {
      if(domainName[i].length()<=0)
	continue;
      byte thisName[] = domainName[i].getBytes();
      buf[offset++] = (byte)thisName.length;
      System.arraycopy(thisName,0,buf,offset,thisName.length);
      offset+=thisName.length;
    }    
    buf[offset++]=0;
    return offset-origOffset;
  }

  public static int readNameFromPointer(byte buf[], int offset, Vector nameVector) {
    int origLoc = offset;
    while(true) {
      byte b = buf[offset++];
      if(b==0)
	return offset-origLoc;
      if((b&0x00C0) >= 0x00C0) {
	int destOffset = (b&0x003f)<<8 | (0x00ff&buf[offset++]);
	readNameFromPointer(buf,destOffset,nameVector);
	return (offset-origLoc);
      } else {
	nameVector.addElement(new String(buf,offset,b));
	offset+=b;
      }
    }
  }
}
