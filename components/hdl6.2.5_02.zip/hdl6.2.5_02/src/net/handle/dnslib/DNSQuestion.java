/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;

public class DNSQuestion {
  public String qName[];   // ie: { "www", "yahoo", "com" }
  public int qType;   // ie: "A" for address, "NS" for name server...
  public int qClass;  // ie: "IN" for internet

  public DNSQuestion(String qName[], int qType, int qClass) {
    this.qName = qName;
    this.qType = qType;
    this.qClass = qClass;
  }

  public DNSQuestion() {
    this.qName = null;
    this.qType = -1;
    this.qClass = -1;
  }


  /** decode the question from the question portion of
      a packet buffer.  Returns the number of bytes 
      processed from the buffer. */
  public int decode(byte buf[], int offset) {
    int origLoc = offset;
    
    // - ouch! heavy operation here...
    Vector nameVect = new Vector();
    offset += DNSResourceRecord.readNameFromPointer(buf,offset,nameVect);
    qName = new String[nameVect.size()];
    for(int i=0; i<qName.length; i++) {
      qName[i] = (String)nameVect.elementAt(i);
    }
    qType = (buf[offset++]<<8) | (buf[offset++]);
    qClass = (buf[offset++]<<8) | (buf[offset++]);
    return offset-origLoc;
  }
  
  /** write this question into the specified DNS message, and return
      the number of bytes written. */
  public int encode(byte msgBuf[], int location, Hashtable nameTable) {
    int origLoc = location;
    
    // write the qNames
    location += DNSResourceRecord.writeNameToPointer(qName,msgBuf,location,nameTable);
    /*
      for(int i=0; i<qName.length; i++) {
      byte buf[] = qName[i].getBytes();
      msgBuf[location++] = (byte)buf.length;
      for(int j=0; j<buf.length; j++)
      msgBuf[location++] = buf[j];
      }
      msgBuf[location++] = (byte)0;
    */

    // write the qType and qClass
    msgBuf[location++] = (byte)((qType & 0xff00)>>8);
    msgBuf[location++] = (byte)(qType & 0x00ff);
    msgBuf[location++] = (byte)((qClass & 0xff00)>>8);
    msgBuf[location++] = (byte)(qClass & 0x00ff);
    return location-origLoc;
  }
  
  public void printValues(java.io.PrintStream out) {
    out.println(toString());
  }

  public String toString() {
    String name = "null";
    if(qName!=null) {
      name = "";
      for(int i=0;i<qName.length;i++) {
	name = name+qName[i]+'.';
      }
    }
    return "name=\""+name+"\" type="+qType+" class="+qClass;
      
  }


}
