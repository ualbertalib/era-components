/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;
import java.net.*;

/** Class that uses BIND and the DNS system to resolve a domain name. 
  *
  * @author Sean Reilly
  * @see DNSCache
  * @see DNSMessage
*/

public class DNSResolver {
  private static int nextID = (new Random()).nextInt();
  private InetAddress rootServers[];
  private DNSCache cache = null;
  public static boolean DEBUG=true;

  public static final int DNS_PORT = 53;

  /** Takes a domain name in the form of an array of names and returns
    * the name in standard DNS "dot" notation.  For example, 
    * [ "cnri", "reston", "va", "us" ] becomes "cnri.reston.va.us."
    * @return the given DNS name in standard "dot" notation
    * @param name The DNS name as an array of name-parts.
    * @param offset The index of the first DNS name in the array to use.
    * @param length The number of DNS names to use from the name array
  */
  public static String convertDNSNameToString(String name[], int offset, int length) {
    StringBuffer sb = new StringBuffer();
    for(int i=offset; i<offset+length; i++) {
      sb.append(name[i]);
      sb.append('.');
    }
    return sb.toString();
  }

  /** Takes a domain name in the form of an array of names and returns
    * the name in standard DNS "dot" notation.  For example, 
    * [ "cnri", "reston", "va", "us" ] becomes "cnri.reston.va.us"
    * @return the given DNS name in standard "dot" notation
    * @param name The DNS name as an array of name-parts.
  */
  public static String convertDNSNameToString(String name[]) {
    return convertDNSNameToString(name,0,name.length);
  }

  /** Takes a name in standard dot notation and returns an array where
    * each part of the dot-notation DNS name is separated into its own
    * array element.  For example, "cnri.reston.va.us" becomes
    * [ "cnri", "reston", "va", "us" ]
    * @return the given DNS name in a DNS name array
    * @param hostName the DNS name in the standard "dot" notation
  */
  public static String[] convertStringToDNSName(String hostName) {
    int dotIndex=0;
    Vector nameVector = new Vector();
    do {
      int nameStart=dotIndex;
      dotIndex = hostName.indexOf('.',dotIndex);
      if(dotIndex>=0) {
	String namePart = hostName.substring(nameStart,dotIndex);
	dotIndex++;
	if(namePart.length()>0)
	  nameVector.addElement(namePart);
      } else {
	String namePart = hostName.substring(nameStart);
	if(namePart.length()>0)
	  nameVector.addElement(namePart);
      }
    } while (dotIndex>=0);
    
    String dnsName[] = new String[nameVector.size()];
    for(int i=0;i<dnsName.length;i++) 
      dnsName[i] = (String)nameVector.elementAt(i);
    return dnsName;
  }


  /** Construct a DNSResolver use the default set of root servers.
    * @exception Exception if the root servers could not be acquired. */
  public DNSResolver() throws Exception {

    InetAddress tmp[] = { InetAddress.getByName("198.41.0.4"),		// A.ROOT-SERVERS.NET
			  InetAddress.getByName("128.9.0.107"),		// B.ROOT-SERVERS.NET
			  InetAddress.getByName("192.33.4.12"),		// C.ROOT-SERVERS.NET
			  InetAddress.getByName("128.8.10.90"),		// D.ROOT-SERVERS.NET
			  InetAddress.getByName("192.203.230.10"),	// E.ROOT-SERVERS.NET
			  InetAddress.getByName("192.5.5.241"),		// F.ROOT-SERVERS.NET
			  InetAddress.getByName("192.112.36.4"),	// G.ROOT-SERVERS.NET
			  InetAddress.getByName("128.63.2.53"),		// H.ROOT-SERVERS.NET
	 		  InetAddress.getByName("192.36.148.17") };  	// I.ROOT-SERVERS.NET

    /* Local CNRI DNS resolvers
    InetAddress tmp[] = { InetAddress.getByName("10.27.2.1"),		// A.ROOT-SERVERS.NET
			  InetAddress.getByName("10.27.2.27"),		// B.ROOT-SERVERS.NET
			  InetAddress.getByName("132.151.1.1") };	// C.ROOT-SERVERS.NET
			  */
    rootServers = tmp;
  }

  /** Construct a DNSResolver use the default set of root servers, and the
    * specified cache.
    * @param cache The cache to use, or <code>null</code> to not use a cache
    * @exception Exception if the root servers could not be acquired. */
  public DNSResolver(DNSCache cache) 
    throws Exception {
      this();
      this.cache = cache;
  }

  /** Resolve the given DNS name by "walking" the DNS tree (using the cache where possible),
    * and querying for the name/type/class.
    * @param name The DNS name to resolve
    * @param recordType The desired type of record requested
    * @param recordClass The desired class of record/address
    * @return The response for this DNS name query
    * @exception Exception if there was an error resolving the name. */
  public DNSMessage resolveNameRecursively(String name, int recordType, int recordClass) throws Exception {
    return resolveNameRecursively(convertStringToDNSName(name),recordType,recordClass);
  }

  
  /** Resolve the given DNS name by "walking" the DNS tree starting at the specified
    * servers and querying for the name/type/class (using the cache where possible). 
    * @param name The DNS name to resolve
    * @param recordType The desired type of record requested
    * @param recordClass The desired class of record/address
    * @param nameServers The servers to query first when looking for this name
    * @return The response for this DNS name query
    * @exception Exception if there was an error resolving the name. */
  public DNSMessage resolveNameRecursively(String name[], int recordType, int recordClass,
					   InetAddress nameServers[], int depth)
    throws Exception {
      if(DEBUG) for(int i=0;i<depth;i++) System.err.print("  ");
      if(DEBUG)	System.err.println("Resolving name: "+convertDNSNameToString(name)+
				   "("+recordType+","+recordClass+") via DNS");
      boolean nsWasCached = false;
      
      // If a cached value exists, let's check for it...
      if(cache!=null ) {
	try {
	  DNSMessage message = cache.getDNSMessage(convertDNSNameToString(name),
						   recordType,
						   recordClass);
	  if(message!=null) {
	    return message;
	  }
	} catch (Exception e) {
	  System.err.println("Exception using DNS cache: "+e);
	}
      }
      
      // create the request packet..
      DNSMessage query = new DNSMessage();
      query.id = (char)nextID++;
      query.isQuery = false;
      query.opcode = DNSMessage.OP_QUERY;
      query.authAnswer = false;
      query.truncated = false;
      query.recursionDesired = true;
      query.recursionAvailable = false;
      query.responseCode = DNSMessage.RC_OK;
      query.questions = new DNSQuestion[1];
      query.questions[0] = new DNSQuestion(name,recordType,recordClass);
      query.answers = new DNSResourceRecord[0];
      query.nameServers = new DNSResourceRecord[0];
      query.additionalResources = new DNSResourceRecord[0];
      query.setDirty();
      
      
      // Let's see if the cache has the address of any nameservers that are
      // responsible for any of this name's domains.
      if(cache!=null && nameServers==null) {
	String parentDomain[] = new String[name.length];
	System.arraycopy(name,0,parentDomain,0,name.length);
	while(parentDomain.length>0) {
	  try {
	    DNSMessage nsMessage = cache.getDNSMessage(convertDNSNameToString(parentDomain),
						       DNSMessage.TYPE_NS,
						       recordClass);
	    if(nsMessage!=null) {
	      // Get the nameservers from the cached answers...
	      if(nsMessage.additionalResources!=null && 
		 nsMessage.additionalResources.length>0) {
		nameServers = extractNameServers(nsMessage);
		nsWasCached = true;
		break;
	      }
	    }
	  } catch (Exception e) {
	    if(DEBUG)
	      System.err.println("Exception using DNS cache: "+e);
	  }
	  String tmpName[] = new String[parentDomain.length-1];
	  System.arraycopy(parentDomain,1,tmpName,0,tmpName.length);
	  parentDomain = tmpName;
	}
      }
      return resolveNameStartingAt(query,name,recordType,recordClass,nameServers,depth);
  }
  
  /** Start resolving the specified name, using the given message, starting
    * at the specified name service. */
  private DNSMessage resolveNameStartingAt(DNSMessage query, String name[], int recordType, 
					   int recordClass, InetAddress nameServers[], 
					   int depth) throws Exception {
    if(nameServers==null)  // If we don't have a cached or pre-determined NS, then use root.
      nameServers = rootServers;

    if(depth>=20)
      throw new DNSResolutionException("Too many hops resolving name: "+
				       convertDNSNameToString(name)+"");

    // query the name "service" to try to find an answer
    DNSMessage response=null;
    try {
      response = queryServers(query,nameServers);
    } catch (Exception e) {
      if(DEBUG) {
	System.err.println("Error querying name service: "+e);
	e.printStackTrace(System.err);
      }
      throw e;  /////// might want to change this to be a DNSResolutionException...
    }

    // If this server had an answer, then cache it and return it.
    if(response.answers!=null && response.answers.length>0) {
      // If we got a record type that we were looking for,
      // return it, otherwise check for a redirect (ie a CNAME record)
      boolean gotAnswer=false;
      String cname[] = null;
      for(int i=0;i<response.answers.length;i++) {
	if(response.answers[i].qType==recordType) {
	  gotAnswer=true;
	  break;
	} else if(response.answers[i].qType==DNSMessage.TYPE_CNAME){
	  cname = ((DNSResourceNameData)response.answers[i].rdata).getName();
	}
      }
      if(gotAnswer) {
	saveToCache(name, recordType, recordClass, response);
      } else if(cname!=null) {
	// got a CNAME (or alias) record that we need to resolve.
	if(DEBUG) System.err.println("Resolving CNAME record ("+response.answers.length+"): "+
				     convertDNSNameToString(((DNSResourceNameData)response.
							     answers[0].rdata).getName()));
	DNSMessage origResponse = response;
	response = resolveNameRecursively(((DNSResourceNameData)response.answers[0].rdata).getName(),
					  recordType, recordClass, extractNameServers(response),depth+1);
	response.questions = query.questions;
	DNSResourceRecord newAnswers[] = new DNSResourceRecord[response.answers.length+origResponse.answers.length];
	System.arraycopy(origResponse.answers,0,newAnswers,0,origResponse.answers.length);
	System.arraycopy(response.answers,0,newAnswers,origResponse.answers.length,response.answers.length);
	response.answers = newAnswers;
	response.setDirty();
	saveToCache(name, recordType, recordClass, response);
      } else {
	// darn, didn't get an answer, and got no redirect... 
	// let's just return whatever we have, maybe the client
	// can cope, but let's not cache it.
      }
      return response;
    }
    
    // If this server isn't responsible, and doesn't know who is,
    // then it's a total bummer, so we should just return the result
    if(response.additionalResources==null || response.additionalResources.length<=0) {
      saveToCache(name,recordType,recordClass,response);
      return response;
    }
    
    // if this server didn't have an answer but did know who would,
    // then we should get set up to try that server.
    InetAddress newNameServers[] = extractNameServers(response);
    // if a cache exists, store the name servers for this domain...
    if(cache!=null && newNameServers.length>0) {
      response.questions[0].qName = response.nameServers[0].qName;
      response.questions[0].qType = response.nameServers[0].qType;
      response.answers = response.nameServers;
      response.nameServers = new DNSResourceRecord[0];
      response.authAnswer = false;
      response.setDirty(); // force the message to re-create it's packet
      saveToCache(response.questions[0].qName,response.answers[0].qType,
		  response.answers[0].qClass,response);
    }
    return resolveNameStartingAt(query,name,recordType, recordClass,newNameServers,depth+1);
  }


  /** Extract the nameservers from the given DNSMessage.
    * @param message The DNSMessage from which to extract the name server data.
    * @return array of nameservers.
    */
  public InetAddress[] extractNameServers(DNSMessage message) {
    if(message.additionalResources==null)
      return null;
    if(message.additionalResources.length<=0)
      return new InetAddress[0];
    InetAddress nameServers[] = new InetAddress[message.additionalResources.length];
    for(int n=0; n<nameServers.length; n++) {
      try {
	nameServers[n] = ((DNSResourceAddressData)message.additionalResources[n].rdata).getAddress();
      } catch (Exception e) {}
    }
    return nameServers;
  }

  /** Resolve the domain name with the specified type and class starting
    * at the root DNS servers.
    * @param name The DNS name to resolve
    * @param recordType The desired type of record requested
    * @param recordClass The desired class of record/address
    * @return The response for this DNS name query
    * @exception Exception if there was an error resolving the name. */
  public DNSMessage resolveNameRecursively(String name[], int recordType, int recordClass) throws Exception {
    return resolveNameRecursively(name,recordType,recordClass,null,0);
  }


  /** Send this DNSMessage to the specified DNS "service" and return the
    * response.
    * @param message The message to send to the server
    * @param servers The addresses of the servers to start the resolution from
    * @return The response for this DNS name query
    * @exception Exception if there was an error with the request, or the request timed out. */
  public DNSMessage queryServers(DNSMessage message, InetAddress servers[]) throws Exception {

    DatagramSocket sock = new DatagramSocket();
    sock = new DatagramSocket();
    sock.setSoTimeout(10000);
	
    byte queryBuf[] = message.getPacketBuffer();

    //if(DEBUG)
    //System.err.println("Querying "+servers.length+" servers");
    // should sort the servers by response time here.  For now, we'll just shuffle them.
    InetAddress tmpServers[] = new InetAddress[servers.length];
    System.arraycopy(servers,0,tmpServers,0,servers.length);
    servers = tmpServers;
    Random rand = new Random();
    for(int i=0; i<servers.length; i++) {
      int swap = (int)(rand.nextFloat()*servers.length);
      if(i==swap)
	continue;
      InetAddress tmp = servers[swap];
      servers[swap] = servers[i];
      servers[i] = tmp;
    }
    
    try {
      for(int i=0; i<servers.length; i++) {
	try {
	  // send the request
	  DatagramPacket packet = new DatagramPacket(queryBuf, queryBuf.length,servers[i],
						     DNS_PORT);
	  if(DEBUG)
	      System.err.println(" ---Sending BIND query to: "+servers[i].getHostAddress()+"---");
	  sock.send(packet);
	  
	  // receive the response
	  packet = new DatagramPacket(new byte[1024],1024);
	  sock.receive(packet);
	  return new DNSMessage(packet.getData(),0,packet.getLength());
	} catch (Exception e) {
	  if(i==servers.length-1)
	    throw e;
	}
      }
    } finally {
      try { sock.close(); } catch (Exception e){}
    }
    throw new DNSResolutionException("Unable to query any nameservers");
  }


  public static void main(String argv[]) {
    if(argv.length<1) {
      System.err.println("Usage: java net.handle.dns.DNSResolver <dns-name>");
      return;
    }
    try {
      DNSCache cache = new DNSCache("dns_cache.db");
      DNSResolver resolver = new DNSResolver(cache);
      System.err.println("Name to resolve: "+argv[0]);
      DNSMessage result = resolver.resolveNameRecursively(argv[0],DNSMessage.TYPE_A,DNSMessage.CLASS_IN);
      System.err.println("Got addresses: ");
      for(int i=0; i<result.answers.length; i++) {
	result.answers[i].printValues(System.err);
      }
    } catch (Exception e) {
      System.err.println("Got exception: "+e);
      e.printStackTrace(System.err);
    }
  }

  private void saveToCache(String name[], int qType, int qClass, DNSMessage response) {
    if(cache==null)
      return;
    //if(DEBUG)
    //System.err.println("Storing results for: "+
    //convertDNSNameToString(name)+"; type="+qType+"; class="+qClass+";");
    try {
      cache.setMessageData(convertDNSNameToString(name),qType,qClass,response);
    } catch (Exception e) {}
  }


  /** Prints the contents of a datagram packet in a human readable format.
   * @param pkt The packet whose data will be printed
   */
  public static void printPacket(DatagramPacket pkt) {
    byte buf[] = pkt.getData();
    for(int i=0; i<pkt.getLength(); i++) {
      if(i%16==0 && i!=0) System.err.print("\n");
      if(buf[i]>='a' && buf[i]<='z' ||
	 buf[i]>='A' && buf[i]<='Z' ||
	 buf[i]=='.')
	System.err.print(" "+((char)(buf[i])));
      else
	System.err.print(" \\"+(buf[i]&0x0ff));
    }
    System.err.print("\n");
  }

}
