/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.dnslib;

import java.util.*;
import java.net.*;

/** class that holds the data from a "HINFO" type resource record.
  *
  * @author Sean Reilly sreilly@cnri.reston.va.us
  * @see DNSResourceRecord
  * @see DNSResourceData
 */

public class DNSResourceHInfoData extends DNSResourceData {
  protected byte buf[];
  protected String cpu = null;
  protected String os  = null;

  public DNSResourceHInfoData() {
    cpu = "";
    os = "";
  }
  
  public DNSResourceHInfoData(byte data[], int offset, int length) {
    decodeData(data,offset,length);
  }

  public void decodeData(byte data[], int offset, int length) {
    System.err.println("parsing HINFO data:");
    buf = new byte[length];
    System.arraycopy(data,offset,buf,0,length);
    DNSResourceData.printBytes(System.err, buf, 0, buf.length);
  }

  public int encodeData(byte data[], int offset, Hashtable nameTable) {
    System.arraycopy(buf,0,data,offset,buf.length);
    return buf.length;
  }

  
  
  /** return a string representation of the name server data. */
  public String toString() {
    return "HINFO..???";
  }

}
