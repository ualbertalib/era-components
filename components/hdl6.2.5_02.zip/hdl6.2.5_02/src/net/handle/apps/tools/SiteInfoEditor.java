/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.tools;

import net.handle.apps.gui.jwidget.*;
import javax.swing.*;
import javax.swing.border.*;
import net.handle.hdllib.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/* 
  GUI for manipulating siteinfo data
*/

public class SiteInfoEditor {

  static String USAGE = 
    "Usage: java net.handle.apps.tools.SiteInfoEditor <siteinfo file | NA handle>";

  public static void main(String argv[]){
    JFrame frame = new JFrame("Site Info Editor");
  
    frame.setJMenuBar(new JMenuBar());
    JMenu menu = new JMenu("File");
    JMenuItem i = new JMenuItem("Exit");
    i.addActionListener(new AbstractAction("Exit"){  
                   public void actionPerformed(ActionEvent e){ System.exit(0); }
                 });
    menu.add(i);
    frame.getJMenuBar().add(menu);
    
    
    SiteDataJPanel p = new SiteDataJPanel(true, true);
    frame.getContentPane().add(p);
    Border border = BorderFactory.createEmptyBorder(15, 15, 15, 15);
    p.setBorder(border);
    frame.pack();
    frame.setVisible(true);

    frame.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent e) {
              System.exit(0);
          }
    });

    if (argv.length > 0){
      if (argv[0].startsWith("--h") || argv[0].startsWith("-h")){
         System.err.println(USAGE);
         System.exit(-1);
      }
      if (argv[0].toUpperCase().startsWith("0.NA")){
        // see if it is a naming authority
        String s[] = { "HS_SITE" };
        try {
          HandleValue v[]=(new HandleResolver()).resolveHandle(argv[0],s,null); 
          if (v == null || v.length == 0){ 
            throw new Exception("HS_SITE not found.");
          }
          p.setValueData(v[0].getData());
        }
        catch (Exception e){
          JOptionPane.showMessageDialog(frame, "Can't load NA "+argv[0]+": "+e,
                                        "Error", JOptionPane.ERROR_MESSAGE);
        } 
      }
      else {
        // it is a file
        try {
          File f = new File(argv[0]);
          byte buf[] = new byte[(int)f.length()];
          (new FileInputStream(f)).read(buf);
          p.setValueData(buf);
        }
        catch (Exception e){
          JOptionPane.showMessageDialog(frame,"Can't load file "+argv[0]+": "+e,
                                        "Error", JOptionPane.ERROR_MESSAGE);
        } 
      }
    }
    
  }

}
