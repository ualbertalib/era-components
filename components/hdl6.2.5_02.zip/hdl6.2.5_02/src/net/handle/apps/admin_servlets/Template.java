/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admin_servlets;

import java.lang.*;
import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Stack;


public class Template {

  // This function returns the index of the next matching closed brace "}}".
  // It assumes that the start brace is *not* a part of the string.
  //  getMatchingBraceLocation("Hello{{xxx}} }}") will return 13.
  public static int getMatchingBraceLocation(String str) {
    Stack stack = new Stack();
    int leftIdx = -1, rightIdx = -1;
    int totIdx = 0;
    String str2 = str;
    while(true){
      leftIdx = str2.indexOf("{{");
      rightIdx = str2.indexOf("}}");
      if(rightIdx<0) {
				return -1;
      }
      if(leftIdx>=0 && leftIdx<rightIdx) {
	// A left bracket came first - {{
	stack.push("{{");
	str2 = str2.substring(leftIdx+2,str2.length());
	totIdx+=leftIdx+2;
	continue;
      } else {
	// We found a right bracket - }}
	str2 = str2.substring(rightIdx+2,str2.length());
	totIdx+=rightIdx+2;
	if(stack.empty()) {
	  return totIdx-2;
	} else {
	  String match = (String)stack.pop();
	}
      }
    }
  }
  
  public static String subDictIntoFile(String filename,Hashtable dict)
    throws IOException, TemplateException
  {
    DataInputStream in = new DataInputStream(new FileInputStream(filename));
    StringBuffer sb = new StringBuffer("");
    while(true){
      String str = in.readLine();
      if(str==null) break;
      sb.append(str+'\n');
    }
    return subDictIntoString(sb.toString(),dict);
  }

  public static String subDictIntoFile(File file, Hashtable dict)
    throws IOException, TemplateException
  {
    DataInputStream in = new DataInputStream(new FileInputStream(file));
    StringBuffer sb = new StringBuffer("");
    while(true){
      String str = in.readLine();
      if(str==null) break;
      sb.append(str+'\n');
    }
    return subDictIntoString(sb.toString(),dict);
  }

  public static String subDictIntoString(String str, Hashtable dict) throws TemplateException {
    String nstr = "";
    String estr = "";
    boolean noMoreTags = false;
    while(true){
      boolean isRepeatingTag = false;
      int begTag = 0, endTag=0;
      begTag = str.indexOf("{{");
      if(begTag<0) 
				break;

      endTag = getMatchingBraceLocation(str.substring(begTag+2,str.length()));
      endTag+=begTag+2;

      if(endTag<0) {
	throw new TemplateException("Unmatched {{.");
      }
      String checkEqualString = str.substring(begTag,endTag);
      
      int eqIndex = checkEqualString.indexOf("=");
      nstr = str.substring(0,begTag);
      estr = str.substring(endTag+2,str.length());
      String key;
      if(eqIndex>2) {
	// Get the key if this is a repeating tag.
	key = checkEqualString.substring(2,eqIndex).trim();
	isRepeatingTag = true;
      } else {
	// Get the key if this is a non-repeating tag.
	key = str.substring(begTag+2,endTag).trim();
	isRepeatingTag = false;
      }
      
      String value = "";
      if(isRepeatingTag) {
	String restOfTag = checkEqualString.substring(eqIndex+1);
	// Recurse into the tag for each hashtable in the vector.
	Vector val;
	try {
	  val = (Vector)dict.get((Object)key);
	} catch (ClassCastException e) {
	  throw new TemplateException("Invalid value for key=\""+key+"\"");
	}
	if(val!=null) {
	  for(int i=0;i<val.size();i++) {
	    Hashtable table;
	    try {
	      table = (Hashtable)val.elementAt(i);
	    } catch (ClassCastException e) {
	      throw new TemplateException("Invalid type for element "+i+" of repeating tag");
	    }
	    if(table!=null) {
	      nstr = nstr+subDictIntoString(restOfTag,table);
	    }
	  }
	}	
      } else {
	String format=null;
	int colonKey = key.indexOf("::");
	if(colonKey>=0) {
	  format = key.substring(colonKey+2);
	  key = key.substring(0,colonKey);
	}
	
	// Replace this tag with its associated value.
	Object obj;
	obj = dict.get((Object)key);
	
	if(obj!=null) {
	  if(format!=null && format.equals("URLEncode")) {
	    nstr = nstr+java.net.URLEncoder.encode(obj.toString());
	  } else if(format!=null && format.equals("CGIEscape")) {
	    nstr = nstr+cgiEscape(obj.toString());
	  } else {
	    nstr = nstr+obj.toString();
	  }
	} else {
	  nstr = nstr;
	}
      }
      
      str = nstr+estr;
    }
    return str;
  }

  public static String cgiEscape(String str) {
    StringBuffer sb = new StringBuffer("");
    for(int i=0;i<str.length();i++) {
      char ch = str.charAt(i);
      if(ch=='<')
	sb.append("&lt;");
      else if(ch=='>')
	sb.append("&gt;");
      else if(ch=='"')
	sb.append("&quot;");
      else
	sb.append(ch);
    }
    return sb.toString();
  }
}


