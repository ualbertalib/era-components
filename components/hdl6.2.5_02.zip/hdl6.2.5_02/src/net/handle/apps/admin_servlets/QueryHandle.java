/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admin_servlets;

/**
 * Servlet used for displaying query results of a handle.
 **/

import net.handle.hdllib.*;
import java.io.*;
import java.text.*;
import java.util.Vector;
import java.util.Hashtable;
import javax.servlet.*;
import javax.servlet.http.*;

public class QueryHandle extends HttpServlet {
  
  private HandleResolver resolver = new HandleResolver();
  private static final String DEFAULT_PAGE="parent.qdisplay.document.location.href='/CNRIHS/blank.html';top.qstatus.document.open(); top.qstatus.document.write('No URL loaded'); top.qstatus.document.close();";
  public void init(ServletConfig config) throws ServletException{
    super.init(config);
    resolver.traceMessages = true;
  }
  
  public void destroy(){
    super.destroy();
  }
  
  public String getServletInfo() {
    return "This servlet is used to query handles.";
  }
  
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
  {
    doPost(req, resp);
  }
  
  public void doPost(HttpServletRequest req, HttpServletResponse resp)
    throws ServletException, IOException
  {
    PrintWriter out = null;
    resp.setContentType("text/html");
    out = new PrintWriter(resp.getOutputStream());
    String handleStr = decodeURLIgnorePlus(req.getParameter("hdl"));
    try {
      byte handle[] = Util.encodeString(handleStr);
      ResolutionRequest rReq = new ResolutionRequest(handle,
                                                     null,null, null);
      
      rReq.authoritative = true;
      AbstractResponse response = resolver.processRequest(rReq);
      printHtmlResponse(response, out);
    }catch(HandleException e){
      out.println("FAILURE: "+handleStr+": "+e);
    }
    
    try { out.flush(); } catch (Exception e) {}
    try { out.close(); } catch (Exception e) {}
  }

  private static final void printHtmlField(String name, String value, Writer out)
    throws IOException
  {
    out.write("<tr><th align=RIGHT>");
    out.write(htmlEscape(name));
    out.write(":</th><td>");
    out.write(htmlEscape(value));
    out.write("</td></tr>\n");
  }

  private static final String htmlEscape(String str) {
    if(str==null) return "null";
    if(str.indexOf('<') < 0) return str;
    StringBuffer sb = new StringBuffer("");
    int sz = str.length();
    int idx = 0;
    for(int i=0; i<sz; i++) {
      char ch = str.charAt(i);
      if(ch=='<')
        sb.append("&lt;");
      else if(ch=='>')
        sb.append("&gt;");
      else if(ch=='"')
        sb.append("&quot;");
      else
        sb.append(ch);
    }
    return sb.toString();
  }
    

  private static final void printHtmlResponse(AbstractResponse resp, Writer out)
    throws IOException
  {
    if(resp instanceof ErrorResponse){
      out.write("<HTML><BODY bgcolor=\"#eeeeee\" onLoad=\""+DEFAULT_PAGE+"\"><center><table>\n");
      printHtmlField("Request ID", String.valueOf(resp.requestId), out);
      printHtmlField("Session ID", String.valueOf(resp.sessionId), out);
      printHtmlField("Op. Code", String.valueOf(resp.opCode), out);
      printHtmlField("Response Code", AbstractMessage.getResponseCodeMessage(resp.responseCode)+
                     " ("+resp.responseCode+")", out);
      printHtmlField("Site Info Serial#", String.valueOf(resp.siteInfoSerial), out);
      printHtmlField("Msg. Expiration", String.valueOf(new java.util.Date(resp.expiration*1000)), out);
      printHtmlField("Msg. Expiration (seconds)", String.valueOf(resp.expiration), out);
      printHtmlField("Recursion Count", String.valueOf(resp.recursionCount), out);
	
      StringBuffer options = new StringBuffer();
      options.append("certify=");
      options.append(resp.certify);
      options.append(";  cacheCertify=");
      options.append(resp.cacheCertify);
      options.append(";  authoritative=");
      options.append(resp.authoritative);
      options.append(";  encrypt=");
      options.append(resp.encrypt);
      options.append(";  ignore-restricted-values=");
      options.append(resp.ignoreRestrictedValues);
	
      options.append(";  recursive=");
      options.append(resp.recursive);
      options.append(";  continuous=");
      options.append(resp.continuous);
      options.append(";  keep-alive=");
      options.append(resp.keepAlive);
      printHtmlField("Options", options.toString(), out);
    }
    
    else if(resp instanceof ResolutionResponse) {
      ResolutionResponse rresp = (ResolutionResponse)resp;
      String handle = Util.decodeString(rresp.handle);
      String durl =null;
      try{
        HandleValue[] values=rresp.getHandleValues();
        for(int i=0; i<values.length; i++)
          if(values[i].hasType(Common.STD_TYPE_URL)){
            durl = Util.decodeString(values[i].getData());
            break;
          }
        if(durl==null){
          out.write("<HTML><BODY bgcolor=\"#eeeeee\" onLoad=\""+DEFAULT_PAGE+"\"><center>"+
                    "<basefont size=2><table cellspacing=1>\n");
        } else {
          out.write("<HTML><BODY bgcolor=\"#eeeeee\""+
                    "onLoad=\"parent.qdisplay.location.href='"+durl+
                    "';top.qstatus.document.open()"+
                    ";top.qstatus.document.write('<html><body bgcolor=f0f0f0> loaded URL="+durl+
                    "<br></body></html>');top.qstatus.document.close()\"><center>"+
                  "<basefont size=2><table cellspacing=1>\n");
        }
        out.write("<tr><th>&nbsp;</th></tr>\n");
        out.write("<tr><th colspan=3 align=\"left\">Handle Values for: "+
                  handle+"</th></tr>\n");
        out.write("<tr><th>&nbsp;</th></tr>\n");
        out.write("<tr bgcolor=\"#bbbbbb\"><th>Type</th><th align=\"left\">Value</th></tr>\n");

        for(int i=0; values!=null && i<values.length; i++) {
          String dataStr = (values[i].getData()==null?"":(Util.looksLikeBinary(values[i].getData())?
                                                     Util.decodeHexString(values[i].getData(),false):new String(values[i].getData())));
          String typeStr = (values[i].getType()==null?"":new String(values[i].getType()));

          if(i%2==0)
            out.write("<tr bgcolor=\"#dddddd\"><td align=CENTER>"+typeStr+"</td>");
          else
            out.write("<tr bgcolor=\"#cccccc\"><td align=CENTER>"+typeStr+"</td>");
          
          if(values[i].hasType(Common.STD_TYPE_URL))//URL
            out.write("<td><a href=\""+ dataStr+"\" onClick=\"top.qstatus.document.open()"+
                      ";top.qstatus.document.write('<html><body bgcolor=dedede> loaded URL="+dataStr+
                      "<br> </body></html>');top.qstatus.document.close()\" target=\"qdisplay\" >"+
                      dataStr+"</a></td></tr>\n");
          else if(values[i].hasType(Common.STD_TYPE_EMAIL))//EMAIL
            out.write("<td><a href=\"mailto:"+ dataStr+"\">"+dataStr+"</a></td></tr>\n");
          else out.write("<td>"+values[i]+"</td></tr>\n");
        }
      } catch (HandleException e) {
        printHtmlField("ERROR", "Invalid Response: "+String.valueOf(e), out);
      }
    }
    
    
    out.write("</TABLE>");
    out.write("</BODY></HTML>");
  }
    
  /**
   * decodes the special characters in a URL encoded string *except* for
   * the + to space conversion.
   */
  public static String decodeURLIgnorePlus(String str)
    throws UTFDataFormatException
  {
    byte utf8Buf[] = new byte[str.length()];
    int utf8Loc = 0;
    int strLoc = 0;
    int strLen = str.length();
    while(strLoc < strLen) {
      char ch = str.charAt(strLoc++);
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str.charAt(strLoc++),
                                           str.charAt(strLoc++));
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }
    
    if(!Util.isValidString(utf8Buf, 0, utf8Loc)) {
      throw new UTFDataFormatException("Invalid UTF-8 encoding: "+str);
    }
    
    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    }
  }
  
  public static final byte decodeHexByte(char ch1, char ch2) {
    ch1 = (char) ((ch1>='0' && ch1<='9') ? ch1-'0' : ((ch1>='a' && ch1<='z') ? ch1-'a'+10 : ch1-'A'+10));
    ch2 = (char) ((ch2>='0' && ch2<='9') ? ch2-'0' : ((ch2>='a' && ch2<='z') ? ch2-'a'+10 : ch2-'A'+10));
    return (byte)(ch1<<4 | ch2);
  }
}
