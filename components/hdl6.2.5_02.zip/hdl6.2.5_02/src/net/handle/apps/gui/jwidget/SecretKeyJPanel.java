/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.gui.jwidget;

import net.handle.apps.gui.jutil.*;

import net.handle.awt.*;
import net.handle.hdllib.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class SecretKeyJPanel extends JPanel
{
    private JTextField userIdHandleField;
    private JTextField userIdIndexField;
    private JPasswordField passwordField;

    public SecretKeyJPanel(){
	
	super(new GridBagLayout());	
	String s = HDLToolConfig.table.getStr("SecIndex", "300");
	userIdIndexField = new JTextField("300",5);
	userIdIndexField.setToolTipText("Input handle value index");
	s = HDLToolConfig.table.getStr("SecHandle", "");
	userIdHandleField = new JTextField(s, 25);
	userIdHandleField.setScrollOffset(0);
	userIdHandleField.setToolTipText("Input handle name");
       
	passwordField = new JPasswordField("", 30);
	passwordField.setScrollOffset(0);
	passwordField.setToolTipText("Input the secret key");
	int x=0; int y=0;
	add(new JLabel(" ID Handle: ",JLabel.RIGHT),
	    AwtUtil.getConstraints(x,y,0,0,1,1,true,true));
	add(userIdHandleField,
	    AwtUtil.getConstraints(x+1,y++,1,1,1,1,true,false));
	add(new JLabel(" ID Index: ",JLabel.RIGHT),
	    AwtUtil.getConstraints(x,y,0,0,1,1,true,true));
	add(userIdIndexField,
	    AwtUtil.getConstraints(x+1,y++,0,1,1,1, new Insets(1,1,1,30),
				   GridBagConstraints.WEST,
				   false,false));
	add(new JLabel(" Secret Key: ",JLabel.RIGHT),
	    AwtUtil.getConstraints(x,y,0,0,1,1,true,true));
	add(passwordField,
	    AwtUtil.getConstraints(x+1,y++,0,0,2,1,true,true));
    }

    public void setUserIdHandle(String newHandle) {
	userIdHandleField.setText(newHandle);
    }
    public void setUserIdIndex(int newIndex) {
	userIdIndexField.setText(String.valueOf(newIndex));
    }
    public String getUserIdHandle() {
	return userIdHandleField.getText().trim();
    }
    public int getUserIdIndex() {
	try {
	    return Integer.parseInt(userIdIndexField.getText().trim());
	}catch(Exception e){
	    return -1;
	}
    }
    
    public char[] getSecretKey() {
	return passwordField.getPassword();
    }
    
    public String getSecretKeyStr(){
	return (new String(passwordField.getPassword()));
    }
   
    public static void main(String[] args){
	JFrame f = new JFrame();
	Container c = f.getContentPane();
	c.add(new SecretKeyJPanel());
	f.setSize(500,500);
	f.pack();
	f.setVisible(true);
    }
}

