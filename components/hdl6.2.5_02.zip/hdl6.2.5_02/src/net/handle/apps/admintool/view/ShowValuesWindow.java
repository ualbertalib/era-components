/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import net.handle.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;
import java.security.PrivateKey;

public class ShowValuesWindow
  extends JFrame
  implements ActionListener,
             MouseListener,
             ViewConstants
{
  private int mode = VIEW_HDL_MODE;
  private String handle = null;
  private HandleValue originalValues[] = null;
  private DefaultListModel valuesListModel;
  private JList valuesList;
  private AdminToolUI ui;
  
  private JPanel modValPanel;
  private JButton copyButton;
  private JButton doneButton;
  private JButton cancelButton;
  private JButton editValButton;
  private JLabel sigStatusLabel;
  
  private JButton addValButton;
  private JButton delValButton;
  private JButton editHdlButton;
  private boolean canceled = true;
  
  public ShowValuesWindow(AdminToolUI ui) {
    super("Show Handle Values");
    this.ui = ui;
    
    setJMenuBar(ui.getAppMenu());
    
    valuesListModel = new DefaultListModel();
    valuesList = new JList(valuesListModel);
    valuesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    valuesList.setCellRenderer(new HandleValueRenderer());
    doneButton = new JButton(ui.getStr("ok"));
    cancelButton = new JButton(ui.getStr("cancel"));
    editValButton = new JButton(ui.getStr("edit_val_button"));
    addValButton = new JButton(ui.getStr("add_val_button"));
    delValButton = new JButton(ui.getStr("remove_val_button"));
    editHdlButton = new JButton(ui.getStr("edit_hdl_button"));
    copyButton = new JButton(ui.getStr("copy_hdl_button"));
    sigStatusLabel = new JLabel(" ");
    
    JPanel p = new JPanel(new GridBagLayout());
    p.add(new JScrollPane(valuesList),
          AwtUtil.getConstraints(0,0,1,1,5,1,new Insets(0,0,0,0),true,true));
    modValPanel = new JPanel(new GridBagLayout());
    modValPanel.add(addValButton,
                    AwtUtil.getConstraints(0,0,0,0,1,1,new Insets(0,0,0,10),false,false));
    modValPanel.add(editValButton,
                    AwtUtil.getConstraints(1,0,0,0,1,1,new Insets(0,0,0,10),false,false));
    modValPanel.add(delValButton,
                    AwtUtil.getConstraints(2,0,0,0,1,1,new Insets(0,0,0,10),false,false));
    p.add(modValPanel,
          AwtUtil.getConstraints(0,1,0,0,1,1,new Insets(10,10,10,10),true,true));
    p.add(editHdlButton,
          AwtUtil.getConstraints(0,1,0,0,1,1,new Insets(10,10,10,0),false,false));
    p.add(copyButton,
          AwtUtil.getConstraints(1,1,0,0,1,1,new Insets(10,10,10,10),false,false));
    p.add(sigStatusLabel,
          AwtUtil.getConstraints(2,1,1,0,1,1,new Insets(10,10,10,10),true,true));
    p.add(cancelButton,
          AwtUtil.getConstraints(3,1,0,0,1,1,new Insets(10,10,10,0),false,false));
    p.add(doneButton,
          AwtUtil.getConstraints(4,1,0,0,1,1,new Insets(10,10,10,10),false,false));
    
    getContentPane().add(p);
    
    cancelButton.addActionListener(this);
    doneButton.addActionListener(this);
    editValButton.addActionListener(this);
    addValButton.addActionListener(this);
    delValButton.addActionListener(this);
    editHdlButton.addActionListener(this);
    copyButton.addActionListener(this);
    valuesList.addMouseListener(this);
    
    getRootPane().setDefaultButton(doneButton);

    setSize(700, 330);
  }

  public void mousePressed(MouseEvent evt) {}
  public void mouseReleased(MouseEvent evt) {}
  public void mouseExited(MouseEvent evt) {}
  public void mouseEntered(MouseEvent evt) {}
  public void mouseClicked(MouseEvent evt) {
    if(evt.getClickCount()>=2 && (mode==EDIT_HDL_MODE || mode==CREATE_HDL_MODE)) {
      editValue();
    }
  }

  private void revert() {
    this.setValues(this.handle, this.originalValues, this.mode);
  }

  private boolean performOperation(String opName, AbstractRequest req) {
    AuthenticationInfo auth = ui.getAuthentication(false);
    if(auth==null) return false;
    req.authInfo = auth;
    
    try {
      AbstractResponse resp = ui.getMain().getResolver().processRequest(req);
      if(resp==null || resp.responseCode!=AbstractMessage.RC_SUCCESS) {
        JOptionPane.showMessageDialog(this, "The '"+opName+"' operation"+
                                      " was not successful.  Response was: "+resp);
        return false;
      } else {
        return true;
      }
    } catch (Exception e) {
      e.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this, "There was an error processing the"+
                                    " '"+opName+"' operation.\n\nMessage: "+e);
      return false;
    }
  }
  
  private void deleteValue() {
    int selectedIdx = valuesList.getSelectedIndex();
    if(selectedIdx<0) return;

    HandleValue val = (HandleValue)valuesListModel.getElementAt(selectedIdx);
    if(val==null) return;

    if(JOptionPane.YES_OPTION==
       JOptionPane.showConfirmDialog(this,
                                     "Are you sure you would like to delete the selected value?",
                                     "Delete Confirmation",
                                     JOptionPane.YES_NO_OPTION,
                                     JOptionPane.QUESTION_MESSAGE)) {
      if(mode==EDIT_HDL_MODE) {
        if(performOperation("remove value",
                            new RemoveValueRequest(Util.encodeString(this.handle),
                                                   val.getIndex(),
                                                   null))) {
          valuesListModel.removeElementAt(selectedIdx);
        }
      } else {
        valuesListModel.removeElementAt(selectedIdx);
      }
    }
  }

  private void editValue() {
    int selIdx = valuesList.getSelectedIndex();
    if(selIdx<0) return;
    HandleValue valueToEdit = (HandleValue)valuesListModel.getElementAt(selIdx);
    if(valueToEdit==null) return;
    
    HandleValue originalValue = valueToEdit;
    valueToEdit = originalValue.duplicate();
    
    EditValueWindow editWin = new EditValueWindow(ui, this);
    editWin.loadValueData(valueToEdit, false);
    AwtUtil.setWindowPosition(editWin, this);

    while(true) {
      editWin.setVisible(true);
      if(editWin.wasCanceled())
        break;
      
      if(editWin.saveValueData(valueToEdit)) {
        if(mode==EDIT_HDL_MODE) { // actually save the modified value
          if(performOperation("edit value",
                              new ModifyValueRequest(Util.encodeString(this.handle),
                                                      valueToEdit, null))) {
            valuesListModel.setElementAt(valueToEdit, selIdx);
            valuesList.repaint();
            break;
          }
        } else {
          valuesListModel.setElementAt(valueToEdit, selIdx);
          valuesList.repaint();
          break;
        }
      }
    }
  }
  
  private void addValue() {
    HandleValue newValue = new HandleValue();
    newValue.setIndex(getNextUnusedIndex(1));
    addValue(newValue);
  }

  public int getNextUnusedIndex(int firstIdx) {
    int nextIdx = firstIdx-1;
    boolean duplicate = true;
    while(duplicate) {
      nextIdx++;
      duplicate = false;
      for(int i=valuesListModel.getSize()-1; i>=0; i--) {
        HandleValue val = (HandleValue)valuesListModel.getElementAt(i);
        if(val!=null && val.getIndex()==nextIdx) {
          duplicate = true;
          break;
        }
      }
    }
    return nextIdx;
  }

  private void addValue(HandleValue newValue) {
    EditValueWindow editWin = new EditValueWindow(ui, this);
    editWin.setTitle("Add Handle Value");
    editWin.loadValueData(newValue, true);
    AwtUtil.setWindowPosition(editWin, this);
    while(true) {
      editWin.setVisible(true);
      if(editWin.wasCanceled())
        break;

      if(!editWin.saveValueData(newValue))
        continue;
      
      if(mode==EDIT_HDL_MODE) { // actually save the modified value
        if(performOperation("add value",
                            new AddValueRequest(Util.encodeString(this.handle),
                                                newValue, null))) {
          valuesListModel.addElement(newValue);
          break;
        }
      } else {
        valuesListModel.addElement(newValue);
        break;
      }
    }
  }
  
  public void setValues(String handle, HandleValue values[], int mode) {
    this.originalValues = values;
    this.mode = mode;
    this.handle = handle;
    
    valuesListModel.removeAllElements();
    for(int i=0; values!=null && i<values.length; i++)
      valuesListModel.addElement(values[i].duplicate());

    if(mode==CREATE_HDL_MODE) {
      setTitle("Create Handle: "+handle);
      doneButton.setText(ui.getStr("create_hdl_button"));
      cancelButton.setVisible(true);
      editHdlButton.setVisible(false);
      //copyButton.setVisible(true);
      modValPanel.setVisible(true);
      modValPanel.setEnabled(true);
    } else if(mode==EDIT_HDL_MODE) {
      setTitle("Edit Handle: "+handle);
      doneButton.setText(ui.getStr("dismiss"));
      cancelButton.setVisible(false);
      editHdlButton.setVisible(false);
      //copyButton.setVisible(true);
      modValPanel.setVisible(true);
      modValPanel.setEnabled(true);
    } else if(mode==VIEW_HDL_MODE) {
      setTitle("View Handle: "+handle);
      doneButton.setText(ui.getStr("dismiss"));
      cancelButton.setVisible(false);
      //copyButton.setVisible(true);
      editHdlButton.setVisible(true);
      modValPanel.setVisible(false);
      modValPanel.setEnabled(false);
    } else {
      setTitle("????: "+handle);
      doneButton.setText("????");
      cancelButton.setVisible(true);
      //copyButton.setVisible(false);
      editHdlButton.setVisible(false);
      modValPanel.setVisible(false);
      modValPanel.setEnabled(false);
    }
  }

  private void cancelButtonPressed() {
    canceled = true;
    setVisible(false);
  }
  
  private void doneButtonPressed() {
    if(mode==CREATE_HDL_MODE) {
      HandleValue values[] = new HandleValue[valuesListModel.getSize()];
      for(int i=0; i<values.length; i++) {
        values[i] = (HandleValue)valuesListModel.getElementAt(i);
      }
      
      boolean success = 
        performOperation("create handle",
                         new CreateHandleRequest(Util.encodeString(this.handle),
                                                 values, null));
      if(success) {
        JOptionPane.showMessageDialog(this, "The handle '"+this.handle+"' "+
                                      " was created!");
        setVisible(false);
      }
    } else if(mode==EDIT_HDL_MODE) {
      // values are added/deleted/modified individually
      // so nothing needs to be done here
      setVisible(false);
    } else if(mode==VIEW_HDL_MODE) {
      canceled = false;
      setVisible(false);
    }
  }
  
  public void actionPerformed(ActionEvent evt) {
    Object src = evt.getSource();
    if(src==doneButton) {
      doneButtonPressed();
    } else if(src==cancelButton) {
      cancelButtonPressed();
    } else if(src==delValButton) {
      deleteValue();
    } else if(src==editValButton) {
      editValue();
    } else if(src==addValButton) {
      showAddValuePopup();
    } else if(src==editHdlButton) {
      String hdl = handle;
      if(ui.getMainWindow().editHandle(hdl))
        cancelButtonPressed();
    } else if(src==copyButton) {
      String newHdlStr = JOptionPane.showInputDialog(ui.getStr("copy_hdl_prompt"));
      if(newHdlStr==null) return;
      MainWindow.ActionHandler handler =
        (ui.getMainWindow()).new ActionHandler(MainWindow.ActionHandler.CREATE_ACTION,
                                               newHdlStr);
      HandleValue newValues[] = new HandleValue[valuesListModel.getSize()];
      for(int i=0; i<newValues.length; i++)
        newValues[i] = (HandleValue)valuesListModel.getElementAt(i);
      handler.setValues(newValues);
      handler.performAction();
    }
  }

  private void addSignature() {
    PrivateKey privKey = null;
    String handle = null;
    
    PublicKeyAuthenticationInfo sigInfo = ui.getSignatureInfo(false);
    
    if(sigInfo!=null) {
      
      
    }
  }
  
  private void addValueWithParams(int idx, byte valType[], byte valData[]) {
    HandleValue newValue = new HandleValue();
    newValue.setType(valType);
    newValue.setData(valData);
    newValue.setIndex(getNextUnusedIndex(idx));
    addValue(newValue);
  }
  
  
  private HDLAction addURLAction = 
    new HDLAction(ui, "add_url_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addValueWithParams(1, Common.STD_TYPE_URL,
                           Util.encodeString("http://example.com/"));
      }
    });
  
  private HDLAction addEmailAction = 
    new HDLAction(ui, "add_email_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addValueWithParams(1, Common.STD_TYPE_EMAIL,
                           Util.encodeString("you@example.com"));
      }
    });
  
  private HDLAction addAdminAction =
    new HDLAction(ui, "add_admin_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        AdminRecord adminInfo = new AdminRecord();
        String hdl = handle;
        if(hdl==null) hdl = "0.NA/test";
        byte hdlBytes[] = Util.encodeString(handle);
        adminInfo.adminId = Util.getNAHandle(hdlBytes);
        adminInfo.adminIdIndex = 200;
        adminInfo.perms[AdminRecord.DELETE_HANDLE] = true;
        adminInfo.perms[AdminRecord.ADD_VALUE] = true;
        adminInfo.perms[AdminRecord.REMOVE_VALUE] = true;
        adminInfo.perms[AdminRecord.MODIFY_VALUE] = true;
        adminInfo.perms[AdminRecord.READ_VALUE] = true;
        adminInfo.perms[AdminRecord.ADD_ADMIN] = true;
        adminInfo.perms[AdminRecord.REMOVE_ADMIN] = true;
        adminInfo.perms[AdminRecord.MODIFY_ADMIN] = true;
        adminInfo.perms[AdminRecord.ADD_HANDLE] = true;
        adminInfo.perms[AdminRecord.LIST_HANDLES] = false;
        adminInfo.perms[AdminRecord.ADD_NAMING_AUTH] = false;
        adminInfo.perms[AdminRecord.DELETE_NAMING_AUTH] = false;
        
        addValueWithParams(100, Common.STD_TYPE_HSADMIN,
                           Encoder.encodeAdminRecord(adminInfo));
      }
    });
  
  private HDLAction addBlankAction =
    new HDLAction(ui, "add_blank_val", "", new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        addValueWithParams(1, new byte[0],
                           Util.encodeString(""));
      }
    });
  
  private HDLAction addSigAction =
    new HDLAction(ui, "add_signature", "", new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            addSignature();
          }
    });
  private JPopupMenu addValPopup = null;
  
  private synchronized void showAddValuePopup() {
    if(addValPopup==null) {
      addValPopup = new JPopupMenu();
      addValPopup.add(addURLAction);
      addValPopup.add(addEmailAction);
      addValPopup.add(addAdminAction);
      addValPopup.add(addBlankAction);

      addValPopup.pack();
    } // end addValPopup construction
    
    addValPopup.show(addValButton, 0, 0-addValPopup.getPreferredSize().height);
  }
  
}
