/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.apps.admintool.view.resources.Resources;
import net.handle.apps.admintool.controller.*;
import net.handle.hdllib.*;
import net.handle.awt.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.ResourceBundle;
import java.util.Locale;
import java.util.Hashtable;
import java.io.*;

public class AdminToolUI {
  private Main main = null;
  private AdminToolUI ui = null;
  private Resources resources = null;
  private MainWindow mainWin = null;
  private BatchRunnerWindow batchWin = null;
  private Console consoleWin = null;
  private AuthenticationInfo authInfo = null;
  private PublicKeyAuthenticationInfo sigInfo = null;
  private Hashtable imageCache = new Hashtable();

  public static boolean isMacOSX = false;
  private HDLAction openBatchFileAction;
  private HDLAction clearCacheAction;
  private HDLAction authenticateAction;
  private HDLAction shutdownAction;
  private HDLAction showBatchAction;
  private HDLAction showConsoleAction;
  private HDLAction showHomingAction;
  
  public AdminToolUI(Main main) {
    this.main = main;
    this.ui = this;

    String osName = System.getProperty("os.name", "");
    isMacOSX = osName.toUpperCase().indexOf("MAC OS X")>=0;
    
    resources = (Resources)ResourceBundle.
      getBundle("net.handle.apps.admintool.view.resources.Resources",
                Locale.getDefault());
    
    openBatchFileAction = 
      new HDLAction(ui, "open_batch_file", "Meta-B", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          openBatchFile();
        }
      });
    
    clearCacheAction = 
      new HDLAction(ui, "clear_cache", "", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          getMain().clearHandleCache();
          JOptionPane.showMessageDialog(null, ui.getStr("cache_cleared_msg"),
                                        "Error", JOptionPane.INFORMATION_MESSAGE);
        }
      });
    
    authenticateAction = 
      new HDLAction(ui, "authenticate", "", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          getAuthentication(true);
        }
      });
    
    shutdownAction =
      new HDLAction(ui, "quit", "", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          shutdown();
        }
      });
    
    showBatchAction =
      new HDLAction(ui, "batch_processor", "", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          showBatchProcessor();
        }
      });
    
    showConsoleAction =
      new HDLAction(ui, "console", "", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          showConsoleWindow();
        }
      });
    
    
    showHomingAction =
      new HDLAction(ui, "home_unhome_prefix", "", new ActionListener() {
        public void actionPerformed(ActionEvent evt) {
          showHomeUnhomeWindow();
        }
      });
    
  }
  
  
  /** Return the current authentication information, if any.  If no authentication
    * information has been provided then this returns null. */
  public PublicKeyAuthenticationInfo getSignatureInfo(boolean changeInfo) {
    if(sigInfo!=null && !changeInfo) return sigInfo;
    /*
    try {
      GetSigKeyWindow sigWin = new GetSigKeyWindow(mainWin);
      sigWin.setVisible(true);
      AuthenticationInfo tmpAuth = sigWin.getSignatureInfo();
      if(tmpAuth==null) {
        return changeInfo ? null : sigInfo;
      }
      if(tmpAuth!=null) {
        try {
          CheckAuthentication checkAuth = new CheckAuthentication(tmpAuth);
          TaskIndicator ti = new TaskIndicator(null);
          ti.invokeTask(checkAuth, "Checking Authentication ...");
          if(checkAuth.wasSuccessful()) {
            authInfo = tmpAuth;
            ClientSessionTracker sessionTracker = new ClientSessionTracker();
            sessionTracker.setSessionSetupInfo(new SessionSetupInfo(authInfo));
            main.getResolver().setSessionTracker(sessionTracker);
            return authInfo;
          } else {
            String msg;
            String errorMsg = checkAuth.getErrorMessage();
            if(errorMsg==null) {
              msg = "Authentication failed";
            } else {
              msg = "Authentication failed: "+errorMsg;
            }
            // System.err.print("showing error message ");
            JOptionPane.showMessageDialog(null, msg,
                                          "Error", JOptionPane.ERROR_MESSAGE);
            return null;
          }
        } catch (Throwable t) {
          JOptionPane.showMessageDialog(null,
                                        "Error: "+ t.getMessage(),
                                        "Error", 
                                        JOptionPane.ERROR_MESSAGE);
          return null;
        }
      }
    } finally {
      if(mainWin!=null)
        mainWin.authenticationChanged(authInfo);
    }
     */
    return sigInfo;
  }
  
  public synchronized AuthenticationInfo getAuthentication(boolean changeAuthentication) {
    if(authInfo!=null && !changeAuthentication) return authInfo;
    
    try {
      AuthWindow authWin = new AuthWindow(mainWin);
      authWin.setVisible(true);
      AuthenticationInfo tmpAuth = authWin.getAuthentication();
      if(tmpAuth==null) {
        return changeAuthentication ? null : authInfo;
      }
      if(tmpAuth!=null) {
        try {
          CheckAuthentication checkAuth = new CheckAuthentication(tmpAuth);
          TaskIndicator ti = new TaskIndicator(null);
          ti.invokeTask(checkAuth, "Checking Authentication ...");
          if(checkAuth.wasSuccessful()) {
            authInfo = tmpAuth;
            ClientSessionTracker sessionTracker = new ClientSessionTracker();
            sessionTracker.setSessionSetupInfo(new SessionSetupInfo(authInfo));
            main.getResolver().setSessionTracker(sessionTracker);
            return authInfo;
          } else {
            String msg;
            String errorMsg = checkAuth.getErrorMessage();
            if(errorMsg==null) {
              msg = "Authentication failed";
            } else {
              msg = "Authentication failed: "+errorMsg;
            }
            // System.err.print("showing error message ");
            JOptionPane.showMessageDialog(null, msg,
                                          "Error", JOptionPane.ERROR_MESSAGE);
            return null;
          }
        } catch (Throwable t) {
          JOptionPane.showMessageDialog(null,
                                        "Error: "+ t.getMessage(),
                                        "Error", 
                                        JOptionPane.ERROR_MESSAGE);
          return null;
        }
      }
    } finally {
      if(mainWin!=null)
        mainWin.authenticationChanged(authInfo);
    }
    return authInfo;
  }
  
  public MainWindow getMainWindow() { return mainWin; }
  public Main getMain() { return main; }

  public synchronized void go() {
    if(mainWin==null) {
      mainWin = new MainWindow(this);
    }
    mainWin.setVisible(true);
    mainWin.toFront();
  }

  public final String getStr(String key) {
    return resources.getString(key);
  }

  public ImageIcon getIcon(String iconPath) {
    if(imageCache.containsKey(iconPath))
      return (ImageIcon)imageCache.get(iconPath);
    
    try {
      java.net.URL imgURL = getClass().getResource(iconPath);
      if(imgURL==null) return null;
      Image img = Toolkit.getDefaultToolkit().getImage(imgURL);
      if(img==null) return null;

      ImageIcon icon = new ImageIcon(img);
      imageCache.put(iconPath, icon);
      return icon;
    } catch (Exception e) {}

    if(imageCache.containsKey("BLANK")) {
      return (ImageIcon)imageCache.get("BLANK");
    } else {
      ImageIcon icon = new ImageIcon();
      imageCache.put("BLANK", icon);
      return icon;
    }
  }

  synchronized void clearConsole() {
    if(consoleWin!=null) {
      consoleWin = null;
    }
  }

  public synchronized void showConsoleWindow() {
    if(consoleWin==null) {
      consoleWin = new Console(this);
    }
    consoleWin.setVisible(true);
    consoleWin.toFront();
  }
  
  public void shutdown() {
    System.exit(0);
  }

  public synchronized void showHomeUnhomeWindow() {
    HomePrefixWindow hpw = new HomePrefixWindow(this);
    hpw.setVisible(true);
    hpw.toFront();
  }
  
  public synchronized void showBatchProcessor() {
    if(batchWin==null || batchWin.isRunning()) {
      batchWin = new BatchRunnerWindow(this);
    }
    batchWin.setVisible(true);
    batchWin.toFront();
  }
  
  public synchronized void openBatchFile() {
    showBatchProcessor();
    batchWin.addBatchFile();
  }

  private class CheckAuthentication
    implements Runnable
  {
    private AuthenticationInfo authInfo = null;
    private boolean success = false;
    private String errorMessage = null;
    
    CheckAuthentication(AuthenticationInfo authInfo) {
      this.authInfo = authInfo;
    }

    public boolean wasSuccessful() { return success; }
    public String getErrorMessage() { return errorMessage; }
    
    public void run() {
      this.success = false;
      try {
        this.success = new AuthenticationUtil(getMain().getResolver()).checkAuthentication(authInfo);
      } catch (Exception e) {
        this.errorMessage = String.valueOf(e);
        e.printStackTrace(System.err);
      }
    }
  }

  private static final boolean AWT_MENU = false;
  public JMenuBar getAppMenu() {
    JMenuBar menuBar = new JMenuBar();
    JMenu fileMenu, toolsMenu;
    menuBar.add(fileMenu = new JMenu(new HDLAction(ui, "file", null, null)));
    menuBar.add(toolsMenu = new JMenu(new HDLAction(ui, "tools", null, null)));
    
    fileMenu.add(openBatchFileAction);
    fileMenu.add(clearCacheAction);
    fileMenu.add(authenticateAction);
    
    if(!isMacOSX) {
      fileMenu.addSeparator();
      fileMenu.add(shutdownAction);
    }
    
    toolsMenu.add(showBatchAction);
    toolsMenu.add(showConsoleAction);
    toolsMenu.add(showHomingAction);
    return menuBar;
  }
      

}
