/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.controller;

import net.handle.apps.admintool.view.*;
import net.handle.hdllib.*;

public class Main {
  private static final String VERSION_STRING = "2.0";
  private HandleResolver resolver = null;
  private AdminToolUI ui = null;
  
  public Main() {
    System.setProperty("com.apple.macos.useScreenMenuBar", "true");
    System.setProperty("apple.laf.useScreenMenuBar", "true");
    
    resolver = new HandleResolver();
    resolver.traceMessages = true;
    resolver.setCache(new MemCache());
    
    // TODO: add code to load/save preferences
  }

  public String getVersion() {
    return VERSION_STRING;
  }

  public HandleResolver getResolver() {
    return resolver;
  }

  /** Sends the given request to the handle system and returns the response. */
  public AbstractResponse sendMessage(AbstractRequest req)
    throws HandleException
  {
    //req.certify = true;
    return resolver.processRequest(req, null);
  }

  public void clearHandleCache() {
    this.resolver.setCache(new MemCache());
  }
  
  synchronized final void go() {
    if(ui==null) ui = new AdminToolUI(this);
    ui.go();
  }

  public static void main(String argv[]) {
    Main m = new Main();
    m.go();
  }

}
