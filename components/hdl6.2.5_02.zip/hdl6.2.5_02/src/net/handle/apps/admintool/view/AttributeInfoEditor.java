/**********************************************************************\
© COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
All rights reserved.

The HANDLE.NET software is made available subject to the
Handle System Public License, which may be obtained at
http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import net.handle.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AttributeInfoEditor
  extends JPanel
{
  private AdminToolUI ui;
  private JTextField keyField;
  private JTextField valField;
  
  public AttributeInfoEditor(AdminToolUI ui) {
    super(new GridBagLayout());
    this.ui = ui;
  
    keyField = new JTextField("", 15);
    valField = new JTextField("", 30);

    int y=0;
    add(new JLabel(ui.getStr("attribute_name")+":", JLabel.RIGHT),
        AwtUtil.getConstraints(0,y,0,0,1,1,new Insets(5,5,5,0),true,false));	
    add(keyField,
        AwtUtil.getConstraints(1,y++,1,0,1,1,new Insets(5,5,5,5),true,false));	
    add(new JLabel(ui.getStr("attribute_value")+":", JLabel.RIGHT),
        AwtUtil.getConstraints(0,y,0,0,1,1,new Insets(5,5,5,0),true,false));	
    add(valField,
        AwtUtil.getConstraints(1,y++,1,0,1,1,new Insets(5,5,5,5),true,false));	
  }
  
  public void loadAttribute(Attribute attribute) {
    if(attribute==null) {
      keyField.setText("");
      valField.setText("");
    } else {
      keyField.setText(attribute.name==null ? "" : Util.decodeString(attribute.name));
      valField.setText(attribute.value==null ? "" : Util.decodeString(attribute.value));
    }
  }
  
  public void saveAttribute(Attribute attribute) {
    attribute.name = Util.encodeString(keyField.getText());
    attribute.value = Util.encodeString(valField.getText());
  }
  
}
