/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import net.handle.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
//import java.text.*;
import java.io.*;

public class SecretKeyValueEditor
  extends JPanel
  implements ActionListener,
             HandleValueEditor
{
  private JTextField inputField;
  private JCheckBox shadowBox;
  private JButton editButton;
  
  public SecretKeyValueEditor() {
    super(new GridBagLayout());
    
    inputField = new JTextField();
    shadowBox = new JCheckBox("Use shadow password");
    editButton = new JButton("Change Password");
    
    add(new JLabel("Secret Key: ", SwingConstants.RIGHT),
        AwtUtil.getConstraints(0,0,0,0,1,1,new Insets(4,4,4,4),true,false));
    add(inputField,
        AwtUtil.getConstraints(1,0,1,0,2,1,new Insets(4,4,4,4),true,false));
    add(shadowBox,
        AwtUtil.getConstraints(0,1,0,0,2,1,new Insets(4,4,4,4),
                               GridBagConstraints.WEST,false,false));
    add(editButton,
        AwtUtil.getConstraints(2,1,0,0,1,1,new Insets(4,4,4,4),false,false));
    add(Box.createHorizontalStrut(40),
        AwtUtil.getConstraints(1,2,1,1,1,1,false,false));
    editButton.addActionListener(this);
    //editButton.setVisible(false);
  }
  
  public boolean saveValueData(HandleValue value) {
    try {
      byte seckey[] = Encoder.encodeSecretKey(Util.encodeString(inputField.getText()),
                                              shadowBox.isSelected());
      value.setData(seckey);
      return true;
    } catch (Exception e) {
      JOptionPane.showMessageDialog(this, "Error encoding secret key: "+e);
      return false;
    }
  }
  
  public void loadValueData(HandleValue value) {
    inputField.setText(Util.decodeString(value.getData()));
    inputField.setEditable(false);
    shadowBox.setVisible(false);
    shadowBox.setSelected(false);
    editButton.setVisible(true);
  }
  
  public void actionPerformed(ActionEvent evt) {
    Object src = evt.getSource();
    if(src==editButton) {
      inputField.setEditable(true);
      shadowBox.setVisible(true);
      shadowBox.setSelected(false);
      editButton.setVisible(false);
    }
  }
  

}
