/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import javax.servlet.*;
import javax.servlet.http.*;
import net.handle.hdllib.*;

/** 
* Interface implemented by classes that want to be able to translate handle
* values into responses for handles that include values with a particular
* type or set of types.
*/
public interface TypeHandler {
  
  /** 
  * Return true iff this TypeHandler can send a redirect to the client
  * based on the given set of HandleValues.
  */
  public boolean canRedirect(HandleValue values[]);
  
  /** 
    * Return true iff this TypeHandler can format the data from the given
    * HandleValue for a human client.
    */
  public boolean canFormat(HandleValue value);
  
  /**
   * return a html string suitable for display in response page
   **/
  public String toHTML(String handle, HandleValue value);


  /** 
    * Do redirect here, if need be.  a return value of true indicates
    * that the servlet should not invoke doResponse on any subsequent type
    * handlers.
    **/
  public boolean doRedirect(HDLServletRequest request,
                            HandleValue values[])
    throws Exception;
  
}
