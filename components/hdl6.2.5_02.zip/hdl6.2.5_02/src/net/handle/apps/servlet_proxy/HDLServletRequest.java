/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import net.handle.hdllib.*;
import java.net.URLEncoder;
import javax.servlet.*;
import javax.servlet.http.*;


/** HDLServletRequest contains the handle, parameters, and other information
  * associated with a single handle resolution request. */
public class HDLServletRequest {
  public HttpServlet servlet;
  public HttpServletRequest req;
  public HttpServletResponse response;
  public String hdl = null;
  public HttpParams params = new HttpParams();
  
  private long intime;
  
  HDLServletRequest(HttpServlet servlet, HttpServletRequest req, HttpServletResponse response) {
    intime = System.currentTimeMillis();
    this.servlet = servlet;
    this.req = req;
    this.response = response;
    hdl = req.getRequestURI();
    while(hdl.startsWith("/")) hdl = hdl.substring(1).trim();
  }
  
  /** Remove any prefixes such as hdl: doi: info:doi/ etc. */
  void normalizeHandle() {
    // remove any namespace prefixes
    String lowerHdl = hdl.toLowerCase();
    if(lowerHdl.startsWith("info:doi/") || lowerHdl.startsWith("info:hdl/")) {
      hdl = hdl.substring(9);
    } else if(lowerHdl.startsWith("hdl:") || lowerHdl.startsWith("doi:")) {
      hdl = hdl.substring(4);
    }
  }
  
  
  /** Return the URL from which the request was linked */
  public String getReferer() {
    String ref = req.getHeader("Referer");
    return ref==null ? "" : ref;
  }
  
  
  /** Close the request and response objects and any other resources that may
    * have been used to process the request. */
  void close() {
    try { req.getInputStream().close(); } catch (Exception e) {}
    try { response.getOutputStream().close(); } catch (Exception e) {}
  }
  
  long getResponseTime() {
    return System.currentTimeMillis() - intime;
  }
  
  int[] getRequestedIndices() {
    // parse requested types and indices from http request
    int indices[] = null;
    String s[] = params.getParameterValues("index");
    if (s != null){
      indices = new int[s.length];
      for (int i=0; i<s.length; i++) indices[i] = Integer.parseInt(s[i]);
    }
    return indices;
  }
  
  byte[][] getRequestedTypes(){
    // parse requested types and indices from http request
    byte types[][] = null;
    String s[] = params.getParameterValues("type");
    if (s != null) {
      types = new byte[s.length][];
      for (int i=0; i<s.length; i++) types[i] = Util.encodeString(s[i]);
    }
    return types;
  }
  
  
  public final String getURLForHandle(String handle) {
    String baseURL = getBaseURL();
    try {
      if(baseURL.endsWith("/"))
        return baseURL+URLEncoder.encode(handle, "UTF-8");
      else
        return baseURL+"/"+URLEncoder.encode(handle, "UTF-8");
    } catch (java.io.UnsupportedEncodingException e) {
      System.err.println("Encoding exception in getURLForHandle(): "+e+" handle="+handle);
      return baseURL+"/"+URLEncoder.encode(handle);
    }
  }
  
  /** Get the base URL for this resolver */
  private String getBaseURL() {
    String servletPath = req.getServletPath();
    if(servletPath==null || servletPath.trim().length()<=0)
      servletPath = "/";
    int servletPort = req.getServerPort();
    if(servletPort<0 || servletPort==80) {
      return "http://"+req.getServerName()+req.getServletPath();
    } else {
      return "http://"+req.getServerName()+":"+servletPort+req.getServletPath();
    }
    
  }
  
}


