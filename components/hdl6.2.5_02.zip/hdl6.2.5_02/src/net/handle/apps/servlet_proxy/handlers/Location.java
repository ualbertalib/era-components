/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy.handlers;

import net.handle.apps.servlet_proxy.*;
import net.handle.hdllib.*;
import net.handle.util.StringUtils;
import net.cnri.simplexml.*;
import com.maxmind.geoip.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.util.Random;
import java.util.ArrayList;

public class Location 
  implements TypeHandler
{
  public static final String CHOOSEBY_COUNTRY = "country";
  public static final String CHOOSEBY_WEIGHTED = "weighted";
  public static final String CHOOSEBY_LINKPARAM = "locatt";
  public static final String DEFAULT_CHOOSEBY = "locatt,country,weighted";
  
  public static final byte LOCATION_TYPE[] = Util.encodeString("CNRI.RSRC_LOC");
  
  private XParser parser = new XParser();
  
  private Object lookupInitLock = new Object();
  private boolean lookupServiceInitialized = false;
  private LookupService geoIP = null;
  private Random random = new Random();
  
  
  /** Return the country code that should be used to */
  private String getCountryCode(HDLServletRequest req) {
    String countryCode = req.req.getParameter("override_country");
    if(countryCode!=null) return countryCode;
    
    String ipAddress = req.req.getParameter("override_ip");
    if(ipAddress==null) {
      ipAddress = req.req.getRemoteAddr();
    }
    
    if(!lookupServiceInitialized) {  // first 'if' is non-synchronized for speed
      synchronized (lookupInitLock) {
        if(!lookupServiceInitialized) { // this 'if' is synchronized for safety
          try {
            String dbFile = req.servlet.getInitParameter("geoip_data_file");
            System.err.println("Creating GeoIP LookupService using "+dbFile);
            geoIP = new LookupService(dbFile, 
                                      LookupService.GEOIP_MEMORY_CACHE |
                                      LookupService.GEOIP_CHECK_CACHE);
          } catch (Exception e) {
            System.err.println("Unable to initialize country lookup service: "+e);
            e.printStackTrace(System.err);
          }
          lookupServiceInitialized = true;
        }
      }
    }
    
    
    
    if(geoIP!=null) {
      try {
        Country country = geoIP.getCountry(ipAddress);
        //System.err.println("Got country: "+country.getCode()+" for IP "+ipAddress);
        return country.getCode();
      } catch (Exception e) {
        System.err.println("Error resolving country for request: "+req);
      }
    }
    return null;
  }
  
  
  /** 
  * Return true if the handle values contain a URL value or a value with
  * a sub-type of URL.
  */
  public boolean canRedirect(HandleValue values[]) {
    if(values==null) return false;
    for(int i=values.length-1; i>=0; i--) {
      if(values[i].hasType(LOCATION_TYPE))
        return true;
    }
    return false;
  }
  
  /** 
    * Return true iff this TypeHandler can format the data from the given
    * HandleValue for a human client.
    */
  public boolean canFormat(HandleValue value) { 
    return false;
    //return value!=null && value.hasType(LOCATION_TYPE);
  }
  
  public String toHTML(String handle, HandleValue value){
    // a nicer display would be as a list of links
    return "<pre>"+value.getDataAsString()+"<pre>";
  }
  
  public boolean doRedirect(HDLServletRequest req, HandleValue values[])
    throws Exception
  {
    if(values==null) return false;
    
    for(int i=0; i<values.length; i++) {
      if(values[i].hasType(LOCATION_TYPE)) {
        if(chooseLocationFromValue(req, values[i])) {
          return true;
        }
      }
    }
    return false;
  }
  
  private boolean chooseLocationFromValue(HDLServletRequest req, HandleValue val) 
    throws Exception
  {
    XTag locXML = 
      parser.parse(new StringReader(Util.decodeString(val.getData())), false);
    String chooseBy[] = 
      StringUtils.split(locXML.getStrAttribute("chooseby", DEFAULT_CHOOSEBY),',');
    
    ArrayList locations = new ArrayList();
    for(int i=locXML.getSubTagCount()-1; i>=0; i--) {
      XTag subtag = locXML.getSubTag(i);
      if(!subtag.getName().equalsIgnoreCase("location")) continue;
      locations.add(subtag);
    }
    
    // find appropriate locations according to the chooseby attribute
    for(int i=0; i<chooseBy.length; i++) {
      if(locations.size()<=1) {
        // only one location left, redirect to it
        return sendRedirect(req, ((XTag)locations.get(0)).getStrAttribute("href", null));
      }
      
      String fieldType = chooseBy[i].trim().toLowerCase();
      if(fieldType.length()<=0) continue; // skip blank values
      
      if(fieldType.equals(CHOOSEBY_COUNTRY)) {
        // narrow down the list of choices based on the country in which the
        // caller is located
        String myCountry = null;
        ArrayList countryLocs = new ArrayList();
        for(int v=0; v<locations.size(); v++) {
          XTag loctag = (XTag)locations.get(v);
          String locCountry = loctag.getStrAttribute("country", null);
          if(locCountry!=null && myCountry==null) {
            // lazy lookup of country from IP address
            myCountry = getCountryCode(req);
          }
          if(locCountry!=null && myCountry.equalsIgnoreCase(locCountry.trim())) {
            // the country is specified and matches
            countryLocs.add(loctag);
          } else if(locCountry!=null) {
            // the country is specified, but doesn't match.  Remove it from  
            // consideration for resolution
            locations.remove(v--);
          }
        }
        
        // if there is at least one country match, use it/them
        // if there are no country matches, don't filter by country at all
        if(countryLocs.size()>0) {
          locations = countryLocs;
        }
      } else if(fieldType.equals(CHOOSEBY_LINKPARAM)) {
        // the preferred location(s) are indicated by a parameter in the URI
        String linkParam = req.req.getParameter("locatt");
        if(linkParam!=null) {
          int colIdx = linkParam.indexOf(':');
          String attName = 
            colIdx<0 ? linkParam.trim() : linkParam.substring(0,colIdx).trim();
          String attVal = 
            colIdx<0 ? null : linkParam.substring(colIdx+1);
          ArrayList newlocs = new ArrayList();
          for(int v=0; v<locations.size(); v++) {
            XTag loctag = (XTag)locations.get(v);
            String att = loctag.getAttribute(attName, null);
            if(att!=null) {
              if(attVal==null || (attVal!=null && attVal.equals(att))) {
                newlocs.add(loctag);
              }
            }
          }
          
          
          // if there is at least one attribute match, use it/them
          // if there are no matches, use the whole set
          if(newlocs.size()>0) {
            locations = newlocs;
          }
        }
      } else if(fieldType.equals(CHOOSEBY_WEIGHTED)) {
        sendWeightedRedirect(req, locations);
      }
    }
    
    return sendWeightedRedirect(req, locations);
  }
  
  private boolean sendWeightedRedirect(HDLServletRequest req, ArrayList locations) 
    throws IOException
  {
    if(locations.size()<=0) {
      // no available locations!
      return false;
    }
    
    double totalWeight = 0f;
    for(int i=locations.size()-1; i>=0; i--) {
      double weight = ((XTag)locations.get(i)).getDoubleAttribute("weight", 1f);
      totalWeight += Math.max(0f, weight);
    }
    
    int randIdx = 0;
    if(totalWeight>0) {
      // the items are weighted
      double randVal = random.nextFloat() * totalWeight;
      totalWeight = 0f;
      XTag loc = null;
      for(int i=locations.size()-1; i>=0; i--) {
        loc = (XTag)locations.get(i);
        totalWeight += Math.max(0f, loc.getDoubleAttribute("weight", 1f));
        if(totalWeight>=randVal) {
          String href = loc.getStrAttribute("href", null);
          if(href!=null) return sendRedirect(req, href);
        }
      }
      if(loc!=null) { // shouldn't happen... return the last location
        return sendRedirect(req, loc.getStrAttribute("href", null));
      } else {
        // there were no locations!  can't get here
        return false;
      }
    } else {
      // the items all have zero (or less) weight... rare but might happen
      randIdx = Math.round(Math.abs(random.nextFloat()) * locations.size());
      randIdx = Math.max(0, Math.min(locations.size()-1, randIdx));
      return sendRedirect(req, ((XTag)locations.get(randIdx)).getStrAttribute("href", null));
    }
  }
  
  
  private boolean sendRedirect(HDLServletRequest req, String url)
    throws IOException
  {
    try {
      // don't use sendRedirect(), because it tries to be smart and 
      // occasionally mangles the uri(e.g. on mailto's)
      // response.sendRedirect(url+suffix);
      req.response.setStatus(req.response.SC_MOVED_TEMPORARILY);
      
      req.response.setHeader("Location", url);
      // print out terse page to avoid tomcat's redirect message for
      // things like mailto where a separate viewer is spawned
      // XXX: seems to be ignored by tomcat?
      OutputStreamWriter out = new OutputStreamWriter(req.response.getOutputStream());
      out.write("\n<HTML><HEAD><TITLE>Handle Redirect</TITLE></HEAD>");
      out.write("\n<BODY><A HREF=\""+url+"\">");
      out.write(url+"</A></BODY></HTML>");
      out.close(); 
      return true;
    } catch (Exception e) {
      System.out.println("Error in Location.sendRedirect for "+req+": "+e); 
    }
    return false;
  }
    
}
