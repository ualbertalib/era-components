/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.db_tool;

import net.handle.hdllib.*;
import net.handle.awt.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;


public class HandleValuePanel
  extends JPanel
  implements ActionListener
{
  private JTextField indexField;
  private JTextField typeField;
  private JTextField dataField;
  private byte data[];
  private JButton editDataButton;
  private JComboBox ttlTypeChoice;
  private JTextField ttlField;
  private JTextField timestampField;
  private JCheckBox adminReadCheckbox;
  private JCheckBox adminWriteCheckbox;
  private JCheckBox publicReadCheckbox;
  private JCheckBox publicWriteCheckbox;

  private JList referenceList;
  private DefaultListModel referenceListModel;
  private Vector references;
  private JButton addReferenceButton;
  private JButton remReferenceButton;
  private JButton editReferenceButton;

  public HandleValuePanel()
  {
    super(new GridBagLayout());
    references = new Vector();

    indexField = new JTextField("",10);
    typeField = new JTextField("",10);
    dataField = new JTextField("",20);
    dataField.setEditable(false);
    editDataButton = new JButton("Edit");
    ttlTypeChoice = new JComboBox();
    ttlTypeChoice.addItem("Relative");
    ttlTypeChoice.addItem("Absolute");
    ttlField = new JTextField("",6);
    timestampField = new JTextField("",10);
    timestampField.setEditable(false);
    adminReadCheckbox = new JCheckBox("AR",true);
    adminWriteCheckbox = new JCheckBox("AW",true);
    publicReadCheckbox = new JCheckBox("PR",true);
    publicWriteCheckbox = new JCheckBox("PW",false);

    referenceListModel = new DefaultListModel();
    referenceList = new JList(referenceListModel);
    addReferenceButton = new JButton("Add");
    remReferenceButton = new JButton("Remove");
    editReferenceButton = new JButton("Modify");
    
    JPanel panel1 = new JPanel(new GridBagLayout());
    JPanel panel2 = new JPanel(new GridBagLayout());
    JPanel panel3 = new JPanel(new GridBagLayout());

    int x=0, y=0;
    panel1.add(new JLabel("Index:",JLabel.RIGHT),
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    panel1.add(indexField,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));

    panel1.add(new JLabel(" Type:",JLabel.RIGHT),
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    panel1.add(typeField,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));
    
    panel1.add(new JLabel(" Data:",JLabel.RIGHT),
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    panel1.add(dataField,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));
    panel1.add(editDataButton,
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    
    x = 0;
    y = 0;
    panel2.add(new JLabel(" TTL:",JLabel.RIGHT),
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    panel2.add(ttlTypeChoice,
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    panel2.add(ttlField,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));
    
    panel2.add(new JLabel(" Timestamp:",JLabel.RIGHT),
               AwtUtil.getConstraints(x++,y,0,0,1,1,true,true));
    panel2.add(timestampField,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));
    
    x = 0;
    y = 0;
    JPanel tmpPanel = new JPanel(new GridBagLayout());
    tmpPanel.add(new JLabel(" Permissions:", JLabel.CENTER),
                 AwtUtil.getConstraints(0,0,0,0,2,1,true,true));
    tmpPanel.add(adminReadCheckbox,
                 AwtUtil.getConstraints(0,1,1,0,1,1,true,true));
    tmpPanel.add(adminWriteCheckbox,
                 AwtUtil.getConstraints(1,1,1,0,1,1,true,true));
    tmpPanel.add(publicReadCheckbox,
                 AwtUtil.getConstraints(0,2,1,0,1,1,true,true));
    tmpPanel.add(publicWriteCheckbox,
                 AwtUtil.getConstraints(1,2,0,0,1,1,true,true));
    panel3.add(tmpPanel,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));
    
    x++;
    tmpPanel = new JPanel(new GridBagLayout());
    tmpPanel.add(new JLabel(" Refs:",JLabel.CENTER),
                 AwtUtil.getConstraints(0,0,0,0,2,1,true,true));
    tmpPanel.add(new JScrollPane(referenceList),
                 AwtUtil.getConstraints(0,1,1,0,1,5,true,true));
    tmpPanel.add(addReferenceButton,
                 AwtUtil.getConstraints(1,1,0,0,1,1,true,true));
    tmpPanel.add(remReferenceButton,
                 AwtUtil.getConstraints(1,2,0,0,1,1,true,true));
    tmpPanel.add(editReferenceButton,
                 AwtUtil.getConstraints(1,3,0,0,1,1,true,true));
    panel3.add(tmpPanel,
               AwtUtil.getConstraints(x++,y,1,0,1,1,true,true));
    
    add(panel1, AwtUtil.getConstraints(0,0,0,0,1,1,true,true));
    add(panel2, AwtUtil.getConstraints(0,1,0,1,1,1,true,true));
    add(panel3, AwtUtil.getConstraints(0,2,0,0,1,1,true,true));
    
    addReferenceButton.addActionListener(this);
    remReferenceButton.addActionListener(this);
    editReferenceButton.addActionListener(this);
    editDataButton.addActionListener(this);
  }

  private void updateDataLabel() 
  {
    if(data==null) {
      dataField.setText("<null>");
    } else if(Util.looksLikeBinary(data)) {
      dataField.setText(Util.decodeHexString(data, false));
    } else {
      dataField.setText(Util.decodeString(data));
    }
  }

  private void rebuildReferenceList() {
    referenceListModel.clear();
    for(int i=0; i<references.size(); i++) {
      referenceListModel.addElement(String.valueOf(references.elementAt(i)));
    }
  }

  public void setHandleValue(HandleValue value) 
  {
    data = value.getData();
    updateDataLabel();
    indexField.setText(String.valueOf(value.getIndex()));
    typeField.setText(Util.decodeString(value.getType()));
    
    switch(value.getTTLType()) {
    case HandleValue.TTL_TYPE_ABSOLUTE:
      ttlTypeChoice.setSelectedIndex(1);
      break;
    case HandleValue.TTL_TYPE_RELATIVE:
    default:
      ttlTypeChoice.setSelectedIndex(0);
    }
    ttlField.setText(String.valueOf(value.getTTL()));
    timestampField.setText(String.valueOf(new Date(value.getTimestamp()*1000)));
    adminReadCheckbox.setSelected(value.getAdminCanRead());
    adminWriteCheckbox.setSelected(value.getAdminCanWrite());
    publicReadCheckbox.setSelected(value.getAnyoneCanRead());
    publicWriteCheckbox.setSelected(value.getAnyoneCanWrite());

    references.removeAllElements();
    ValueReference refs[] = value.getReferences();
    if(refs!=null) {
      for(int i=0; i<refs.length; i++) {
        references.addElement(refs[i]);
      }
    }
    rebuildReferenceList();
  }


  public void getHandleValue(HandleValue value) 
  {
    try {
      value.setIndex(Integer.parseInt(indexField.getText().trim()));
    } catch (Exception e) {
      System.err.println("Error: invalid index value: "+indexField.getText());
    }
    try {
      value.setTTL(Integer.parseInt(ttlField.getText().trim()));
      if(ttlTypeChoice.getSelectedIndex()==0) {
        value.setTTLType(HandleValue.TTL_TYPE_RELATIVE);
      } else {
        value.setTTLType(HandleValue.TTL_TYPE_ABSOLUTE);
      }
    } catch (Exception e) {
      System.err.println("Error: invalid ttl: "+ttlField.getText());
    }

    value.setData(data);
    value.setType(Util.encodeString(typeField.getText()));
    value.setAdminCanRead(adminReadCheckbox.isSelected());
    value.setAdminCanWrite(adminWriteCheckbox.isSelected());
    value.setAnyoneCanRead(publicReadCheckbox.isSelected());
    value.setAnyoneCanWrite(publicWriteCheckbox.isSelected());
    ValueReference refs[] = new ValueReference[references.size()];
    for(int i=0; i<refs.length; i++) {
      refs[i] = (ValueReference)references.elementAt(i);
    }
    value.setReferences(refs);
  }


  private void editData() 
  {
    DefaultDataPanel dataPanel = new DefaultDataPanel();
    dataPanel.setValue(data);
    if(GenericDialog.ANSWER_CANCEL==
       GenericDialog.showDialog("Edit Data", dataPanel,
                                GenericDialog.QUESTION_OK_CANCEL, this))
      return;
    data = dataPanel.getValue();
    updateDataLabel();
  }

  private void evtAddReference()
  {
  }
  private void evtRemoveReference()
  {
  }
  private void evtEditReference()
  {
  }

  public void actionPerformed(ActionEvent evt) 
  {
    Object src = evt.getSource();
    if(src==editDataButton) {
      editData();
    } else if(src==addReferenceButton) {
      evtAddReference();
    } else if(src==remReferenceButton) {
      evtRemoveReference();
    } else if(src==editReferenceButton) {
      evtEditReference();
    }
  }


}
