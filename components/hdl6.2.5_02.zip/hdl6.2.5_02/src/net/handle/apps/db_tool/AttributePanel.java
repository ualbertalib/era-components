/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.db_tool;

import java.awt.*;
import java.awt.event.*;


public class AttributePanel
  extends Panel
{

  private TextField nameField;
  private TextField valueField;

  public AttributePanel()
  {
    nameField = new TextField("",10);
    valueField = new TextField("",10);
    add(new Label("  Name: ",Label.RIGHT));
    add(nameField);
    add(new Label("  Value: ",Label.RIGHT));
    add(valueField);
  }
  
  public void setName(String name) {
    nameField.setText(name);
  }
  public String getName() {
    return nameField.getText();
  }

  public void setValue(String value) {
    valueField.setText(value);
  }
  public String getValue() {
    return valueField.getText();
  }

}
