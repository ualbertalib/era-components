/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.db_tool;

import net.handle.hdllib.*;
import net.handle.server.*;
import net.handle.util.*;

public class DBList
{
  private HandleStorage storage;


  public DBList(HandleStorage storage) 
  {
    this.storage = storage;
    
    System.out.println("\nListing handles: ");
    try {
      storage.scanHandles(new ScanCallback() {
          public void scanHandle(byte handle[]) {
            System.out.println(Util.decodeString(handle));
          }
        });
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }

  public static void main(String argv[]) 
    throws Exception
  {
    if(argv==null || argv.length<1) {
      System.err.println("usage: java net.handle.apps.db_tool.DBList <server-directory>");
      return;
    }

    java.io.File serverDir = new java.io.File(argv[0]);
    StreamTable serverInfo = new StreamTable();
    serverInfo.readFromFile(new java.io.File(serverDir, "config.dct"));
    serverInfo = (StreamTable)serverInfo.get("server_config");
    HandleStorage storage = HandleStorageFactory.getStorage(serverDir, serverInfo, true);
    DBList dbList = new DBList(storage);
  }

}
