/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

import java.io.Serializable;


/**
 *  High-performance set of Strings.  This is strongly based on the
 *  org.python.core.PyStringMap class from JPython.
 *
 *  developer     Jim Hugunin
 *  developer     Barry Warsaw  <bwarsaw@python.org>
 *  developer     Fred L. Drake, Jr.  <fdrake@acm.org>
 *  developer     Jason Petrone(Minor changes for hashing by value) <jpetrone@cnri.reston.va.us>
 *  @version    $Revision: 1.9 $
 *
 **/

public final class StringSet implements Serializable
{
    // Table of primes to cycle through:
    private static final int[] primes = {
        7, 13, 31, 61, 127, 251, 509, 1021, 2017, 4093,
        5987, 9551, 15683, 19609, 31397,
        65521, 131071, 262139, 524287, 1048573, 2097143,
        4194301, 8388593, 16777213, 33554393, 67108859,
        134217689, 268435399, 536870909, 1073741789,};

    /**
     *  Table which stores the set data.
     *
     *  @serial String array which contains keys, flags for deleted entries,
     *          and null values.
     **/
    private String[] keys;

    /**
     *  Number of set members.
     *
     *  @serial Integer specifying the number of set members.
     **/
    private int size;
    private transient int filled;
    private transient int prime;

    private static final String DELETED_KEY = "<deleted key>";


    /** Initialize an empty StringSet. */
    public StringSet()
        throws CapacityError
    {
        super();
        prime = 0;
        keys = null;
        resize(4);
    }

    /**
     *  Retrieve the current size of the set.
     *
     *  @return         number of elements in this set
     **/
    public int getSize()
    {
        return this.size;
    }

    /**
     *  Add a String to the set if it isn't already a member.
     *
     *  @exception CapacityError indicates the set could not be
     *                           enlarged to accomodate a String
     *                           which wasn't already a member
     **/
    public synchronized void add(String key)
        throws CapacityError
    {
        if (2*filled > keys.length)
            resize(keys.length + 1);

        String[] table = keys;
        int maxindex = table.length;
        int index = (key.hashCode() & 0x7fffffff) % maxindex;

        // Fairly aribtrary choice for stepsize...
        int stepsize = maxindex / 5;

        // Cycle through possible positions for the key;
        while (true) {
            String tkey = table[index];
            if (tkey == null) {
                table[index] = key;
                filled++;
                size++;
                break;
            } else if (tkey.equals(key)) {
                break;
            } else if (tkey == DELETED_KEY) {
                table[index] = key;
                size++;
                break;
            }
            index = (index+stepsize) % maxindex;
        }
    }

    /**
     *  Returns true if this set contains the specified element.
     *
     *  @param  key     element to test for
     *  @return         true if key is a member of the set
     **/
    public synchronized boolean contains(String key) {
        String[] table = keys;
        int maxindex = table.length;
        int index = (key.hashCode() & 0x7fffffff) % maxindex;

        // Fairly aribtrary choice for stepsize...
        int stepsize = maxindex / 5;

        // Cycle through possible positions for the key;
        //int collisions = 0;
        while (true) {
            String tkey = table[index];
            if (tkey == null)
                return false;
            if (tkey.equals(key)) {
                return true;
            }

            //collisions++;
            index = (index+stepsize) % maxindex;
        }
    }

    /**
     *  Return array of all set members.
     *
     *  @return         list of all set members
     **/
    public synchronized String[] members() {
        String[] keyTable = keys;
        int n = keyTable.length;

        String[] newKeys = new String[size];
        int j = 0;

        for (int i=0; i < n; i++) {
            String key = keyTable[i];
            if (key == null || key == DELETED_KEY)
                continue;
            newKeys[j++] = key;
        }
        return newKeys;
    }

    /**
     *  Remove a specific member from the set, if present.  If not
     *  present, do nothing.
     *
     *  @param  key     set member to remove
     **/
    public synchronized void remove(String key) {
        String[] table = keys;
        int maxindex = table.length;
        int index = (key.hashCode() & 0x7fffffff) % maxindex;

        // Fairly aribtrary choice for stepsize...
        int stepsize = maxindex / 5;

        // Cycle through possible positions for the key;
        while (true) {
            String tkey = table[index];
            if (tkey == null) {
                // not here, but we just don't care!
                return;
            }
            if (tkey.equals(key)) {
                table[index] = DELETED_KEY;
                size--;
                break;
            }
            index = (index+stepsize) % maxindex;
        }
    }

    /**
     *  Return a somewhat human-readable representation of the set as
     *  a String.
     *
     *  @return         textual representation of the set
     **/
    public synchronized String toString() {
        String[] keyTable = keys;
        int n = keyTable.length;

        StringBuffer buf = new StringBuffer("{");

        for (int i=0; i < n; i++) {
            buf.append("'");
            buf.append(keyTable[i]);
            buf.append("', ");
        }
        // A hack to remove the final ", " from the string repr
        int len = buf.length();
        if (len > 4) {
            buf.setLength(len - 2);
        }
        buf.append("}");
        return buf.toString();
    }

    /**
     *  Resize the map to hold at least the given number of entries.
     *
     *  @param  capacity    minimum capacity of the map after expansion
     **/
    private synchronized void resize(int capacity)
        throws CapacityError
    {
        int p = prime;
        for (; p < primes.length; p++) {
            if (primes[p] >= capacity)
                break;
        }
        if (primes[p] < capacity) {
            throw new CapacityError(capacity, "StringSet");
        }
        capacity = primes[p];
        prime = p;

        String[] oldKeys = keys;

        keys = new String[capacity];
        size = 0;
        filled = 0;

        // repopulate
        if (oldKeys != null) {
            int n = oldKeys.length;

            for (int i=0; i < n; i++) {
                String k = oldKeys[i];
                if (k != null && k != DELETED_KEY)
                    add(k);
            }
        }
    }
}
