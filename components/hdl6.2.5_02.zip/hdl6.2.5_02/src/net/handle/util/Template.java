/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

import java.lang.*;
import java.io.*;
import java.util.*;


public class Template {

  /** This function returns the index of the next matching closed brace "}}".
    * It assumes that the start brace is *not* a part of the string.
    * getMatchingBraceLocation("Hello{{xxx}} }}") will return 13. 
    */
  public static int getMatchingBraceLocation(String str) {
    Stack stack = new Stack();
    int leftIdx = -1, rightIdx = -1;
    int totIdx = 0;
    String str2 = str;
    while(true){
      leftIdx = str2.indexOf("{{");
      rightIdx = str2.indexOf("}}");
      if(rightIdx<0) {
        return -1;
      }
      if(leftIdx>=0 && leftIdx<rightIdx) {
        // A left bracket came first - {{
        stack.push("{{");
        str2 = str2.substring(leftIdx+2,str2.length());
        totIdx+=leftIdx+2;
        continue;
      } else {
        // We found a right bracket - }}
        str2 = str2.substring(rightIdx+2,str2.length());
        totIdx+=rightIdx+2;
        if(stack.empty()) {
          return totIdx-2;
        } else {
          String match = (String)stack.pop();
        }
      }
    }
  }
  
  /** Merge the hashtable data with the text from the specified file */
  public static String subDictIntoFile(String filename,Hashtable dict) 
  throws IOException, TemplateException {
      return subDictIntoFile(new File(filename),dict);
  }

  /** Merge the hashtable data with the text from the specified file */
  public static String subDictIntoFile(File file,Hashtable dict) 
    throws IOException, TemplateException
  {
    BufferedReader in = new BufferedReader(new FileReader(file));
    StringBuffer sb = new StringBuffer();
    char ch[] = new char[256];
    int n = 0;
    while((n=in.read(ch,0,ch.length))>=0) {
      sb.append(ch,0,n);
    }
    try {
      in.close();
    } catch (Exception e){}
      return subDictIntoString(sb.toString(),dict);
  }
  
  
  
  public static String subDictIntoStream(InputStream in, Hashtable dict)
    throws IOException, TemplateException
  {
    try {
      InputStreamReader rdr = new InputStreamReader(in, "UTF8");
      StringWriter sw = new StringWriter();
      char ch[] = new char[1024];
      int r;
      while((r=rdr.read(ch, 0, ch.length))>=0)
      sw.write(ch, 0, r);
      return subDictIntoString(sw.toString(), dict);
    } finally {
      if(in!=null) in.close();
    }
  }
    
  
  /** Merge the hashtable data with the specified text */
  public static String subDictIntoString(String str, Map dict) 
    throws TemplateException
  {
    String nstr = "";
    String estr = "";
    boolean noMoreTags = false;
    while(true) { // re-merge the data and the template until there are no more tags
      int begTag = 0, endTag=0;
      begTag = str.indexOf("{{");
      if(begTag<0) 
        break;
      
      endTag = getMatchingBraceLocation(str.substring(begTag+2, str.length()));
      endTag+=begTag+2;
      
      if(endTag<0) {
        throw new TemplateException("Unmatched {{.");
      }
      
      nstr = str.substring(0, begTag);
      estr = str.substring(endTag+2);
      
      String key = str.substring(begTag+2, endTag);
      String extra = null;
      int doubleColonIdx = key.indexOf("::");
      int nextOpenBracketIdx = key.indexOf("{{");
      if(doubleColonIdx>=0 && (nextOpenBracketIdx<0 || nextOpenBracketIdx>doubleColonIdx)) {
        // the double-colon applies to this tag and not a nested tag
        // put everything after the double-colon into 'extra'
        extra = key.substring(doubleColonIdx+2);
        key = key.substring(0, doubleColonIdx);
      }
      
      Object obj = dict.get(key);
      
      if(extra==null) extra = "";
      
      //System.err.println(">template>>replacing: key='"+key+"'; extra='"+extra+"' with: '"+obj+"'");
      if(extra.startsWith("?")) { // conditional sub-template
        nstr = nstr + conditionalInclude(extra.substring(1), obj, false);
      } else if(extra.startsWith("!")) { // negative conditional sub-template
        nstr = nstr + conditionalInclude(extra.substring(1), obj, true);
      } else if(obj==null) {
        // if the object is null, then this tag is ignored
        
      } else if(extra.startsWith("*")) { // repeating sub-template
        extra = extra.substring(1);
        if(obj instanceof List) {
          List list = (List)obj;
          for(Iterator it=list.iterator(); it.hasNext(); ) {
            Object subObj = it.next();
            if(subObj instanceof Map) {
              nstr = nstr + subDictIntoString(extra, (Map)subObj);
            } else {
              nstr = nstr + String.valueOf(subObj);
            }
          }
        } else if(obj instanceof Map) {
          nstr = nstr + subDictIntoString(extra, (Map)obj);
        } else { 
          nstr = nstr + subDictIntoString(extra, dict);
        }
      } else if(extra.equalsIgnoreCase("URLEncode")) {
        nstr = nstr + java.net.URLEncoder.encode(String.valueOf(obj));
      } else if(extra.equalsIgnoreCase("CGIEscape")) {
        nstr = nstr + cgiEscape(String.valueOf(obj));
      } else if(extra.equalsIgnoreCase("SQLString")) {
        nstr = nstr + sqlEscape(String.valueOf(obj));
      } else { // no format or special handler found - do a simple replacement
        nstr = nstr + String.valueOf(obj);
      }
      
      str = nstr+estr;
    }
    return str;
  }

  /** Returns the contents of a tag only if the first part of the tag matches 
    * (or doesn't match if the notEqual parameter is true) the given value.  
    * Given the tag:  {{volunteer_coord::?Yes:CHECKED}} this method should be
    * used to handle the "Yes:CHECKED" part.  The expected format of 
    * tagContents is:  <conditionalvalue>:<result>.
    * If the <conditionalvalue> matches (or doesn't, if notEquals is set) the 
    * given value in a case-sensitive String comparison then the <result> will 
    * be returned.
    */
  private static String conditionalInclude(String tagContents, Object value, boolean notEqual) {
    if(tagContents==null || tagContents.length()<=0)
      return "";
    int firstColon = tagContents.indexOf(':');
    if(firstColon<0) return ""; // no colon - bad formatting
    boolean matches = false;
    if(notEqual) {
      matches = value==null || !tagContents.substring(0, firstColon).equals(String.valueOf(value));
    } else {
      matches = value!=null && tagContents.substring(0, firstColon).equals(String.valueOf(value));
    }
    return matches ? tagContents.substring(firstColon+1) : "";
  }
  
  public static String cgiEscape(String str) {
    StringBuffer sb = new StringBuffer("");
    for(int i=0;i<str.length();i++) {
      char ch = str.charAt(i);
      if(ch=='<')
        sb.append("&lt;");
      else if(ch=='>')
        sb.append("&gt;");
      else if(ch=='"')
        sb.append("&quot;");
      else
        sb.append(ch);
    }
    return sb.toString();
  }

  public static String sqlEscape(String str) {
    StringBuffer sb = new StringBuffer("");
    for(int i=0;i<str.length();i++) {
      char ch = str.charAt(i);
      if(ch=='\'')
        sb.append("''");
      else if(ch=='\n')
        sb.append("\\n");
      else if(ch=='\r')
        sb.append("\\r");
      else
        sb.append(ch);
    }
    return sb.toString();
  }
}





