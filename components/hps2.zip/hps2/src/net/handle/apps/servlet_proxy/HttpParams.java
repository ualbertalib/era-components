/**********************************************************************\
 � COPYRIGHT 2006 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

/**********************************************************************\
 Java servlet lib doesn't support ';' as a CGI delimiter.  This is a wrapper
 class to allow it.
\***********************************************************************/

package net.handle.apps.servlet_proxy;

import java.util.Hashtable;
import java.util.Vector;

public class HttpParams {
  Hashtable params = new Hashtable();

  public String getParameter(String name){
    Vector v = (Vector)params.get(name);
    if (v == null) return null;
    else return (String)v.get(0);
  }

  public String[] getParameterValues(String name){
    Vector v = (Vector)params.get(name);
    if (v == null) return null;
    String p[] = new String[v.size()];
    for (int i=0; i<p.length; i++) p[i] = (String)v.get(i);
    return p;
  }

  public void addParameter(String name, String val){
    Vector v = (Vector)params.get(name);
    if (v == null){ 
      v = new Vector();
      params.put(name, v);
    }
    v.add(val);
  }

  public void addParameters(String name, String vals[]){
    for (int i=0; i<vals.length; i++) addParameter(name, vals[i]);
  }

  public void clear(){
    params.clear();
  }
}
