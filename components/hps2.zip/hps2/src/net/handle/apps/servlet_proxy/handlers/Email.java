/**********************************************************************\
 © COPYRIGHT 2006 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy.handlers;

import net.handle.hdllib.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import net.handle.apps.servlet_proxy.*;

public class Email implements TypeHandler {
  
  /** 
  * Return true iff this TypeHandler can send a redirect to the client
  * based on the given set of HandleValues.
  */
  public boolean canRedirect(HandleValue values[]) {
    return false;
  }
  
  /** 
  * Return true iff this TypeHandler can format the data from the given
  * HandleValue for a human client.
  */
  public boolean canFormat(HandleValue value) {
    return value.hasType(Common.STD_TYPE_EMAIL);
  }
  
  
  public String toHTML(String handle, HandleValue value){
    return "<a href=\"mailto:"+value.getDataAsString()+"\">" +
           value.getDataAsString()+"</a>";
  }

  public boolean doRedirect(HttpServletRequest request, 
                            HttpServletResponse response, HttpParams params,
                            String handle, HandleValue values[]) {
    return false;
  }
  
}
