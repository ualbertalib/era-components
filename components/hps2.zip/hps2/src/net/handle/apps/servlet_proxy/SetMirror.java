/**********************************************************************\
 � COPYRIGHT 2006 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;

import net.handle.hdllib.*;

public class SetMirror extends HttpServlet {

    public void init(){
    }


  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
      PrintWriter out = response.getWriter();

      String country = request.getParameter("country");

      response.setContentType("text/html");

      if (country == null){
        // no request, show default page
        // out.write(defaultPage);
        return;
      }
      
      String ref = request.getHeader("Referer");
  
      response.addCookie(new Cookie("preferred_country", country));

      out.println("<html><head><title>Set mirror "+country+"</title></head>");
      out.println("<body>");
      out.println("Using "+country+" mirror.");
      if (ref!=null && !(ref.trim().length()==0)){
        out.println("<p>Return to <a href=\""+ref+"\">"+ref+"</a>");
      }
      out.println("</body></html>");

  }

}



