/**********************************************************************\
 � COPYRIGHT 2006 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;

import net.handle.hdllib.*;


public class OpenURL
  extends HttpServlet
  implements SingleThreadModel
{

  // normal HDLProxy is used for resolution after the url is parsed
  HDLProxy hdlproxy = new HDLProxy();

  static final String URL_TYPE[] = {"URL"};
  static final Hashtable passThroughKeys = new Hashtable();
  static {
    passThroughKeys.put("nosfx", "");
    passThroughKeys.put("nols", "");
  }

  public void init() throws ServletException {
    hdlproxy.init(getServletConfig());
  }


  private final void doOpenURLResolution(HttpServletRequest req,
                                         HttpServletResponse resp)
    throws ServletException, IOException
  { 
    //Hashtable params = new Hashtable();
    int ampIdx = -1;
    int sectionStart; 
    int eqIdx;
    String query = req.getQueryString();
    hdlproxy.params.clear();
    String paramKey = null;
    String paramVal = null;
    String hdl = null;
    do {
      sectionStart = ampIdx+1;
      ampIdx = query.indexOf('&', sectionStart);
      String section = (ampIdx<0) ? query.substring(sectionStart) :
                                    query.substring(sectionStart,ampIdx);
      eqIdx = section.indexOf('=');
      if(eqIdx<0) {
        paramKey = URLDecoder.decode(section);
        paramVal = "";
      } else {
        paramKey = URLDecoder.decode(section.substring(0,eqIdx));
        paramVal = URLDecoder.decode(section.substring(eqIdx+1));
      }
      if(paramKey.equals("id")) {
        hdl = paramVal;
      } else if(passThroughKeys.containsKey(paramKey)) {
        hdlproxy.params.addParameter(paramKey, paramVal);
      }
    } while(ampIdx>=0);

    if(hdl==null) hdl = "";
    else hdl = hdl.trim();
    
    if(hdl.startsWith("hdl:") || hdl.startsWith("doi:")){
      hdl = hdl.substring(4);
    }

    hdlproxy.doResponse(hdl, req, resp);
  }



  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    doOpenURLResolution(request, response);
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response)
      throws IOException, ServletException {
    doOpenURLResolution(request, response);
  }

}
