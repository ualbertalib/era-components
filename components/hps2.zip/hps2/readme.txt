HANDLE.NET(R) SOFTWARE
PROXY SERVLET (ver. 2) -- Java Version

Please be sure you have read the license.txt and agree to the terms.

README.txt

The HANDLE.NET Proxy Servlet enables handle resolution using a web 
browser. It accepts HTTP GET requests for handles, resolves those 
handles, and returns an HTTP redirect to the URL value associated with 
the handle (or randomly chooses one of the URL values if there is more 
than one). The proxy servlet includes support for OpenURL, an HTML 
query form, type and index selection, and decoding of percent-encoded 
UTF8 handles.

The proxy servlet is implemented as a Java servlet 
(see http://java.sun.com/products/servlet/). The proxy servlet was 
developed and tested under the Apache Tomcat servlet environment. 

CNRI runs a Proxy Server System at http://hdl.handle.net. The 
servlet distribution is for those who want to set up their own proxy 
server.

PLEASE FOLLOW THESE STEPS IN ORDER.

1) Install Java version 1.4.2 or higher on your computer. 
   Note: if you already have Java installed on your computer, type 
   'java -version' at the command prompt to find out what version 
   has been installed.
   
2) Install a Servlet environment. The proxy servlet was developed 
   and tested under Apache Tomcat.

3) Under the new hps2 directory, there will be one htdocs directory 
   and six files:  license.txt, readme.txt, hdlproxy.jar, 
   hdlproxy.properties, web.xml.sample, and src.zip.
   
   The hdlproxy.jar file contains all the necessary libraries to 
   run the handle proxy. 
   
   The hdlproxy.properties file contains information that is used 
   to configure a proxy servlet. It should be passed as an 
   initialization parameter to the proxy servlet. 
   
   The web.xml.sample file is a sample web.xml file for the servlet 
   proxy.
   
   To view the proxy servlet code and modify it for development of 
   custom proxy servlets, you will need to unzip the src.zip file. 
   In order to successfully compile the proxy servlet code you 
   should include hdlproxy.jar in your classpath. You will also 
   need to include the Java Servlet API libraries. More information 
   on Java Servlets, including instructions on how to download 
   the servlet libraries, can be found at 
   http://java.sun.com/products/servlet/. 
   
4) Please send all comments, questions and bug reports to 
   hdladmin@cnri.reston.va.us.

Thank you for your interest in CNRI's HANDLE.NET SOFTWARE.
