
package fedora.services.oaiprovider.test;

public enum DisseminationOrigin {
    DATASTREAM, SERVICE, NONE
}
