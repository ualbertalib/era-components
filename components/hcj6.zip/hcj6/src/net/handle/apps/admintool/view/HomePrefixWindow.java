/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import net.handle.awt.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class HomePrefixWindow
  extends JFrame
  implements ActionListener
{
  private AdminToolUI ui;
  
  private JRadioButton homeChoice;
  private JRadioButton unhomeChoice;
  
  private JRadioButton byAddressChoice;
  private JRadioButton bySiteChoice;
  private JTextField prefixField;
  private JTextField hostField;
  private JTextField portField;
  private JButton siteFileButton;
  private JTextField siteFileField;
  private JButton goButton;
  
  private JLabel siteFileLabel;
  private JLabel hostLabel;
  private JLabel portLabel;
  
  private boolean isRunning = false;
  private HomePrefixWindow thisObj;
  
  public HomePrefixWindow(AdminToolUI ui) {
    super(ui.getStr("home_unhome_prefix"));
    this.ui = ui;
    this.thisObj = this;

    setJMenuBar(ui.getAppMenu());

    homeChoice = new JRadioButton(ui.getStr("home_prefix"));
    unhomeChoice = new JRadioButton(ui.getStr("unhome_prefix"));
    ButtonGroup huGroup = new ButtonGroup();
    huGroup.add(homeChoice);
    huGroup.add(unhomeChoice);
    
    byAddressChoice = new JRadioButton(ui.getStr("by_address"));
    prefixField = new JTextField("");
    hostField = new JTextField("127.0.0.1");
    portField = new JTextField("2641");
    
    bySiteChoice = new JRadioButton(ui.getStr("by_siteinfo"));
    siteFileButton = new JButton(ui.getStr("choose_file"));
    siteFileField = new JTextField("");
    
    ButtonGroup byGroup = new ButtonGroup();
    byGroup.add(byAddressChoice);
    byGroup.add(bySiteChoice);
    
    goButton = new JButton(ui.getStr("do_it"));
    
    JPanel p = new JPanel(new GridBagLayout());
    JPanel p1;
    int y = 0;
    
    p.add(new JLabel("<html>"+ui.getStr("home_unhome_desc")+"</html>"),
          AwtUtil.getConstraints(0,y++,1,0,1,1,new Insets(15,15,5,15),true,true));
    
    p1 = new JPanel(new GridBagLayout());
    p1.add(new JLabel(ui.getStr("prefix")+": "), 
           AwtUtil.getConstraints(0,0,0,0,1,1,new Insets(5,5,5,5),false,false));
    p1.add(prefixField, 
           AwtUtil.getConstraints(1,0,1,0,1,1,new Insets(5,5,5,5),true,false));
    p.add(p1, 
          AwtUtil.getConstraints(0,y++,1,0,1,1,new Insets(5,5,0,5),true,true));
    
    p1 = new JPanel(new GridBagLayout());
    p1.add(homeChoice, 
           AwtUtil.getConstraints(0,0,1,0,1,1,new Insets(5,5,5,5),false,false));
    p1.add(unhomeChoice, 
           AwtUtil.getConstraints(1,0,1,0,1,1,new Insets(5,5,5,5),false,false));
    p.add(p1, 
          AwtUtil.getConstraints(0,y++,1,0,1,1,new Insets(5,5,0,5),true,true));
    
    p1 = new JPanel(new GridBagLayout());
    p1.setBorder(new EtchedBorder());
    p1.add(bySiteChoice,
           AwtUtil.getConstraints(0,0,1,0,3,1,new Insets(5,5,5,5),
                                  GridBagConstraints.WEST,false,false));
    p1.add(siteFileLabel = new JLabel(ui.getStr("siteinfo_file")+":"),
           AwtUtil.getConstraints(0,1,0,0,1,1,new Insets(5,5,5,5),true,true));
    p1.add(siteFileField,
           AwtUtil.getConstraints(1,1,1,0,1,1,new Insets(5,5,5,5),true,true));
    p1.add(siteFileButton,
           AwtUtil.getConstraints(2,1,0,0,1,1,new Insets(5,5,5,5),true,true));
    p.add(p1, 
          AwtUtil.getConstraints(0,y++,1,0,1,1,new Insets(15,15,15,15),true,true));
    
    p1 = new JPanel(new GridBagLayout());
    p1.setBorder(new EtchedBorder());
    p1.add(byAddressChoice,
           AwtUtil.getConstraints(0,0,1,0,3,1,new Insets(5,5,5,5),
                                  GridBagConstraints.WEST,false,false));
    p1.add(hostLabel = new JLabel(ui.getStr("server_address")+":"),
           AwtUtil.getConstraints(0,1,0,0,1,1,new Insets(5,5,5,5),true,true));
    p1.add(hostField,
           AwtUtil.getConstraints(1,1,1,0,1,1,new Insets(5,5,5,5),true,true));
    p1.add(portLabel = new JLabel(ui.getStr("server_port")+":"),
           AwtUtil.getConstraints(0,2,0,0,1,1,new Insets(5,5,5,5),true,true));
    p1.add(portField,
           AwtUtil.getConstraints(1,2,1,0,1,1,new Insets(5,5,5,5),true,true));
    p.add(p1, 
          AwtUtil.getConstraints(0,y++,1,0,1,1,new Insets(15,15,15,15),true,true));

    p1 = new JPanel(new GridBagLayout());
    p1.add(Box.createHorizontalStrut(250),
           AwtUtil.getConstraints(0,0,1,1,1,1,true,true));
    p1.add(goButton,
           AwtUtil.getConstraints(1,1,0,0,1,1,false,false));
    p.add(p1, 
          AwtUtil.getConstraints(0,y++,1,1,1,1,new Insets(0,15,15,15),true,true));
    
    getContentPane().add(p);
    
    byAddressChoice.addActionListener(this);
    bySiteChoice.addActionListener(this);

    goButton.addActionListener(this);
    siteFileButton.addActionListener(this);

    homeChoice.setSelected(true);
    bySiteChoice.setSelected(true);
    enableAppropriateFields();
    getRootPane().setDefaultButton(goButton);
    
    pack();
    setSize(new Dimension(400, getPreferredSize().height+80));
    AwtUtil.setWindowPosition(this, AwtUtil.WINDOW_CENTER);
  }
  
  public void actionPerformed(ActionEvent evt) {
    Object src = evt.getSource();
    if(src==byAddressChoice || src==bySiteChoice) {
      enableAppropriateFields();
    } else if(src==siteFileButton) {
      FileDialog fwin = new FileDialog(AwtUtil.getFrame(this),
                                       ui.getStr("choose_file"),
                                       FileDialog.LOAD);
      String currentFile = siteFileField.getText();
      if(currentFile!=null && currentFile.trim().length()>0) {
        try {
          File f = new File(currentFile);
          fwin.setDirectory(f.getParent());
          fwin.setFile(f.getName());
        } catch (Exception e) {}
      }
      fwin.setVisible(true);
      
      String fileStr = fwin.getFile();
      String dirStr = fwin.getDirectory();
      if(fileStr!=null && dirStr!=null) {
        siteFileField.setText(new File(dirStr, fileStr).getPath());
      }
    } else if(src==goButton) {
      doit();
    }
  }
  
  /** Load/retrieve/parse the siteinfo that describes the site where the prefix
    * will be homed.  Displays an error and returns null if there was a problem. */
  public SiteInfo getSiteInfo() {
    if(byAddressChoice.isSelected()) {
      return getManualSiteInfo();
    } else {
      SiteInfo siteinfo = new SiteInfo();
      try {
        FileInputStream fin = new FileInputStream(siteFileField.getText());
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        byte buf[] = new byte[2048];
        int r;
        while((r=fin.read(buf))>=0) bout.write(buf, 0, r);
        Encoder.decodeSiteInfoRecord(bout.toByteArray(), 0, siteinfo);
        return siteinfo;
      } catch (Exception e) {
        JOptionPane.showMessageDialog(this, 
                                      ui.getStr("error_loading_siteinfo")+"\n\n"+e,
                                      ui.getStr("error_title"),
                                      JOptionPane.ERROR_MESSAGE);
        return null;
      }
    }
  }
  
  /** Retrieve the siteinfo that describes the site where the prefix will be 
    * homed.  Displays an error and returns null if there was a problem. */
  public SiteInfo getManualSiteInfo() {
    InetAddress svrAddr;
    try {
      svrAddr = InetAddress.getByName(hostField.getText().trim());
    } catch (Exception e) {
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("error_retrieve_siteinfo")+"\n\n"+e,
                                    ui.getStr("error_title"),
                                    JOptionPane.ERROR_MESSAGE);
      return null;
    }
    int svrPort = Integer.parseInt(portField.getText().trim());
    
    // retrieve the site information...
    GenericRequest siReq = new GenericRequest(Common.BLANK_HANDLE,
                                              AbstractMessage.OC_GET_SITE_INFO,
                                              null);
    siReq.majorProtocolVersion = 2;
    siReq.minorProtocolVersion = 0;
    siReq.certify = false;
    AbstractResponse response = null;
    HandleResolver resolver = ui.getMain().getResolver();
    Exception error = null;
    int preferredProtocols[] = {
      Interface.SP_HDL_UDP, 
      Interface.SP_HDL_TCP,
      Interface.SP_HDL_HTTP
    };
    
    // try each protocol, until one works...
    for(int i=0; i<preferredProtocols.length; i++) {
      try {
        switch(preferredProtocols[i]) {
          case Interface.SP_HDL_TCP:
            response = resolver.sendHdlTcpRequest(siReq, svrAddr, svrPort);
            break;
          case Interface.SP_HDL_UDP:
            response = resolver.sendHdlUdpRequest(siReq, svrAddr, svrPort);
            break;
          case Interface.SP_HDL_HTTP:
          default:
            response = resolver.sendHttpRequest(siReq, svrAddr, svrPort);
            break;
        }
        if(response.responseCode==AbstractResponse.RC_SUCCESS) {
          return ((GetSiteInfoResponse)response).siteInfo;
        }
      } catch (Exception e) {
        error = e;
        System.err.println("Error sending get-site-info request: "+e);
      }
    }
      
    if(error!=null) {
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("error_retrieve_siteinfo")+"\n\n"+error,
                                    ui.getStr("error_title"),
                                    JOptionPane.ERROR_MESSAGE);
    } else {
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("error_retrieve_siteinfo"),
                                    ui.getStr("error_title"),
                                    JOptionPane.ERROR_MESSAGE);
    }
    return null;
  }
  
  public void doit() {
    String prefix = prefixField.getText().trim().toUpperCase();
    if(!prefix.startsWith("0.NA/"))
      prefix = "0.NA/"+prefix;
    byte naHandle[] = Util.encodeString(prefix);
    
    SiteInfo site = getSiteInfo();
    if(site==null) return;
    
    try {
      if(!site.isPrimary) {
        throw new Exception("Given server is not a primary server.");
      }
      
      AuthenticationInfo authInfo = ui.getAuthentication(false);
      if(authInfo==null)
        return;
      
      GenericRequest homeNAReq =
        new GenericRequest(naHandle, AbstractMessage.OC_HOME_NA, authInfo);
      
      homeNAReq.majorProtocolVersion = 2;
      homeNAReq.minorProtocolVersion = 0;
      homeNAReq.isAdminRequest = true;
      
      
      homeNAReq.certify = true;
      for(int i=0; i<site.servers.length; i++) {
        AbstractResponse response = 
          ui.getMain().getResolver().sendRequestToServer(homeNAReq, site.servers[i]);
        if(response.responseCode!=AbstractMessage.RC_SUCCESS) {
          throw new Exception(String.valueOf(response));
        }
      }
      
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("success_home_unhome"),
                                    ui.getStr("success_title"),
                                    JOptionPane.INFORMATION_MESSAGE);
    } catch (Exception e) {
      e.printStackTrace(System.err);
      JOptionPane.showMessageDialog(this, 
                                    ui.getStr("error_home_unhome")+"\n\n"+e,
                                    ui.getStr("error_title"),
                                    JOptionPane.ERROR_MESSAGE);
    }
  }
  
  
  public void enableAppropriateFields() {
    boolean bySite = bySiteChoice.isSelected();
    hostLabel.setEnabled(!bySite);
    hostField.setEnabled(!bySite);
    portLabel.setEnabled(!bySite);
    portField.setEnabled(!bySite);

    siteFileLabel.setEnabled(bySite);
    siteFileButton.setEnabled(bySite);
    siteFileField.setEnabled(bySite);
  }
  
}
