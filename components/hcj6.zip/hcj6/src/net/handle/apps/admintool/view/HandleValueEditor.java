/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.admintool.view;

import net.handle.hdllib.*;
import java.awt.*;

public interface HandleValueEditor {
  
  /**
   * Saves the handle value data in the given HandleValue.  Returns false
   * if there was an error and the operation was canceled.
   */
  public boolean saveValueData(HandleValue value);


  /**
   * Sets the handle value data from the given HandleValue.
   */
  public void loadValueData(HandleValue value);
  
}  
