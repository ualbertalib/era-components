/**********************************************************************\
 ® COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.apps.simple;


import net.handle.hdllib.*;
import net.handle.security.*;

import java.io.*;
import java.net.*;
import java.util.*;
import java.math.BigInteger;
import java.security.*;


/**
 * Simple tool for homing NAs.
 * Uses public key authentication.  
 **/
public class HomeNA {
  
  public static void main(String argv[]) {
    if (argv.length < 5){
      System.err.println("usage: java net.handle.apps.simple.HomeNA <auth hdl> <privkey> <server ip> <server tcp port> <NA handle1> [<NA handle2>...]");
      System.exit(-1);
    }

    String authHdl = argv[0];
    String privKeyFile = argv[1];
    String serverIp = argv[2];
    int port = Integer.parseInt(argv[3]);
    String nas[] = new String[argv.length-4];
    System.arraycopy(argv, 4, nas, 0, nas.length);

    // First we need to read the private key in from disk
    byte[] key = null;
    try {
      File f = new File(privKeyFile);
      FileInputStream fs = new FileInputStream(f);
      key = new byte[(int)f.length()];
      int n=0;
      while(n<key.length) key[n++] = (byte)fs.read();
      fs.read(key);
    }
    catch (Throwable t){
      System.err.println("Cannot read private key " + privKeyFile + ": " + t);
      System.exit(-1);
    }

    // A HandleResolver object is used not just for resolution, but for
    // all handle operations(including create)
    HandleResolver resolver = new HandleResolver();
    resolver.traceMessages = true;

    // Check to see if the private key is encrypted.  If so, read in the
    // user's passphrase and decrypt.  Finally, convert the byte[] 
    // representation of the private key into a PrivateKey object.
    PrivateKey privkey = null;
    byte secKey[] = null;
    try {
      if(Util.requiresSecretKey(key)){
        secKey = Util.getPassphrase("passphrase: ");
      }
      key = Util.decrypt(key, secKey);
      privkey = Util.getPrivateKeyFromBytes(key, 0);
    } catch (Throwable t) {
      System.err.println("Can't load private key in " + privKeyFile + ": " +t);
      System.exit(-1);
    }

    try {
      // Create a PublicKeyAuthenticationInfo object to pass to HandleResolver.
      // This is constructed with the admin handle, index, and PrivateKey as
      // arguments.
      PublicKeyAuthenticationInfo auth = 
        new PublicKeyAuthenticationInfo(authHdl.getBytes("UTF8"), 300, privkey);

      // get site info for server
      InetAddress svrAddr = InetAddress.getByName(serverIp);
      GenericRequest siReq = new GenericRequest(Common.BLANK_HANDLE,
                              AbstractMessage.OC_GET_SITE_INFO, null);
      siReq.certify = true;
      resolver.setCheckSignatures(false);
      AbstractResponse response = resolver.sendHdlTcpRequest(siReq, svrAddr, port);

      SiteInfo siteInfo = null;

      if(response !=null && response.responseCode==AbstractMessage.RC_SUCCESS){ 
        siteInfo = ((GetSiteInfoResponse)response).siteInfo;
      } else {
        throw new Exception("Unable to retrieve site information from server");
      }
      if(!siteInfo.isPrimary) {
        throw new Exception("Given server is not a primary server.");
      }
                                        
      // prepare the home na message
      resolver.setCheckSignatures(true);
      resolver.traceMessages = true;

      // send it
      for(int naIdx = 0; naIdx<nas.length; naIdx++) {
        GenericRequest req =
          new GenericRequest(Util.encodeString(nas[naIdx]), AbstractMessage.OC_HOME_NA, auth);
        req.majorProtocolVersion = 2;
        req.minorProtocolVersion = 0;
        req.certify = true;
        req.isAdminRequest = true;
        
        for(int i=0; i<siteInfo.servers.length; i++) {
          response = resolver.sendRequestToServer(req, siteInfo.servers[i]);
          if(response.responseCode!=AbstractMessage.RC_SUCCESS) {
            throw new Exception(String.valueOf(response));
          }
        }
      }

    } catch (Throwable t) {
      System.err.println("\nError: "+t);
    }
  }

}
