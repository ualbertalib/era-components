/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

/**
 * Class that holds the information known about a single transaction
 * on a handle server.  This is generally never used on the client side.
 */

public class Transaction {
  public static final byte ACTION_PLACEHOLDER = 0;
  public static final byte ACTION_CREATE_HANDLE = 1;
  public static final byte ACTION_DELETE_HANDLE = 2;
  public static final byte ACTION_UPDATE_HANDLE = 3;
  public static final byte ACTION_HOME_NA = 4;
  public static final byte ACTION_UNHOME_NA = 5;
  public static final byte ACTION_DELETE_ALL = 6;
  
  public long txnId;
  public byte handle[];
  public byte action;
  public long date;
  public int hashOnAll;
  public int hashOnNA;
  public int hashOnId;

  // this is only used on the receiving side
  // also used in Stroage transaction log
  public HandleValue values[] = null;

  public String toString() {
    return "Transaction[txn: id="+txnId+"; action="+action+
      "; hdl="+Util.decodeString(handle)+
      "; date="+(new java.util.Date(date))+";]";
  }
}



