/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import net.handle.security.*;
import java.lang.*;
import java.security.*;
import java.security.interfaces.*;

/****************************************************************
 * Base class for all request types
 ****************************************************************/

public abstract class AbstractMessage {
  // message types...(opCode)
  public static final int OC_RESERVED = 0;
  public static final int OC_RESOLUTION = 1;
  public static final int OC_GET_SITE_INFO = 2;

  public static final int OC_CREATE_HANDLE = 100;
  public static final int OC_DELETE_HANDLE = 101;
  public static final int OC_ADD_VALUE = 102;
  public static final int OC_REMOVE_VALUE = 103;
  public static final int OC_MODIFY_VALUE = 104;
  public static final int OC_LIST_HANDLES = 105;
  
  public static final int OC_RESPONSE_TO_CHALLENGE = 200;
  public static final int OC_VERIFY_CHALLENGE = 201;

  public static final int OC_HOME_NA = 300;
  public static final int OC_UNHOME_NA = 301;
  public static final int OC_LIST_HOMED_NAS = 302;
  
  public static final int OC_SESSION_SETUP = 400;
  public static final int OC_SESSION_TERMINATE = 401;
  public static final int OC_SESSION_EXCHANGEKEY = 402;
  
  public static final int OC_GET_NEXT_TXN_ID = 1000;
  public static final int OC_RETRIEVE_TXN_LOG = 1001;
  public static final int OC_DUMP_HANDLES = 1002;
  public static final int OC_BACKUP_SERVER = 1003;
  
  // response codes... (responseCode)
  public static final int RC_RESERVED = 0; // (only used for requests)
  public static final int RC_SUCCESS = 1;
  public static final int RC_ERROR = 2;
  public static final int RC_SERVER_TOO_BUSY = 3;
  public static final int RC_PROTOCOL_ERROR = 4;
  public static final int RC_OPERATION_NOT_SUPPORTED = 5;
  public static final int RC_RECURSION_COUNT_TOO_HIGH = 6;
  
  public static final int RC_HANDLE_NOT_FOUND = 100;
  public static final int RC_HANDLE_ALREADY_EXISTS = 101;
  public static final int RC_INVALID_HANDLE = 102;

  public static final int RC_VALUES_NOT_FOUND = 200;
  public static final int RC_VALUE_ALREADY_EXISTS = 201;
  
  public static final int RC_OUT_OF_DATE_SITE_INFO = 300;
  public static final int RC_SERVER_NOT_RESP = 301;
  public static final int RC_SERVICE_REFERRAL = 302;
  public static final int RC_SERVER_BACKUP = 303;

  public static final int RC_INVALID_ADMIN = 400; // requestor not an administrator for the operation
  public static final int RC_INSUFFICIENT_PERMISSIONS = 401;  // requestor doesn't have permission
  public static final int RC_AUTHENTICATION_NEEDED = 402;  // no auth info provided, but necessary
  public static final int RC_AUTHENTICATION_FAILED = 403;   // couldn't verify requestor identity
  public static final int RC_INVALID_CREDENTIAL = 404;  // requestor auth info is invalid
  public static final int RC_AUTHEN_TIMEOUT = 405;   // got response after challenge timed out
  public static final int RC_AUTHEN_ERROR = 406;   // unexpected error trying to authenticate (catch-all)

  public static final int RC_SESSION_TIMEOUT = 500;
  public static final int RC_SESSION_FAILED = 501;
  public static final int RC_INVALID_SESSION_KEY = 502;
  public static final int RC_NEED_RSAKEY_FOR_SESSIONEXCHANGE = 503;
  public static final int RC_INVALID_SESSIONSETUP_REQUEST = 504;  //server is down, then session info is gone, whie client info is still there
  
  //public static final int RC_AUTHENTICATION_ERROR = 7;

  public int requestId = -1;
  public int sessionId = 0;

  /** The major version of the protocol used to send this message.
      This is only valid when the message has been decoded from the network
      using the Encoder.decodeEnvelope and Encoder.decodeMessage methods.
   */
  public byte majorProtocolVersion = -1;

  /** the minor version of the protocol used to send this message.
      This is only valid when the message has been decoded from the network
      using the Encoder.decodeEnvelope and Encoder.decodeMessage methods.
   */
  public byte minorProtocolVersion = -1;

  public int opCode;
  public int responseCode = RC_RESERVED;
  public int siteInfoSerial = -1;
  public int expiration;  // time (in seconds from epoch) when message is no longer valid
  public short recursionCount = 0;
  
  public boolean certify = false;
  public boolean cacheCertify = true;
  public boolean authoritative = false;
  public boolean encrypt = false;
  public boolean ignoreRestrictedValues = true;
  public boolean returnRequestDigest = false;

  public boolean recursive = true;     // Indicates whether handle servers should recursively
                                       // process handle resolution if they are not responsible
                                       // for the requested handle.  The server is not
                                       // required to honor this.

  public boolean continuous = false;   // Indicates whether this message is to-be-continued

  public boolean keepAlive = false;    // Indicates that the client would like the server to
                                       // keep the current connection open for more requests
                                       // the server is not required to honor this.

  public byte signerHdl[] = null; // currently unused
  public int signerHdlIdx = 0;    // currently unused

  public byte messageBody[] = null;
  public byte signature[] = null;
  public byte encodedMessage[] = null;
  public byte requestDigest[] = null;  // the digest of the request, if this is a response
  public byte rdHashType = Common.HASH_CODE_SHA1;

  public AbstractMessage() {
    // default expiration is twelve hours from now
    expiration = (int)(System.currentTimeMillis()/1000) + 43200; 
  }
  
  public AbstractMessage(int opCode) {
    this.opCode = opCode;

    // default expiration is twelve hours from now
    expiration = (int)(System.currentTimeMillis()/1000) + 43200;
  }

  
  /** Return true if the major and minor version of this message is equal to or
    * greater than the given major/minor versions.  */
  public boolean hasEqualOrGreaterVersion(byte majorVersion, byte minorVersion) {
    if(majorProtocolVersion > majorVersion) return true;
    if(majorProtocolVersion < majorVersion) return false;
    return minorProtocolVersion >= minorVersion;
  }
  
  /********************************************************************************
   * Takes the request parameters (certify, cacheCertify, authoritative, and 
   * encrypt) from the given request object.  This is useful when several queries
   * are required to resolve a handle and all of the queries must have the same
   * parameters as the overall request.  This is also useful when generating
   * responses to requests that must contain the same flags as the request.
   ********************************************************************************/
  public final void takeValuesFrom(AbstractMessage msg)
    throws HandleException
  {
    this.certify = msg.certify;
    this.cacheCertify = msg.cacheCertify;
    this.authoritative = msg.authoritative;
    this.encrypt = msg.encrypt;
    this.ignoreRestrictedValues = msg.ignoreRestrictedValues;
    this.recursionCount = msg.recursionCount;
    this.returnRequestDigest = this.returnRequestDigest || msg.returnRequestDigest;
    this.majorProtocolVersion = msg.majorProtocolVersion;
    this.minorProtocolVersion = msg.minorProtocolVersion;
    
    if(this.returnRequestDigest && this instanceof AbstractResponse) {
      // if this is a response to the given message, attach a digest of
      // the request to this message.
      this.requestDigest = Util.doDigest(Common.DEFAULT_HASH_CODE,
                                         msg.getEncodedMessageBody());
    }
  }

  /*******************************************************************************
   * Generate a MAC code with a given secretKey.
   * secretKey is a symetric key. The secret keyexchange before hand has to be 
   * secured with RSA keys. See HandleResolver.java.
   *
   * One usage now is to sign message with MAC code in session menagement.
   * <pre>
   *
   * Credential section (including signature) within each message:
   *
   *	Version		octet		(always be 0)
   *
   *	Reserved	octet		(set to 0)
   *
   *	Flags		int2			
   *
   *	Signer      Handle              0 length UTF8 string
   *                index               sesion id (speicified in message envelop)
   *
   *    SignatureType   UTF8String      (the handle type of the signature - HS_MAC)
   *    SignatureLength int4            (length of signature section)
   *    SignatureSection                (the bytes of the signature, dependent on SignatureType)
   *
   *
   * SignatureSection for MAC signatures:
   *	DigestAlg	UTF8String      (e.g. SHA-1)
   *	ContentInfo	int4, signedData (Hash on <session key + message header + message body + session key>)
   *
   *
   * </pre>
   * Call verifyMessage(byte[] secretKey) to verify.
   * Also see method signMessage(Signature signer), signMessage(PrivateKey key).
   *******************************************************************************/
  public final void signMessage(byte[] secretKey) 
    throws HandleException
  {
    
    //getEncodedMessageBody() will return the "message header + message body"
    byte[] messageHeaderAndBody = getEncodedMessageBody();
     
    byte sigType[] = Common.CREDENTIAL_TYPE_MAC;
    byte sigHashType[] = new byte[1];
    
    sigHashType[0] = Common.DEFAULT_HASH_CODE;   //use SHA 1 for hash
    byte[] signatureBytes = null;
    
    byte[] tobeMACed = new byte[2 * secretKey.length + messageHeaderAndBody.length];
    System.arraycopy(secretKey, 0, tobeMACed, 0, secretKey.length);
    System.arraycopy(messageHeaderAndBody, 0, tobeMACed, secretKey.length, messageHeaderAndBody.length);
    System.arraycopy(secretKey, 0, tobeMACed, secretKey.length + messageHeaderAndBody.length, secretKey.length);
    
    signatureBytes = Util.doDigest(sigHashType[0], tobeMACed);

    int offset = 0;
    signature = new byte[1 + // version - 1 octet
                        1 + // reserved - 1 octet
                        2 + // flags - 2 octets, options
                        Encoder.INT_SIZE + sigType.length + // signature type length + bytes
                        Encoder.INT_SIZE + // signature section length
                        Encoder.INT_SIZE * 2 + // signer hdl length and signer hdl index - 8 octets
                        Encoder.INT_SIZE + // signature length field - 4 octets
                        signatureBytes.length + // signature bytes
                        Encoder.INT_SIZE + // signature hash type length field - 4 octets
                        sigHashType.length ]; // signature type bytes
    signature[offset++] = 0; // version
    signature[offset++] = 0; // reserved
    offset += Encoder.writeInt2(signature, offset, 0); // flags

    offset += Encoder.writeByteArray(signature, offset, Util.encodeString("")); // 0 length string
    offset += Encoder.writeInt(signature, offset, sessionId);    // session id

    // the type of the signature (e.g. HS_MAC)
    offset += Encoder.writeByteArray(signature, offset, sigType);
    
    // length of the signature section...
    offset += Encoder.writeInt(signature, offset, sigHashType.length + Encoder.INT_SIZE +
                               signatureBytes.length + Encoder.INT_SIZE);
                               
    // signature type length + bytes
    offset += Encoder.writeByteArray(signature, offset, sigHashType);

    // signature length + bytes
    offset += Encoder.writeByteArray(signature, offset, signatureBytes);
    
    // force a re-encoding of the body+signature part of the message.
    encodedMessage = null;
  }
  
  /***************************************************************************
   * Generate a signature for this message using the PrivateKey.
   * Method can be used to sign message with RSA Private key and DSA private
   * key.  
   * <pre>
   *
   * Credential section (including signature) within each message:
   *
   *	Version		octet		(always be 0)
   *
   *	Reserved	octet		(set to 0)
   *
   *	Flags		int2			
   *
   *	Signer          HdlValueRef     (place holder in hdl authentication)
   *					  (note: HdlValueRef: UTF8String:int4)
   *
   *    SignatureType   UTF8String      (the handle type of the signature - HS_SIGNED)
   *    SignatureLength int4            (length of signature section)
   *    SignatureSection                (the bytes of the signature, dependent on SignatureType)
   *
   *
   * SignatureSection for HS_SIGNED signatures:
   *	DigestAlg	UTF8String      (e.g. SHA-1)
   *	ContentInfo	int4, signedData
   *
   *
   * </pre>
   * Call verifyMessage(PublicKey key) to verify.
   * Also see method signMessage(Signature signer).
   *******************************************************************************/
  public final boolean signMessage(PrivateKey key) 
    throws HandleException, java.security.SignatureException
  {
    byte[] toBeSigned = getEncodedMessageBody();
       
    byte sigType[] = Common.CREDENTIAL_TYPE_SIGNED;
    byte sigHashType[] = Common.HASH_ALG_SHA1;
    byte signatureBytes[] = null;
    
    try {  
      // compute the signature of the message bytes
      Signature sig = Signature.getInstance(key.getAlgorithm());
      sig.initSign(key);
      sig.update(toBeSigned);
      signatureBytes = sig.sign();
    } catch (java.security.NoSuchAlgorithmException nsae) {
      throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                                "No such algorithm." + nsae.getMessage());
    } catch (java.security.InvalidKeyException ike) {
      throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE,
                                "Can not sign the message." + ike.getMessage());
    }

    
    int offset = 0;
    signature = new byte[1 + // version - 1 octet
                        1 + // reserved - 1 octet
                        2 + // flags - 2 octets
                        Encoder.INT_SIZE + sigType.length + // signature type length + bytes
                        Encoder.INT_SIZE + // signature section length
                        Encoder.INT_SIZE * 2 + // signer hdl length and signer hdl index - 8 octets
                        Encoder.INT_SIZE + // signature length field - 4 octets
                        signatureBytes.length + // signature bytes
                        Encoder.INT_SIZE + // signature hash type length field - 4 octets
                        sigHashType.length ]; // signature type bytes
    signature[offset++] = 0; // version
    signature[offset++] = 0; // reserved
    offset += Encoder.writeInt2(signature, offset, 0); // flags

    offset += Encoder.writeByteArray(signature, offset, signerHdl); // signer handle
    offset += Encoder.writeInt(signature, offset, signerHdlIdx); // signer handle index

    // the type of the signature (e.g. HS_SIGNED)
    offset += Encoder.writeByteArray(signature, offset, sigType);
    
    // length of the signature section...
    offset += Encoder.writeInt(signature, offset, sigHashType.length + Encoder.INT_SIZE +
                               signatureBytes.length + Encoder.INT_SIZE);
                               
    // after this point, the format depends on the sigType, but we currently
    // only support HS_DSAPUBKEY.
    
    // signature type length + bytes
    offset += Encoder.writeByteArray(signature, offset, sigHashType);

    // signature length + bytes
    offset += Encoder.writeByteArray(signature, offset, signatureBytes);

    // force a re-encoding of the body+signature part of the message.
    encodedMessage = null;
    return true;
  }
  
  /****************************************************************************
   * Generate a signature for this message using the given Signature object.
   * The Signature object must already have been initialized for signing.
   * There can be more than one type of message signature, but this
   * implementation can currently only handle HS_DSAPUBKEY-based signatures.
   * <pre>
   *
   * Credential section (including signature) within each message:
   *
   *	Version		octet		(always be 0)
   *
   *	Reserved	octet		(set to 0)
   *
   *	Flags		int2			
   *
   *	Signer          HdlValueRef     (place holder in hdl authentication)
   *					  (note: HdlValueRef: UTF8String:int4)
   *
   *    SignatureType   UTF8String      (the handle type of the signature - HS_DSAPUBKEY, etc)
   *    SignatureLength int4            (length of signature section)
   *    SignatureSection                (the bytes of the signature, dependent on SignatureType)
   *
   *
   * SignatureSection for HS_DSAPUBKEY signatures:
   *	DigestAlg	UTF8String      (e.g. SHA-1)
   *	ContentInfo	int4, signedData
   *
   *
   * </pre>
   * Also see method signMessageWithRSAKey(RSAPrivateKeyImpl key).
   *******************************************************************************/
  public final void signMessage(Signature signer) 
    throws HandleException, java.security.SignatureException
  {
    signer.update(getEncodedMessageBody());
    byte sigType[] = Common.CREDENTIAL_TYPE_SIGNED;
    byte sigHashType[] = Util.getHashAlgIdFromSigId(signer.getAlgorithm());

    byte signatureBytes[] = signer.sign();
    int offset = 0;
    signature = new byte[1 + // version - 1 octet
                        1 + // reserved - 1 octet
                        2 + // flags - 2 octets
                        Encoder.INT_SIZE + sigType.length + // signature type length + bytes
                        Encoder.INT_SIZE + // signature section length
                        Encoder.INT_SIZE * 2 + // signer hdl length and signer hdl index - 8 octets
                        Encoder.INT_SIZE + // signature length field - 4 octets
                        signatureBytes.length + // signature bytes
                        Encoder.INT_SIZE + // signature hash type length field - 4 octets
                        sigHashType.length ]; // signature type bytes
    signature[offset++] = 0; // version
    signature[offset++] = 0; // reserved
    offset += Encoder.writeInt2(signature, offset, 0); // flags

    offset += Encoder.writeByteArray(signature, offset, signerHdl); // signer handle
    offset += Encoder.writeInt(signature, offset, signerHdlIdx); // signer handle index

    // the type of the signature (e.g. HS_SIGNED)
    offset += Encoder.writeByteArray(signature, offset, sigType);
    
    // length of the signature section...
    offset += Encoder.writeInt(signature, offset, sigHashType.length + Encoder.INT_SIZE +
                               signatureBytes.length + Encoder.INT_SIZE);
                               
    // after this point, the format depends on the sigType, but we currently only
    // support HS_DSAPUBKEY.
    
    // signature type length + bytes
    offset += Encoder.writeByteArray(signature, offset, sigHashType);

    // signature length + bytes
    offset += Encoder.writeByteArray(signature, offset, signatureBytes);

    // force a re-encoding of the body+signature part of the message.
    encodedMessage = null;
  }

  /****************************************************************************
   * Validate the signature for this message.  The given Signature object must
   * have been initialized with the public key of the entity that supposedly
   * signed this message.  Returns true if the signature checks out, false 
   * if it doesn't.
   ****************************************************************************/
  public final boolean verifyMessage(byte secretKey[])
    throws Exception
  {
    if(signature==null || signature.length<=0) {
      return false;
      //throw new HandleException(HandleException.MISSING_OR_INVALID_SIGNATURE);
    }
   
    int offset = 0;
    byte sigVersion = signature[offset++];
    byte reserved = signature[offset++];
    int flags = Encoder.readInt2(signature, offset);
    offset += Encoder.INT2_SIZE;

    // 0 length UTF8 string, not used
    byte[] emptyByte = Encoder.readByteArray(signature, offset);
    offset += Encoder.INT_SIZE + emptyByte.length;
    
    // read the session id now
    int sessionid = Encoder.readInt(signature, offset);
    offset += Encoder.INT_SIZE;

    byte[] sigType = Encoder.readByteArray(signature, offset);
    offset += Encoder.INT_SIZE + sigType.length;

    if(!Util.equals(sigType, Common.CREDENTIAL_TYPE_MAC) ) {
      throw new HandleException(HandleException.UNKNOWN_ALGORITHM_ID,
                                "Unknown signature type: "+Util.decodeString(sigType));
    }

    int sigSectionLength = Encoder.readInt(signature, offset);
    offset += Encoder.INT_SIZE;
    
    byte hashAlgBytes[] = Encoder.readByteArray(signature, offset);
    offset += Encoder.INT_SIZE + hashAlgBytes.length;
    
    byte origDigestBytes[] = Encoder.readByteArray(signature, offset);

    byte[] messageHeaderAndBody = getEncodedMessageBody();
    byte[] tobeMACed = new byte[2 * secretKey.length + messageHeaderAndBody.length];
    System.arraycopy(secretKey, 0, tobeMACed, 0, secretKey.length);
    System.arraycopy(messageHeaderAndBody, 0, tobeMACed, secretKey.length, messageHeaderAndBody.length);
    System.arraycopy(secretKey, 0, tobeMACed, secretKey.length + messageHeaderAndBody.length, secretKey.length);
    
    byte verifyDigest[] = Util.doDigest(hashAlgBytes[0], tobeMACed);
    return Util.equals(origDigestBytes, verifyDigest);
  }
  
  /****************************************************************************
   * Validate the signature for this message.  The given Signature object must
   * have been initialized with the public key of the entity that supposedly
   * signed this message.  Returns true if the signature checks out, false 
   * if it doesn't.
   *
   ***************************************************************************/
  public final boolean verifyMessage(PublicKey pubKey)
    throws Exception
  {
    if(signature==null || signature.length<=0) {
      return false;
    }
    int offset = 0;
    byte sigVersion = signature[offset++];
    byte reserved = signature[offset++];
    int flags = Encoder.readInt2(signature, offset);
    offset += Encoder.INT2_SIZE;

    signerHdl = Encoder.readByteArray(signature, offset);
    offset += Encoder.INT_SIZE + signerHdl.length;
    signerHdlIdx = Encoder.readInt(signature, offset);
    offset += Encoder.INT_SIZE;

    byte[] sigType = Encoder.readByteArray(signature, offset);
    offset += Encoder.INT_SIZE + sigType.length;

    if(!Util.equals(sigType, Common.CREDENTIAL_TYPE_SIGNED) &&
       !Util.equals(sigType, Common.CREDENTIAL_TYPE_OLDSIGNED)) {
      throw new HandleException(HandleException.UNKNOWN_ALGORITHM_ID,
                         "Unknown signature type: "+Util.decodeString(sigType));
    }

    int sigSectionLength = Encoder.readInt(signature, offset);
    offset += Encoder.INT_SIZE;
    
    byte hashAlgBytes[] = Encoder.readByteArray(signature, offset);
    offset += Encoder.INT_SIZE + hashAlgBytes.length;
    
    byte sigBytes[] = Encoder.readByteArray(signature, offset);
    
    if (pubKey instanceof RSAPublicKey) {
      
      HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();
      if (cryptoProvider==null) {
        throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                  "Encryption/Key generation engine missing");
      }
      
      byte[] toBeVerified = getEncodedMessageBody();  
      if (Util.equals(hashAlgBytes, Common.HASH_ALG_SHA1)) {
        return cryptoProvider.verify_RSA_SHA1_PKCS1(toBeVerified,
                                            0, toBeVerified.length, 
                                            sigBytes, 
                                            (RSAPublicKey)pubKey);
      }
      else if (Util.equals(hashAlgBytes, Common.HASH_ALG_MD5)) {
        return cryptoProvider.verify_RSA_MD5_PKCS1(toBeVerified,
                                            0, toBeVerified.length,
                                            sigBytes, (RSAPublicKey)pubKey);
      } else {
         throw new HandleException(HandleException.UNKNOWN_ALGORITHM_ID,
                              "Unknown signature type or not supported: "+Util.decodeString(sigType));
      }
      
      
    } else {
      //only DSA key falls in here now ...
      Signature sig = Signature.getInstance(
        Util.getSigIdFromHashAlgId(hashAlgBytes, pubKey.getAlgorithm()));
    
      sig.initVerify(pubKey);
    
      sig.update(getEncodedMessageBody());  
      return sig.verify(sigBytes);
    }
  }
  
   /***************************************************************************
   * Encrypt message header and body with a given secretKey.
   * secretKey is a symetric key. Use DES encryption algorithm.
   * See HandleResolver.java.
   *
   * One usage now is to encrypt message with sessionKey in session menagement.
   * <pre>
   *
   *
   * </pre>
   * Call decryptMessage(byte[] ciphermsg, byte[] secretKey) to decrypt.
   * Also see methods encryptMessage(PublicKey key), decrypt(PrivateKey key).
   ****************************************************************************/
  public static final byte[] encryptMessage(byte[] clearmsg, byte[] secretKey) 
    throws HandleException
  {
    
    //now the member encodedMessage contains the byte array before encryption
    HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();
    if (cryptoProvider==null) {
      throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                "Encryption/Key generation engine missing");
    } else {
      try {
        // return cipher msg
        return cryptoProvider.encrypt_DES_ECB_PKCS5(clearmsg, 0, clearmsg.length, secretKey);
      } catch (Exception e){
        
        if (e instanceof HandleException){
          throw (HandleException)e;
        } else{
          throw new HandleException(HandleException.SECURITY_ALERT,
                                    "Can not encrypt mesage with session key. Message not encrypted!!");
        }
      }                                                           
    }
  }
  
   /*******************************************************************************
   * Decrypt message header and body with a given secretKey.
   * secretKey is a symetric key. Use DES encryption algorithm.
   * See HandleResolver.java.
   *
   * One usage now is to encrypt message with sessionKey in session menagement.
   * Call encryptMessage(byte[] secretKey) to decrypt.
   *
   * @deprecated use Encoder.decryptMessage(SessionInfo, byte[])
   *******************************************************************************/  
  public static final byte[] decryptMessage(byte[] ciphermsg, byte[] secretKey) 
    throws HandleException
  {
         
    //now the member encodedMessage contains the byte array before encryption
    HdlSecurityProvider cryptoProvider = HdlSecurityProvider.getInstance();
	if (cryptoProvider==null) {
      throw new HandleException(HandleException.MISSING_CRYPTO_PROVIDER,
                                "Encryption/Key generation engine missing");
    } else {
      try {
        return cryptoProvider.decrypt_DES_ECB_PKCS5(ciphermsg, 0, 
                                                    ciphermsg.length, secretKey);
      } catch (Exception e){
        if (e instanceof HandleException){
          throw (HandleException)e;
        } else{
          throw new HandleException(HandleException.SECURITY_ALERT,
                                    "Can not decrypt message with session key. Message may not be encrypted!");                   
        }
      }
    }
  }
  
  /*****************************************************************************
   * Removed all cached copies of the encoded message.  This should be
   * called after every change to the message object so that the message
   * encoding is regenerated the next time it is used.
   *****************************************************************************/
  public void clearBuffers() {
    encodedMessage = null;
    signature = null;
    messageBody = null;
  }

  /********************************************************************************
   * Encode (if necessary) and retrieve the header and body portion of this
   * message.  This will leave the encoded value laying around (in the messageBody
   * field) for later use.
   *******************************************************************************/
  public final byte[] getEncodedMessageBody() 
    throws HandleException
  {
    if(messageBody!=null) return messageBody;
    return (messageBody = Encoder.encodeMessage(this));
  }

  /*******************************************************************************
   * Get the encoded value of this message.  Since this object is stupid
   * when it comes to caching the encoded value (for the sake of speed),
   * applications need to make sure that they set the rawMessage and
   * signature fields to null after changing any of the messages fields.
   * This is NOT thread-safe.  If you want to make it thread-safe, 
   * synchronize this method.
   *******************************************************************************/
  public final byte[] getEncodedMessage() 
    throws HandleException 
  {
    // return the message if it has already been generated...
    if(encodedMessage!=null) return encodedMessage;
    
    // generate the messageBody field, if it hasn't already been generated...
    getEncodedMessageBody();
    
    // concatenate the message body and the sig (if any) and return the result
    encodedMessage = 
      new byte[messageBody.length + Encoder.INT_SIZE + (signature==null ? 0 : signature.length)];
    System.arraycopy(messageBody, 0, encodedMessage, 0, messageBody.length);
    if(signature==null) {
      Encoder.writeInt(encodedMessage, messageBody.length, 0);
    } else {
      Encoder.writeInt(encodedMessage, messageBody.length, signature.length);
      System.arraycopy(signature, 0, encodedMessage, 
                       messageBody.length + Encoder.INT_SIZE, signature.length);
    }
    return encodedMessage;
  }
  

  public String toString() {
    return 
      "version="+((int)majorProtocolVersion)+'.'+((int)minorProtocolVersion)+
      "; oc="+opCode+
      "; rc="+responseCode+
      "; snId="+sessionId+
      //"; rqId="+requestId+
      (certify?" crt":"")+
      (cacheCertify?" caCrt":"")+
      (authoritative?" auth":"")+
      (continuous?" cont'd":"")+
      (encrypt?" encrypt":"")+
      (ignoreRestrictedValues?" noAuth":"")+
      (expiration!=0?(" expires:"+new java.util.Date(expiration*1000l)):"")
    ;
  }


  public static final String getResponseCodeMessage(int responseCode) {
    switch(responseCode) {
      case RC_RESERVED: return "RC_RESERVED";
      case RC_SUCCESS: return "SUCCESS";
      case RC_ERROR: return "ERROR";
      case RC_SERVER_TOO_BUSY: return "SERVER TOO BUSY";
      case RC_PROTOCOL_ERROR: return "PROTOCOL ERROR";
      case RC_OPERATION_NOT_SUPPORTED: return "OPERATION NOT SUPPORTED";
      case RC_RECURSION_COUNT_TOO_HIGH: return "RECURSION COUNT TOO HIGH";
      case RC_HANDLE_NOT_FOUND: return "HANDLE NOT FOUND";
      case RC_HANDLE_ALREADY_EXISTS: return "HANDLE ALREADY EXISTS";
      case RC_INVALID_HANDLE: return "INVALID HANDLE";
      case RC_VALUES_NOT_FOUND: return "VALUES NOT FOUND";
      case RC_VALUE_ALREADY_EXISTS: return "VALUE ALREADY EXISTS";
      case RC_OUT_OF_DATE_SITE_INFO: return "OUT OF DATE SITE INFO";
      case RC_SERVER_NOT_RESP: return "SERVER NOT RESPONSIBLE FOR HANDLE";
      case RC_SERVICE_REFERRAL: return "SERVICE REFERRAL";
      case RC_INVALID_ADMIN: return "INVALID ADMIN";
      case RC_INSUFFICIENT_PERMISSIONS: return "INSUFFICIENT PERMISSIONS";
      case RC_AUTHENTICATION_NEEDED: return "AUTHENTICATION NEEDED";
      case RC_AUTHENTICATION_FAILED: return "AUTHENTICATION FAILED";
      case RC_INVALID_CREDENTIAL: return "INVALID CREDENTIAL";
      case RC_AUTHEN_TIMEOUT: return "AUTHENTICATION TIMEOUT";
      case RC_AUTHEN_ERROR: return "AUTHENTICATION ERROR";
      case RC_SESSION_TIMEOUT: return "SESSION TIMEOUT";
      case RC_SESSION_FAILED: return "SESSION FAILED";
      case RC_INVALID_SESSION_KEY: return "INVALID SESSION KEY";
      case RC_SERVER_BACKUP: return "SERVER BACKUP/MAINTAIN";
      case RC_NEED_RSAKEY_FOR_SESSIONEXCHANGE: return "REQUIRE RSA KEY FOR SESSION EXCHANGE";
      case RC_INVALID_SESSIONSETUP_REQUEST: return "INVALID SESSION REQUEST";
      default:
        return "??";
    }
  }

}
