/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import net.handle.jdb.*;
import java.io.File;
import java.util.Random;

/*************************************************************
 * Class used to cache values in a local database file.
 *************************************************************/

public class JDBCache implements Cache {
  private DBHash db;
  
  // private int maxHandles = -1;
  // private long maxSize = 64*1024*1024; // default: 64 megs
  private long purgeInterval = 1000*60*5; // default: five minutes
  private Integer dbLock = new Integer(new Random().nextInt());
  private Runnable purger;
  private boolean needReplacement = false;
  private File cacheFile;

  public JDBCache(File cacheDBFile) throws Exception {
    this.cacheFile = cacheDBFile;
    
    try {
      db = new DBHash(cacheFile, 2048, 1024);
    } catch (Exception e) {
      System.err.println("Error setting up cache: "+e);
      System.err.println("Cache will be reset in purge cycle");
      needReplacement = true;
    }
    
    purger = new Runnable() {
      public void run() {
        while(true) {
          try {
            purgeHandles();
          } catch (Exception e) {
            System.err.println("Error purging handles: "+e);
            e.printStackTrace(System.err);
            needReplacement = true;
          }

          // if there was an error with the database, 
          try {

            // do a synchronized check of the needReplacement flag.
            // this check needs to be synchronized because some DB operations
            // will set needReplacement to 'true' in case it doesn't return
            // from the associated DB call
            boolean localReset = false;
            synchronized(dbLock) {
              localReset = needReplacement;
            }
            
            if(localReset) {
              System.err.println("resetting cache DB file");
              synchronized(dbLock) {
                db = null;
              }
              if(cacheFile.exists()) {
                cacheFile.delete();

                // sleep for 5 seconds so that the delete is sure to take effect
                Thread.currentThread().sleep(5000);
              }
              
              DBHash tmpDB = new DBHash(cacheFile, 2048, 1024);
              
              synchronized(dbLock) {
                db = tmpDB;
              }
            }
          } catch (Exception e) {
            System.err.println("Error resetting cache DB: "+e);
          }
          
          try {
            synchronized(this) {
              this.wait(purgeInterval);
            }
          } catch (Exception e) {
            System.err.println("Error waiting for next cache purge: "+e);
          }
        }
      }
    };
    
    Thread t = new Thread(purger);
    t.setDaemon(true);
    t.setPriority(Thread.MIN_PRIORITY);
    t.start();
  }


  /** Returns any non-expired handle values that are in the caches 
   *  storage.  A null return value indicates that the requested values
   *  aren't in the cache.  Returning the an array of values (including
   *  an array of zero length) indicates that the returned values are
   *  the only values from the requested set (ie the handle doesn't have
   *  any more values from the requested set).
   *
   *  ***** Speed is important in this method *****
   */
  public byte[][] getCachedValues(byte handle[], byte reqTypes[][], 
                                  int reqIndexes[])
    throws Exception
  {
    if(db==null || needReplacement) return null;
    
    byte clumps[];
    try {
      synchronized(dbLock) {
        boolean oldReplace = needReplacement;
        needReplacement = true;
        clumps = db.getValue(handle);
        needReplacement = oldReplace;
      }
    } catch (Exception e) {
      System.err.println("JDB error: "+e);
      needReplacement = true;
      return null;
    }
    if(clumps==null) {
      return null;
    }

    int idx=0;

    boolean allValues =
      (reqIndexes==null || reqIndexes.length<=0) &&
      (reqTypes==null || reqTypes.length<=0);

    // records should have this layout:
    //  typeArrayLen typeArray indexArrayLen indexArray numClumps ( length time_retrieved clump )+
    byte types[][] = new byte[Encoder.readInt(clumps,idx)][];
    idx+=Encoder.INT_SIZE;
    idx+=Encoder.readByteArrayArray(types,clumps,idx);

    int indexes[] = Encoder.readIntArray(clumps, idx);
    idx += Encoder.INT_SIZE + Encoder.INT_SIZE*indexes.length;

    int numClumps = Encoder.readInt(clumps, idx);
    idx += Encoder.INT_SIZE;
    
    // if we don't have the requested types, return null
    if(!(types.length==0 && indexes.length==0)) {
      // the cache DB only has specific values (not necessarily all values) for the handle
      
      if(allValues) {
        return null;         // they were asking for all values, which we don't have
      }

      if(reqIndexes!=null && reqIndexes.length>0) {
        // the user is requesting specific indexes, see if we have them...
        for(int i=0; i<reqIndexes.length; i++) {
          if(!Util.isInArray(indexes, reqIndexes[i])) {
            return null;        // one of the requested indexes wasn't cached
          }
        }
      }
      if(reqTypes!=null && reqTypes.length>0) {
        // the user is requesting specific types, see if we have them...
        for(int i=0; i<reqTypes.length; i++) {
          if(!Util.isInArray(types, reqTypes[i])) {
            return null;     // one of the requested types wasn't cached
          }
        }
      }
    }


    // at this point, we know that we have the requested values cached so
    // we just need to filter them out, check for timeouts and return them

    int clumpLen;
    byte clumpType[];
    int clumpIndex;
    int startIdx = idx;
    int numMatches = 0;
    int now = (int)(System.currentTimeMillis()/1000);
    boolean gotClumps = false;

    // count the number of matching records
    while(idx<clumps.length) {
      clumpLen = Encoder.readInt(clumps,idx);
      idx+=Encoder.INT_SIZE;
      idx+=Encoder.INT_SIZE; // skip the time-retrieved field

      clumpType = Encoder.getHandleValueType( clumps, idx);
      clumpIndex = Encoder.getHandleValueIndex( clumps, idx);
      
      if( allValues ||
          Util.isInArray(reqTypes, clumpType) ||
          Util.isInArray(reqIndexes, clumpIndex))
        numMatches++;
      gotClumps = true;
      idx+=clumpLen;
    }

    // if we didn't find any of the requested records, return null 
    // not empty set - because the empty set would never time-out
    if(!gotClumps) {
      return null;
    }

    // put the matching records into an array
    byte retValues[][] = new byte[numMatches][];
    int clumpNum = 0;
    idx = startIdx;
    int valueDate;
    HandleValue testValue = null;
    while(idx<clumps.length) {
      clumpLen = Encoder.readInt(clumps,idx);
      idx+=Encoder.INT_SIZE;
      valueDate = Encoder.readInt(clumps,idx);
      idx+=Encoder.INT_SIZE;

      clumpType = Encoder.getHandleValueType(clumps, idx);
      clumpIndex = Encoder.getHandleValueIndex(clumps, idx);
      
      if( allValues ||
          Util.isInArray(reqTypes, clumpType) ||
          Util.isInArray(reqIndexes, clumpIndex)) {
        // check to see if the value is timed out... if so, return nothing.

        retValues[clumpNum] = new byte[clumpLen];
        if(testValue==null) testValue = new HandleValue();
        Encoder.decodeHandleValue(clumps, idx, testValue);
        if(testValue.isExpired(now, valueDate)) {
          // value is stale, need to re-retrieve all values for this query
          return null;
        }
        System.arraycopy(clumps, idx, retValues[clumpNum], 0, retValues[clumpNum].length);
        clumpNum++;
      }
      
      idx+=clumpLen;
    }

    if(clumpNum!=retValues.length) {
      // we missed something along the way - failsafe!!
      System.err.println("Unknown cache error!!!");
      needReplacement = true;
      return null;
    }

    return retValues;
  }



  /** Store the given handle values after a query for the handle.  The 
   *  query was performed with the given type-list and index-list.
   *
   * ***** Speed is less important in this method *****
   *
   */
  public void setCachedValues(byte handle[], HandleValue newValues[], 
                              byte newTypeList[][], int newIndexList[])
    throws Exception
  {
    byte types[][] = null;
    int indexes[] = null;
    int valueDates[] = null;
    HandleValue values[] = null;
    
    byte clumps[] = null;
    try {
      synchronized(dbLock) {
        if(db==null) return;
        
        boolean oldReplace = needReplacement;
        needReplacement = true;
        clumps = db.getValue(handle);
        needReplacement = oldReplace;
      }
    } catch (Exception e) {
      System.err.println("JDB error: "+e);
      needReplacement = true;
      e.printStackTrace(System.err);
      return;
    }
    
    int idx=0;
    
    if(clumps!=null) {
      types = new byte[Encoder.readInt(clumps,idx)][];
      idx+=Encoder.INT_SIZE;
      idx+=Encoder.readByteArrayArray(types, clumps, idx);
      
      indexes = Encoder.readIntArray(clumps, idx);
      idx += Encoder.INT_SIZE + Encoder.INT_SIZE*indexes.length;
      
      values = new HandleValue[Encoder.readInt(clumps, idx)];
      idx += Encoder.INT_SIZE;
      
      valueDates = new int[values.length];
      
      int startValuesIdx = idx;
      int i = 0;
      while(idx < clumps.length) {
        int clumpLen = Encoder.readInt(clumps, idx);
        idx += Encoder.INT_SIZE;
        valueDates[i] = Encoder.readInt(clumps, idx);
        idx += Encoder.INT_SIZE;
        
        values[i] = new HandleValue();
        Encoder.decodeHandleValue(clumps, idx, values[i]);
        i++;
        idx += clumpLen;
      }
    }
    
    int now = (int)(System.currentTimeMillis()/1000);
    int newValueCount = values==null ? 0 : values.length;
    
    
    // at this point the values that will go into the cache are the union of the
    // values in 'values' and 'newValues'
    
    if((newTypeList==null || newTypeList.length<=0) &&
       (newIndexList==null || newIndexList.length<=0)) {
      // replace all old values with new values...
      types = null;
      indexes = null;
      values = null;
    } else if((types!=null && types.length<=0) &&
              (indexes!=null && indexes.length<=0)) {
      // there was already a query for all values, we'll only update the new
      // values that were just retrieved
      for(int i=0; values!=null && i<newValues.length; i++) {
        int thisIndex = newValues[i].index;
        for(int j=0; j<values.length; j++) {
          if(values[j]!=null && values[j].index==thisIndex) {
            values[j] = null;
          }
        }
      }
      newTypeList = null;
      newIndexList = null;
      
    } else {
      // There were already some values in the cache, and we got some more.
      // merge the new fresh values with the old ones.
      
      if(newTypeList!=null && newTypeList.length>0) {
        byte typeListCopy[][] = new byte[newTypeList.length][];
        System.arraycopy(newTypeList,0,typeListCopy,0,newTypeList.length);
        newTypeList = typeListCopy;
      }
      
      // remove duplicates in intersections of the old type query list and the new one
      for(int i=0; types!=null && i<types.length; i++) {
        if(types[i]==null) continue;
        for(int j=0; newTypeList!=null && j<newTypeList.length; j++) {
          if(newTypeList[j]!=null && Util.equalsCI(types[i],newTypeList[j])) {
            newTypeList[j] = null;
          }
        }
      }
      
      // remove duplicates in intersections of the old index query list and the new one
      for(int i=0; indexes!=null && i<indexes.length; i++) {
        if(indexes[i]<0) continue;
        for(int j=0; newIndexList!=null && j<newIndexList.length; j++) {
          if(newIndexList[j]>=0 && indexes[i]==newIndexList[j]) {
            newIndexList[j] = -1;
          }
        }
      }
      
      // remove values for which we have newer values from the old list of values
      for(int i=0; values!=null && i<newValues.length; i++) {
        boolean alreadyHaveVal = false;
        int thisIndex = newValues[i].index;
        for(int j=0; j<values.length; j++) {
          if(values[j]!=null && values[j].index==thisIndex) {
            // get rid of old values
            values[j] = null;
            alreadyHaveVal = true;
          }
        }
      }
    }
    
    // copy the new values, index-queries, and type-queries into a new clump to
    // put back in the database.
    int dataLen = 0;
    int typeCount = 0;
    int indexCount = 0;
    int valueCount = 0;
    dataLen += Encoder.INT_SIZE;  // type-list length
    dataLen += Encoder.INT_SIZE;  // index-list length
    dataLen += Encoder.INT_SIZE;  // value-list length
    
    // typeArrayLen typeArray indexArrayLen indexArray numClumps ( length time_retrieved clump )+
    for(int i=0; types!=null && i<types.length; i++) {
      if(types[i]!=null) {
        dataLen += Encoder.INT_SIZE + types[i].length;
        typeCount++;
      }
    }
    for(int i=0; newTypeList!=null && i<newTypeList.length; i++) {
      if(newTypeList[i]!=null) {
        dataLen += Encoder.INT_SIZE + newTypeList[i].length;
        typeCount++;
      }
    }
            
    for(int i=0; indexes!=null && i<indexes.length; i++) {
      if(indexes[i]>=0) {
        dataLen += Encoder.INT_SIZE;
        indexCount++;
      }
    }
    for(int i=0; newIndexList!=null && i<newIndexList.length; i++) {
      if(newIndexList[i]>=0) {
        dataLen += Encoder.INT_SIZE;
        indexCount++;
      }
    }
    for(int i=0; values!=null && i<values.length; i++) {
      if(values[i]!=null) {
        dataLen += Encoder.INT_SIZE; // the time-retrieved field
        dataLen += Encoder.INT_SIZE; // the value-length field
        dataLen += Encoder.calcStorageSize(values[i]);
        valueCount++;
      }
    }
    for(int i=0; newValues!=null && i<newValues.length; i++) {
      if(newValues[i]!=null) {
        dataLen += Encoder.INT_SIZE; // the time-retrieved field
        dataLen += Encoder.INT_SIZE; // the value-length field
        dataLen += Encoder.calcStorageSize(newValues[i]);
        valueCount++;
      }
    }
                            
    byte dataBuf[] = new byte[dataLen];
    int loc = 0;
    loc += Encoder.writeInt(dataBuf, loc, typeCount);
    for(int i=0; types!=null && i<types.length; i++) {
      if(types[i]!=null) {
        loc += Encoder.writeByteArray(dataBuf, loc, types[i]);
      }
    }
    for(int i=0; newTypeList!=null && i<newTypeList.length; i++) {
      if(newTypeList[i]!=null) {
        loc += Encoder.writeByteArray(dataBuf, loc, newTypeList[i]);
      }
    }
    
    loc += Encoder.writeInt(dataBuf, loc, indexCount);
    for(int i=0; indexes!=null && i<indexes.length; i++) {
      if(indexes[i]>=0) {
        loc += Encoder.writeInt(dataBuf, loc, indexes[i]);
      }
    }

    for(int i=0; newIndexList!=null && i<newIndexList.length; i++) {
      if(newIndexList[i]>=0) {
        loc += Encoder.writeInt(dataBuf, loc, newIndexList[i]);
      }
    }
            
    loc += Encoder.writeInt(dataBuf, loc, valueCount);
    for(int i=0; values!=null && i<values.length; i++) {
      if(values[i]!=null) {
        int lenLoc = loc;
        loc += Encoder.INT_SIZE; // placeholder for the value-length field
        loc += Encoder.writeInt(dataBuf, loc, valueDates[i]);
        loc += Encoder.encodeHandleValue(dataBuf, loc, values[i]);
        Encoder.writeInt(dataBuf, lenLoc, loc-lenLoc-2*Encoder.INT_SIZE); // the value-length field
      }
    }
        
    for(int i=0; newValues!=null && i<newValues.length; i++) {
      if(newValues[i]!=null) {
        int lenLoc = loc;
        loc += Encoder.INT_SIZE; // placeholder for the value-length field
        loc += Encoder.writeInt(dataBuf, loc, now);
        loc += Encoder.encodeHandleValue(dataBuf, loc, newValues[i]);
        Encoder.writeInt(dataBuf, lenLoc, loc-lenLoc-2*Encoder.INT_SIZE); // the value-length field
      }
    }
    
    synchronized(dbLock) {
      if(db==null) return;
      db.setValue(handle, dataBuf);
    }
  }


  /** Set the maximum size for the cache by the number of handles.
   * NOT IMPLEMENTED!
   */
  public void setMaximumHandles(int maxHandles) {
    // this.maxHandles = maxHandles;
    // if(maxHandles>=0) {
    //   notifyPurger();
    // }
  }
  
  /** Set the maximum size for the cache by the number of bytes
   *  used for storage.
   *  NOT IMPLEMENTED!
   */
  public void setMaximumSize(int maxSize) {
    // this.maxSize = maxSize;
    // if(maxSize>=0) {
    //   notifyPurger();
    // }
  }

  
  /** Remove all values from the cache */
  public void clear() 
    throws Exception
  {
    db.deleteAllRecords();
  }
  
  public void close()
    throws Exception
  {
    db.close();
  }
  

  private void notifyPurger() {
    try {
      synchronized (purger) {
        purger.notify();
      }
    } catch (Exception e) {
      System.err.println("Error notifying purge thread!");
      e.printStackTrace(System.err);
    }
  }

  private void purgeHandles() {
    if(db==null) return;
    
    HandleValue value = new HandleValue();
    for(java.util.Enumeration enumeration = db.getEnumerator(); enumeration.hasMoreElements(); ) {
      try {
        Object nextObj = enumeration.nextElement();
        if(nextObj==null) continue;
        byte[][] record = (byte[][])nextObj;

        int now = (int)(System.currentTimeMillis()/1000);
        byte handle[] = record[0];
        byte buf[] = record[1];
        
        //  typeArrayLen typeArray indexArrayLen indexArray numClumps ( length time_retrieved clump )+
        int loc = 0;
        int numTypes = Encoder.readInt(buf, loc);
        loc += Encoder.INT_SIZE;
        for(int i=0; i<numTypes; i++) {
          loc += Encoder.readInt(buf, loc) + Encoder.INT_SIZE;
        }

        int indexes[] = Encoder.readIntArray(buf, loc);
        loc += Encoder.INT_SIZE + indexes.length * Encoder.INT_SIZE;

        int numValues = Encoder.readInt(buf, loc);
        loc += Encoder.INT_SIZE;

        int numValidValues = 0;
        for(int i=0; i<numValues; i++) {
          int valueLength = Encoder.readInt(buf, loc);
          loc += Encoder.INT_SIZE;

          int valueDate = Encoder.readInt(buf, loc);
          loc += Encoder.INT_SIZE;
          
          Encoder.decodeHandleValue(buf, loc, value);
          loc += valueLength;

          if(!value.isExpired(now, valueDate))
            numValidValues++;
        }
        if(numValidValues<=0) {
          db.deleteValue(handle);
        }
        
      } catch (Exception e) {
        needReplacement = true;
        System.err.println("Got exception purging handles: "+e);
        e.printStackTrace(System.err);
        break;
      }
    }
  }
}
