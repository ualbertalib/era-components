/**********************************************************************\
 © COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.security.*;
import java.net.*;

public class ServerInfo {
  public int serverId;         // The "ID" of this server
  public byte[] ipAddress;     // IP Address of the server
  //public int protocolVersion;  // The protocol version# of the server
  public byte publicKey[];     // The public key used to verify responses from the server
  public Interface[] interfaces;// The "interfaces" presented by this server (port,protocol,etc)

  private String addrString = null;

  /**
   * Return the server's Interface for the given protocol which can handle the
   * given request; assume server has only 1 such interface.
   */
  public Interface interfaceWithProtocol(int desiredProtocol, AbstractRequest req) {
    for (int i = 0; i < this.interfaces.length; i++) {
      if (this.interfaces[i].protocol == desiredProtocol
          && this.interfaces[i].canHandleRequest(req)) {
        return this.interfaces[i];
      }
    }
    
    return (Interface) null;
  }

  public java.net.InetAddress getInetAddress()
    throws UnknownHostException
  {
    // TODO:  Replace with less resource-hungry operation when the
    // baseline Java requirement allows it
    return InetAddress.getByName(getAddressString());
  }

  public String getAddressString() {
    if (addrString != null) return addrString;

    StringBuffer sb = new StringBuffer();
    if(ipAddress == null) return "";

    boolean ipv6 = false;
    int IPV6_ONLY = Common.IP_ADDRESS_LENGTH - 4;
    for (int i=0; i<IPV6_ONLY; i++){
      if (ipAddress[i] != 0){
        ipv6 = true;
        break;
      }
    }
    
    if (ipv6){
      for(int i=0; i<ipAddress.length; i+=2) {
        if(sb.length()>0) sb.append(':');
        sb.append(Util.decodeHexString(ipAddress, i, i+2, false));
      }
    }
    else {
      for(int i=IPV6_ONLY; i<ipAddress.length; i++) {
        if(sb.length()>0)
          sb.append('.');
        sb.append(0x00ff & ipAddress[i]);
      }
    }
    
    addrString = sb.toString();
    return addrString;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(serverId);
    sb.append(' ');
    sb.append(getAddressString());
    sb.append(' ');
    Interface ifcs[] = interfaces;
    boolean hasInterfaces = false;
    for(int i=0; ifcs!=null && i<ifcs.length; i++) {
      Interface ifc = ifcs[i];
      if(ifc==null) continue;
      if(!hasInterfaces) {
        sb.append("(");
        hasInterfaces = true;
      } else {
        sb.append(",");
      }
      sb.append(Interface.protocolName(ifc.protocol));
      sb.append("/");
      sb.append(ifc.port);
    }
    if(hasInterfaces) sb.append(")");
    return sb.toString();
  }

  public ServerInfo cloneServerInfo() {
    ServerInfo si2 = new ServerInfo();
    si2.serverId = serverId;
    byte tmp[] = ipAddress;
    if(tmp!=null) {
      si2.ipAddress = new byte[tmp.length];
      System.arraycopy(tmp, 0, si2.ipAddress, 0, tmp.length);
    } else {
      si2.ipAddress = null;
    }
    tmp = publicKey;
    if(tmp!=null) {
      si2.publicKey = new byte[tmp.length];
      System.arraycopy(tmp, 0, si2.publicKey, 0, tmp.length);
    } else {
      si2.publicKey = null;
    }
    Interface tmpIA[] = interfaces;
    si2.interfaces = tmpIA==null ? null : new Interface[tmpIA.length];
    for(int i=0; tmpIA!=null && i<tmpIA.length; i++) {
      Interface tmpI = tmpIA[i];
      si2.interfaces[i] = tmpI==null ? null : tmpI.cloneInterface();
    }
    return si2;
  }
  

  public PublicKey getPublicKey()
    throws Exception
  {
    return Util.getPublicKeyFromBytes(publicKey, 0);
  }

  /** Returns true if the given object is a ServerInfo object and refers
      to the same server as this object. */
  public boolean equals(Object obj) {
    if(!(obj instanceof ServerInfo))
      return false;
    ServerInfo info = (ServerInfo)obj;

    if(serverId!=info.serverId)
      return false;
    
    if(!Util.equals(info.ipAddress, this.ipAddress))
      return false;
    
    if(interfaces==null && info.interfaces==null)
      return true;
    
    if(interfaces==null && info.interfaces!=null)
      return false;

    if(interfaces!=null && info.interfaces==null)
      return false;
    
    if(interfaces.length!=info.interfaces.length)
      return false;

    for(int i=0; i<interfaces.length; i++) {
      if(!interfaces[i].equals(info.interfaces[i]))
        return false;
    }
    return true;
  }
}
