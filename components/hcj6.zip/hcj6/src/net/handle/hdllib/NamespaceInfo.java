/**********************************************************************\
 © COPYRIGHT 2005 Corporation for National Research Initiatives (CNRI);
 All rights reserved.

 This software is made available subject to the 
 Handle System Public License, which may be obtained at
 http://hdl.handle.net/4263537/5009 or hdl:4263537/5009
------------------------------------------------------------------------
Developer: Sean Reilly <sreilly@cnri.reston.va.us>
Created: Aug 1, 2004
\**********************************************************************/

package net.handle.hdllib;

import net.handle.security.*;
import java.net.*;
import java.io.*;
import java.util.*;
import net.cnri.simplexml.*;
import java.security.PublicKey;


/** Object containing information about a handle namespace.  A namespace is
  * basically a prefix for an identifier and can be a global prefix which 
  * consists of everything before the first slash of a handle identifer, or it
  * can be a local prefix which includes the global prefix and also some part
  * of the identifer after the slash.  A handle could be contained within
  * multiple nested namespaces.
  */
public class NamespaceInfo {
  public static final String STATUS_ACTIVE = "active";
  public static final String STATUS_INACTIVE = "inactive";
  
  public static final String PUBKEY_TAG = "pubkey";
  public static final String CONTACT_TAG = "contact";
  public static final String STATUS_MSG_TAG = "statusmsg";
  public static final String STATUS_TAG = "status";
  public static final String DELEGATE_SUBNAMESPACES_TAG = "delegate";
  public static final String DELEGATION_DELIM_TAG = "delimiter";
  public static final char DEFAULT_DELEGATION_DELIMITER = '/';
  
  private static XParser xmlParser = new XParser();
  private static final NamespaceInfo nsInfo = new NamespaceInfo();
  
  private XTag xmlInfo = null;
  private NamespaceInfo parentNamespace = null;
  
  public NamespaceInfo(HandleValue namespaceValue) 
    throws HandleException
  {
    this(namespaceValue.getData());
  }
  
  public NamespaceInfo(byte rawInfo[]) 
    throws HandleException
  {
    try {
      xmlInfo = 
        xmlParser.parse(new InputStreamReader(new ByteArrayInputStream(rawInfo), "UTF8"), false);
    } catch (Exception e) {
      if(e instanceof HandleException) throw (HandleException)e;
      throw new HandleException(HandleException.INVALID_VALUE,
                                "Error parsing namespace information: "+e);
    }
  }
  
  /** Construct a new namespace information record, with the default settings */
  public NamespaceInfo() {
    this.xmlInfo = new XTag("NAMESPACE");
  }
  
  /** Set the parent for this namespace.  This should be called when resolving 
    * an identifier that is contained within multiple nested namespaces.
    */
  public void setParentNamespace(NamespaceInfo parent) {
    this.parentNamespace = parent;
  }
  
  /** Get the parent for this namespace.  This can be useful for tracing back
    * namespaces when debugging or when verifying identifiers or sub-namespaces
    * based on signatures applied by parent namespaces.  If there is no higher
    * level namespace, then this will return null;
    */
  public NamespaceInfo getParentNamespace() {
    return this.parentNamespace;
  }
  
  
  /** Return an email address for the person or company that is responsible for
    * this namespace.
    */
  public String getResponsiblePartyContactAddress() {
    return xmlInfo.getStrSubTag(CONTACT_TAG, null);
  }
  
  /** Return a message that can be presented to a user who tries to resolve
    * an identifier under this namespace if the namespace status is not active.
    */
  public String getStatusMessage() {
    return xmlInfo.getStrSubTag(STATUS_MSG_TAG, null);
  }
  
  /** Return the status of this namespace as a String.  Currently known values
    * are "active" and "inactive" although it is possible that other values will
    * be used in the future.
    */
  public String getNamespaceStatus() {
    return xmlInfo.getStrSubTag(STATUS_TAG, STATUS_ACTIVE);
  }
  
  /** Return whether or not names under this namespace can be delegated to other
    * handle servers.  If so, the getDelegationDelimeter() method should be
    * called in order to indicate the character that separates different 
    * delegation levels of the namespace.
    */
  public boolean getAllowDelegation() {
    return xmlInfo.getBoolSubTag(DELEGATE_SUBNAMESPACES_TAG, false);
  }
  
  /** Returns the delimiter that should be used to determine the next part of the
    * handle/identifier that is delegated to another service.
    */
  public char getDelegationDelimeter() {
    String delStr =
      xmlInfo.getStrSubTag(DELEGATION_DELIM_TAG, null);
    if(delStr==null || delStr.length()<=0)
      return DEFAULT_DELEGATION_DELIMITER;
    return delStr.charAt(0);
  }
  
  /** Return a list of public keys that can sign values within this namespace.
    * Keep in mind that these keys should not be considered valid unless the 
    * HandleValue that was used to construct this object was verified in some
    * way, such as with a signed handle response or using the SecureResolver.
    */
  public java.security.PublicKey[] getPublicKeys() {
    ArrayList keys = new ArrayList();
    for(int i=xmlInfo.getSubTagCount()-1; i>=0; i--) {
      XTag tag = xmlInfo.getSubTag(i);
      if(tag.getName().equalsIgnoreCase(PUBKEY_TAG)) {
        try {
          PublicKey key = Util.getPublicKeyFromBytes(Util.encodeHexString(tag.getStrValue()), 0);
          if(key!=null) keys.add(key);
        } catch (Exception e) {
          System.err.println("Error parsing public key from namespace info: "+
                             e+"\n"+tag);
        }
      }
    }
    return (java.security.PublicKey[])keys.toArray(new java.security.PublicKey[keys.size()]);
  }
  
}
