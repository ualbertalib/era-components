/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;

import java.security.PublicKey;

/**
 * Base class for all request types.  Holds the Handle to which the request
 * applies as well as the namespace information that was acquired
 * during the resolution process
 */
public abstract class AbstractRequest 
  extends net.handle.hdllib.AbstractMessage
{
  public byte handle[];
  public boolean isAdminRequest = false;
  public boolean requiresConnection = false;

  public net.handle.hdllib.AuthenticationInfo authInfo = null;
  
  public int siteInfoSerial = -1;

  // if there is a session object associated with this
  // request, sessionInfo will be set and used to begin
  // (or continue) a session with the destination server.
  // If this is set, the ClientSessionTracker setting is
  // ignored.
  public net.handle.hdllib.ClientSideSessionInfo sessionInfo = null;

  // This is used to keep track of sessions so that
  // if a session has been created with whatever server
  // this is sent to, that same session can be used to
  // send this message.  If a session is found, then
  // it is used to send the message.  If a session is
  // not found and sessionInfo is not null, a new session
  // is created and used to send this message.
  // If sessionInfo is non-null and authInfo is null
  // then an anonymous session is used to send this message.
  public net.handle.hdllib.ClientSessionTracker sessionTracker = null;

  // these are for use by the resolver for verifying the
  // signatues of responses.
  byte serverPubKeyBytes[] = null;
  PublicKey serverPubKey = null;

  // Indicates whether or not the response to this request 
  // is "streamable."  If so, the request/response can only 
  // be sent via a TCP or other stream-oriented transport.
  // This 'streaming' flag is not a part of the official handle
  // protocol or API specification.
  public boolean streaming = false;
  
  // The most specific namespace containing this handle.  Parent namespaces
  // are accessible by calling the getParentNamespace() method on this namespace.
  private net.handle.hdllib.NamespaceInfo namespace = null;
  
  public AbstractRequest(byte handle[], int opCode, net.handle.hdllib.AuthenticationInfo authInfo) {
    super(opCode);
    this.authInfo = authInfo;
    this.handle = handle;
    this.responseCode = net.handle.hdllib.AbstractMessage.RC_RESERVED;
  }
  
  /** Returns the information for the most specific namespace that was 
    * encountered when performing this resolution.  Higher level namespaces
    * can be accessed using the getParentNamespace() method of NamespaceInfo. */
  public net.handle.hdllib.NamespaceInfo getNamespace() {
    return this.namespace;
  }
  
  /** Set the most specific namespace containing the identifier being
    * resolved.  This will set the parent of the given namespace to the 
    * current namespace. */
  public void setNamespace(NamespaceInfo namespace) {
    if(namespace!=null) namespace.setParentNamespace(this.namespace);
    this.namespace = namespace;
  }
  
  
  /** Override the clearing of buffers to also clear the namespace information */
  public void clearBuffers() {
    this.namespace = null;
    super.clearBuffers();
  }
  

  public String toString() {
    return super.toString()+(isAdminRequest?" adm":"")+' '+Util.decodeString(handle);
  }
}
