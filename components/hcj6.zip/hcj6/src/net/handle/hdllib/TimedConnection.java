/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.hdllib;



import java.net.*;

import java.io.*;



/**

 * Factory for socket connections which time out if not connected after

 * a specified delay.  The underlying java.net.Socket object actually sticks

 * around until the native connect operation times out(takes a LONG time), or

 * when the Java VM exits(because the connect occurs in a daemon thread).

 **/

public class TimedConnection {



  private static final int POLL_DELAY = 100;



  public static Socket getSocket (InetAddress addr, int port, int delay)

    throws InterruptedIOException, IOException 

  {

    SocketThread t = new SocketThread(addr, port);

    t.start();



    int timer = 0;



    while (true) {

      if (t.isConnected()) {

        return t.getSocket();

      }

      else {

        if (t.isError()){ 

          throw (t.getException());

        }

        try {

          Thread.sleep(POLL_DELAY);

        }

        catch (InterruptedException ie) {}

        timer += POLL_DELAY;

        if (timer > delay) {

          throw new InterruptedIOException("Connection timed out.");

        }

      }

    }

  }



  static class SocketThread extends Thread {

    volatile private Socket socket = null;

    private InetAddress addr  = null;

    private int    port       = 0;

    private IOException exception = null;



    public SocketThread(InetAddress addr, int port) {

      this.addr = addr;

      this.port = port;

      setDaemon(true);

    }



    public void run() {

      Socket sock = null;

      try {

          sock = new Socket(addr, port);

      }

      catch (IOException e) {

        exception = e;

        return;

      }

      socket = sock;

    }



    public boolean isConnected() {

      return (socket != null);

    }



    public boolean isError() {

      return (exception != null);

    }



    public Socket getSocket() {

      return socket;

    }



    public IOException getException() {

      return exception;

    }

  }



}

