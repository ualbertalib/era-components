/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security;

import java.math.*;
import java.security.*;
import java.security.interfaces.*;
import javax.crypto.interfaces.*;
import javax.crypto.spec.*;

public class DHPrivateKeyImpl
  implements DHPrivateKey
{
  private BigInteger x, p, g;
  
  public DHPrivateKeyImpl(BigInteger x, BigInteger p, BigInteger g){
    this.x = x;
    this.p = p;
    this.g = g;
  }
  
  public BigInteger getX(){ return x; }
  public BigInteger getP(){ return p; }
  public BigInteger getG(){ return g; }

  public DHParameterSpec getParams() {
    return new DHParameterSpec(p, g);
  }

  public String getAlgorithm() { return "DH"; }

  public String getFormat() { return "HDL_DH_PRIV"; }
  
  public byte[] getEncoded() {
    //// need to implement
    return null;
  }
}
