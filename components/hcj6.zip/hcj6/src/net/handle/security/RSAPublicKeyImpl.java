/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security;

import net.handle.hdllib.Util;
import java.math.*;
import java.security.*;
import java.security.interfaces.*;

public class RSAPublicKeyImpl 
  implements RSAPublicKey
  //implements PublicKey
{
  private BigInteger modulus;
  private BigInteger publicExponent;
  
  public RSAPublicKeyImpl(BigInteger m, BigInteger exp) 
    throws NumberFormatException
  {
    this.modulus = m;
    this.publicExponent = exp;
  }
  
  public BigInteger getModulus()  { return modulus;}
  
  public BigInteger getPublicExponent() { return publicExponent;}

  public String getAlgorithm() { return "RSA"; }

  public String getFormat() { return "HDL_RSA_PUB"; }
  
  public byte[] getEncoded() {
    try {
      return Util.getBytesFromPublicKey(this);
    } catch (Exception e) {
      System.err.println("Error encoding public key: "+e);
      return null;
    }
  }
}
