/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.security;

import java.math.*;
import java.security.*;
import java.security.interfaces.*;

public class RSAPrivateKeyImpl 
  implements RSAPrivateKey
  //implements PrivateKey
{
  private BigInteger modulus;
  private BigInteger privateExponent;
  
  public RSAPrivateKeyImpl(BigInteger m, BigInteger exp) 
    throws NumberFormatException
  {
    this.modulus = m;
    this.privateExponent = exp;
  }
  
  public BigInteger getModulus()  { return modulus;}
  
  public BigInteger getPrivateExponent() { return privateExponent;}

  public String getAlgorithm() { return "RSA"; }

  public String getFormat() { return "HDL_RSA_PRIV"; }
  
  public byte[] getEncoded() {
    //// need to implement
    return null;
  }
}

