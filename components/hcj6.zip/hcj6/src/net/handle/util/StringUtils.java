/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

import java.util.Calendar;

public class StringUtils {

  /***********************************************************
   * This function will return the Nth string segment in the
   * string "str" delimited by "delimiter".  If n is out of
   * the range of string segments, it will just return an
   * empty string.  The string segments start at 0.  This 
   * can probably be sped up a bit.
   * For example, fieldIndex("A:B:C:D:E",':',2) would return "C"
   ***********************************************************/
  public static final String fieldIndex(String str, char delimiter, int n) {
    int delimLoc = str.indexOf(delimiter);
    int currentField=0, lastIndex=0, thisIndex;
    int strLen = str.length();
    String val = "";
    do {
      if(currentField==n) {
        thisIndex = str.indexOf(delimiter,lastIndex);
        if(thisIndex>=0){ return str.substring(lastIndex,thisIndex);}
        else { return str.substring(lastIndex,strLen); }
      } else {
        thisIndex = str.indexOf(delimiter,lastIndex);
        if(thisIndex<0) return "";
        else {
          currentField++;
          lastIndex=thisIndex+1;
        }
      }
    } while(lastIndex<strLen);
    return "";
  }

  public static final String[] split(String str, char ch) {
    if(str==null) return new String[0];
    int numFields = 1;
    int strLen = str.length();
    for(int i=0; i<strLen; i++) 
      if(str.charAt(i)==ch)
        numFields++;
    String result[] = new String[numFields];
    int strNum = 0;
    int idx = 0;
    for(int i=0; i<strLen; i++) {
      if(str.charAt(i)==ch) {
        result[strNum++] = str.substring(idx, i);
        idx = i+1;
      }
    }
    result[strNum] = str.substring(idx);
    return result;
  }

  /**
   * Return a copy of the given string with the characters in escChars
   * (and any backslashes) escaped with backslashes.  The unbackslash call
   * can be used to return the string to its original state.
   */
  public static final String backslash(String str, String escChars) {
    int len = str.length();
    int currPos = 0;
    StringBuffer sb = new StringBuffer(str.length());
    char ch;
    while(currPos<len) {
      ch = str.charAt(currPos);
      if(ch=='\\' || escChars.indexOf(ch)>=0) {
        sb.append('\\');
        sb.append(ch);
      } else {
        sb.append(ch);
      }
      currPos++;
    }
    return sb.toString();
  }
  
  /**
   * Return a copy of the given string with the characters in escChars
   * (and any backslashes) unescaped with backslashes.  This should perform 
   * the reverse of the backslash() call, given the same escChars 
   * parameter.
   */
  public static final String unbackslash(String str) {
    int len = str.length();
    int currPos = 0;
    char backslash = '\\';
    StringBuffer sb = new StringBuffer(str.length());
    while(currPos<len) {
      char ch = str.charAt(currPos++);
      if(ch==backslash && currPos<len) {
        sb.append(str.charAt(currPos++));  // ignore backslash, append char
      } else {
        sb.append(ch);
      }
    }
    return sb.toString();
  }
  
  public static final String decode(String str) {
    int len = str.length();
    int currPos = 0;
    StringBuffer sb = new StringBuffer(str.length());
    while(currPos<len) {
      char ch = str.charAt(currPos);
      if(ch=='\\') {
        currPos++;
        if(currPos>=len) {sb.append(ch); break;}
        ch = str.charAt(currPos);
        if(ch=='n') sb.append('\n');
        else if(ch=='t') sb.append('\t');
        else if(ch=='r') sb.append('\r');
        else sb.append(ch);
      } else {
        sb.append(ch);
      }
      currPos++;
    }
    return sb.toString();
  }


  /* Encode a string for storage... basically remove all tabs so that it
   * doesn't screw up our tab-delimited format */
  public static final String encode(String str)
  {
    StringBuffer sb = new StringBuffer("");
    for(int i=0;i<str.length();i++){
      char ch = str.charAt(i);
      switch(ch) {
        case '\t':
          sb.append("\\t");
          break;
        case '\n':
          sb.append("\\n");
          break;
        case '\r':
          sb.append("\\r");
          break;
        default:
          sb.append(ch);
      }
    }
    return sb.toString();
  }

  /** decodes the special characters in a URL encoded string *except* for
   * the + to space conversion. */
  public static String decodeURLIgnorePlus(String str) {
    byte utf8Buf[] = new byte[str.length()];
    int utf8Loc = 0;
    int strLoc = 0;
    int strLen = str.length();
    while(strLoc < strLen) {
      char ch = str.charAt(strLoc++);
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str.charAt(strLoc++),
                                           str.charAt(strLoc++));
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }

    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    }
  }
  
  /** decodes the special characters in a URL encoded string *except* for
   * the + to space conversion. */
  public static String decodeURLIgnorePlus(char str[], int start, int len) {
    byte utf8Buf[] = new byte[len];
    int utf8Loc = 0;
    int strLoc = start;
    int strLen = start+len;
    while(strLoc < strLen) {
      char ch = str[strLoc++];
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str[strLoc++],
                                           str[strLoc++]);
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }

    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    }
  }
  
  /** decodes the special characters in a URL encoded string. */
  public static String decodeURL(String str) {
    byte utf8Buf[] = new byte[str.length()];
    int utf8Loc = 0;
    int strLoc = 0;
    int strLen = str.length();
    while(strLoc < strLen) {
      char ch = str.charAt(strLoc++);
      if(ch=='%' && strLoc+2<=strLen) {
        utf8Buf[utf8Loc++] = decodeHexByte(str.charAt(strLoc++),
                                           str.charAt(strLoc++));
      } else if(ch=='+') {
        utf8Buf[utf8Loc++] = (byte)' ';
      } else {
        utf8Buf[utf8Loc++] = (byte)ch;
      }
    }

    try {
      return new String(utf8Buf, 0, utf8Loc, "UTF8");
    } catch (Exception e) {
      return new String(utf8Buf, 0, utf8Loc);
    } 
  }

  public static final byte decodeHexByte(char ch1, char ch2) {
    ch1 = (char) ((ch1>='0' && ch1<='9') ? ch1-'0' : ((ch1>='a' && ch1<='z') ? ch1-'a'+10 : ch1-'A'+10));
    ch2 = (char) ((ch2>='0' && ch2<='9') ? ch2-'0' : ((ch2>='a' && ch2<='z') ? ch2-'a'+10 : ch2-'A'+10));
    return (byte)(ch1<<4 | ch2);
  }

  private static final char hexByteMap[] = {'0','1','2','3','4','5','6','7','8',
                                            '9','A','B','C','D','E','F','G','H'};
  
  public static String encodeHexChar(byte b) {
    StringBuffer sb = new StringBuffer();
    sb.append(hexByteMap[(b&0xF0)>>4]);
    sb.append(hexByteMap[b&0x0F]);
    return sb.toString();
  }

  public static final String padr(String str, int n, char padchar) {
    StringBuffer sb = new StringBuffer(str);
    while(sb.length()<n) sb.append(padchar);
    return sb.toString();
  }

  public static final String padl(String str, int n, char padchar) {
    StringBuffer sb = new StringBuffer(str);
    while(sb.length()<n) sb.insert(0,padchar);
    return sb.toString();
  }

  public static final void sortStringArray(String array[])
  {
    quicksortAscending(array,0,array.length-1);
  }
  
  private static final void quicksortAscending(String array[], int first,
                                               int last )
  {
    int piv_index;
    if ( first < last ) { 
      piv_index = partitionAscending( array, first, last );
      quicksortAscending( array, first, piv_index - 1 );
      quicksortAscending( array, piv_index, last );
    }
  }
  
  private static final int partitionAscending( String array[], int first, 
                                               int last )
  {
    String pivot, temp, temp2;
    pivot = array[ (first + last) / 2 ];
    while ( first <= last ) {
      while ( array[first].compareTo(pivot) < 0 )
        ++first;
      
      while ( array[last].compareTo(pivot) > 0 )
        --last;
      
      if ( first <= last ) {
        temp = array[first];
        array[first] = array[last];
        array[last] = temp;
        ++first;  
        --last;
      }
    }
    return (first);
  }
}
