/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

package net.handle.util;

import java.util.*;
import java.io.*;

/*************************************************************
 * Class that can represent HTTP cookies that are received
 * with an HTTP request.
 *************************************************************/
public class HTTPCookie {
  private Hashtable cookies = new Hashtable();

  public boolean containsCookie(String cookie) {
    return cookies.containsKey(cookie);
  }

  public String getCookieVal(String cookie) {
    Cookie c = (Cookie)cookies.get(cookie);
    if(c==null)
      return null;
    return c.value;
  }
  
  public void clear() {
    cookies.clear();
  }

  public void parseRequestHeader(String cookieHdr) {
    PushbackReader rdr = new PushbackReader(new StringReader(cookieHdr));
    try {
      while(true) {
        KeyValuePair kvp = readPair(rdr);
        if(kvp==null)
          return;
        cookies.put(kvp.key, new Cookie(kvp.key, kvp.val));
      }
    } catch (Exception e) {
      System.err.println("Error parsing cookie: "+e);
      e.printStackTrace(System.err);
    }
  }

  private final void encodeString(String val, StringBuffer sb) {
    sb.append('"');
    if(val!=null) {
      for(int i=0; i<val.length(); i++) {
        char ch = val.charAt(i);
        switch(ch) {
          case '"':
            sb.append("\\\"");
            break;
          case '\n':
            sb.append("\\n");
            break;
          case '\r':
            sb.append("\\r");
            break;
          case '\t':
            sb.append("\\t");
            break;
          default:
            sb.append(ch);
        }
      }
    }
    sb.append('"');
  }
  
  private KeyValuePair readPair(PushbackReader rdr)
    throws IOException
  {
    String nm = readToken(rdr);
    if(nm==null)
      return null;
    String equalsSign = readToken(rdr);
    if(equalsSign==null)
      return new KeyValuePair(nm, null);
    if(!equalsSign.equals("="))
      return new KeyValuePair(nm, equalsSign);
    String val = readToken(rdr);
    return new KeyValuePair(nm, val);
  }
  
  private final static String readToken(PushbackReader rdr)
    throws IOException
  {
    StringBuffer sb = new StringBuffer();
    int ich = ' ';
    // read any leading whitespace...
    while(ich>=0 && Character.isWhitespace((char)ich))
      ich = rdr.read();

    if(ich<0) // got eof, and no tokens
      return null;

    // put back the first non-whitespace character that we read
    rdr.unread(ich);
    
    while(true) {
      ich = rdr.read();
      if(ich<0) { // got eof
        if(sb.length()>0) {
          return sb.toString();
        } else {
          return null;
        }
      }
      switch(ich) {
        case ';':
          if(sb.length()>0) {
            return sb.toString();
          } else {
            return String.valueOf((char)ich);
          }
        case '=':
          if(sb.length()>0) {
            rdr.unread(ich);
            return sb.toString();
          } else {
            return String.valueOf((char)ich);
          }
        case '"':
          if(sb.length()>0) {
            return sb.toString();
          } else {
            return readRestOfString(rdr);
          }
        default:
          if(Character.isWhitespace((char)ich)) // end of token
            return sb.toString();
          sb.append((char)ich);
      }
    }
  }

  private static final String readRestOfString(PushbackReader rdr)
    throws IOException
  {
    int ich;
    StringBuffer sb = new StringBuffer();
    while(true) {
      ich = rdr.read();
      if(ich<0)
        return sb.toString();
      switch(ich) {
        case '\\':  // there is some escaped character...
          ich = rdr.read();
          if(ich<0)
            return sb.toString();
          switch(ich) {
            case 'n':
              sb.append('\n');
              break;
            case 't':
              sb.append('\t');
              break;
            case 'r':
              sb.append('\r');
              break;
            default:
              sb.append((char)ich);
          }
          break;
        case '"':
          return sb.toString();
        default:
          sb.append((char)ich);
      }
    }
  }

  private class Cookie {
    String name = null;
    String value = null;
    String domain = null;
    Date expires = null;

    Cookie(String nm, String val) {
      this.name = nm;
      this.value = val;
    }
  }

  private class KeyValuePair {
    String key = "";
    String val = "";
    KeyValuePair(String k, String v) {
      this.key = k;
      this.val = v;
    }
    public String toString() {
      return key+"="+val;
    }
  }
}
