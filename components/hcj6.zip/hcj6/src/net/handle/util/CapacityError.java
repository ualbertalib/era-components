/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/
/**
 *  Error raised when a StringMap or StringSet can't be enlarged any
 *  further.
 *
 *  developer     Fred L. Drake, Jr.
 *  @version    $Revision: 1.9 $
 **/

/**
 *  Error raised when a StringMap or StringSet can't be enlarged any
 *  further.
 *
 *  developer     Fred L. Drake, Jr.
 *  @version    $Revision: 1.9 $
 **/

package net.handle.util;

public class CapacityError extends Error
{
    /** Requested size for expansion. */
    public int size;

    /**
     *  Initialize a CapacityException with a specific capacity
     *  which was attempted but could not be met.
     *
     *  @param  capacity   number of slots that needed to be allocated
     *  @param  classname  name of the class being expanded
     **/
    protected CapacityError(int capacity, String classname)
    {
        super("can't make " + classname + " of size " + capacity);
        this.size = capacity;
    }
}
