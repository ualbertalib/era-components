/**********************************************************************\
 � COPYRIGHT 2007 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
         Handle System Public License, which may be obtained at
         http://hdl.handle.net/4263537/5030 or hdl:4263537/5030
\**********************************************************************/

/**
 *
 * Table that never exceeds a maximum number of elements.  Uses a Least
 * Recently Used(LRU) replacement strategy.
 *
 * Adding, removing, getting, and contains key all have an additional
 * overhead of O(lg(n))
 * 
 * 
 **/

package net.handle.util;

import java.util.Hashtable;
import java.util.TreeSet;
import java.util.Comparator;

public class LRUCacheTable extends Hashtable {
  
  private int maxsize;
  private TreeSet lru;

  class Entry {
    long atime;
    Object key;
    Object val;
  }

  public LRUCacheTable(int maxsize){
    super(maxsize);
    this.maxsize = maxsize;
    
    lru = new TreeSet(new Comparator(){
        public int compare(Object o1, Object o2){
          return (int)(((Entry)o1).atime - ((Entry)o2).atime);
        }
        public boolean equals(Object o1, Object o2){
          return compare(o1, o2) == 0;
        }
    });
  }

  public int getSize(){
    return maxsize;
  }

  public void setSize(int newsize){
    maxsize = newsize;
  }

  public synchronized Object put(Object key, Object val){
    Entry oldentry = (Entry)super.get(key);
    Entry newentry = new Entry();
    newentry.key = key;
    newentry.val = val;
    newentry.atime = System.currentTimeMillis();
    super.put(key, newentry);

    if (oldentry != null) lru.remove(oldentry);
    lru.add(newentry);
    evict();

    if (oldentry == null) return null;
    else return oldentry.val;
  }

  private synchronized void evict(){
    while (size() > maxsize){ 
      Entry e = (Entry)lru.first();
      remove(e.key);
      lru.remove(e);
    }
  }

  /**
   * Returns key of least recently used object
   **/
  public synchronized Object getLruKey(){
    Entry e = (Entry)lru.first();
    return e.key;
  }
  
  public synchronized Object get(Object key){
    Entry entry = (Entry)super.get(key);
    if (entry == null) return null;
    lru.remove(entry);
    entry.atime = System.currentTimeMillis();
    lru.add(entry);
    return entry.val;
  }
  
}

/**
TESTING CODE

from net.cnri.tools.cache import *
map = LRUCacheTable(3)
map.put('a', 'a')
map.put('b', 'a')
map.put('c', 'a')
map.put('d', 'a')

assert map.get('a') == None
assert map.get('b') != None
map.put('e', 'f')
assert map.get('b') != None

map.put('d', 'a')
map.put('f', 'a')
assert map.get('d') != None

**/
